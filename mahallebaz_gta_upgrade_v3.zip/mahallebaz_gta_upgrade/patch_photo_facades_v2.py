# -*- coding: utf-8 -*-
"""Photo facades v2 — full cover:
- world3d.js: replace facade utils with box-cover system (per-face center-crop,
  photo-average tint walls, night emissive), body uses material array, dome kept
  for dome-kind photo buildings, remove old plane plates
- world-data.js: img for ALL non-park buildings
- index.html: world3d -> v59
"""
import io
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz"
WD = BASE + r"\js\world-data.js"
W3 = BASE + r"\js\world3d.js"
IX = BASE + r"\index.html"

fail = []
def sub1(s, old, new, tag):
    if s.count(old) != 1:
        fail.append("%s (count=%d)" % (tag, s.count(old)))
        return s
    print("OK  " + tag)
    return s.replace(old, new, 1)

# ---------------- world3d.js ----------------
s = open(W3, encoding="utf-8", newline="").read()

i0 = s.find("// ===== نماهای عکس")
i1 = s.find("const WIN_GEO")
assert i0 >= 0 and i1 > i0, "facade block not found"

NEW_BLOCK = """// ===== نماهای عکس‌دار واقعی: کل بدنهٔ ساختمان با تکسچر عکس پوشانده می‌شود =====
  const _facadeTex = {}, _facadeCbs = {};
  function facadeTex(url, cfg) {
    if (!_facadeCbs[url]) {
      _facadeCbs[url] = [];
      _facadeTex[url] = new THREE.TextureLoader().load(url, t => {
        if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = 4;
        for (const cb of _facadeCbs[url]) cb(t);
        _measureFacadeAvg(url, t.image);
      });
    }
    _facadeCbs[url].push(cfg);
    return _facadeTex[url];
  }
  // میانگین رنگ عکس → دیوارهای کناری هم‌رنگ خود عکس می‌شوند
  const _facadeAvg = {}, _tintMats = {};
  function _measureFacadeAvg(url, img) {
    try {
      const c = document.createElement('canvas');
      c.width = c.height = 48;
      const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(img, 0, 0, 48, 48);
      const d = x.getImageData(0, 0, 48, 48).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) continue;
        r += d[i]; g += d[i + 1]; b += d[i + 2]; n++;
      }
      if (!n) return;
      const hex = (((r / n) << 16) | ((g / n) << 8) | (b / n)) & 0xffffff;
      _facadeAvg[url] = hex;
      for (const m of (_tintMats[url] || [])) m._setTint(hex);
    } catch (e) { /* ignore */ }
  }
  const _tintCache = {};
  function tintMat(hex) {
    if (_tintCache[hex]) return _tintCache[hex];
    const m = new THREE.MeshStandardMaterial({ color: hex, roughness: .88, metalness: 0 });
    m._setTint = h => m.color.setHex(h);
    _tintCache[hex] = m;
    return m;
  }
  function _shadeHex(hex, k) {
    const r = Math.min(255, ((hex >> 16 & 255) * k) | 0),
          g = Math.min(255, ((hex >> 8 & 255) * k) | 0),
          b = Math.min(255, ((hex & 255) * k) | 0);
    return ((r << 16) | (g << 8) | b) >>> 0;
  }
  // هر وجه: برش مرکزیِ عکس به نسبت ابعاد همان وجه — بدون کشیدگی
  const _faceMatCache = {};
  function facadeFaceMat(url, faceAR) {
    const key = url + '@' + faceAR.toFixed(2);
    if (_faceMatCache[key]) return _faceMatCache[key];
    const m = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: .82, metalness: 0,
      emissive: 0xffc46b, emissiveIntensity: 0,
    });
    const apply = src => {
      const t = src.clone();
      t.needsUpdate = true;
      if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
      const ia = src.image.width / src.image.height;
      const rx = Math.min(1, ia / faceAR), ry = Math.min(1, faceAR / ia);
      t.repeat.set(rx, ry);
      t.offset.set((1 - rx) / 2, (1 - ry) / 2);
      t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
      m.map = t; m.emissiveMap = t; m.needsUpdate = true;
    };
    const base = facadeTex(url, apply);
    if (base.image && base.image.width) apply(base);
    _faceMatCache[key] = m;
    return m;
  }
  const _photoNightMats = [];
  function coverBoxMats(b) {
    const hex0 = _facadeAvg[b.img] || b.color;
    const tint = tintMat(hex0), dark = tintMat(_shadeHex(hex0, .7));
    const list = _tintMats[b.img] || (_tintMats[b.img] = []);
    list.push(tint, dark);
    const front = facadeFaceMat(b.img, b.w / b.h);
    const sideF = facadeFaceMat(b.img, b.d / b.h);
    _photoNightMats.push(front, sideF);
    // ترتیب متریال BoxGeometry: +x -x +y -y +z(جلو) -z(پشت)
    return [tint, tint, dark, dark, front, sideF];
  }
  function _applyPhotoFacadeNight(daylight) {
    const glow = Math.max(0, 1 - daylight * 2.2) * .55;
    for (const m of _photoNightMats) m.emissiveIntensity = glow;
  }
  """
s = s[:i0] + NEW_BLOCK + s[i1:]

# بدنه: متریال آرایهٔ عکس‌دار
s = sub1(s,
    "const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), wallMat(b.color, b.w, b.d, b.h));",
    "const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), b.img ? coverBoxMats(b) : wallMat(b.color, b.w, b.d, b.h));",
    "body material array")

# پلن‌های قدیمی حذف (کل بدنه عکس شد)
s = sub1(s, "\n      applyPhotoFacade(b, g);", "", "remove plate call")

# گنبد برای ساختمان‌های عکس‌دارِ dome حفظ شود
s = sub1(s,
    "      } else { // flat\n        const edge = new THREE.Mesh(new THREE.BoxGeometry(b.w + .5, .5, b.d + .5), mat(0x333333));\n        edge.position.y = b.h + .25;\n        g.add(edge);\n      }",
    "      } else { // flat\n        const edge = new THREE.Mesh(new THREE.BoxGeometry(b.w + .5, .5, b.d + .5), mat(0x333333));\n        edge.position.y = b.h + .25;\n        g.add(edge);\n      }\n      if (_photoMode && b.kind === 'dome') {   // گنبد بالای نمای عکس‌دار حفظ شود\n        const dome2 = new THREE.Mesh(new THREE.SphereGeometry(Math.min(b.w, b.d)/2.4, 14, 10, 0, Math.PI*2, 0, Math.PI/2), mat(0xd4af37));\n        dome2.position.y = b.h; dome2.castShadow = true;\n        g.add(dome2);\n      }",
    "dome kept for photo buildings")

open(W3, "w", encoding="utf-8", newline="").write(s)

# ---------------- world-data.js ----------------
ALL_IMG = {
    'home': 'home_red', 'realty': 'home_red', 'market': 'home_red', 'bakery': 'home_red',
    'cafe': 'home_red', 'restaurant': 'home_red', 'bank': 'classic', 'mobile': 'modern',
    'hospital': 'apartment_glass', 'clothes': 'home_red', 'university': 'classic',
    'gym': 'modern', 'dealership': 'office_curved', 'repair': 'modern', 'airport': 'office_curved',
    'terminal': 'apartment_glass', 'flower': 'home_red', 'pastry': 'home_red', 'juice': 'home_red',
    'apartment1': 'apartment_glass', 'book': 'home_red', 'gamenet': 'modern', 'salon': 'home_red',
    'mosque': 'classic', 'policeStation': 'modern', 'robotics': 'modern', 'dairy': 'home_red',
    'mansion': 'classic',
    'deco1': 'apartment_brick', 'deco2': 'apartment_glass', 'deco3': 'cylinder_tower',
    'deco4': 'modern', 'deco5': 'tower_dark', 'deco6': 'apartment_brick', 'deco7': 'apartment_glass',
    'deco8': 'office_curved', 'deco9': 'cylinder_tower', 'deco10': 'tower_dark',
    'deco11': 'apartment_brick', 'deco12': 'office_curved', 'deco13': 'cylinder_tower',
    'deco14': 'home_red', 'deco15': 'tower_dark', 'deco16': 'apartment_brick',
    'deco17': 'apartment_glass', 'deco18': 'tower_dark',
}
s = open(WD, encoding="utf-8", newline="").read()
lines = s.split("\r\n") if "\r\n" in s else s.split("\n")
sep = "\r\n" if "\r\n" in s else "\n"
hit, upd = set(), set()
for i, ln in enumerate(lines):
    m = re.search(r"id:'([A-Za-z0-9_]+)',", ln)
    if not m or m.group(1) not in ALL_IMG:
        continue
    bid = m.group(1)
    url = "assets/buildings/%s.png" % ALL_IMG[bid]
    if "img:" in ln:
        lines[i] = re.sub(r"img:'[^']*'", "img:'%s'" % url, ln)
        upd.add(bid)
        continue
    ln2, n = re.subn(r"(color:0x[0-9a-fA-F]+,)", lambda mm: mm.group(1) + " img:'%s'," % url, ln, count=1)
    if n != 1:
        fail.append("world-data %s: color anchor" % bid)
        continue
    lines[i] = ln2
    hit.add(bid)
missing = set(ALL_IMG) - hit - upd
if missing:
    fail.append("world-data ids not found: %s" % sorted(missing))
s = sep.join(lines)
if "window.BUILDINGS" not in s:
    s += "\nwindow.BUILDINGS = BUILDINGS;   // دسترسی دیباگ/تست\n"
open(WD, "w", encoding="utf-8", newline="").write(s)
print("world-data: %d new + %d updated (target %d)" % (len(hit), len(upd), len(ALL_IMG)))

# ---------------- index.html ----------------
s = open(IX, encoding="utf-8", newline="").read()
s = sub1(s, "js/world3d.js?v=58", "js/world3d.js?v=59", "bump world3d v59")
open(IX, "w", encoding="utf-8", newline="").write(s)

print("\n" + ("ALL PATCHES OK" if not fail else "FAILURES:\n  " + "\n  ".join(fail)))
sys.exit(1 if fail else 0)
