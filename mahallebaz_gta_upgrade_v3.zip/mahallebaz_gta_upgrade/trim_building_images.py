# -*- coding: utf-8 -*-
import os
import numpy as np
from PIL import Image

DST = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz\assets\buildings"
for fn in sorted(os.listdir(DST)):
    if not fn.endswith(".png"):
        continue
    p = os.path.join(DST, fn)
    im = Image.open(p).convert("RGBA")
    a = np.asarray(im)[:, :, 3]
    ys, xs = np.where(a > 16)
    if not len(xs):
        print(fn, "EMPTY!"); continue
    m = 3
    box = (max(0, xs.min()-m), max(0, ys.min()-m),
           min(im.width, xs.max()+1+m), min(im.height, ys.max()+1+m))
    out = im.crop(box)
    out.save(p)
    print("%-22s %s -> %s" % (fn, im.size, out.size))
