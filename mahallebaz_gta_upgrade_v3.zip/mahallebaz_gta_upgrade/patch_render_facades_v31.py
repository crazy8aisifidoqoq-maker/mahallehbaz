# -*- coding: utf-8 -*-
"""Render facades v3.1 — کامل‌تر و تمیزتر:
- پد تخت هم‌رنگ رندر به‌جای جعبهٔ تیرهٔ بزرگ
- مقیاس: رندر کل زمین را پر می‌کند ولی از پیاده‌رو خیلی بیرون نمی‌زند
- سه صفحهٔ ضربدری (0/60/120°) → سیلوئت کامل از هر زاویه
- آستانهٔ آلفا نرم‌تر برای لبه‌های تمیز
- world3d → v61
"""
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz"
W3 = BASE + r"\js\world3d.js"
IX = BASE + r"\index.html"

fail = []
def sub1(s, old, new, tag):
    if s.count(old) != 1:
        fail.append("%s (count=%d)" % (tag, s.count(old)))
        return s
    print("OK  " + tag)
    return s.replace(old, new, 1)

s = open(W3, encoding="utf-8", newline="").read()

i0 = s.find("// ===== ساختمان‌های رندری")
i1 = s.find("const WIN_GEO")
assert i0 >= 0 and i1 > i0, "v3 facade block not found"

NEW_BLOCK = """// ===== ساختمان‌های رندری: رندر سه‌رخ روی صفحات ضربدری + پد تخت =====
  const _facadeTex = {}, _facadeCbs = {};
  function facadeTex(url, cb) {
    if (!_facadeCbs[url]) {
      _facadeCbs[url] = [];
      _facadeTex[url] = new THREE.TextureLoader().load(url, t => {
        if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = 4;
        t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
        _measureFacadeAvg(url, t.image);
        for (const cb2 of _facadeCbs[url]) cb2(t);
      });
    }
    _facadeCbs[url].push(cb);
    return _facadeTex[url];
  }
  // میانگین رنگ رندر → پد زیر ساختمان هم‌رنگ خودش می‌شود
  const _facadeAvg = {}, _tintMats = {};
  function _measureFacadeAvg(url, img) {
    try {
      const c = document.createElement('canvas');
      c.width = c.height = 48;
      const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(img, 0, 0, 48, 48);
      const d = x.getImageData(0, 0, 48, 48).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) continue;
        r += d[i]; g += d[i + 1]; b += d[i + 2]; n++;
      }
      if (!n) return;
      const hex = (((r / n) << 16) | ((g / n) << 8) | (b / n)) & 0xffffff;
      _facadeAvg[url] = hex;
      for (const m of (_tintMats[url] || [])) m._setTint(hex);
    } catch (e) { /* ignore */ }
  }
  const _tintCache = {};
  function tintMat(hex) {
    if (_tintCache[hex]) return _tintCache[hex];
    const m = new THREE.MeshStandardMaterial({ color: hex, roughness: .9, metalness: 0 });
    m._setTint = h => m.color.setHex(h);
    _tintCache[hex] = m;
    return m;
  }
  function _shadeHex(hex, k) {
    const r = Math.min(255, ((hex >> 16 & 255) * k) | 0),
          g = Math.min(255, ((hex >> 8 & 255) * k) | 0),
          b = Math.min(255, ((hex & 255) * k) | 0);
    return ((r << 16) | (g << 8) | b) >>> 0;
  }
  const _renderNightMats = [];
  function buildRenderVisual(b, g, body) {
    body.visible = false;            // بدنهٔ توپر پنهان؛ فقط برای برخورد/دوربین می‌ماند
    body.castShadow = false;
    const hex0 = _facadeAvg[b.img] || b.color;
    // پد تخت مثل میدان‌جلوی ساختمان — نه جعبهٔ بلند
    const padMat = tintMat(_shadeHex(hex0, .55));
    (_tintMats[b.img] || (_tintMats[b.img] = [])).push(padMat);
    const padR = Math.max(b.w, b.d) * .62;
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(padR, padR * 1.04, .16, 20), padMat);
    pad.position.y = .08;
    pad.receiveShadow = true;
    g.add(pad);
    // رندر روی سه صفحهٔ ضربدری → حجم کامل از هر زاویه
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: .8, metalness: 0,
      alphaTest: .3, side: THREE.DoubleSide,
      emissive: 0xffc46b, emissiveIntensity: 0,
    });
    _renderNightMats.push(mat);
    const geo = new THREE.PlaneGeometry(1, 1);
    const planes = [];
    for (const rot of [0, Math.PI / 3, Math.PI * 2 / 3]) {
      const p = new THREE.Mesh(geo, mat);
      p.rotation.y = rot;
      g.add(p);
      planes.push(p);
    }
    const fit = img => {
      const imgAR = img.width / img.height;
      const maxW = Math.min(Math.max(b.w, b.d) * 1.45, Math.min(b.w, b.d) * 1.6 + 6);
      const ph = Math.min(b.h * 1.3, maxW / imgAR);
      const pw = ph * imgAR;
      for (const p of planes) {
        p.scale.set(pw, ph, 1);      // کشیدگی در فضای خودِ صفحه، نه بعد از چرخش
        p.position.y = ph / 2 + .1;  // روی زمین می‌ایستد
      }
    };
    facadeTex(b.img, t => {
      mat.map = t; mat.emissiveMap = t; mat.needsUpdate = true;
      if (t.image && t.image.width) fit(t.image);
    });
  }
  function _applyPhotoFacadeNight(daylight) {
    const glow = Math.max(0, 1 - daylight * 2.2) * .55;   // پنجره‌ها شب روشن
    for (const m of _renderNightMats) m.emissiveIntensity = glow;
  }
  """
s = s[:i0] + NEW_BLOCK + s[i1:]

open(W3, "w", encoding="utf-8", newline="").write(s)

s = open(IX, encoding="utf-8", newline="").read()
s = sub1(s, "js/world3d.js?v=60", "js/world3d.js?v=61", "bump world3d v61")
open(IX, "w", encoding="utf-8", newline="").write(s)

print("\n" + ("ALL PATCHES OK" if not fail else "FAILURES:\n  " + "\n  ".join(fail)))
sys.exit(1 if fail else 0)
