# -*- coding: utf-8 -*-
import os
from PIL import Image, ImageDraw

DST = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz\assets\buildings"
OUT = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\contact_sheet.png"
files = [f for f in sorted(os.listdir(DST)) if f.endswith(".png")]
CELL = 240
cols = 4
rows = (len(files) + cols - 1) // cols
sheet = Image.new("RGB", (cols*CELL, rows*(CELL+22)), (255, 0, 255))
d = ImageDraw.Draw(sheet)
for i, fn in enumerate(files):
    im = Image.open(os.path.join(DST, fn)).convert("RGBA")
    im.thumbnail((CELL-12, CELL-12))
    x = (i % cols) * CELL; y = (i // cols) * (CELL+22)
    sheet.paste(im, (x + (CELL-im.width)//2, y + (CELL-im.height)//2), im)
    d.text((x+6, y+CELL+4), fn, fill=(255,255,0))
sheet.save(OUT)
print(OUT)
