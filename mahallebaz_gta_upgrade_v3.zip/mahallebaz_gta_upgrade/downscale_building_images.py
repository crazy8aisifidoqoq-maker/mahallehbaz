# -*- coding: utf-8 -*-
"""Downscale the 8 building PNGs (already de-checkered/cropped) to game size."""
import os
from PIL import Image

DST = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz\assets\buildings"
MAXW = 480
for fn in sorted(os.listdir(DST)):
    if not fn.endswith(".png"):
        continue
    p = os.path.join(DST, fn)
    im = Image.open(p)
    ow, oh = im.size
    if im.width > MAXW:
        im = im.resize((MAXW, max(1, round(im.height * MAXW / im.width))), Image.LANCZOS)
        im.save(p)
    print("%-22s %s -> %s" % (fn, (ow, oh), im.size))
