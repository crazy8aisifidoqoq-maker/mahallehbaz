# -*- coding: utf-8 -*-
"""Prep building photos (v4): checker texture-signature masking.
A pixel is background only if it matches a checker shade AND both checker shades
appear in its neighbourhood (the alternating-texture signature), then flood from
borders. Building whites have uniform neighbourhoods -> protected."""
import os
import numpy as np
from PIL import Image, ImageFilter

SRC = r"C:\Users\USER\Downloads"
DST = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz\assets\buildings"
os.makedirs(DST, exist_ok=True)

JOBS = [
    ("images.jpg",     "classic.png",         "checker", None),
    ("images (1).jpg", "modern.png",          "sky",     0.84),
    ("images (2).jpg", "apartment_brick.png", "sky",     None),
    ("images (3).jpg", "apartment_glass.png", "checker", None),
    ("images (4).jpg", "tower_dark.png",      "checker", None),
    ("images (5).jpg", "office_curved.png",   "checker", None),
    ("images (6).jpg", "cylinder_tower.png",  "checker", None),
    ("images (7).jpg", "home_red.png",        "checker", None),
]

def grow(mask, allow, max_iter=9000):
    m = mask.copy()
    for _ in range(max_iter):
        nb = np.zeros_like(m)
        nb[1:, :] |= m[:-1, :]; nb[:-1, :] |= m[1:, :]
        nb[:, 1:] |= m[:, :-1]; nb[:, :-1] |= m[:, 1:]
        add = nb & allow & (~m)
        if not add.any():
            break
        m |= add
    return m

def dilate8(m, it=1):
    for _ in range(it):
        nb = np.zeros_like(m)
        nb[1:, :] |= m[:-1, :]; nb[:-1, :] |= m[1:, :]
        nb[:, 1:] |= m[:, :-1]; nb[:, :-1] |= m[:, 1:]
        nb[1:, 1:] |= m[:-1, :-1]; nb[:-1, :-1] |= m[1:, 1:]
        nb[1:, :-1] |= m[:-1, 1:]; nb[:-1, 1:] |= m[1:, :-1]
        m = m | nb
    return m

def hole_fill(opaque):
    h, w = opaque.shape
    border = np.zeros_like(opaque)
    border[0, :] = True; border[h-1, :] = True; border[:, 0] = True; border[:, w-1] = True
    outside = grow(border, ~opaque)
    return opaque | (~outside)

def border_shades(img):
    """Two dominant shades from the 8px border ring via histogram peaks."""
    a = np.asarray(img).astype(np.float32)
    ring = np.concatenate([
        a[:8].reshape(-1, 3), a[-8:].reshape(-1, 3),
        a[:, :8].reshape(-1, 3), a[:, -8:].reshape(-1, 3)])
    lum = ring.mean(1)
    lum = lum[lum > 100]
    if lum.size < 40:
        return 190.0, 240.0
    hist, edges = np.histogram(lum, bins=39, range=(100, 256))  # 4-lum bins
    k = np.convolve(hist, [1, 2, 3, 2, 1], "same")
    order = np.argsort(k)[::-1]
    p1 = order[0]
    p2 = None
    for cand in order[1:]:
        if abs(cand - p1) >= 6 and k[cand] > k[p1] * 0.15:  # >=24 luminance apart
            p2 = cand
            break
    if p2 is None:
        p2 = p1
    v1 = 100 + (p1 + 0.5) * 4
    v2 = 100 + (p2 + 0.5) * 4
    return (min(v1, v2), max(v1, v2))

def process_checker(img):
    L1, L2 = border_shades(img)
    med = img.filter(ImageFilter.MedianFilter(3))
    a = np.asarray(med).astype(np.float32)
    sat = a.max(2) - a.min(2)
    bright = a.mean(2)
    blue = a[:, :, 2] - a[:, :, 0]
    near1 = np.abs(bright - L1) < 18
    near2 = np.abs(bright - L2) < 18
    neutral = (sat < 34) & (blue < 20) & (bright > 105)
    ctx = dilate8(near1, 5) & dilate8(near2, 5)     # alternating-texture signature
    bgish = (near1 | near2) & neutral & ctx
    h, w = bgish.shape
    seed = np.zeros_like(bgish)
    seed[0, :] = True; seed[h-1, :] = True; seed[:, 0] = True; seed[:, w-1] = True
    mask = grow(seed & bgish, bgish)
    near_any = near1 | near2
    near_ctx = dilate8(near_any, 6)   # a real checker shade lives nearby
    for _ in range(24):   # greedy: eat mottled checker mixed into soft shadows
        nb = np.zeros_like(mask)
        nb[1:, :] |= mask[:-1, :]; nb[:-1, :] |= mask[1:, :]
        nb[:, 1:] |= mask[:, :-1]; nb[:, :-1] |= mask[:, 1:]
        add = (nb & (near_any | ((sat < 38) & (bright > 140)))
               & (sat < 38) & (blue < 16) & (bright > 130) & near_ctx & (~mask))
        if not add.any():
            break
        mask |= add
    # shadowed checker (checker seen through arch openings, in shade)
    S1, S2 = max(105, L1 - 42), max(105, L1 - 84)
    near_shadow = (np.abs(bright - S1) < 22) | (np.abs(bright - S2) < 22)
    shadow_allow = near_shadow & (sat < 26) & (blue < 12) & (bright > 108)
    for _ in range(30):
        shadow_ctx = dilate8(mask, 6)      # re-grow context as mask advances
        nb = np.zeros_like(mask)
        nb[1:, :] |= mask[:-1, :]; nb[:-1, :] |= mask[1:, :]
        nb[:, 1:] |= mask[:, :-1]; nb[:, :-1] |= mask[:, 1:]
        add = nb & shadow_allow & shadow_ctx & (~mask)
        if not add.any():
            break
        mask |= add
    opaque = hole_fill(~mask)
    alpha = (opaque * 255).astype(np.uint8)
    return Image.fromarray(np.dstack([np.asarray(img).astype(np.uint8), alpha]), "RGBA")

def process_sky(img, crop_bottom=None):
    a = np.asarray(img.convert("RGB")).astype(np.float32)
    r = a[:, :, 0]; b = a[:, :, 2]
    sat = a.max(2) - a.min(2)
    bright = a.mean(2)
    skyish = (b > r + 8) | ((sat < 30) & (bright > 195))
    h, w = skyish.shape
    seed = np.zeros_like(skyish)
    seed[0, :] = True
    side = int(h * 0.55)
    seed[:side, 0] = True; seed[:side, w-1] = True
    mask = grow(seed & skyish, skyish)
    alpha = np.where(mask, 0, 255).astype(np.uint8)
    y2lim = h
    if crop_bottom:
        y2lim = int(h * crop_bottom)
        alpha[y2lim:, :] = 255
    out = Image.fromarray(np.dstack([np.asarray(img.convert("RGB")).astype(np.uint8), alpha]), "RGBA")
    ys, xs = np.where(alpha > 10)
    if len(xs):
        m = 4
        out = out.crop((max(0, xs.min()-m), max(0, ys.min()-m),
                        min(w, xs.max()+1+m), min(y2lim, ys.max()+1+m)))
    return out

for old in os.listdir(DST):
    if old.endswith(".png"):
        os.remove(os.path.join(DST, old))

for src, out, mode, crop in JOBS:
    img = Image.open(os.path.join(SRC, src)).convert("RGB")
    if mode == "checker":
        sh = border_shades(img)
        res = process_checker(img)
        cov = (np.asarray(res)[:, :, 3] > 128).mean()
        print("%-16s -> %-22s %sx%s  content=%.0f%%  shades=(%.0f,%.0f)"
              % (src, out, res.width, res.height, cov*100, sh[0], sh[1]))
    else:
        res = process_sky(img, crop)
        cov = (np.asarray(res)[:, :, 3] > 128).mean()
        print("%-16s -> %-22s %sx%s  content=%.0f%%" % (src, out, res.width, res.height, cov*100))
    al = res.getchannel("A").filter(ImageFilter.GaussianBlur(0.8))
    res.putalpha(al)
    res.save(os.path.join(DST, out))
print("DONE")
