# -*- coding: utf-8 -*-
import io

P = 'world3d.js'
s = io.open(P, encoding='utf-8').read()
orig_len = len(s)
edits = []
MISS = []

def rep(name, old, new):
    global s
    if old not in s:
        MISS.append(name)
        return
    s = s.replace(old, new, 1)
    edits.append(name)

# ---------- 1) fog + exposure ----------
rep('fog-far', """  scene.fog = new THREE.Fog(0x87ceeb, 80, 220);""",
             """  scene.fog = new THREE.Fog(0x87ceeb, 80, 260);""")

rep('exposure', """  renderer.shadowMap.type = THREE.PCFSoftShadowMap; // سایه نرم
""",
"""  renderer.shadowMap.type = THREE.PCFSoftShadowMap; // سایه نرم
  if (renderer.toneMappingExposure !== undefined) renderer.toneMappingExposure = 1.12;
""")

# ---------- 2) light rig via cine3d ----------
rep('light-rig', """  const sun = new THREE.DirectionalLight(0xfff2d0, 2.2);
  sun.position.set(40, 70, 30);
  sun.castShadow = true;
  sun.shadow.mapSize.set(_lowEnd ? 1024 : 2048, _lowEnd ? 1024 : 2048);
  sun.shadow.bias = -.0004;
  Object.assign(sun.shadow.camera, { left:-100, right:100, top:100, bottom:-100 });
  scene.add(sun);
  const amb = new THREE.AmbientLight(0xbbccff, .55);
  scene.add(amb);
  // نور پرکننده‌ی ملایم از جهت مخالف خورشید تا سایه‌های کاملاً سیاه روی مدل‌ها نباشه (حس عمق بیشتر)
  const fill = new THREE.DirectionalLight(0xaebfe0, .35);
  fill.position.set(-30, 25, -40);
  scene.add(fill);
""",
"""  // ===== ریگ نور سینمایی (cine3d): خورشید/ماه/همی/برنس — جایگزین نورهای قدیمی =====
  const cine = window.CINE3D ? window.CINE3D(scene, renderer, camera) : null;
  const sun = cine ? cine.state.lights.sun : (() => {
    const s0 = new THREE.DirectionalLight(0xfff2d0, 2.2);
    s0.position.set(40, 70, 30); s0.castShadow = true;
    Object.assign(s0.shadow.camera, { left:-100, right:100, top:100, bottom:-100 });
    scene.add(s0); return s0;
  })();
  const amb = cine ? cine.state.lights.hemi : (() => {
    const a0 = new THREE.AmbientLight(0xbbccff, .55); scene.add(a0); return a0;
  })();
  const fill = cine ? cine.state.lights.bounce : (() => {
    const f0 = new THREE.DirectionalLight(0xaebfe0, .35);
    f0.position.set(-30, 25, -40); scene.add(f0); return f0;
  })();
  if (cine) { cine.setMode(G.settings.quality === 'mid' ? 'mid' : G.settings.quality === 'low' ? 'low' : 'high'); }
""")

# ---------- 3) asphalt PBR ----------
rep('asphalt', """  const roadMat = new THREE.MeshLambertMaterial({ color: 0x444444 });
""",
"""  // ===== آسفالت PBR: آلبیدو + نورمال + رافنس (از cine3d) =====
  const CINE_PBR = window.CINE_PBR || null;
  const asphaltP = CINE_PBR ? CINE_PBR.asphalt() : null;
  const roadMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: asphaltP ? asphaltP.map : null,
    normalMap: asphaltP ? asphaltP.normal : null,
    normalScale: new THREE.Vector2(.75, .75),
    roughnessMap: asphaltP ? asphaltP.rough : null,
    roughness: .92, metalness: .02,
  });
  W.cineRoadMat = roadMat;
""")

# ---------- 4) sidewalks ----------
rep('sidewalk', """  // دو خیابون فرعی قدیمی
  [[14, 240, -80, -60], [240, 14, 80, 60]].forEach(([w, d, x, z]) => {
    const r = new THREE.Mesh(new THREE.PlaneGeometry(w, d), roadMat);
    r.rotation.x = -Math.PI/2; r.position.set(x, .01, z);
    scene.add(r);
  });
""",
"""  // دو خیابون فرعی قدیمی
  [[14, 240, -80, -60], [240, 14, 80, 60]].forEach(([w, d, x, z]) => {
    const r = new THREE.Mesh(new THREE.PlaneGeometry(w, d), roadMat);
    r.rotation.x = -Math.PI/2; r.position.set(x, .01, z);
    r.receiveShadow = true;
    scene.add(r);
  });
  // ===== پیاده‌رو سنگ‌فرش PBR دو طرف بلوارها =====
  const sidewalkP = CINE_PBR ? CINE_PBR.sidewalk() : null;
  if (sidewalkP) {
    const swMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, map: sidewalkP.map, normalMap: sidewalkP.normal,
      normalScale: new THREE.Vector2(.8, .8),
      roughness: .95, metalness: 0,
    });
    W.cineSidewalkMat = swMat;
    const swGeoV = new THREE.PlaneGeometry(4.6, 940);
    const swGeoH = new THREE.PlaneGeometry(940, 4.6);
    MAIN_LANES.forEach(c => {
      for (const off of [9.3, -9.3]) {
        const v = new THREE.Mesh(swGeoV, swMat);
        v.rotation.x = -Math.PI/2; v.position.set(c + off, .015, 0); v.receiveShadow = true;
        scene.add(v);
        const h = new THREE.Mesh(swGeoH, swMat);
        h.rotation.x = -Math.PI/2; h.position.set(0, .015, c + off); h.receiveShadow = true;
        scene.add(h);
      }
    });
  }
""")

# ---------- 5) instanced dashes ----------
rep('dashes', """  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  MAIN_LANES.forEach(c => {
    for (let i = -450; i < 455; i += 12) {
      const l = new THREE.Mesh(new THREE.PlaneGeometry(.5, 4), lineMat);
      l.rotation.x = -Math.PI/2; l.position.set(c, .02, i); scene.add(l);
      const l2 = new THREE.Mesh(new THREE.PlaneGeometry(4, .5), lineMat);
      l2.rotation.x = -Math.PI/2; l2.position.set(i, .02, c); scene.add(l2);
    }
  });
""",
"""  // خط‌کشی‌ها: یک InstancedMesh برای همهٔ خط‌ها (۲ دراُکال به‌جای صدها)
  {
    const dashGeo = new THREE.PlaneGeometry(.5, 4);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xdddddd, transparent: true, opacity: .85 });
    const dashes = [];
    MAIN_LANES.forEach(c => {
      for (let i = -450; i < 455; i += 12) {
        dashes.push([c, i, 0]);          // عمودی
        dashes.push([i, c, 1]);          // افقی
      }
    });
    const inst = new THREE.InstancedMesh(dashGeo, lineMat, dashes.length);
    const dummy = new THREE.Object3D();
    dashes.forEach(([x, z, horiz], i) => {
      dummy.position.set(x, .02, z);
      dummy.rotation.set(-Math.PI/2, 0, horiz ? 0 : Math.PI/2);
      dummy.updateMatrix();
      inst.setMatrixAt(i, dummy.matrix);
    });
    inst.instanceMatrix.needsUpdate = true;
    scene.add(inst);
  }
""")

# ---------- 6) facade PBR + glass ----------
rep('facade', """  const WIN_MAT = new THREE.MeshLambertMaterial({ color: 0x224466, emissive: 0x112233 });
""",
"""  // ===== نمای PBR: نرمال‌مپ آجر/پنل + شیشهٔ بازتابی =====
  const facadeP = CINE_PBR ? CINE_PBR.facade() : null;
  const WIN_MAT = new THREE.MeshLambertMaterial({ color: 0x224466, emissive: 0x112233 });
  const GLASS_MAT = new THREE.MeshStandardMaterial({
    color: 0x3d5a72, roughness: .08, metalness: .9, envMapIntensity: 1.6,
  });
""")

rep('wallMat', """  function wallMat(c, w, d, h, roughness = .88, metalness = .04) {
    const key = c + '|' + Math.round(w) + '|' + Math.round(h);
    let m = WALL_MAT_CACHE.get(key);
    if (!m) {
      const tex = new THREE.CanvasTexture(FACADE_CANVAS);
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(Math.max(1, w / 4), Math.max(1, h / 4));
      m = new THREE.MeshStandardMaterial({ color: c, map: tex, roughness, metalness });
      WALL_MAT_CACHE.set(key, m);
    }
    return m;
  }
""",
"""  function wallMat(c, w, d, h, roughness = .88, metalness = .04) {
    const key = c + '|' + Math.round(w) + '|' + Math.round(h);
    let m = WALL_MAT_CACHE.get(key);
    if (!m) {
      const tex = new THREE.CanvasTexture(FACADE_CANVAS);
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(Math.max(1, w / 4), Math.max(1, h / 4));
      const params = { color: c, map: tex, roughness, metalness };
      if (facadeP) {
        const nt = facadeP.normal.clone(); nt.needsUpdate = true;
        nt.wrapS = nt.wrapT = THREE.RepeatWrapping;
        nt.repeat.set(Math.max(1, w / 4), Math.max(1, h / 4));
        params.normalMap = nt;
        params.normalScale = new THREE.Vector2(.6, .6);
      }
      m = new THREE.MeshStandardMaterial(params);
      WALL_MAT_CACHE.set(key, m);
    }
    return m;
  }
""")

# ---------- 7) modern glass ----------
rep('modern-glass', """      } else if (b.kind === 'modern') {
        const glassMat = new THREE.MeshLambertMaterial({ color: 0x66aacc, emissive: 0x224455 });
        const glass = new THREE.Mesh(new THREE.BoxGeometry(b.w * .95, b.h * .7, .2), glassMat);
""",
"""      } else if (b.kind === 'modern') {
        const glass = new THREE.Mesh(new THREE.BoxGeometry(b.w * .95, b.h * .7, .2), GLASS_MAT);
""")

# ---------- 8) car mesh PBR ----------
rep('car-mesh', """  function makeCarMesh(color) {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.15, .72, 4.35), mat(color, .28, .62));
    body.position.y = .75; body.castShadow = true;
    const hood = new THREE.Mesh(new THREE.BoxGeometry(2.02, .18, 1.25), mat(color, .25, .66));
    hood.position.set(0, 1.13, 1.38);
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.82, .7, 2.05), mat(color, .35, .45));
    cabin.position.set(0, 1.42, -.18);
    const windshield = new THREE.Mesh(new THREE.PlaneGeometry(1.55, .58), mat(0x7cb3c9, .08, .65));
    windshield.position.set(0, 1.48, .866); windshield.rotation.x = -.16;
    const rearGlass = windshield.clone(); rearGlass.position.z = -1.225; rearGlass.rotation.x = .16;
    const bumperF = new THREE.Mesh(new THREE.BoxGeometry(2.2, .18, .16), mat(0x25282c, .36, .7));
    bumperF.position.set(0, .62, 2.22);
    const bumperR = bumperF.clone(); bumperR.position.z = -2.22;
    g.add(body, hood, cabin, windshield, rearGlass, bumperF, bumperR);
    [-.72,.72].forEach(x => {
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(.42,.2,.06), new THREE.MeshStandardMaterial({color:0xfff1b0,emissive:0xffd166,emissiveIntensity:1.2}));
      lamp.position.set(x,.86,2.21); g.add(lamp);
      const tail = new THREE.Mesh(new THREE.BoxGeometry(.35,.18,.06), new THREE.MeshStandardMaterial({color:0xb51f2e,emissive:0x7a1018,emissiveIntensity:.7}));
      tail.position.set(x,.86,-2.21); g.add(tail);
    });
    [[-1.05,-1.45],[1.05,-1.45],[-1.05,1.45],[1.05,1.45]].forEach(w => {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(.42, .42, .32, 12), mat(0x111111));
      wheel.rotation.z = Math.PI/2;
      wheel.position.set(w[0], .42, w[1]);
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.34,12), mat(0xb8bec7,.3,.8));
      hub.rotation.z = Math.PI/2; hub.position.copy(wheel.position);
      g.add(wheel);
      g.add(hub);
    });
    return g;
  }
""",
"""  // ===== متریال‌های خودرو: بدنه clearcoat سینمایی + شیشه آینه‌ای =====
  const CAR_GLASS_MAT = new THREE.MeshStandardMaterial({
    color: 0x0e1c26, roughness: .05, metalness: .95, envMapIntensity: 2.2,
  });
  const CAR_TIRE_MAT = new THREE.MeshStandardMaterial({ color: 0x0c0c0e, roughness: .95, metalness: 0 });
  const CAR_RIM_MAT = new THREE.MeshStandardMaterial({ color: 0xc9cfd8, roughness: .25, metalness: .95, envMapIntensity: 1.4 });
  const HEAD_GEO = new THREE.BoxGeometry(.42, .2, .06);
  const TAIL_GEO = new THREE.BoxGeometry(.35, .18, .06);
  const HEAD_MAT = new THREE.MeshStandardMaterial({ color: 0xfff6d8, emissive: 0xffe9a8, emissiveIntensity: 1.2 });
  const TAIL_MAT = new THREE.MeshStandardMaterial({ color: 0x8a1420, emissive: 0xff2a30, emissiveIntensity: .55 });
  const HEAD_MAT_OFF = new THREE.MeshStandardMaterial({ color: 0xe8e4d2, emissiveIntensity: 0 });
  const TAIL_MAT_ON = new THREE.MeshStandardMaterial({ color: 0xb51f2e, emissive: 0xff2230, emissiveIntensity: 2.2 });
  const CAR_SHADOW_TEX = (() => {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(32, 32, 4, 32, 32, 31);
    g.addColorStop(0, 'rgba(0,0,0,.5)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  const CAR_SHADOW_MAT = new THREE.MeshBasicMaterial({ map: CAR_SHADOW_TEX, transparent: true, depthWrite: false, opacity: .85 });
  const CAR_SHADOW_GEO = new THREE.PlaneGeometry(4.4, 5.6);

  function makeCarMesh(color) {
    const g = new THREE.Group();
    const paint = new THREE.MeshPhysicalMaterial({
      color, roughness: .22, metalness: .78,
      clearcoat: 1, clearcoatRoughness: .1, envMapIntensity: 1.5,
    });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.15, .72, 4.35), paint);
    body.position.y = .75; body.castShadow = true;
    const hood = new THREE.Mesh(new THREE.BoxGeometry(2.02, .18, 1.25), paint);
    hood.position.set(0, 1.13, 1.38);
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.82, .7, 2.05), paint);
    cabin.position.set(0, 1.42, -.18);
    const windshield = new THREE.Mesh(new THREE.PlaneGeometry(1.55, .58), CAR_GLASS_MAT);
    windshield.position.set(0, 1.48, .866); windshield.rotation.x = -.16;
    const rearGlass = windshield.clone(); rearGlass.position.z = -1.225; rearGlass.rotation.x = .16;
    const bumperF = new THREE.Mesh(new THREE.BoxGeometry(2.2, .18, .16), mat(0x25282c, .36, .7));
    bumperF.position.set(0, .62, 2.22);
    const bumperR = bumperF.clone(); bumperR.position.z = -2.22;
    g.add(body, hood, cabin, windshield, rearGlass, bumperF, bumperR);
    const wheels = [];
    [[-1.05,-1.45],[1.05,-1.45],[-1.05,1.45],[1.05,1.45]].forEach(w => {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(.42, .42, .32, 14), CAR_TIRE_MAT);
      wheel.rotation.z = Math.PI/2;
      wheel.castShadow = true;
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.34,12), CAR_RIM_MAT);
      hub.rotation.z = Math.PI/2;
      const wrap = new THREE.Group();
      wrap.add(wheel, hub);
      wrap.position.set(w[0], .42, w[1]);
      g.add(wrap); wheels.push(wrap);
    });
    const headL = new THREE.Mesh(HEAD_GEO, HEAD_MAT); headL.position.set(-.72,.86,2.21);
    const headR = headL.clone(); headR.position.x = .72;
    const tailL = new THREE.Mesh(TAIL_GEO, TAIL_MAT); tailL.position.set(-.72,.86,-2.21);
    const tailR = tailL.clone(); tailR.position.x = .72;
    g.add(headL, headR, tailL, tailR);
    // سایهٔ تماس همیشه‌زیر ماشین (حتی وقتی shadowmap خاموش است)
    const blob = new THREE.Mesh(CAR_SHADOW_GEO, CAR_SHADOW_MAT);
    blob.rotation.x = -Math.PI/2; blob.position.y = .021; blob.renderOrder = 2;
    g.add(blob);
    g.userData.wheels = wheels;
    g.userData.paint = paint;
    g.userData.head = [headL, headR];
    g.userData.tail = [tailL, tailR];
    return g;
  }
""")

# ---------- 9) traffic lamps ----------
rep('traffic-lamps', """    scene.add(car);
    const speed = 8 + Math.random() * 6;
""",
"""    scene.add(car);
    // چراغ جلو/عقب: شب و باران روشن
    const setCarLamps = on => {
      if (car.userData.head) car.userData.head.forEach(h => { h.material = on ? HEAD_MAT : HEAD_MAT_OFF; });
      if (car.userData.tail) car.userData.tail.forEach(h => { h.material = on ? TAIL_MAT_ON : TAIL_MAT; });
    };
    car.userData.setLamps = setCarLamps;
    setCarLamps(G.hour >= 19 || G.hour < 6);
    const speed = 8 + Math.random() * 6;
""")

rep('lamps-frame', """  function updateTraffic(dt, now) {
    for (let i = traffic.length - 1; i >= 0; i--) {
      const t = traffic[i];
      const distToPlayer = t.car.position.distanceTo(player.position);
""",
"""  function updateTraffic(dt, now) {
    const lampsShouldBeOn = G.hour >= 19 || G.hour < 6 || G.weather === 'rainy' || G.weather === 'stormy';
    for (let i = traffic.length - 1; i >= 0; i--) {
      const t = traffic[i];
      const distToPlayer = t.car.position.distanceTo(player.position);
      if (t.car.userData.setLamps && t._lampOn !== lampsShouldBeOn) { t._lampOn = lampsShouldBeOn; t.car.userData.setLamps(lampsShouldBeOn); }
""")

# ---------- 10) lamp lights ----------
rep('lamp-lights', """  const lampBulbs = [];
  function addLamp(x, z) {
""",
"""  const lampBulbs = [];
  const lampLights = [];          // نورهای واقعی چراغ خیابان (استخرشده)
  const LAMP_LIGHT_COUNT = 5;     // فقط نزدیک‌ترین‌ها نور واقعی می‌گیرند
  const lampPositions = [];
  function addLamp(x, z) {
""")

rep('lamp-record', """    scene.add(pole, arm, bulb);
    lampBulbs.push(bulb);
  }
  for (let i = -200; i <= 200; i += 33) { addLamp(-8.5, i); addLamp(i, 8.5); }
""",
"""    scene.add(pole, arm, bulb);
    lampBulbs.push(bulb);
    lampPositions.push(bulb.position);
  }
  for (let i = -200; i <= 200; i += 33) { addLamp(-8.5, i); addLamp(i, 8.5); }
  // توزیع نور واقعی بین نزدیک‌ترین تیرها به بازیکن (هر فریم نه — سبک)
  function updateLampLights() {
    const night = G.hour >= 19 || G.hour < 6;
    if (!night) { lampLights.forEach(l => { l.intensity = 0; l.visible = false; }); return; }
    const px = player.position.x, pz = player.position.z;
    const best = [];
    for (const p of lampPositions) {
      const d = (p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz);
      if (best.length < LAMP_LIGHT_COUNT) { best.push({ p, d }); best.sort((a, b) => a.d - b.d); }
      else if (d < best[best.length - 1].d) { best[best.length - 1] = { p, d }; best.sort((a, b) => a.d - b.d); }
    }
    for (let i = 0; i < LAMP_LIGHT_COUNT; i++) {
      const l = lampLights[i];
      if (i < best.length) {
        const p = best[i].p;
        l.position.set(p.x, p.y - .2, p.z);
        l.intensity = 22 + Math.sin(i * 2.4) * 2;
        l.visible = true;
      } else { l.intensity = 0; l.visible = false; }
    }
  }
""")

# lamp pool creation needs to be after scene exists — insert right before first addLamp loop usage
rep('lamp-pool', """  const lampBulbs = [];
  const lampLights = [];          // نورهای واقعی چراغ خیابان (استخرشده)
  const LAMP_LIGHT_COUNT = 5;     // فقط نزدیک‌ترین‌ها نور واقعی می‌گیرند
  const lampPositions = [];
""",
"""  const lampBulbs = [];
  const lampLights = [];          // نورهای واقعی چراغ خیابان (استخرشده)
  const LAMP_LIGHT_COUNT = 5;     // فقط نزدیک‌ترین‌ها نور واقعی می‌گیرند
  for (let li = 0; li < LAMP_LIGHT_COUNT; li++) {
    const pl = new THREE.PointLight(0xffd98a, 0, 26, 2);
    pl.visible = false;
    scene.add(pl);
    lampLights.push(pl);
  }
  const lampPositions = [];
""")

# ---------- 11) rain mat share ----------
rep('rainmat', """  const rainMat = new THREE.PointsMaterial({ color: 0x99bbee, size: .25, transparent: true, opacity: .7 });
""",
"""  const rainMat = (cine && cine.rain) ? cine.rain.points.material : new THREE.PointsMaterial({ color: 0x99bbee, size: .25, transparent: true, opacity: .7 });
""")

# ---------- 12) applyWeather + updateDayLight ----------
rep('daylight', """  let precipWanted = false;
  function applyWeather() {
    scene.fog.near = G.weather === 'polluted' ? 25 : 80;
    scene.fog.far = G.weather === 'polluted' ? 90 : 220;
    precipWanted = ['rainy', 'snowy', 'stormy'].includes(G.weather);
    precip.visible = precipWanted;
    precip.material = G.weather === 'snowy' ? snowMat : G.weather === 'stormy' ? dustMat : rainMat;
  }
  // چرخه‌ی نور شبانه‌روزی: صبح/ظهر/غروب/شب — گرادیان real-time
  function updateDayLight() {
    const t = (G.hour + G.minute / 60) / 24;
    const elev = Math.sin((t - .25) * Math.PI * 2);           // -۱ نیمه‌شب .. ۱ ظهر
    const daylight = Math.max(0, Math.min(1, (elev + .15) * 2.2));
    const duskGlow = Math.max(0, 1 - Math.abs(elev) * 5) * (t > .5 ? 1 : .7); // طلوع/غروب
    const base = new THREE.Color(skyByWeather[G.weather] || 0x87ceeb);
    const sky = skyNight.clone().lerp(base, daylight).lerp(skyDusk, duskGlow * .45);
    scene.background = sky;
    scene.fog.color = sky;
    const wI = { sunny:2.2, cloudy:1.4, rainy:1, polluted:1.1, snowy:1.5, stormy:.8 }[G.weather] || 2;
    sun.intensity = .12 + daylight * wI;
    sun.color.setHex(duskGlow > .3 ? 0xffb26b : 0xfff2d0);
    sun.position.set(Math.cos(t * Math.PI * 2) * 60, 15 + daylight * 55, 30);
    amb.intensity = .22 + daylight * .6;
    // چراغ‌های خیابون شب روشن!
    const lampOn = daylight < .35 ? 1.6 : 0;
    for (const b of lampBulbs) b.material.emissiveIntensity = lampOn;
  }
  applyWeather();
  updateDayLight();
""",
"""  let precipWanted = false;
  function applyWeather() {
    scene.fog.near = G.weather === 'polluted' ? 25 : 70;
    scene.fog.far = G.weather === 'polluted' ? 100 : 300;
    precipWanted = ['rainy', 'snowy', 'stormy'].includes(G.weather);
    // باران واقعی از cine3d؛ precip قدیمی فقط برای برف/گردوخاک
    const rainNow = G.weather === 'rainy' || G.weather === 'stormy';
    precip.material = G.weather === 'snowy' ? snowMat : G.weather === 'stormy' ? dustMat : rainMat;
    precip.visible = precipWanted && !rainNow;
    if (cine && W.cineRoadMat) cine.applyWetness(W.cineRoadMat, W.cineSidewalkMat);
  }
  // چرخه‌ی نور شبانه‌روزی — سینمایی (cine3d): آسمان شیدری + خورشید/ماه + مه گرم
  const skyByWeather = { sunny:0x87ceeb, cloudy:0x9aa5b1, rainy:0x5c6b7a, polluted:0xb0a080, snowy:0xcfd8e3, stormy:0x6a5c48 };
  const _skyNightC = new THREE.Color(0x0b1026);
  const _skyDuskC = new THREE.Color(0xf4a261);
  function updateDayLight() {
    const t = (G.hour + G.minute / 60) / 24;
    const elev = Math.sin((t - .25) * Math.PI * 2);
    const daylight = Math.max(0, Math.min(1, (elev + .15) * 2.2));
    const duskGlow = Math.max(0, 1 - Math.abs(elev) * 5) * (t > .5 ? 1 : .7);
    if (cine) {
      cine.update(_lastFrameDt, performance.now(), { player, inside: INT.isInside() });
      updateLampLights();
    } else {
      const base = new THREE.Color(skyByWeather[G.weather] || 0x87ceeb);
      const sky = _skyNightC.clone().lerp(base, daylight).lerp(_skyDuskC, duskGlow * .45);
      scene.background = sky;
      scene.fog.color = sky;
      const wI = { sunny:2.2, cloudy:1.4, rainy:1, polluted:1.1, snowy:1.5, stormy:.8 }[G.weather] || 2;
      sun.intensity = .12 + daylight * wI;
      sun.color.setHex(duskGlow > .3 ? 0xffb26b : 0xfff2d0);
      sun.position.set(Math.cos(t * Math.PI * 2) * 60, 15 + daylight * 55, 30);
      amb.intensity = .22 + daylight * .6;
    }
    // چراغ‌های خیابون شب روشن!
    const lampOn = daylight < .35 ? 2.4 : 0;
    for (const b of lampBulbs) b.material.emissiveIntensity = lampOn;
  }
  applyWeather();
  updateDayLight();
""")

# remove now-duplicate old const skyByWeather/night/dusk decls
rep('old-sky-vars', """  const skyByWeather = {
    sunny: 0x87ceeb, cloudy: 0x9aa5b1, rainy: 0x5c6b7a,
    polluted: 0xb0a080, snowy: 0xcfd8e3, stormy: 0x6a5c48,
  };
  const skyNight = new THREE.Color(0x0b1026);
  const skyDusk = new THREE.Color(0xf4a261);
""", "")

# ---------- 13) camera helpers ----------
rep('cam-helpers', """  // ---------- حلقه ----------
  const clock = new THREE.Clock();
""",
"""  // ---------- حلقه ----------
  const clock = new THREE.Clock();
  // ابزار دوربین سینمایی
  const _camTarget = new THREE.Vector3();
  const _lookTarget = new THREE.Vector3();
  const _smoothLook = new THREE.Vector3();
  const _ray = new THREE.Raycaster();
  let _prevCarPos = null;
  let _lastFrameDt = .016;
  const _camBlockers = [];      // بدنهٔ ساختمان‌ها برای برخورد دوربین
""")

rep('camblock-add', """    const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), wallMat(b.color, b.w, b.d, b.h));
    body.position.y = b.h/2; body.castShadow = body.receiveShadow = true;
    g.add(body);
""",
"""    const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), wallMat(b.color, b.w, b.d, b.h));
    body.position.y = b.h/2; body.castShadow = body.receiveShadow = true;
    g.add(body);
    if (b.kind !== 'open') _camBlockers.push(body);
""")

rep('dt-capture', """    const dt = Math.min(clock.getDelta(), .05);
    fpsTick(dt);
""",
"""    const dt = Math.min(clock.getDelta(), .05);
    _lastFrameDt = dt;
    fpsTick(dt);
""")

# ---------- 14) driving camera ----------
rep('drive-cam', """        camera.position.lerp(new THREE.Vector3(
          playerCarMesh.position.x + Math.sin(camYaw) * Math.cos(camPitch) * 13,
          3 + Math.sin(camPitch) * 13,
          playerCarMesh.position.z + Math.cos(camYaw) * Math.cos(camPitch) * 13), .12);
        camera.lookAt(playerCarMesh.position.x, 2, playerCarMesh.position.z);
""",
"""        // دوربین رانندگی: دمپ نمایی (مستقل از فریم‌ریت) + FOV پویا با سرعت
        const camK = 1 - Math.exp(-8 * dt);
        _camTarget.set(
          playerCarMesh.position.x + Math.sin(camYaw) * Math.cos(camPitch) * 13,
          3 + Math.sin(camPitch) * 13,
          playerCarMesh.position.z + Math.cos(camYaw) * Math.cos(camPitch) * 13);
        camera.position.lerp(_camTarget, camK);
        const lookK = 1 - Math.exp(-14 * dt);
        _lookTarget.set(playerCarMesh.position.x, 2, playerCarMesh.position.z);
        _smoothLook.lerp(_lookTarget, lookK);
        camera.lookAt(_smoothLook);
        // FOV: سرعت واقعی تخمینی از جابه‌جایی
        const carSpd = _prevCarPos ? playerCarMesh.position.distanceTo(_prevCarPos) / Math.max(dt, .001) : 0;
        _prevCarPos = _prevCarPos || playerCarMesh.position.clone();
        _prevCarPos.copy(playerCarMesh.position);
        const wantedFov = 62 + Math.min(14, carSpd * .55);
        if (Math.abs(camera.fov - wantedFov) > .1) {
          camera.fov += (wantedFov - camera.fov) * Math.min(1, dt * 4);
          camera.updateProjectionMatrix();
        }
        // لرزش جزئی موتور در سرعت بالا
        if (carSpd > 9) {
          const sh = Math.min(.045, (carSpd - 9) * .004);
          camera.position.y += (Math.random() - .5) * sh;
          camera.position.x += (Math.random() - .5) * sh;
        }
""")

# ---------- 15) walk camera ----------
rep('walk-cam', """        const camDist = INT.isInside() ? 7.5 : 9;
        camera.position.lerp(new THREE.Vector3(
          player.position.x + Math.sin(camYaw) * Math.cos(camPitch) * camDist,
          player.position.y + 2 + Math.sin(camPitch) * camDist,
          player.position.z + Math.cos(camYaw) * Math.cos(camPitch) * camDist), .15);
        clampCamInside();
        camera.lookAt(player.position.x, player.position.y + 1.6, player.position.z);
""",
"""        const camDist = INT.isInside() ? 7.5 : 9;
        const camK = 1 - Math.exp(-9 * dt);
        _camTarget.set(
          player.position.x + Math.sin(camYaw) * Math.cos(camPitch) * camDist,
          player.position.y + 2 + Math.sin(camPitch) * camDist,
          player.position.z + Math.cos(camYaw) * Math.cos(camPitch) * camDist);
        // برخورد دوربین با ساختمان‌ها: اگر هدف پشت دیوار است نزدیک‌تر شو
        if (!INT.isInside() && _camBlockers.length) {
          const from = new THREE.Vector3(player.position.x, player.position.y + 1.6, player.position.z);
          const dirC = new THREE.Vector3().subVectors(_camTarget, from);
          const lenC = dirC.length();
          dirC.normalize();
          _ray.set(from, dirC);
          _ray.far = lenC;
          const hitsC = _ray.intersectObjects(_camBlockers, false);
          if (hitsC.length) {
            const d = Math.max(2.2, hitsC[0].distance - .5);
            _camTarget.copy(from).addScaledVector(dirC, d);
          }
        }
        camera.position.lerp(_camTarget, camK);
        clampCamInside();
        const lookK = 1 - Math.exp(-16 * dt);
        _lookTarget.set(player.position.x, player.position.y + 1.6, player.position.z);
        _smoothLook.lerp(_lookTarget, lookK);
        camera.lookAt(_smoothLook);
""")

# ---------- 16) applyQuality ----------
rep('applyQuality', """    renderer.shadowMap.enabled = q === 'high';
    sun.castShadow = q === 'high';
    scene.fog.near = q === 'low' ? 40 : 80;
    scene.fog.far = q === 'low' ? 130 : q === 'mid' ? 180 : 240;
    camera.far = q === 'low' ? 200 : q === 'mid' ? 320 : 500;
    camera.updateProjectionMatrix();
    if (q === 'low') precip.visible = false;
    // ساختمان‌های دور در کیفیت پایین مخفی بشن
    farCull = q === 'low' ? 140 : q === 'mid' ? 220 : 0;
  };
""",
"""    renderer.shadowMap.enabled = q !== 'low';
    sun.castShadow = q !== 'low';
    scene.fog.near = q === 'low' ? 45 : 70;
    scene.fog.far = q === 'low' ? 150 : q === 'mid' ? 240 : 300;
    camera.far = q === 'low' ? 220 : q === 'mid' ? 400 : 700;
    camera.updateProjectionMatrix();
    if (q === 'low') precip.visible = false;
    // ساختمان‌های دور در کیفیت پایین مخفی بشن
    farCull = q === 'low' ? 150 : q === 'mid' ? 240 : 0;
    if (cine) cine.setMode(q);
  };
""")

# ---------- 17) destroy cleanup ----------
rep('destroy', """    renderer.dispose();
    canvas.remove();
  };
""",
"""    renderer.dispose();
    canvas.remove();
    const film = document.getElementById('cineFilm');
    if (film) film.remove();
  };
""")

# ---------- 18) power challenge lamp lights ----------
rep('power-off', """      // چراغ‌های شهر خاموش
      lampBulbs.forEach(b => b.material.emissiveIntensity = 0);
""",
"""      // چراغ‌های شهر خاموش
      lampBulbs.forEach(b => b.material.emissiveIntensity = 0);
      lampLights.forEach(l => l.intensity = 0);
""")

rep('power-on', """          lampBulbs.forEach(b => b.material.emissiveIntensity = 1.6);
""",
"""          lampBulbs.forEach(b => b.material.emissiveIntensity = 2.4);
          lampLights.forEach(l => { if (G.hour >= 19 || G.hour < 6) l.intensity = 22; });
""")

# ---------- report ----------
print('APPLIED:', len(edits), '/', len(edits) + len(MISS))
if MISS:
    print('MISSES:')
    for m in MISS:
        print('  MISS ' + m)

io.open(P, 'w', encoding='utf-8', newline='\n').write(s)
print('len', orig_len, '->', len(s))
