// ===== world2d.js — دنیای دوبعدی نمای بالا (موتور رندر ارتقایافته به سبک «محله‌باز») =====
// منطق بازی دقیقاً همون قبلیه؛ فقط لایهٔ تصویری بازنویسی شده:
// DPR، دوربین نرم، شبکهٔ خیابون، سایه و سقف و تابلو، نور شب، هوا، مینی‌مپ.
'use strict';

function createWorld2D() {
  const W = { mode: '2d' };
  const canvas = document.createElement('canvas');
  canvas.id = 'canvas2d';
  $id('game').appendChild(canvas);
  const ctx = canvas.getContext('2d');

  let VW = innerWidth, VH = innerHeight, dpr = 1, SCALE = 14;
  function resize() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    VW = innerWidth; VH = innerHeight;
    canvas.width = Math.round(VW * dpr);
    canvas.height = Math.round(VH * dpr);
    canvas.style.width = VW + 'px';
    canvas.style.height = VH + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // هر واحد دنیا چند پیکسل؟ روی موبایل کوچیک‌تر تا دید بازتر بمونه
    SCALE = Math.max(9, Math.min(19, Math.min(VW, VH) / 56));
  }
  resize();
  addEventListener('resize', resize);

  const player = { x: G.px, z: G.pz, angle: Math.PI / 2, walk: 0 };
  let driving = false;
  const carPos = { x: G.px + 5, z: G.pz };
  const cam = { x: player.x, z: player.z };

  // ---------- ابزار رنگ ----------
  const hexColor = c => '#' + c.toString(16).padStart(6, '0');
  const cl = v => Math.max(0, Math.min(255, Math.round(v)));
  // خروجی عدد (نه رشته) چون mixHex عدد می‌گیره
  function tint(c, amt) {
    const r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
    return (cl(r + amt) << 16) | (cl(g + amt) << 8) | cl(b + amt);
  }
  function mixHex(a, b, t) {
    const ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
    const br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
    return `rgb(${cl(ar + (br - ar) * t)},${cl(ag + (bg - ag) * t)},${cl(ab + (bb - ab) * t)})`;
  }

  // ---------- NPC ها ----------
  // چند نفر ممکنه پاتوق مشترک داشته باشن؛ با آفست پخششون می‌کنیم که روی هم نیفتن
  const hangCount = {};
  const npc2d = NPCS.map(n => {
    const hang = buildingById(n.hangout) || buildingById('park');
    const k = hangCount[n.hangout] = (hangCount[n.hangout] || 0) + 1;
    const ring = (k - 1);
    const home = {
      x: hang.x + hang.w / 2 + 4 + Math.cos(ring * 2.1) * ring * 2.4,
      z: hang.z + hang.d / 2 + 3 + Math.sin(ring * 2.1) * ring * 2.4,
    };
    // اگه افتاد وسط خیابون، بکشش کنار پیاده‌رو
    let guard = 0;
    while (onRoad(home.x, home.z, 1.4) && guard++ < 12) {
      const r = onRoad(home.x, home.z, 1.4);
      if (r.dir === 'h') home.z += (home.z >= r.c ? 1 : -1) * 1.2;
      else home.x += (home.x >= r.c ? 1 : -1) * 1.2;
    }
    return { npc: n, x: home.x, z: home.z, home, tx: home.x, tz: home.z, t: Math.random() * 4, walk: 0 };
  });

  // ---------- ترافیک ----------
  const HONKS2D = [
    '🚗 راننده: «هوووی! درست راه برو داداش!»',
    '🚕 راننده: «مگه پیاده‌رو نیست؟!»',
    '🚙 راننده: «بپا جوون!»',
    '🚗 راننده: «برو کنار عمو، عجله دارم!»',
  ];
  let lastHonk = 0, knockUntil = 0, lastArgue = 0;
  const traffic2d = [];
  const trafficColors2d = ['#d62828', '#005f73', '#e9c46a', '#eeeeee', '#555555', '#40916c'];
  const mainRoads = ROADS.filter(r => r.main);
  function spawnTraffic2d() {
    const road = mainRoads[Math.floor(Math.random() * mainRoads.length)];
    const dir = Math.random() < .5 ? 1 : -1;
    const isTaxi = Math.random() < .35;
    const lane = road.c + dir * road.hw * .48;   // راست‌رو
    traffic2d.push({
      vertical: road.dir === 'v', dir, taxi: isTaxi,
      x: road.dir === 'v' ? lane : -130 * dir,
      z: road.dir === 'v' ? -130 * dir : lane,
      speed: 8 + Math.random() * 6,
      color: isTaxi ? '#f4c430' : trafficColors2d[Math.floor(Math.random() * trafficColors2d.length)],
    });
  }
  function nearTaxi() {
    return traffic2d.some(t => t.taxi && Math.hypot(t.x - player.x, t.z - player.z) < 7);
  }
  const trafficTimer = setInterval(() => {
    if (gameStarted && !gamePaused && traffic2d.length < 8) spawnTraffic2d();
  }, 3200);
  function hitsCar2d(x, z) {
    if (activeCarData() && !driving && Math.hypot(x - carPos.x, z - carPos.z) < 2.8) return true;
    for (const t of traffic2d)
      if (Math.hypot(x - t.x, z - t.z) < 2.8) return true;
    return false;
  }

  // ---------- ورودی ----------
  const keys = {};
  const keydown = e => {
    keys[e.code] = true;
    if (e.code === 'KeyE') tryInteract();
    if (e.code === 'KeyF') toggleDrive();
    if (e.code === 'Escape' && !panelOpen && gameStarted && !gamePaused) setTimeout(openPause, 40);
  };
  const keyup = e => keys[e.code] = false;
  addEventListener('keydown', keydown);
  addEventListener('keyup', keyup);

  function toggleDrive() {
    if (panelOpen || !gameStarted) return;
    const car = activeCarData();
    if (!car) { toast('🚗 ماشین نداری! برو نمایشگاه.'); return; }
    if (!driving) {
      if (Math.hypot(carPos.x - player.x, carPos.z - player.z) > 7) { toast('🚗 ماشینت دوره!'); return; }
      if (G.fuel <= 0) { toast('⛽ بنزین نداری!'); return; }
      if (G.damage >= 90) { toast('🔧 ماشین داغونه!'); return; }
      driving = true; toast('🚗 سوار شدی! F = پیاده شدن');
    } else {
      driving = false;
      player.x = carPos.x + 3; player.z = carPos.z;
      toast('🚶 پیاده شدی');
    }
  }

  function collide(x, z, pad = 0) {
    for (const b of BUILDINGS) {
      if (b.kind === 'open') continue;
      if (Math.abs(x - b.x) < b.w / 2 + 1 + pad && Math.abs(z - b.z) < b.d / 2 + 1 + pad) return true;
    }
    return false;
  }

  function nearestTarget() {
    for (const n of npc2d)
      if (Math.hypot(n.x - player.x, n.z - player.z) < 4.5) return { type: 'npc', npc: n.npc };
    if (nearTaxi()) return { type: 'taxi' };
    for (const b of BUILDINGS) {
      if (b.deco) continue;
      if (Math.abs(player.x - b.x) < b.w / 2 + 4 && Math.abs(player.z - b.z) < b.d / 2 + 4)
        return { type: 'building', b };
    }
    return null;
  }
  function tryInteract() {
    if (panelOpen || !gameStarted || driving) return;
    const t = nearestTarget();
    if (!t) return;
    if (t.type === 'npc') openNPC(t.npc);
    else if (t.type === 'taxi') openTaxi(false);
    else openBuilding(t.b.id);
  }

  // ---------- گپ NPC ها با هم ----------
  let social = null, nextSocial = performance.now() + 12000;
  function updateSocial2d(now) {
    if (!social && now > nextSocial && npc2d.length > 1) {
      const a = npc2d[Math.floor(Math.random() * npc2d.length)];
      let b;
      do { b = npc2d[Math.floor(Math.random() * npc2d.length)]; } while (b === a);
      social = { a, b, phase: 'walk', until: now + 25000 };
      b.t = 30;
    }
    if (!social) return;
    const { a, b } = social;
    if (social.phase === 'walk') {
      b.tx = a.x; b.tz = a.z;
      if (Math.hypot(b.x - a.x, b.z - a.z) < 3.5) {
        social.phase = 'talk';
        social.until = now + 9000;
        if (Math.hypot(player.x - a.x, player.z - a.z) < 25) {
          const [l1, l2] = randomAmbient();
          uiChatter(a.npc.name.split(' (')[0], l1, b.npc.name.split(' (')[0], l2);
        }
      }
    }
    if (now > social.until) {
      b.t = 0; a.t = 0;
      social = null;
      nextSocial = now + 15000 + Math.random() * 15000;
    }
  }

  // ---------- دکور: درخت‌ها، تیر چراغ‌برق ----------
  function nearBuilding(x, z, pad) {
    for (const b of BUILDINGS)
      if (Math.abs(x - b.x) < b.w / 2 + pad && Math.abs(z - b.z) < b.d / 2 + pad) return true;
    return false;
  }
  const trees = TREE_SPOTS.map(([x, z], i) => ({ x, z, s: .95 + (i % 4) * .07, tone: i % 3 }));
  const lamps = [];
  for (const r of ROADS) {
    const step = r.main ? 24 : 34;
    for (let t = r.from + 5; t < r.to - 5; t += step) {
      for (const side of [-1, 1]) {
        const ox = r.dir === 'v' ? r.c + side * (r.hw + 1.9) : t;
        const oz = r.dir === 'v' ? t : r.c + side * (r.hw + 1.9);
        if (Math.abs(ox) > 92 || Math.abs(oz) > 92) continue;
        if (nearBuilding(ox, oz, 1.6)) continue;
        lamps.push({ x: ox, z: oz, flip: side });
        // یکی درمیون درخت هم بکاریم
        const tx = r.dir === 'v' ? r.c + side * (r.hw + 4.2) : t + 5.5;
        const tz = r.dir === 'v' ? t + 5.5 : r.c + side * (r.hw + 4.2);
        if (lamps.length % 3 !== 0 && !nearBuilding(tx, tz, 2.4) && !onRoad(tx, tz, .5) && Math.abs(tx) < 90 && Math.abs(tz) < 90)
          trees.push({ x: tx, z: tz, s: .8 + (trees.length % 4) * .06, tone: trees.length % 3 });
      }
    }
  }

  // ---------- دکور زمین (لکه‌های چمن و بوته) ----------
  let seed = 20250819;
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  const groundDecor = [];
  for (let i = 0; i < 420 && groundDecor.length < 190; i++) {
    const x = -96 + rnd() * 192, z = -96 + rnd() * 192;
    if (onRoad(x, z, 2.2) || nearBuilding(x, z, 3)) continue;
    const kind = rnd();
    groundDecor.push({
      x, z,
      type: kind < .55 ? 'patch' : kind < .9 ? 'bush' : 'rock',
      r: 1.4 + rnd() * 3.6,
      a: rnd() * 6.28,
      v: rnd(),
    });
  }
  function drawGroundDecor(dl) {
    for (const d of groundDecor) {
      const px = wx(d.x), py = wy(d.z);
      if (px < -60 || px > VW + 60 || py < -60 || py > VH + 60) continue;
      if (d.type === 'patch') {
        ctx.fillStyle = `rgba(${d.v > .5 ? '124,150,88' : '88,116,66'},${(.07 + d.v * .07) * (.35 + .65 * dl)})`;
        ctx.beginPath(); ctx.ellipse(px, py, d.r * SCALE, d.r * SCALE * .62, d.a, 0, 7); ctx.fill();
      } else if (d.type === 'bush') {
        const c = d.v > .5 ? 0x4f8050 : 0x3e6f47;
        ctx.fillStyle = `rgba(20,40,28,${.14 * dl + .06})`;
        ctx.beginPath(); ctx.ellipse(px + SCALE * .18, py + SCALE * .2, SCALE * .62, SCALE * .34, 0, 0, 7); ctx.fill();
        ctx.fillStyle = mixHex(0x16203a, c, .3 + .7 * dl);
        for (const [ox, oy, rr2] of [[-.28, .04, .38], [.26, -.04, .34], [0, -.2, .42]]) {
          ctx.beginPath(); ctx.arc(px + ox * SCALE, py + oy * SCALE, rr2 * SCALE, 0, 7); ctx.fill();
        }
      } else {
        ctx.fillStyle = mixHex(0x1d2433, 0x9aa0a6, .3 + .7 * dl);
        ctx.beginPath(); ctx.ellipse(px, py, SCALE * .34, SCALE * .24, d.a, 0, 7); ctx.fill();
      }
    }
  }

  // ---------- بارش ----------
  const drops = Array.from({ length: 170 }, () => ({ x: Math.random(), y: Math.random(), s: .5 + Math.random() }));
  function dtDrop(s, snow) { return (snow ? .002 : .012) * s; }

  // ==========================================================
  //                        حلقهٔ بازی
  // ==========================================================
  let last = performance.now(), running = true;
  function frame(now) {
    if (!running) return;
    requestAnimationFrame(frame);
    const dt = Math.min((now - last) / 1000, .05);
    last = now;

    if (gameStarted && !gamePaused && !panelOpen && !G.traveling) {
      G.minute += dt * 2; // هر ثانیه واقعی = ۲ دقیقه بازی
      if (G.minute >= 60) { G.minute -= 60; G.hour++; if (G.hour >= 24) { G.hour = 0; runDailyTick(); } checkForcedSleep(); if (G.hour % 2 === 0) updateHUD(); }

      let mx = 0, mz = 0;
      if (keys['KeyW'] || keys['ArrowUp']) mz -= 1;
      if (keys['KeyS'] || keys['ArrowDown']) mz += 1;
      if (keys['KeyA'] || keys['ArrowLeft']) mx -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) mx += 1;
      if (window.touchInput) { mx += touchInput.mx; mz += touchInput.mz; }

      if (mx || mz) {
        const len = Math.hypot(mx, mz); mx /= len; mz /= len;
        if (driving) {
          const car = activeCarData();
          const speed = car.speed * (G.trafficJam ? .5 : 1) * (1 - G.damage / 200);
          const nx = carPos.x + mx * speed * dt, nz = carPos.z + mz * speed * dt;
          if (!collide(nx, nz, 1)) { carPos.x = nx; carPos.z = nz; G.fuel = Math.max(0, G.fuel - dt * .12); }
          else G.damage = Math.min(100, G.damage + .5);
          carPos.x = Math.max(-455, Math.min(455, carPos.x));
          carPos.z = Math.max(-455, Math.min(455, carPos.z));
          carPos.angle = Math.atan2(mz, mx);
          if (G.fuel <= 0) { driving = false; player.x = carPos.x; player.z = carPos.z; toast('⛽ بنزین تموم شد!'); }
        } else if (performance.now() > knockUntil) {
          const speed = (keys['ShiftLeft'] || window.touchInput?.run) ? 12 : 6.5;
          const nx = player.x + mx * speed * dt, nz = player.z + mz * speed * dt;
          if (!collide(nx, player.z) && !hitsCar2d(nx, player.z)) player.x = nx;
          if (!collide(player.x, nz) && !hitsCar2d(player.x, nz)) player.z = nz;
          player.walk += dt * 10;
          player.x = Math.max(-455, Math.min(455, player.x));
          player.z = Math.max(-455, Math.min(455, player.z));
          player.angle = Math.atan2(mz, mx);
          G.px = player.x; G.pz = player.z;
        }
      }

      // NPC
      for (const n of npc2d) {
        n.t -= dt;
        if (n.t <= 0) {
          n.t = 3 + Math.random() * 5;
          n.tx = n.home.x + (Math.random() - .5) * 8;
          n.tz = n.home.z + (Math.random() - .5) * 8;
        }
        const dx = n.tx - n.x, dz = n.tz - n.z, d = Math.hypot(dx, dz);
        if (d > .4) { n.x += dx / d * dt * 1.2; n.z += dz / d * dt * 1.2; n.walk += dt * 8; }
      }

      updateSocial2d(performance.now());

      // ترافیک
      const nowMs = performance.now();
      for (let i = traffic2d.length - 1; i >= 0; i--) {
        const t = traffic2d[i];
        const spd = t.speed * (G.trafficJam ? .4 : 1);
        if (t.vertical) t.z += spd * dt * t.dir;
        else t.x += spd * dt * t.dir;
        const distP = Math.hypot(t.x - player.x, t.z - player.z);
        if (!driving && distP < 6 && nowMs - lastHonk > 5000) {
          lastHonk = nowMs;
          toast(HONKS2D[Math.floor(Math.random() * HONKS2D.length)]);
        }
        if (!driving && distP < 2 && nowMs > knockUntil) {
          knockUntil = nowMs + 2000;
          G.health -= 5; G.happy -= 3;
          const dx = player.x - t.x, dz = player.z - t.z, dl = Math.hypot(dx, dz) || 1;
          player.x += dx / dl * 3.5; player.z += dz / dl * 3.5;
          toast('🚑 ماشین بهت زد و پخش زمین شدی! راننده: «خودت اومدی جلوم!» (-۵ سلامتی)');
          updateHUD();
        }
        // ماشین به NPC نزدیک شد؟ کنار می‌پره و دعوا!
        if (nowMs > lastArgue + 12000) {
          for (const n of npc2d) {
            if (Math.hypot(t.x - n.x, t.z - n.z) < 2.5) {
              lastArgue = nowMs;
              const dx = n.x - t.x, dz = n.z - t.z, dl = Math.hypot(dx, dz) || 1;
              n.x += dx / dl * 3; n.z += dz / dl * 3;
              n.home.x = n.x; n.home.z = n.z;
              if (Math.hypot(player.x - n.x, player.z - n.z) < 25) {
                const [a1, a2] = randomArgue();
                uiChatter(n.npc.name, a1, '🚗 راننده', a2);
              }
              break;
            }
          }
        }
        if (Math.abs(t.x) > 135 || Math.abs(t.z) > 135) traffic2d.splice(i, 1);
      }

      const t = nearestTarget();
      const hint = $id('interactHint');
      if (t && !driving) {
        hint.style.display = 'block';
        hint.textContent = 'E ⌨️ ' + (t.type === 'npc' ? 'گفتگو با ' + t.npc.name : t.type === 'taxi' ? '🚕 سوار تاکسی شو!' : 'ورود به ' + t.b.name);
      } else hint.style.display = 'none';
    }

    // دوربین نرم دنبال بازیکن
    const tx = driving ? carPos.x : player.x, tz = driving ? carPos.z : player.z;
    const k = Math.min(1, dt * 6.5);
    cam.x += (tx - cam.x) * k;
    cam.z += (tz - cam.z) * k;

    draw(now);
  }

  // ==========================================================
  //                          رندر
  // ==========================================================
  let cx = 0, cy = 0;
  const wx = x => cx + (x - cam.x) * SCALE;
  const wy = z => cy + (z - cam.z) * SCALE;
  const S = () => SCALE;

  // چقدر روزه؟ ۱ = ظهر، ۰ = نصفه‌شب
  function daylight() {
    const h = G.hour + G.minute / 60;
    if (h >= 7 && h <= 17.5) return 1;
    if (h > 17.5 && h < 20.5) return 1 - (h - 17.5) / 3;
    if (h >= 20.5 || h < 5) return 0;
    return (h - 5) / 2;
  }

  function rr(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); }

  // ---------- زمین ----------
  const GROUND = { sunny: 0x9db877, cloudy: 0x8fa974, rainy: 0x6f8a5c, polluted: 0x9d9a6f, snowy: 0xe3ebf0, stormy: 0x67775a };
  function drawGround(dl) {
    const base = GROUND[G.weather] ?? GROUND.sunny;
    ctx.fillStyle = mixHex(0x1b2440, base, .25 + .75 * dl);
    ctx.fillRect(0, 0, VW, VH);
    // بافت نقطه‌ای هم‌راستا با دنیا (حس چمن/خاک)
    const step = 3.4 * SCALE;
    if (step > 9) {
      ctx.fillStyle = `rgba(255,255,255,${.03 + .03 * dl})`;
      const ox = ((wx(0) % step) + step) % step, oy = ((wy(0) % step) + step) % step;
      for (let x = ox - step; x < VW + step; x += step)
        for (let y = oy - step; y < VH + step; y += step)
          if ((Math.round((x - ox) / step) + Math.round((y - oy) / step)) % 3 === 0)
            ctx.fillRect(x, y, 2.2, 2.2);
    }
  }

  // ---------- خیابون‌ها ----------
  function drawRoads(dl) {
    const curb = mixHex(0x2a3049, 0xd6d0bd, .3 + .7 * dl);
    const asphaltMain = mixHex(0x151a2e, 0x5c6469, .28 + .72 * dl);
    const asphaltSide = mixHex(0x151a2e, 0x656d70, .28 + .72 * dl);

    // جدول و پیاده‌رو
    for (const r of ROADS) {
      ctx.fillStyle = curb;
      if (r.dir === 'h') ctx.fillRect(wx(r.from), wy(r.c - r.hw - 2.1), (r.to - r.from) * SCALE, (r.hw + 2.1) * 2 * SCALE);
      else ctx.fillRect(wx(r.c - r.hw - 2.1), wy(r.from), (r.hw + 2.1) * 2 * SCALE, (r.to - r.from) * SCALE);
    }
    // آسفالت
    for (const r of ROADS) {
      ctx.fillStyle = r.main ? asphaltMain : asphaltSide;
      if (r.dir === 'h') ctx.fillRect(wx(r.from), wy(r.c - r.hw), (r.to - r.from) * SCALE, r.hw * 2 * SCALE);
      else ctx.fillRect(wx(r.c - r.hw), wy(r.from), r.hw * 2 * SCALE, (r.to - r.from) * SCALE);
    }
    // خط کنارهٔ سفید + خط‌چین وسط
    for (const r of ROADS) {
      const lw = Math.max(1, SCALE * .12);
      ctx.fillStyle = `rgba(255,255,255,${.10 + .06 * dl})`;
      if (r.dir === 'h') {
        ctx.fillRect(wx(r.from), wy(r.c - r.hw + .5), (r.to - r.from) * SCALE, lw);
        ctx.fillRect(wx(r.from), wy(r.c + r.hw - .6), (r.to - r.from) * SCALE, lw);
      } else {
        ctx.fillRect(wx(r.c - r.hw + .5), wy(r.from), lw, (r.to - r.from) * SCALE);
        ctx.fillRect(wx(r.c + r.hw - .6), wy(r.from), lw, (r.to - r.from) * SCALE);
      }
      ctx.strokeStyle = r.main ? `rgba(233,200,96,${.55 + .35 * dl})` : `rgba(240,240,235,${.35 + .3 * dl})`;
      ctx.lineWidth = Math.max(1.5, SCALE * .16);
      ctx.setLineDash([SCALE * 1.9, SCALE * 1.6]);
      ctx.beginPath();
      if (r.dir === 'h') { ctx.moveTo(wx(r.from), wy(r.c)); ctx.lineTo(wx(r.to), wy(r.c)); }
      else { ctx.moveTo(wx(r.c), wy(r.from)); ctx.lineTo(wx(r.c), wy(r.to)); }
      ctx.stroke();
      ctx.setLineDash([]);
    }
    // خط‌کشی عابر سر چهارراه‌ها
    ctx.fillStyle = `rgba(245,244,228,${.55 + .25 * dl})`;
    for (const h of ROADS) {
      if (h.dir !== 'h') continue;
      for (const v of ROADS) {
        if (v.dir !== 'v') continue;
        if (v.c < h.from || v.c > h.to || h.c < v.from || h.c > v.to) continue;
        // نوارهای عمودی، بالا و پایین تقاطع
        for (const sgn of [-1, 1]) {
          const zEdge = h.c + sgn * (h.hw - .3);
          for (let x = v.c - v.hw + .7; x < v.c + v.hw - 1; x += 1.5)
            ctx.fillRect(wx(x), wy(zEdge - sgn * 1.5), .8 * SCALE, 1.5 * SCALE);
        }
        for (const sgn of [-1, 1]) {
          const xEdge = v.c + sgn * (v.hw - .3);
          for (let z = h.c - h.hw + .7; z < h.c + h.hw - 1; z += 1.5)
            ctx.fillRect(wx(xEdge - sgn * 1.5), wy(z), 1.5 * SCALE, .8 * SCALE);
        }
      }
    }
  }

  // ---------- پیاده‌روی دور ساختمون ----------
  function drawApron(b, dl) {
    const pad = 1.7;
    ctx.fillStyle = mixHex(0x2a3049, 0xcfc9b6, .3 + .7 * dl);
    rr(wx(b.x - b.w / 2 - pad), wy(b.z - b.d / 2 - pad), (b.w + pad * 2) * SCALE, (b.d + pad * 2) * SCALE, SCALE * .8);
    ctx.fill();
  }

  // ---------- درخت ----------
  const TREE_TONES = [[0x386d4a, 0x578b54, 0x76a65e], [0x3e754f, 0x6d9b57, 0x91b66c], [0x315f43, 0x4f8050, 0x6da05a]];
  function drawTree(t, dl) {
    const px = wx(t.x), py = wy(t.z), s = SCALE * t.s * .082;
    if (px < -70 || px > VW + 70 || py < -70 || py > VH + 70) return;
    ctx.save();
    ctx.translate(px, py);
    ctx.scale(s, s);
    ctx.fillStyle = 'rgba(25,49,39,.22)';
    ctx.beginPath(); ctx.ellipse(9, 20, 27, 13, -.2, 0, 7); ctx.fill();
    ctx.fillStyle = '#70543a';
    ctx.beginPath(); ctx.roundRect(-4, 0, 8, 27, 3); ctx.fill();
    const tones = TREE_TONES[t.tone];
    const snowy = G.weather === 'snowy';
    [[-15, -10, 18, tones[0]], [12, -12, 20, tones[1]], [0, -27, 23, tones[2]], [4, -7, 19, tones[1]]]
      .forEach(([x, y, r, c]) => {
        ctx.fillStyle = snowy ? mixHex(c, 0xffffff, .55) : mixHex(0x16203a, c, .3 + .7 * dl);
        ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
      });
    ctx.restore();
  }

  // ---------- تیر چراغ‌برق ----------
  function drawLamp(l, dl) {
    const px = wx(l.x), py = wy(l.z), s = SCALE;
    if (px < -40 || px > VW + 40 || py < -40 || py > VH + 40) return;
    ctx.fillStyle = 'rgba(20,30,25,.25)';
    ctx.beginPath(); ctx.ellipse(px + s * .5, py + s * .35, s * .75, s * .38, 0, 0, 7); ctx.fill();
    ctx.fillStyle = mixHex(0x2b3542, 0x6b7480, .3 + .7 * dl);
    ctx.beginPath(); ctx.arc(px, py, s * .26, 0, 7); ctx.fill();
    ctx.fillRect(px - s * .1, py - s * .95, s * .2, s * .95);
    ctx.fillStyle = dl < .45 && !G.powerOut ? '#ffe6a8' : mixHex(0x3a4450, 0x8d97a3, dl);
    rr(px - s * .42, py - s * 1.25, s * .84, s * .34, s * .17); ctx.fill();
  }

  // ---------- تابلوی مغازه ----------
  const labelQueue = [];
  function queueSign(b) {
    if (b.deco || !b.name) return;
    labelQueue.push(b);
  }
  function drawSigns(dl) {
    for (const b of labelQueue) {
      const px = wx(b.x), py = wy(b.z - b.d / 2);
      const fs = Math.max(11, Math.min(17, SCALE * .95));
      ctx.font = `700 ${fs}px Vazirmatn, Tahoma`;
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      const label = b.name;
      const bw = ctx.measureText(label).width + fs * 1.9 + 20;
      const bx = px - bw / 2, by = py - fs * 2.5;
      ctx.fillStyle = 'rgba(16,22,34,.86)';
      rr(bx, by, bw, fs * 1.9, 8); ctx.fill();
      ctx.strokeStyle = 'rgba(255,209,102,.35)'; ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = '#ffd166';
      ctx.fillText(label, bx + bw - 9, by + fs * .98);
      ctx.textAlign = 'left';
      ctx.font = `${fs}px Vazirmatn, Tahoma`;
      ctx.fillText(b.icon || '', bx + 8, by + fs * .98);
    }
    ctx.textBaseline = 'alphabetic';
    labelQueue.length = 0;
  }

  // ---------- پارک ----------
  function drawPark(b, dl) {
    const x = wx(b.x - b.w / 2), y = wy(b.z - b.d / 2), w = b.w * SCALE, h = b.d * SCALE;
    ctx.fillStyle = 'rgba(20,45,30,.25)';
    rr(x + SCALE * .5, y + SCALE * .8, w, h, SCALE * 2.2); ctx.fill();
    ctx.fillStyle = mixHex(0x1c3326, 0x75aa6b, .3 + .7 * dl);
    rr(x, y, w, h, SCALE * 2.2); ctx.fill();
    ctx.strokeStyle = mixHex(0x243c2c, 0x4d8054, .3 + .7 * dl);
    ctx.lineWidth = Math.max(2, SCALE * .25); ctx.stroke();
    // مسیر خاکی
    ctx.save();
    ctx.beginPath(); ctx.roundRect(x, y, w, h, SCALE * 2.2); ctx.clip();
    ctx.strokeStyle = mixHex(0x3b3524, 0xd9c79c, .3 + .7 * dl);
    ctx.lineWidth = SCALE * 1.5;
    ctx.beginPath();
    ctx.moveTo(x + w * .1, y + h * .92);
    ctx.bezierCurveTo(x + w * .35, y + h * .55, x + w * .65, y + h * .75, x + w * .92, y + h * .12);
    ctx.stroke();
    // بوته‌ها
    for (let i = 0; i < 14; i++) {
      const bx = x + w * (.08 + ((i * 37) % 84) / 100), by = y + h * (.1 + ((i * 53) % 80) / 100);
      ctx.fillStyle = mixHex(0x1e3527, 0x5b9560, .3 + .7 * dl);
      ctx.beginPath(); ctx.arc(bx, by, SCALE * (.35 + (i % 3) * .1), 0, 7); ctx.fill();
    }
    // حوض
    ctx.fillStyle = mixHex(0x1d3550, 0x77b7bd, .3 + .7 * dl);
    ctx.beginPath(); ctx.ellipse(x + w * .68, y + h * .34, SCALE * 2.6, SCALE * 1.7, -.25, 0, 7); ctx.fill();
    ctx.strokeStyle = mixHex(0x2f3a3f, 0xe7dfc8, .3 + .7 * dl); ctx.lineWidth = SCALE * .28; ctx.stroke();
    // نیمکت‌ها
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = mixHex(0x39281c, 0xb36a43, .3 + .7 * dl);
      rr(x + w * .15 + i * SCALE * 3.6, y + h * .68 + (i % 2) * SCALE * 1.6, SCALE * 2.3, SCALE * .6, 3);
      ctx.fill();
    }
    ctx.restore();
    queueSign(b);
  }

  // ---------- ساختمون ----------
  function drawBuilding(b, dl) {
    if (b.kind === 'open') return drawPark(b, dl);
    const x = wx(b.x - b.w / 2), y = wy(b.z - b.d / 2), w = b.w * SCALE, h = b.d * SCALE;
    if (x + w < -60 || x > VW + 60 || y + h < -60 || y > VH + 60) return;

    const tall = (b.h || 5) / 18;                 // ۰..۱ — هرچی بلندتر، سایه بلندتر
    const off = SCALE * (.5 + tall * 1.6);
    const light = .42 + .58 * dl;

    // سایهٔ افتاده
    ctx.fillStyle = `rgba(22,34,32,${.18 + .16 * dl})`;
    rr(x + off, y + off * 1.25, w, h, SCALE * .9); ctx.fill();

    // بدنه
    ctx.fillStyle = mixHex(0x1a2138, b.color, light);
    rr(x, y, w, h, SCALE * .8); ctx.fill();

    // لبهٔ بام (جان‌پناه)
    ctx.strokeStyle = `rgba(0,0,0,${.28})`;
    ctx.lineWidth = Math.max(1.5, SCALE * .2);
    ctx.stroke();
    ctx.save();
    ctx.beginPath(); ctx.roundRect(x, y, w, h, SCALE * .8); ctx.clip();

    // نور خورشید از شمال‌غرب روی بام
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, `rgba(255,255,255,${.18 * dl})`);
    g.addColorStop(1, `rgba(0,0,0,${.14})`);
    ctx.fillStyle = g; ctx.fillRect(x, y, w, h);

    const roofC = tint(b.color, 26);
    const deepC = tint(b.color, -34);

    if (b.kind === 'gable') {                       // شیروونی: تیغهٔ وسط
      ctx.fillStyle = mixHex(0x1a2138, b.color, light * 1.12);
      ctx.beginPath();
      ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w / 2, y + h / 2); ctx.closePath(); ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x, y + h); ctx.lineTo(x + w, y + h); ctx.lineTo(x + w / 2, y + h / 2); ctx.closePath();
      ctx.fillStyle = `rgba(0,0,0,${.10})`; ctx.fill();
      ctx.strokeStyle = `rgba(255,255,255,${.22 * dl + .06})`;
      ctx.lineWidth = Math.max(1.5, SCALE * .16);
      ctx.beginPath(); ctx.moveTo(x + SCALE * .3, y + h / 2); ctx.lineTo(x + w - SCALE * .3, y + h / 2); ctx.stroke();
    } else if (b.kind === 'dome') {                 // گنبد
      ctx.fillStyle = mixHex(0x1a2138, roofC, light);
      ctx.beginPath(); ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) * .33, 0, 7); ctx.fill();
      ctx.strokeStyle = `rgba(233,200,96,${.5 + .3 * dl})`; ctx.lineWidth = Math.max(2, SCALE * .22);
      ctx.beginPath(); ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) * .33, 0, 7); ctx.stroke();
      ctx.fillStyle = `rgba(255,255,255,${.25 * dl})`;
      ctx.beginPath(); ctx.arc(x + w / 2 - Math.min(w, h) * .11, y + h / 2 - Math.min(w, h) * .11, Math.min(w, h) * .11, 0, 7); ctx.fill();
      if (b.id === 'mosque') {                      // مناره‌ها
        for (const [mx2, my2] of [[x + SCALE * .9, y + SCALE * .9], [x + w - SCALE * .9, y + SCALE * .9]]) {
          ctx.fillStyle = mixHex(0x1a2138, 0xf1faee, light);
          ctx.beginPath(); ctx.arc(mx2, my2, SCALE * .5, 0, 7); ctx.fill();
          ctx.fillStyle = '#0f766e';
          ctx.beginPath(); ctx.arc(mx2, my2, SCALE * .22, 0, 7); ctx.fill();
        }
      }
    } else if (b.kind === 'tower') {                // برج: طبقه‌های پنجره‌دار
      ctx.fillStyle = mixHex(0x1a2138, deepC, light);
      rr(x + w * .12, y + h * .12, w * .76, h * .76, SCALE * .5); ctx.fill();
      const cols = Math.max(2, Math.round(b.w / 3)), rows = Math.max(2, Math.round(b.d / 3));
      for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
        const lit = !G.powerOut && dl < .5 && ((i * 7 + j * 13 + b.x) % 3 !== 0);
        ctx.fillStyle = lit ? 'rgba(255,214,140,.92)' : mixHex(0x223047, 0x9fb6c6, light);
        const ww = (w * .76) / cols * .58, hh = (h * .76) / rows * .58;
        ctx.fillRect(x + w * .12 + (i + .21) * (w * .76) / cols, y + h * .12 + (j + .21) * (h * .76) / rows, ww, hh);
      }
      // تانکر آب روی بام
      ctx.fillStyle = mixHex(0x1a2138, 0xb8c1c9, light);
      ctx.beginPath(); ctx.arc(x + w * .84, y + h * .84, SCALE * .55, 0, 7); ctx.fill();
    } else if (b.kind === 'modern') {               // مدرن: نوارهای شیشه‌ای
      for (let i = 1; i < 5; i++) {
        ctx.fillStyle = dl < .5 && !G.powerOut ? 'rgba(255,220,160,.5)' : `rgba(200,235,245,${.2 + .22 * dl})`;
        ctx.fillRect(x + w * .08, y + h * (i / 5) - SCALE * .22, w * .84, SCALE * .44);
      }
      ctx.strokeStyle = `rgba(255,255,255,${.2 + .2 * dl})`; ctx.lineWidth = Math.max(1, SCALE * .12);
      ctx.strokeRect(x + w * .08, y + h * .08, w * .84, h * .84);
    } else if (b.kind === 'awning') {               // سایبون راه‌راه جلوی مغازه
      const ah = Math.min(h * .3, SCALE * 2.2);
      for (let i = 0; x + i * SCALE * .9 < x + w; i++) {
        ctx.fillStyle = i % 2 ? mixHex(0x1a2138, 0xfaf4e6, light) : mixHex(0x1a2138, 0xd1584f, light);
        ctx.fillRect(x + i * SCALE * .9, y + h - ah, SCALE * .9, ah);
      }
      ctx.fillStyle = `rgba(0,0,0,${.2})`;
      ctx.fillRect(x, y + h - ah, w, SCALE * .22);
      // ویترین
      ctx.fillStyle = dl < .5 && !G.powerOut ? 'rgba(255,224,164,.85)' : `rgba(190,225,235,${.35 + .25 * dl})`;
      ctx.fillRect(x + w * .12, y + h - ah - SCALE * 1.5, w * .76, SCALE * 1.1);
    } else {                                        // flat
      ctx.fillStyle = mixHex(0x1a2138, deepC, light);
      rr(x + w * .1, y + h * .1, w * .8, h * .8, SCALE * .4); ctx.fill();
      // کولر و آنتن روی بام
      ctx.fillStyle = mixHex(0x1a2138, 0xc9ccd1, light);
      ctx.fillRect(x + w * .2, y + h * .2, SCALE * 1.1, SCALE * .9);
      ctx.fillRect(x + w * .62, y + h * .58, SCALE * .9, SCALE * .8);
      ctx.strokeStyle = mixHex(0x1a2138, 0x8b9096, light); ctx.lineWidth = Math.max(1, SCALE * .1);
      ctx.beginPath(); ctx.arc(x + w * .78, y + h * .24, SCALE * .55, .6, 3.5); ctx.stroke();
      // نورگیرهای سقفی
      const lit = dl < .5 && !G.powerOut;
      ctx.fillStyle = lit ? 'rgba(255,220,150,.8)' : `rgba(205,232,240,${.25 + .3 * dl})`;
      for (let i = 0; i < 3; i++)
        ctx.fillRect(x + w * .16 + i * w * .26, y + h * .74, w * .16, SCALE * .5);
    }

    // در ورودی (سمت جنوب)
    ctx.fillStyle = mixHex(0x1a2138, 0x5c3a21, light);
    ctx.fillRect(wx(b.x) - SCALE * .75, y + h - SCALE * .55, SCALE * 1.5, SCALE * .55);
    ctx.fillStyle = `rgba(255,209,102,${dl < .5 ? .8 : .3})`;
    ctx.fillRect(wx(b.x) - SCALE * .75, y + h - SCALE * .62, SCALE * 1.5, SCALE * .12);

    ctx.restore();

    // ---- جزئیات ویژهٔ چند مغازه (مثل نسخهٔ قبل) ----
    if (b.id === 'flower') {
      const fc = ['#ff2d78', '#ffd166', '#ffffff', '#c084fc', '#ff6b35', '#ff8fab'];
      for (let i = 0; i < 6; i++) {
        const fx = wx(b.x - b.w / 2 + 1 + i * (b.w - 2) / 5), fy = wy(b.z + b.d / 2 + 1.3);
        ctx.fillStyle = '#2d6a4f'; ctx.fillRect(fx - SCALE * .09, fy - SCALE * .5, SCALE * .18, SCALE * .9);
        ctx.fillStyle = fc[i];
        ctx.beginPath(); ctx.arc(fx, fy - SCALE * .55, SCALE * .38, 0, 7); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(fx, fy - SCALE * .55, SCALE * .13, 0, 7); ctx.fill();
      }
    }
    if (b.id === 'dealership') {
      const sc = ['#e63946', '#ffffff', '#1d3557'];
      for (let i = 0; i < 3; i++) {
        const fx = b.x - b.w / 2 + 3 + i * (b.w - 6) / 2, fz = b.z + b.d / 2 + 3;
        ctx.fillStyle = mixHex(0x2a3049, 0xdddddd, .3 + .7 * dl);
        ctx.beginPath(); ctx.arc(wx(fx), wy(fz), SCALE * 2.2, 0, 7); ctx.fill();
        drawCar2d(fx, fz, sc[i], -.5 + i * .5, true);
      }
    }
    if (b.id === 'robotics') {
      const lx = wx(b.x), ly = wy(b.z), r = Math.min(w, h) * .28;
      ctx.save();
      ctx.shadowBlur = 16; ctx.shadowColor = '#6a4c9c'; ctx.fillStyle = '#6a4c9c';
      ctx.beginPath(); ctx.arc(lx, ly, r, Math.PI / 2, Math.PI * 1.5); ctx.fill();
      ctx.shadowColor = '#e8a83c'; ctx.fillStyle = '#e8a83c';
      ctx.beginPath(); ctx.arc(lx, ly, r, -Math.PI / 2, Math.PI / 2); ctx.fill();
      ctx.restore();
      ctx.fillStyle = '#14101f';
      ctx.font = `bold ${Math.round(r)}px Vazirmatn, Tahoma`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('ن', lx, ly + r * .08);
      ctx.textBaseline = 'alphabetic';
    }

    queueSign(b);
  }

  // ---------- آدمک نمای بالا ----------
  function drawPerson(px, py, shirt, look = {}, angle = Math.PI / 2, walk = 0, dl = 1) {
    const s = SCALE * 1.6;
    if (px < -40 || px > VW + 40 || py < -40 || py > VH + 40) return;
    // سایه (بدون چرخش، روی زمین)
    ctx.fillStyle = `rgba(15,25,20,${.2 + .12 * dl})`;
    ctx.beginPath(); ctx.ellipse(px + s * .18, py + s * .3, s * .78, s * .5, 0, 0, 7); ctx.fill();

    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(angle - Math.PI / 2);
    const sw = Math.sin(walk) * s * .5;
    const shade = c => mixHex(0x1c2338, c, .35 + .65 * dl);
    const shirtC = typeof shirt === 'number' ? shade(shirt) : shirt;
    const skin = mixHex(0x2a2438, 0xf0c8a0, .35 + .65 * dl);

    // دست‌ها
    ctx.fillStyle = shirtC;
    ctx.beginPath(); ctx.ellipse(-s * .68, sw, s * .24, s * .36, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.ellipse(s * .68, -sw, s * .24, s * .36, 0, 0, 7); ctx.fill();
    ctx.fillStyle = skin;
    ctx.beginPath(); ctx.arc(-s * .68, sw + s * .26, s * .16, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(s * .68, -sw + s * .26, s * .16, 0, 7); ctx.fill();
    // تنه
    ctx.fillStyle = shirtC;
    ctx.beginPath(); ctx.ellipse(0, 0, s * .62, s * .48, 0, 0, 7); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = Math.max(1, s * .09); ctx.stroke();
    // سر
    const style = look.style || 'hair';
    if (style === 'scarf') {
      ctx.fillStyle = mixHex(0x1c2338, look.accColor ?? 0x6a0572, .35 + .65 * dl);
      ctx.beginPath(); ctx.arc(0, s * .06, s * .45, 0, 7); ctx.fill();
      ctx.fillStyle = skin;
      ctx.beginPath(); ctx.arc(0, s * .16, s * .27, 0, 7); ctx.fill();
    } else if (style === 'helmet') {
      ctx.fillStyle = mixHex(0x1c2338, look.accColor ?? 0xe63946, .35 + .65 * dl);
      ctx.beginPath(); ctx.arc(0, s * .06, s * .41, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.45)';
      ctx.beginPath(); ctx.arc(0, s * .22, s * .2, 0, Math.PI); ctx.fill();
    } else if (style === 'cap') {
      ctx.fillStyle = skin;
      ctx.beginPath(); ctx.arc(0, s * .06, s * .36, 0, 7); ctx.fill();
      ctx.fillStyle = mixHex(0x1c2338, look.accColor ?? 0x1d3557, .35 + .65 * dl);
      ctx.beginPath(); ctx.arc(0, s * .03, s * .33, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, s * .32, s * .28, s * .18, 0, 0, Math.PI); ctx.fill();
    } else if (style === 'bald') {
      ctx.fillStyle = skin;
      ctx.beginPath(); ctx.arc(0, s * .06, s * .36, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(160,160,160,.85)'; ctx.lineWidth = Math.max(1.2, s * .14);
      ctx.beginPath(); ctx.arc(0, s * .06, s * .32, Math.PI * .15, Math.PI * .85); ctx.stroke();
    } else {
      ctx.fillStyle = skin;
      ctx.beginPath(); ctx.arc(0, s * .08, s * .36, 0, 7); ctx.fill();
      ctx.fillStyle = mixHex(0x1c2338, look.hair ?? 0x2b1d0e, .35 + .65 * dl);
      ctx.beginPath(); ctx.arc(0, 0, s * .33, Math.PI, 0); ctx.fill();
      ctx.beginPath(); ctx.ellipse(0, 0, s * .33, s * .2, 0, Math.PI, 0); ctx.fill();
    }
    if (look.moustache) {
      ctx.fillStyle = 'rgba(45,32,20,.9)';
      ctx.fillRect(-s * .16, s * .3, s * .32, s * .07);
    }
    ctx.restore();
  }

  // ---------- ماشین ----------
  function drawCar2d(x, z, color, angle = 0, small = false, dl = 1) {
    const px = wx(x), py = wy(z), s = SCALE * (small ? .85 : 1);
    if (px < -60 || px > VW + 60 || py < -60 || py > VH + 60) return;
    ctx.fillStyle = `rgba(15,22,20,${.22 + .12 * dl})`;
    ctx.beginPath(); ctx.ellipse(px + s * .3, py + s * .4, s * 2.05, s * 1.15, 0, 0, 7); ctx.fill();
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(angle);
    // چرخ‌ها
    ctx.fillStyle = '#1c1c1f';
    for (const [wxp, wzp] of [[-1.2, -1.05], [1.2, -1.05], [-1.2, 1.05], [1.2, 1.05]])
      ctx.fillRect(wxp * s - s * .32, wzp * s - s * .16, s * .64, s * .32);
    // بدنه
    ctx.fillStyle = color;
    rr(-1.95 * s, -1.02 * s, 3.9 * s, 2.04 * s, s * .42); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = Math.max(1.2, s * .12); ctx.stroke();
    // شیشه‌ها
    ctx.fillStyle = mixHex(0x121a26, 0x28405c, .4 + .6 * dl);
    rr(-.85 * s, -.8 * s, 1.7 * s, 1.6 * s, s * .26); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.16)';
    rr(-.75 * s, -.72 * s, .55 * s, 1.44 * s, s * .2); ctx.fill();
    // چراغ‌ها
    ctx.fillStyle = dl < .5 ? '#fff3c4' : '#ffe8a3';
    ctx.fillRect(1.65 * s, -.82 * s, s * .28, s * .42);
    ctx.fillRect(1.65 * s, .4 * s, s * .28, s * .42);
    ctx.fillStyle = '#c1121f';
    ctx.fillRect(-1.9 * s, -.8 * s, s * .22, s * .38);
    ctx.fillRect(-1.9 * s, .42 * s, s * .22, s * .38);
    ctx.restore();
  }

  // ---------- پلاک اسم NPC ----------
  function drawNameTag(x, z, name, marriageable) {
    const px = wx(x), py = wy(z);
    if (px < -80 || px > VW + 80 || py < -60 || py > VH + 60) return;
    const fs = Math.max(10, Math.min(14, SCALE * .8));
    ctx.font = `${fs}px Vazirmatn, Tahoma`;
    ctx.textAlign = 'center';
    const tw = ctx.measureText(name).width;
    ctx.fillStyle = 'rgba(12,17,28,.7)';
    rr(px - tw / 2 - 7, py - SCALE * 1.9 - fs, tw + 14, fs * 1.55, 7); ctx.fill();
    ctx.fillStyle = marriageable ? '#ffb3c6' : '#ffd166';
    ctx.fillText(name, px, py - SCALE * 1.9 + fs * .18);
  }

  // ---------- حلقهٔ رسم ----------
  function draw(now) {
    cx = VW / 2; cy = VH / 2;
    const dl = daylight();
    const dark = G.powerOut ? Math.max(dl, 0) * .35 : dl;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawGround(dark);
    drawGroundDecor(dark);
    drawRoads(dark);

    // پیاده‌روها زیر همه
    for (const b of BUILDINGS) if (b.kind !== 'open') drawApron(b, dark);

    // ساختمون‌ها از شمال به جنوب (حس عمق)
    const sorted = BUILDINGS.slice().sort((a, b) => (a.z + a.d / 2) - (b.z + b.d / 2));
    for (const b of sorted) drawBuilding(b, dark);

    for (const t of trees) drawTree(t, dark);
    for (const l of lamps) drawLamp(l, dark);

    // موجودات متحرک، مرتب‌شده بر اساس z
    const actors = [];
    for (const t of traffic2d) actors.push({ z: t.z, kind: 'car', o: t });
    for (const n of npc2d) actors.push({ z: n.z, kind: 'npc', o: n });
    const myCar = activeCarData();
    if (myCar) actors.push({ z: carPos.z, kind: 'mycar', o: myCar });
    if (!driving) actors.push({ z: player.z, kind: 'player' });
    actors.sort((a, b) => a.z - b.z);

    for (const a of actors) {
      if (a.kind === 'car') {
        const t = a.o;
        drawCar2d(t.x, t.z, t.color, t.vertical ? (t.dir > 0 ? Math.PI / 2 : -Math.PI / 2) : (t.dir > 0 ? 0 : Math.PI), false, dark);
        if (t.taxi) {
          ctx.fillStyle = '#111';
          ctx.font = `bold ${Math.max(9, SCALE * .7)}px Vazirmatn, Tahoma`;
          ctx.textAlign = 'center';
          ctx.fillText('تاکسی', wx(t.x), wy(t.z) + SCALE * .3);
        }
      } else if (a.kind === 'npc') {
        const n = a.o;
        const dx = n.tx - n.x, dz = n.tz - n.z;
        const ang = Math.hypot(dx, dz) > .4 ? Math.atan2(dz, dx) : Math.PI / 2;
        drawPerson(wx(n.x), wy(n.z), n.npc.color, n.npc.look, ang, n.walk, dark);
      } else if (a.kind === 'mycar') {
        drawCar2d(carPos.x, carPos.z, hexColor(a.o.color), carPos.angle || 0, false, dark);
      } else {
        drawPerson(wx(player.x), wy(player.z), 0xe63946, { style: 'cap', accColor: 0x1d3557 }, player.angle, player.walk, dark);
      }
    }

    // پلاک اسم‌ها و تابلوها روی همه
    for (const n of npc2d) drawNameTag(n.x, n.z, n.npc.name, n.npc.marriageable);
    drawSigns(dark);
    ctx.textAlign = 'left';

    // ---------- شب ----------
    if (dark < 1) {
      const a = (1 - dark) * .44;
      const g = ctx.createLinearGradient(0, 0, 0, VH);
      g.addColorStop(0, `rgba(10,16,44,${a})`);
      g.addColorStop(1, `rgba(6,10,30,${a * 1.08})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, VW, VH);
      // نورهای شب (هالهٔ چراغ‌ها + نور خود بازیکن)
      if (dark < .55) {
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        if (!G.powerOut) {
          for (const l of lamps) {
            const px = wx(l.x), py = wy(l.z - 1.1), r = SCALE * 4.2;
            if (px < -r || px > VW + r || py < -r || py > VH + r) continue;
            const rg = ctx.createRadialGradient(px, py, 0, px, py, r);
            rg.addColorStop(0, `rgba(255,206,124,${.19 * (1 - dark)})`);
            rg.addColorStop(1, 'rgba(255,206,124,0)');
            ctx.fillStyle = rg;
            ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill();
          }
        }
        // چراغ‌قوهٔ خود بازیکن — تو خاموشی هم روشنه
        const ppx = wx(driving ? carPos.x : player.x), ppy = wy(driving ? carPos.z : player.z);
        const pr = SCALE * (G.powerOut ? 7 : 5.2);
        const pg = ctx.createRadialGradient(ppx, ppy, 0, ppx, ppy, pr);
        pg.addColorStop(0, `rgba(198,220,255,${(G.powerOut ? .24 : .16) * (1 - dark)})`);
        pg.addColorStop(1, 'rgba(198,220,255,0)');
        ctx.fillStyle = pg;
        ctx.beginPath(); ctx.arc(ppx, ppy, pr, 0, 7); ctx.fill();
        ctx.restore();
      }
    }

    // ---------- هوا ----------
    if (G.weather === 'rainy' || G.weather === 'stormy' || G.weather === 'snowy') {
      const snow = G.weather === 'snowy';
      ctx.strokeStyle = snow ? '#fff' : 'rgba(170,200,240,.65)';
      ctx.fillStyle = 'rgba(255,255,255,.9)';
      ctx.lineWidth = 1.4;
      for (const d of drops) {
        d.y += dtDrop(d.s, snow);
        if (d.y > 1) { d.y = 0; d.x = Math.random(); }
        const px = d.x * VW, py = d.y * VH;
        if (snow) { ctx.beginPath(); ctx.arc(px, py, 2.3 * d.s, 0, 7); ctx.fill(); }
        else { ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px - 2.5, py + 13 * d.s); ctx.stroke(); }
      }
    }
    if (G.weather === 'polluted') {
      ctx.fillStyle = 'rgba(150,130,80,.26)';
      ctx.fillRect(0, 0, VW, VH);
    }
    if (G.weather === 'stormy') {
      ctx.fillStyle = 'rgba(30,35,60,.22)';
      ctx.fillRect(0, 0, VW, VH);
    }

    // ---------- وینیت ----------
    const vg = ctx.createRadialGradient(VW / 2, VH / 2, Math.min(VW, VH) * .34, VW / 2, VH / 2, Math.max(VW, VH) * .78);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(5,12,16,.42)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, VW, VH);
  }

  requestAnimationFrame(t => { last = t; frame(t); });

  // ---------- API مشترک با نسخهٔ سه‌بعدی ----------
  // مختصات صفحه‌ای بالای سر (برای حباب گفتگو)
  W.screenOf = who => {
    if (who === 'player') return { x: wx(player.x), y: wy(player.z) - SCALE * 2.2 };
    const n = npc2d.find(m => m.npc.id === who);
    if (!n) return null;
    return { x: wx(n.x), y: wy(n.z) - SCALE * 2.2 };
  };
  W.onNewDay = () => {};
  W.onCarChanged = () => { carPos.x = player.x + 5; carPos.z = player.z; };
  W.onMarried = () => {};
  W.requestLock = () => {};
  W.teleport = (x, z) => { player.x = x; player.z = z; cam.x = x; cam.z = z; driving = false; };
  W.nearTaxi = nearTaxi;
  // کات‌سین قرار: دوتایی جلوی کافه
  W.dateCutscene = (npc, done) => {
    const cafe = buildingById('cafe');
    driving = false;
    player.x = cafe.x - 1.5; player.z = cafe.z + cafe.d / 2 + 4;
    G.px = player.x; G.pz = player.z;
    cam.x = player.x; cam.z = player.z;
    const n = npc2d.find(m => m.npc.id === npc.id);
    if (n) {
      n.x = cafe.x + 1.5; n.z = cafe.z + cafe.d / 2 + 4;
      n.tx = n.x; n.tz = n.z; n.t = 30;
    }
    setTimeout(() => { if (n) n.t = 0; done(); }, 4300);
  };
  // کات‌سین کار: جلوی محل کار
  W.workCutscene = (job, done) => {
    const b = buildingById(job.place || (job.remote ? 'home' : 'restaurant')) || buildingById('home');
    driving = false;
    player.x = b.x; player.z = b.z + b.d / 2 + 3;
    G.px = player.x; G.pz = player.z;
    cam.x = player.x; cam.z = player.z;
    setTimeout(done, 3500);
  };
  W.destroy = () => {
    running = false;
    clearInterval(trafficTimer);
    removeEventListener('keydown', keydown);
    removeEventListener('keyup', keyup);
    removeEventListener('resize', resize);
    canvas.remove();
  };
  return W;
}
