// ===== events.js — رویدادهای رندوم روزانه + آب‌وهوا =====
'use strict';

const WEATHERS = [
  { id:'sunny',   name:'آفتابی ☀️',  p:.30 },
  { id:'cloudy',  name:'ابری ⛅',    p:.20 },
  { id:'rainy',   name:'بارانی 🌧️', p:.15 },
  { id:'polluted',name:'آلوده 😷',   p:.18 },
  { id:'snowy',   name:'برفی ❄️',   p:.07 },
  { id:'stormy',  name:'طوفانی 🌪️', p:.10 },
];
function rollWeather() {
  let r = Math.random(), acc = 0;
  for (const w of WEATHERS) { acc += w.p; if (r <= acc) return w.id; }
  return 'sunny';
}
function weatherName(id) { return (WEATHERS.find(w => w.id === id) || WEATHERS[0]).name; }

// رویدادها: هرکدوم effect روی state + پیام
const RANDOM_EVENTS = [
  { id:'rain', name:'بارون شدید', fn:() => {
      G.weather = 'rainy';
      G.happy += 5;
      return '🌧️ بارون گرفت! جوب‌ها پر شد، ترافیک قفل شد، ولی هوا تمیز شد. (+۵ شادی)';
    } },
  { id:'pollution', name:'آلودگی هوا', fn:() => {
      G.weather = 'polluted';
      G.health -= 8;
      return '😷 شاخص آلودگی قرمز شد! مدارس تعطیل، ریه‌ها ناراضی. (-۸ سلامتی)';
    } },
  { id:'traffic', name:'ترافیک سنگین', fn:() => {
      G.trafficJam = true;
      G.happy -= 5;
      return '🚗🚙🚕 ترافیک امروز افسانه‌ایه! سرعت ماشین‌ها نصف شد. (-۵ شادی)';
    } },
  { id:'blackout', name:'قطعی برق', fn:() => {
      G.powerOut = true;
      G.happy -= 4;
      return '⚡ برق رفت! نه طبق جدول، همینجوری. (-۴ شادی)';
    } },
  { id:'internet', name:'قطعی اینترنت', fn:() => {
      G.internetDown = true;
      return '📵 اینترنت ملی هم قطع شد! دورکارها امروز حقوق ندارن. یوتیوبرها در سوگ.';
    } },
  { id:'carbreak', name:'خرابی ماشین', fn:() => {
      if (!G.cars.length) return null;
      G.damage = Math.min(100, G.damage + 30);
      return '🔧 ماشین ریپ می‌زنه! مکانیک: «قطعه‌ش نیست، از دبی میاد.» (+۳۰ خرابی)';
    } },
  { id:'phonecrack', name:'ترک گوشی', fn:() => {
      if (!G.phone || G.phoneBroken) return null;
      G.phoneBroken = true;
      return '📱💔 گوشیت از جیبت افتاد! صفحه‌ش شد نقشه عنکبوت. (برای کار باید تعمیرش کنی — موبایل‌فروشی)';
    } },
  { id:'guest', name:'مهمون سرزده', fn:() => {
      const cost = Math.round(3000000 * dailyInflationFactor() ** G.dayIndex);
      addMoney(-cost);
      G.happy += 8;
      return '🚪 مهمون سرزده اومد! شام و میوه و آجیل... (-' + faMoney(cost) + '، +۸ شادی)';
    } },
  { id:'holiday', name:'تعطیلی ناگهانی', fn:() => {
      G.happy += 10;
      return '🎉 فردا تعطیل رسمی اعلام شد! هیچکس نمی‌دونه چرا، ولی کسی هم اعتراض نداره. (+۱۰ شادی)';
    } },
  { id:'roadwork', name:'پروژه عمرانی', fn:() => {
      G.roadClosed = true;
      return '🚧 خیابون اصلی بسته شد! پروژه عمرانی؛ اتمام: «به زودی» (تعریف نشده).';
    } },
  { id:'bonus', name:'پول غیرمنتظره', fn:() => {
      const amount = Math.round((2 + Math.random() * 8) * 1000000);
      addMoney(amount);
      return '💸 ' + faMoney(amount) + ' یارانه/سود سهام عدالت واریز شد! هیچکس نمی‌دونه از کجا!';
    } },
  { id:'fine', name:'جریمه رانندگی', fn:() => {
      if (!G.cars.length) return null;
      const amount = 1200000;
      addMoney(-amount);
      return '📸 دوربین جریمه‌ات کرد: «سرعت غیرمجاز» — تو ترافیک؟! (-' + faMoney(amount) + ')';
    } },
  { id:'dollarShock', name:'شوک ارزی', fn:() => {
      G.eco.dollar = Math.round(G.eco.dollar * (1.04 + Math.random() * .06));
      return '🚨 شوک ارزی! دلار پرید: ' + faMoney(G.eco.dollar) + '! صرافی‌ها کرکره رو کشیدن پایین.';
    } },
  { id:'snow', name:'برف ناگهانی', fn:() => {
      G.weather = 'snowy';
      G.happy += 6;
      return '❄️ برف اومد! تهران قشنگ شد و مدیریت شهری غافلگیر... مثل هر سال. (+۶ شادی)';
    } },
];

// تیک روزانه: آب‌وهوا، رویداد، هزینه‌ها
function dailyTick() {
  const messages = [];
  // غیبت از کار (قبل از ریست روز)
  if (G.job && !G.workedToday) {
    G.missedWork = (G.missedWork || 0) + 1;
    if (G.missedWork >= 3) {
      const jobName = JOBS.find(j => j.id === G.job)?.name || 'کارت';
      G.job = null; G.missedWork = 0;
      messages.push('🔥 اخراج شدی از ' + jobName + '! رئیس: «گفتم میای یا نه! برو یکی دیگه رو پیدا کن!»');
      G.happy -= 12;
    } else if (G.missedWork >= 2) {
      messages.push('😡 صاحب‌کار زنگ زد: «دو روزه پیدات نیست! همین الان میای وگرنه اخراجی!!»');
      G.happy -= 8;
    } else {
      messages.push('⚠️ دیروز سر کار نرفتی! رئیس یادداشت کرده...');
    }
  }
  G.dayIndex++;
  G.stats.daysPlayed++;
  G.workedToday = false;
  // ریست شرایط موقت
  G.trafficJam = G.internetDown = G.powerOut = G.roadClosed = false;

  // آب‌وهوا
  G.weather = rollWeather();
  messages.push('🌤️ هوای امروز: ' + weatherName(G.weather));
  if (G.weather === 'polluted') { G.health -= 3; }
  if (G.weather === 'stormy') { G.happy -= 3; messages.push('🌪️ طوفان! درها و پنجره‌ها رو ببندید!'); }

  // اقتصاد
  messages.push(...economyDailyTick());

  // ---------- زندگی مشترک: خرج خانواده و فشار کار ----------
  if (G.married) {
    const wife = NPCS.find(n => n.id === G.married);
    const wname = wife ? wife.name.split(' (')[0] : 'همسرت';
    const family = Math.round((G.childName ? 9000000 : 5000000) * G.eco.housingCoef);
    addMoney(-family);
    messages.push('👨‍👩‍👧 خرج خانواده امروز: ' + faMoney(family) + (G.childName ? ' (با بچه دو برابر شد!)' : ''));
    if (!G.job) {
      G.noJobDays = (G.noJobDays || 0) + 1;
      addAffection(G.married, -3);
      G.happy -= 4;
      const nag = [
        wname + ': «کِی می‌خوای بری سر کار؟ خرج زندگی از آسمون نمیاد که!»',
        wname + ': «مامانم پرسید دامادمون کجا کار می‌کنه، نمی‌دونستم چی بگم!»',
        wname + ': «قبض‌ها اومده... من که حقوق نمی‌گیرم!»',
      ];
      messages.push('😤 ' + nag[G.noJobDays % nag.length] + ' (-۳ علاقه)');
    } else {
      G.noJobDays = 0;
      if (G.workedToday === false && G.missedWork > 0) messages.push('😐 ' + wname + ': «امروز نرفتی سر کار؟ چیزی شده؟»');
    }
    if (G.childName && !G.childGrown) {
      const left = 10 - (G.dayIndex - (G.childBornDay ?? G.dayIndex));
      if (left === 10 || left === 3) messages.push('👶 ' + G.childName + ' داره بزرگ میشه! ' + fa(left) + ' روز دیگه می‌ره مدرسه.');
    }
  }

  // رویداد رندوم (۱ تا ۲ در روز)
  const count = Math.random() < .3 ? 2 : 1;
  for (let i = 0; i < count; i++) {
    const ev = RANDOM_EVENTS[Math.floor(Math.random() * RANDOM_EVENTS.length)];
    const msg = ev.fn();
    if (msg) messages.push(msg);
  }

  // اجاره (اول هر ماه)
  const sd = shamsiDate(G.dayIndex);
  if (sd.day === 1 && !G.homeOwned) {
    const rent = rentToday();
    addMoney(-rent);
    messages.push('🏠 اجاره ماهانه پرداخت شد: ' + faMoney(rent) + '. صاحبخونه: «سال دیگه میره بالا‌ها!»');
  }

  // سود بانکی
  if (G.bank.deposit > 0) {
    const interest = Math.round(G.bank.deposit * .20 / 365);
    G.bank.deposit += interest;
  }
  if (G.bank.loan > 0) {
    const due = Math.round(G.bank.loan * .04 / 30);
    addMoney(-due);
    messages.push('🏦 قسط وام: -' + faMoney(due));
  }

  // خرج بچه
  if (G.childName) {
    const cost = Math.round(2000000 * dailyInflationFactor() ** G.dayIndex);
    addMoney(-cost);
    G.happy += 2;
  }

  // 📋 تسک‌لیست صبحگاهی
  const todo = [];
  if (G.job) todo.push('🧰 ساعت ۱۰ برو سر کار!');
  else todo.push('💼 دنبال کار بگرد (بقالی، کافه، رستوران، بانک...)');
  const sd2 = shamsiDate(G.dayIndex);
  if (!G.homeOwned && sd2.day >= 27) todo.push('🏠 اول ماه اجاره‌ست! پول جور کن!');
  if (G.energy < 40) todo.push('😴 انرژیت کمه، خواب یادت نره!');
  if (G.health < 40) todo.push('🏥 سلامتیت پایینه، برو دکتر!');
  if (G.married && getAffection(G.married) < 60) todo.push('💐 همسرت دلخوره، یه گل بگیر براش!');
  messages.push('📋 تسک‌های امروز: ' + todo.join(' | '));

  // افت طبیعی
  G.energy -= 5; G.happy -= 2;
  if (G.happy < 20) { G.health -= 3; }
  clampStats();
  return messages;
}
