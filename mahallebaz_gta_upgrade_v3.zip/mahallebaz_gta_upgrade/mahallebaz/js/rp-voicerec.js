// ===== rp-voicerec.js — صداگذاری دستی: خودت برای شخصیت‌ها صدا ضبط کن =====
// صداها در IndexedDB مرورگر (لوکال) ذخیره میشن — بعداً میشه به سرور منتقلشون کرد.
'use strict';

/* ---------------- ذخیره‌سازی لوکال (IndexedDB) ---------------- */
const VDB_NAME = 'mahallebaz-voices', VDB_STORE = 'clips';
let _vdb = null;
function vdb() {
  return new Promise((res, rej) => {
    if (_vdb) return res(_vdb);
    const req = indexedDB.open(VDB_NAME, 1);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(VDB_STORE)) db.createObjectStore(VDB_STORE);
    };
    req.onsuccess = e => { _vdb = e.target.result; res(_vdb); };
    req.onerror = e => rej(e);
  });
}
async function voiceSave(key, blob) {
  const db = await vdb();
  return new Promise((res, rej) => {
    const tx = db.transaction(VDB_STORE, 'readwrite');
    tx.objectStore(VDB_STORE).put(blob, key);
    tx.oncomplete = () => res(true);
    tx.onerror = rej;
  });
}
async function voiceLoad(key) {
  const db = await vdb();
  return new Promise((res) => {
    const tx = db.transaction(VDB_STORE, 'readonly');
    const rq = tx.objectStore(VDB_STORE).get(key);
    rq.onsuccess = () => res(rq.result || null);
    rq.onerror = () => res(null);
  });
}
async function voiceDelete(key) {
  const db = await vdb();
  return new Promise(res => {
    const tx = db.transaction(VDB_STORE, 'readwrite');
    tx.objectStore(VDB_STORE).delete(key);
    tx.oncomplete = () => res(true);
    tx.onerror = () => res(false);
  });
}
async function voiceKeys() {
  const db = await vdb();
  return new Promise(res => {
    const tx = db.transaction(VDB_STORE, 'readonly');
    const rq = tx.objectStore(VDB_STORE).getAllKeys();
    rq.onsuccess = () => res(rq.result || []);
    rq.onerror = () => res([]);
  });
}

/* ---------------- ضبط صدا با میکروفن ---------------- */
let _rec = null, _chunks = [], _recStream = null;
async function recStart() {
  if (_rec) return false;
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  _recStream = stream;
  _chunks = [];
  _rec = new MediaRecorder(stream);
  _rec.ondataavailable = e => { if (e.data.size) _chunks.push(e.data); };
  _rec.start();
  return true;
}
function recStop() {
  return new Promise(res => {
    if (!_rec) return res(null);
    _rec.onstop = () => {
      const blob = new Blob(_chunks, { type: _rec.mimeType || 'audio/webm' });
      _recStream?.getTracks().forEach(t => t.stop());
      _rec = null; _recStream = null; _chunks = [];
      res(blob);
    };
    _rec.stop();
  });
}

/* ---------------- پخش صدای ضبط‌شده ---------------- */
const _clipUrls = new Map();
async function playClip(key) {
  let url = _clipUrls.get(key);
  if (!url) {
    const blob = await voiceLoad(key);
    if (!blob) return false;
    url = URL.createObjectURL(blob);
    _clipUrls.set(key, url);
  }
  const a = new Audio(url);
  a.volume = .9;
  a.play().catch(() => {});
  return true;
}
// آیا برای این شخصیت صدای ضبط‌شده داریم؟
const _clipIndex = new Set();
async function refreshClipIndex() {
  const keys = await voiceKeys();
  _clipIndex.clear();
  keys.forEach(k => _clipIndex.add(k));
  return keys.length;
}
function hasClip(npcId, slot) { return _clipIndex.has(npcId + '::' + slot); }

/* ---------------- جمله‌های استاندارد هر شخصیت ---------------- */
const VOICE_SLOTS = [
  { id: 'greet',   label: '👋 سلام و احوال‌پرسی',  hint: 'مثلاً: سلام! خوش اومدی!' },
  { id: 'happy',   label: '😄 خوشحالی',            hint: 'مثلاً: چه خوب شد! دمت گرم!' },
  { id: 'sad',     label: '😞 ناراحتی',            hint: 'مثلاً: ای بابا... حیف شد.' },
  { id: 'angry',   label: '😠 عصبانیت',            hint: 'مثلاً: این چه کاری بود آخه؟!' },
  { id: 'bye',     label: '👋 خداحافظی',           hint: 'مثلاً: خدانگهدار، بازم بیا!' },
];

/* ---------------- پنل صداگذاری (داخل گادمود) ---------------- */
function openVoiceStudio(preNpc) {
  refreshClipIndex().then(() => {
    openPanel('🎙️ استودیوی صداگذاری', p => {
      noteP(p, 'برای هر شخصیت صدای خودت رو ضبط کن! صداها تو مرورگر خودت ذخیره میشن (لوکال) و بعداً میشه روی سرور برد.');
      const target = preNpc || VS_STATE.npc;
      // انتخاب شخصیت
      const h = document.createElement('h4');
      h.textContent = '👤 شخصیت: ' + (target ? target.name.split(' (')[0] : 'انتخاب نشده');
      p.appendChild(h);
      if (!target) {
        NPCS.slice(0, 30).forEach(n => {
          const cnt = VOICE_SLOTS.filter(s => hasClip(n.id, s.id)).length;
          actionRow(p, (cnt ? '🎙️ ' : '⬜ ') + n.name.split(' (')[0],
            cnt ? fa(cnt) + ' از ' + fa(VOICE_SLOTS.length) + ' صدا ضبط شده' : n.job || '',
            () => { VS_STATE.npc = n; closePanel(); openVoiceStudio(n); });
        });
        return;
      }
      actionRow(p, '🔙 انتخاب شخصیت دیگه', '', () => { VS_STATE.npc = null; closePanel(); openVoiceStudio(null); });
      // همهٔ دیالوگ‌های این شخصیت (از روز اول)
      const lines = allLinesOf(target);
      const recorded = lines.filter(l => _clipIndex.has(lineKey(target.id, l.text))).length;
      const hh = document.createElement('h4');
      hh.textContent = '📜 همهٔ جمله‌های ' + target.name.split(' (')[0] + ' — ' + fa(recorded) + ' از ' + fa(lines.length) + ' ضبط شده';
      p.appendChild(hh);
      if (!VS_STATE.showAll) {
        actionRow(p, '📜 نمایش و ضبط ' + fa(lines.length) + ' جمله', 'تک‌تک دیالوگ‌ها رو صداگذاری کن', () => {
          VS_STATE.showAll = true; closePanel(); openVoiceStudio(target);
        });
      } else {
        actionRow(p, '🔼 بستن لیست جمله‌ها', '', () => { VS_STATE.showAll = false; closePanel(); openVoiceStudio(target); });
        lines.forEach(l => {
          const key = lineKey(target.id, l.text);
          const has = _clipIndex.has(key);
          const row = actionRow(p, (has ? '✅ ' : '⬜ ') + l.label,
            '«' + l.text.slice(0, 58) + (l.text.length > 58 ? '…' : '') + '»',
            async () => {
              if (VS_STATE.recording === key) {
                const blob = await recStop();
                VS_STATE.recording = null;
                if (blob && blob.size > 400) { await voiceSave(key, blob); _clipIndex.add(key); toast('✅ ذخیره شد!'); }
                else toast('⚠️ خیلی کوتاه بود.');
                closePanel(); openVoiceStudio(target);
                return;
              }
              if (has) { playClip(key); return; }
              try {
                if (!(await recStart())) { toast('🎙️ میکروفن در دسترس نیست.'); return; }
                VS_STATE.recording = key;
                row.querySelector('button').textContent = '⏹️ توقف';
                toast('🔴 بگو: «' + l.text.slice(0, 40) + '…»');
              } catch (e) { toast('⚠️ دسترسی میکروفن رد شد.'); }
            });
          if (has) {
            const del = document.createElement('button');
            del.textContent = '🗑️';
            del.style.cssText = 'background:#7a3040;color:#fff;border:none;border-radius:8px;padding:8px 11px;cursor:pointer;margin-right:6px';
            del.onclick = async e => { e.stopPropagation(); await voiceDelete(key); _clipIndex.delete(key); _clipUrls.delete(key); closePanel(); openVoiceStudio(target); };
            row.appendChild(del);
          }
        });
      }
      // اسلات‌های عمومی (وقتی جمله صدای اختصاصی نداره)
      const hs = document.createElement('h4'); hs.textContent = '🎭 صداهای عمومی (جایگزین جمله‌های ضبط‌نشده)'; p.appendChild(hs);
      VOICE_SLOTS.forEach(slot => {
        const key = target.id + '::' + slot.id;
        const has = _clipIndex.has(key);
        const rowLabel = (has ? '✅ ' : '⬜ ') + slot.label;
        const row = actionRow(p, rowLabel, has ? 'ضبط شده — بزن تا بشنوی' : slot.hint, async () => {
          if (has) { playClip(key); return; }
          // ضبط
          try {
            const btn = row.querySelector('button');
            if (VS_STATE.recording === key) {
              const blob = await recStop();
              VS_STATE.recording = null;
              if (blob && blob.size > 500) {
                await voiceSave(key, blob);
                _clipIndex.add(key);
                toast('✅ صدا ذخیره شد: ' + slot.label);
              } else toast('⚠️ صدا خیلی کوتاه بود، دوباره امتحان کن.');
              closePanel(); openVoiceStudio(target);
              return;
            }
            const ok = await recStart();
            if (!ok) { toast('🎙️ میکروفن در دسترس نیست.'); return; }
            VS_STATE.recording = key;
            btn.textContent = '⏹️ توقف';
            toast('🔴 در حال ضبط... حرف بزن، بعد دوباره بزن تا ذخیره شه.');
          } catch (e) {
            toast('⚠️ دسترسی میکروفن رد شد یا مرورگر پشتیبانی نمی‌کنه.');
          }
        });
        if (has) {
          const del = document.createElement('button');
          del.textContent = '🗑️';
          del.style.cssText = 'background:#7a3040;color:#fff;border:none;border-radius:8px;padding:8px 12px;cursor:pointer;margin-right:6px';
          del.onclick = async e => {
            e.stopPropagation();
            await voiceDelete(key);
            _clipIndex.delete(key);
            _clipUrls.delete(key);
            toast('🗑️ صدا پاک شد.');
            closePanel(); openVoiceStudio(target);
          };
          row.appendChild(del);
        }
      });
      // ابزارها
      const h2 = document.createElement('h4'); h2.textContent = '🧰 ابزار'; p.appendChild(h2);
      actionRow(p, '📊 وضعیت کلی', '', async () => {
        const keys = await voiceKeys();
        const chars = new Set(keys.map(k => k.split('::')[0])).size;
        toast('🎙️ ' + fa(keys.length) + ' صدا برای ' + fa(chars) + ' شخصیت ذخیره شده (لوکال).');
      });
      actionRow(p, '📤 خروجی گرفتن برای سرور', 'همهٔ صداها رو دانلود کن', async () => {
        const keys = await voiceKeys();
        if (!keys.length) { toast('هنوز صدایی ضبط نکردی!'); return; }
        for (const k of keys) {
          const blob = await voiceLoad(k);
          if (!blob) continue;
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = k.replace('::', '_') + '.webm';
          a.click();
          await new Promise(r => setTimeout(r, 250));
        }
        toast('📤 ' + fa(keys.length) + ' فایل دانلود شد — بذارشون تو فولدر voices/ سرور.');
      });
      actionRow(p, '🗑️ پاک کردن همهٔ صداها', 'برگشت‌ناپذیر', async () => {
        if (!VS_STATE.confirmWipe) { VS_STATE.confirmWipe = true; toast('⚠️ مطمئنی؟ دوباره بزن.'); return; }
        const keys = await voiceKeys();
        for (const k of keys) await voiceDelete(k);
        _clipIndex.clear(); _clipUrls.clear();
        VS_STATE.confirmWipe = false;
        toast('🗑️ همهٔ صداها پاک شد.');
        closePanel(); openVoiceStudio(target);
      });
    });
  });
}
const VS_STATE = { npc: null, recording: null, confirmWipe: false, showAll: false };

/* ---------------- کلید صدا بر اساس متنِ دقیق دیالوگ ---------------- */
function lineHash(text) {
  let h = 5381;
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  for (let i = 0; i < t.length; i++) h = ((h * 33) ^ t.charCodeAt(i)) >>> 0;
  return h.toString(36);
}
function lineKey(npcId, text) { return npcId + '::L' + lineHash(text); }

// همهٔ جمله‌های یک شخصیت (از روز اول) برای صداگذاری
function allLinesOf(npc) {
  const out = [];
  const push = (label, text) => { if (text && typeof text === 'string') out.push({ label, text }); };
  push('سلام', npc.greet);
  (npc.chats || []).forEach((t, i) => push('گپ ' + (i + 1), t));
  (npc.memories || []).forEach((t, i) => push('خاطره ' + (i + 1), t));
  (npc.qa || []).forEach(([q, a], i) => push('جواب ' + (i + 1), a));
  push('جواب رد', npc.reject);
  push('معرفی شغل', npc.jobReveal);
  if (npc.intro && npc.intro.scene) push('آشنایی', npc.intro.scene);
  return out;
}

// صدای ضبط‌شده اولویت داره: اول همون جملهٔ دقیق، بعد حالت، بعد سلام
function sayWithClip(npc, text, mood) {
  if (!npc) return false;
  const exact = lineKey(npc.id, text);
  if (_clipIndex.has(exact)) { playClip(exact); return true; }
  const slot = mood === 'happy' || mood === 'love' ? 'happy'
             : mood === 'sad' ? 'sad'
             : mood === 'angry' ? 'angry' : 'greet';
  if (hasClip(npc.id, slot)) { playClip(npc.id + '::' + slot); return true; }
  if (hasClip(npc.id, 'greet')) { playClip(npc.id + '::greet'); return true; }
  return false;
}

/* ---------------- ضبط درجا حین گفتگو ---------------- */
let _liveBar = null;
function liveRecBar() {
  if (_liveBar) return _liveBar;
  const el = document.createElement('div');
  el.id = 'liveRecBar';
  el.style.cssText = 'position:fixed;top:60px;right:50%;transform:translateX(50%);z-index:120;' +
    'display:none;gap:8px;align-items:center;background:rgba(20,8,26,.95);color:#fff;' +
    'padding:8px 14px;border-radius:12px;border:1px solid #b08cff;font-size:12px;font-family:inherit;' +
    'box-shadow:0 8px 30px rgba(0,0,0,.6);max-width:92vw;flex-wrap:wrap;justify-content:center';
  document.body.appendChild(el);
  _liveBar = el;
  return el;
}
let _liveCtx = null;
function liveRecShow(npc, text) {
  if (!G._godLive) return;
  _liveCtx = { npc, text };
  const el = liveRecBar();
  const key = lineKey(npc.id, text);
  const has = _clipIndex.has(key);
  el.style.display = 'flex';
  el.innerHTML = '';
  const info = document.createElement('span');
  info.textContent = (has ? 'ضبط‌شده ✅' : 'بدون صدا 🎙️') + ' — ' + npc.name.split(' (')[0] + ': «' + String(text).slice(0, 32) + '…»';
  el.appendChild(info);
  const mk = (label, bg, fn) => {
    const b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = 'background:' + bg + ';color:#fff;border:none;border-radius:8px;padding:5px 11px;cursor:pointer;font-family:inherit;font-size:12px';
    b.onclick = fn;
    el.appendChild(b);
    return b;
  };
  let recBtn;
  recBtn = mk(has ? 'ضبط دوباره 🔁' : 'ضبط این جمله 🔴', '#b3305a', async () => {
    if (VS_STATE.recording === key) {
      const blob = await recStop();
      VS_STATE.recording = null;
      if (blob && blob.size > 400) {
        await voiceSave(key, blob);
        _clipIndex.add(key);
        toast('✅ صدای این جمله ذخیره شد!');
      } else toast('⚠️ خیلی کوتاه بود.');
      liveRecShow(npc, text);
      return;
    }
    try {
      if (!(await recStart())) { toast('🎙️ میکروفن در دسترس نیست.'); return; }
      VS_STATE.recording = key;
      recBtn.textContent = '⏹️ توقف و ذخیره';
      recBtn.style.background = '#e63946';
      toast('🔴 در حال ضبط... جمله رو بگو، بعد «توقف» بزن.');
    } catch (e) { toast('⚠️ دسترسی میکروفن رد شد.'); }
  });
  if (has) {
    mk('▶️ پخش', '#2a6f4a', () => playClip(key));
    mk('🗑️', '#7a3040', async () => { await voiceDelete(key); _clipIndex.delete(key); _clipUrls.delete(key); toast('🗑️ پاک شد'); liveRecShow(npc, text); });
  }
  mk('🎬 استودیو', '#3a2f56', () => { if (typeof closeTalk === 'function') closeTalk(); openVoiceStudio(npc); });
  mk('✕', '#444', () => { el.style.display = 'none'; });
}
function liveRecHide() { if (_liveBar) _liveBar.style.display = 'none'; }
function godLiveToggle() {
  G._godLive = !G._godLive;
  if (!G._godLive) liveRecHide();
  toast(G._godLive ? '🎙️ ضبط درجا روشن شد — با هر کی حرف بزنی، نوار ضبط بالای صفحه میاد.'
                   : '🎙️ ضبط درجا خاموش شد.');
}
// در شروع بازی ایندکس رو پر کن
if (typeof window !== 'undefined') setTimeout(() => refreshClipIndex().catch(() => {}), 1200);
