// ===== player-character.js — نمونهٔ ماژولار کاراکتر بازیکن =====
'use strict';

(function () {
  const DEFAULTS = {
    body: { build: 'average', height: 1, shoulderWidth: 1 },
    skin: 0xd9a276,
    hair: { style: 'textured', color: 0x211711 },
    face: { eyeColor: 0x35251d, brow: 'soft', beard: 'stubble' },
    outfit: {
      jacket: 0xb32632,
      hoodie: 0xeee9df,
      shirt: 0x17223b,
      pants: 0x273247,
      shoes: 0xf4f1ea,
      accent: 0x17223b
    },
    accessory: { hat: 'cap', hatColor: 0x17223b, watch: true }
  };

  function mergeLook(look) {
    look = look || {};
    return {
      body: Object.assign({}, DEFAULTS.body, look.body),
      skin: look.skin ?? DEFAULTS.skin,
      hair: Object.assign({}, DEFAULTS.hair, look.hair),
      face: Object.assign({}, DEFAULTS.face, look.face),
      outfit: Object.assign({}, DEFAULTS.outfit, look.outfit),
      accessory: Object.assign({}, DEFAULTS.accessory, look.accessory)
    };
  }

  function createPlayerCharacter(THREE, material, customLook) {
    const look = mergeLook(customLook);
    const root = new THREE.Group();
    root.name = 'player-character';
    const parts = {};

    const mesh = (geometry, color, roughness = .78, metalness = .03) => {
      const m = new THREE.Mesh(geometry, material(color, roughness, metalness));
      m.castShadow = m.receiveShadow = true;
      return m;
    };
    const sphere = (r, color, sx = 1, sy = 1, sz = 1) => {
      const m = mesh(new THREE.SphereGeometry(r, 28, 22), color);
      m.scale.set(sx, sy, sz);
      return m;
    };

    // پاها: هر پا یک pivot مستقل دارد تا انیمیشن فعلی بازی حفظ شود.
    function makeLeg(side) {
      const leg = new THREE.Group();
      const thigh = mesh(new THREE.CapsuleGeometry(.17, .43, 8, 16), look.outfit.pants);
      thigh.position.y = -.31;
      const cuff = mesh(new THREE.CylinderGeometry(.155, .17, .22, 16), look.outfit.pants);
      cuff.position.y = -.67;
      const shoe = mesh(new THREE.BoxGeometry(.36, .2, .58, 2, 2, 2), look.outfit.shoes);
      shoe.position.set(0, -.83, .09);
      const sole = mesh(new THREE.BoxGeometry(.37, .055, .6), 0x20242b);
      sole.position.set(0, -.94, .1);
      const stripe = mesh(new THREE.BoxGeometry(.375, .045, .32), look.outfit.accent);
      stripe.position.set(0, -.86, .225);
      leg.add(thigh, cuff, shoe, sole, stripe);
      leg.position.set(side * .205, .96, 0);
      return leg;
    }
    parts.legL = makeLeg(-1);
    parts.legR = makeLeg(1);

    // تنهٔ چندلایه: تی‌شرت، هودی و کاپشن کوتاه.
    const hips = mesh(new THREE.CylinderGeometry(.38, .36, .32, 20), look.outfit.pants);
    hips.position.y = 1.05;
    const torso = mesh(new THREE.CapsuleGeometry(.4, .52, 10, 20), look.outfit.hoodie);
    torso.scale.set(1.03 * look.body.shoulderWidth, 1, .72);
    torso.position.y = 1.52;
    const jacketL = mesh(new THREE.BoxGeometry(.38, .82, .16), look.outfit.jacket);
    jacketL.position.set(-.2, 1.55, .33); jacketL.rotation.z = -.035;
    const jacketR = jacketL.clone(); jacketR.position.x = .2; jacketR.rotation.z = .035;
    const zipper = mesh(new THREE.BoxGeometry(.035, .72, .035), 0xd9d3c7, .35, .55);
    zipper.position.set(0, 1.55, .425);
    const shirt = mesh(new THREE.BoxGeometry(.18, .39, .035), look.outfit.shirt);
    shirt.position.set(0, 1.6, .42);
    const pocketL = mesh(new THREE.BoxGeometry(.15, .055, .035), 0x7d1721);
    pocketL.position.set(-.23, 1.38, .425);
    const pocketR = pocketL.clone(); pocketR.position.x = .23;

    function makeArm(side) {
      const arm = new THREE.Group();
      const shoulder = sphere(.19, look.outfit.jacket, 1, 1.12, .92);
      shoulder.position.y = -.08;
      const sleeve = mesh(new THREE.CapsuleGeometry(.12, .47, 8, 16), look.outfit.jacket);
      sleeve.position.y = -.42;
      const cuff = mesh(new THREE.CylinderGeometry(.125, .125, .12, 16), look.outfit.accent);
      cuff.position.y = -.72;
      const hand = sphere(.13, look.skin, .82, 1.1, .82);
      hand.position.y = -.86;
      arm.add(shoulder, sleeve, cuff, hand);
      arm.position.set(side * .51 * look.body.shoulderWidth, 1.91, 0);
      if (look.accessory.watch && side === -1) {
        const watch = mesh(new THREE.BoxGeometry(.17, .08, .16), 0x171a20, .32, .45);
        watch.position.set(0, -.75, .01); arm.add(watch);
      }
      return arm;
    }
    parts.armL = makeArm(-1);
    parts.armR = makeArm(1);

    // سر و صورت: فرم سر، فک، گوش، چشم، پلک، ابرو و ته‌ریش اجزای مستقل‌اند.
    const neck = mesh(new THREE.CylinderGeometry(.19, .22, .28, 18), look.skin);
    neck.position.y = 2.12;
    const head = new THREE.Group();
    head.position.y = 2.47;
    const skull = sphere(.38, look.skin, .92, 1.08, .9);
    const jaw = sphere(.29, look.skin, .92, .72, .82); jaw.position.y = -.22;
    head.add(skull, jaw);
    [-1, 1].forEach(side => {
      const ear = sphere(.085, look.skin, .62, 1.05, .42);
      ear.position.set(side * .355, -.01, 0); head.add(ear);
      const eyeWhite = sphere(.078, 0xf6f2eb, 1.12, .72, .38);
      eyeWhite.position.set(side * .14, .045, .321);
      const iris = sphere(.043, look.face.eyeColor, 1, 1, .35);
      iris.position.set(side * .14, .04, .365);
      const pupil = sphere(.021, 0x090807, 1, 1, .3);
      pupil.position.set(side * .14, .04, .382);
      const glint = sphere(.008, 0xffffff); glint.position.set(side * .13, .055, .392);
      const brow = mesh(new THREE.BoxGeometry(.16, .027, .025), look.hair.color);
      brow.position.set(side * .14, .145, .348); brow.rotation.z = side * -.08;
      head.add(eyeWhite, iris, pupil, glint, brow);
    });
    const nose = sphere(.075, 0xc98964, .72, 1.15, .9); nose.position.set(0, -.035, .37);
    const mouth = mesh(new THREE.TorusGeometry(.085, .014, 8, 24, Math.PI), 0x7d3e3e);
    mouth.position.set(0, -.185, .326); mouth.rotation.x = Math.PI;
    head.add(nose, mouth);
    if (look.face.beard === 'stubble') {
      const beard = sphere(.292, look.hair.color, .94, .68, .84);
      beard.position.set(0, -.235, -.005);
      beard.material.transparent = true; beard.material.opacity = .18;
      head.add(beard);
    }

    if (look.hair.style !== 'none' && look.accessory.hat !== 'scarf' && look.accessory.hat !== 'helmet') {
      const hairTop = sphere(.385, look.hair.color, .96, .56, .92);
      hairTop.position.set(0, .22, -.025);
      const hairBack = sphere(.35, look.hair.color, .94, .92, .43);
      hairBack.position.set(0, .06, -.25);
      head.add(hairTop, hairBack);
      for (let i = -2; i <= 2; i++) {
        const tuft = sphere(.105, look.hair.color, .72, 1.15, .65);
        tuft.position.set(i * .105, .31 + Math.abs(i) * -.012, .07);
        tuft.rotation.z = i * -.12; head.add(tuft);
      }
    }
    if (look.accessory.hat === 'cap') {
      const crown = sphere(.405, look.accessory.hatColor, 1.03, .58, .98);
      crown.position.set(0, .275, -.03);
      const brim = mesh(new THREE.BoxGeometry(.48, .055, .3), look.accessory.hatColor);
      brim.position.set(0, .24, .29); brim.rotation.x = -.08;
      const badge = mesh(new THREE.CylinderGeometry(.07, .07, .025, 16), look.outfit.jacket);
      badge.rotation.x = Math.PI / 2; badge.position.set(0, .34, .36);
      head.add(crown, brim, badge);
    } else if (look.accessory.hat === 'scarf') {
      const scarfTop = sphere(.415, look.accessory.hatColor, 1.04, .72, 1.02);
      scarfTop.position.set(0, .18, -.035);
      const scarfBack = sphere(.38, look.accessory.hatColor, 1.02, 1.18, .48);
      scarfBack.position.set(0, -.04, -.28);
      const scarfTail = mesh(new THREE.CapsuleGeometry(.12, .34, 8, 14), look.accessory.hatColor);
      scarfTail.position.set(.27, -.36, -.2); scarfTail.rotation.z = -.28;
      head.add(scarfTop, scarfBack, scarfTail);
    } else if (look.accessory.hat === 'helmet') {
      const helmet = sphere(.43, look.accessory.hatColor, 1.05, .75, 1.04);
      helmet.position.set(0, .18, -.03);
      const visor = mesh(new THREE.BoxGeometry(.48, .08, .2), 0x27384a, .18, .5);
      visor.position.set(0, .13, .34); visor.rotation.x = -.12;
      head.add(helmet, visor);
    }

    root.add(parts.legL, parts.legR, hips, torso, jacketL, jacketR, zipper, shirt,
      pocketL, pocketR, parts.armL, parts.armR, neck, head);
    root.scale.y = look.body.height;
    root.userData.limbs = { legL: parts.legL, legR: parts.legR, armL: parts.armL, armR: parts.armR };
    root.userData.characterParts = Object.assign(parts, { head, torso, jacketL, jacketR });
    root.userData.look = look;
    return root;
  }

  window.createPlayerCharacter = createPlayerCharacter;
  window.createGameCharacter = function (THREE, material, shirtColor, legacy, identity) {
    legacy = legacy || {};
    identity = identity || String(shirtColor) + ':' + (legacy.style || '') + ':' + (legacy.accColor || '');
    let hash = 0;
    for (const ch of identity) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
    const scarf = legacy.style === 'scarf';
    const headwear = ['cap', 'scarf', 'helmet'].includes(legacy.style) ? legacy.style : 'none';
    const builds = ['slim', 'average', 'broad'];
    const build = builds[hash % builds.length];
    return createPlayerCharacter(THREE, material, {
      body: {
        build,
        height: .94 + (hash % 9) * .012,
        shoulderWidth: build === 'broad' ? 1.12 : build === 'slim' ? .9 : 1
      },
      skin: legacy.skin ?? [0xd9a276, 0xe5b58a, 0xc88e65, 0xf0c3a0][hash % 4],
      hair: { style: scarf ? 'none' : 'textured', color: legacy.hair ?? 0x2b1d0e },
      face: {
        eyeColor: [0x35251d, 0x233c50, 0x31442e][hash % 3],
        brow: hash % 2 ? 'soft' : 'straight',
        beard: legacy.moustache ? 'stubble' : 'none'
      },
      outfit: {
        jacket: shirtColor,
        hoodie: scarf ? 0xf0dfd0 : 0xeee9df,
        shirt: legacy.accColor ?? 0x26334a,
        pants: [0x273247, 0x32302f, 0x263b35][hash % 3],
        shoes: hash % 2 ? 0xf2eee5 : 0x272b31,
        accent: legacy.accColor ?? 0x17223b
      },
      accessory: {
        hat: headwear,
        hatColor: legacy.accColor ?? legacy.hair ?? 0x26334a,
        watch: hash % 3 === 0
      }
    });
  };
})();
