import * as THREE from './three.module.js';
window.THREE = THREE;
window.dispatchEvent(new Event('three-ready'));
