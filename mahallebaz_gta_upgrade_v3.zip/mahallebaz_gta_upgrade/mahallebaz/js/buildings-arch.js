// ===== buildings-arch.js — معماری سه‌بعدی واقعی برای ساختمان‌های محله‌باز =====
// جایگزین «عکس روی صفحه‌های ضربدری». هر ساختمان حجم واقعی دارد:
// نمای تکسچری (آجر/سنگ/شیشه) + پنجره‌هایی که شب تصادفی روشن می‌شوند،
// سقف با تجهیزات (کولر، منبع، ماهواره)، بالکن، ستون، گنبد، مناره و ...
// استفاده: ARCH3D.build(b, group)  و  ARCH3D.setNight(daylight 0..1)
'use strict';
(function () {
  const THREE = window.THREE;
  if (!THREE) return;

  // ---------- ابزار ----------
  function hash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) {
    let a = seed >>> 0;
    return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
  }
  const css = h => '#' + ('000000' + (h >>> 0).toString(16)).slice(-6);
  function lerpHex(a, b, t) {
    const f = (s) => Math.round(((a >> s) & 255) + (((b >> s) & 255) - ((a >> s) & 255)) * t);
    return ((f(16) << 16) | (f(8) << 8) | f(0)) >>> 0;
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const cvs = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };

  // کش هندسه و متریال
  const GC = new Map();
  function geo(key, make) { let g = GC.get(key); if (!g) { g = make(); GC.set(key, g); } return g; }
  const BG = (w, h, d) => geo('b' + w.toFixed(2) + '|' + h.toFixed(2) + '|' + d.toFixed(2), () => new THREE.BoxGeometry(w, h, d));
  const CG = (rt, rb, h, s = 20) => geo('c' + rt.toFixed(2) + '|' + rb.toFixed(2) + '|' + h.toFixed(2) + '|' + s, () => new THREE.CylinderGeometry(rt, rb, h, s));
  const MC = new Map();
  function M(color, rough = .85, metal = .05, extra) {
    const key = color + '|' + rough + '|' + metal + (extra ? JSON.stringify(extra) : '');
    let m = MC.get(key);
    if (!m) { m = new THREE.MeshStandardMaterial(Object.assign({ color, roughness: rough, metalness: metal }, extra || {})); MC.set(key, m); }
    return m;
  }
  const NIGHT = [];                           // {m, k} → emissiveIntensity = k * شب
  function nightMat(params, k) { const m = new THREE.MeshStandardMaterial(params); NIGHT.push({ m, k }); return m; }
  function add(g, geometry, material, x = 0, y = 0, z = 0, o = {}) {
    const m = new THREE.Mesh(geometry, material);
    m.position.set(x, y, z);
    if (o.rx) m.rotation.x = o.rx; if (o.ry) m.rotation.y = o.ry; if (o.rz) m.rotation.z = o.rz;
    if (o.sx !== undefined) m.scale.set(o.sx, o.sy ?? 1, o.sz ?? 1);
    m.castShadow = !!o.cast; m.receiveShadow = o.recv !== false;
    g.add(m); return m;
  }

  // ---------- بافت نما ----------
  const TEXC = new Map();
  function toTex(c, srgb = true) {
    const t = new THREE.CanvasTexture(c);
    if (srgb && t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8; t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    return t;
  }
  function paintBrick(x, W, H, base, r) {
    x.fillStyle = css(base); x.fillRect(0, 0, W, H);
    const bh = 7, bw = 16;
    for (let y = 0, row = 0; y < H; y += bh, row++) {
      for (let xx = -(row % 2) * bw / 2; xx < W; xx += bw) {
        const k = .86 + r() * .28;
        x.fillStyle = css(lerpHex(base, r() < .5 ? 0x2a1208 : 0xffd9b0, (k - .86) * .9));
        x.fillRect(xx + 1, y + 1, bw - 2, bh - 2);
      }
    }
  }
  function paintNoise(x, W, H, r, a = .05) {
    for (let i = 0; i < W * H / 260; i++) {
      x.fillStyle = r() < .5 ? 'rgba(255,255,255,' + a + ')' : 'rgba(0,0,0,' + a + ')';
      x.fillRect(r() * W, r() * H, 2 + r() * 5, 2 + r() * 5);
    }
  }
  function archPath(x, wx, wy, ww, wh) {
    const rr = ww / 2;
    x.beginPath(); x.moveTo(wx, wy + wh); x.lineTo(wx, wy + rr); x.arc(wx + rr, wy + rr, rr, Math.PI, 0); x.lineTo(wx + ww, wy + wh); x.closePath();
  }
  const WARM = ['#ffd9a0', '#ffe7b8', '#ffc77a', '#fff1d0', '#ffcf8a', '#bfe0ff'];

  // S: {cols, rows, style, wall, glassTop, glassBot, frame, lit, brick, rnd}
  function paintFacade(S) {
    const CW = 44, CH = 56, W = S.cols * CW, H = S.rows * CH, r = S.rnd;
    const c = cvs(W, H), x = c.getContext('2d');
    const e = cvs(W, H), ex = e.getContext('2d');
    ex.fillStyle = '#000'; ex.fillRect(0, 0, W, H);
    if (S.brick) paintBrick(x, W, H, S.wall, r); else { x.fillStyle = css(S.wall); x.fillRect(0, 0, W, H); paintNoise(x, W, H, r); }
    const st = S.style;
    for (let j = 0; j < S.rows; j++) {
      const ground = j === S.rows - 1 && S.rows > 1;
      const y0 = j * CH;
      if (st === 'classic' && ground) {              // پاشنهٔ سنگی با خط‌های افقی
        x.fillStyle = css(lerpHex(S.wall, 0x000000, .12)); x.fillRect(0, y0, W, CH);
        x.strokeStyle = 'rgba(0,0,0,.25)'; x.lineWidth = 2;
        for (let yy = y0 + 8; yy < y0 + CH; yy += 14) { x.beginPath(); x.moveTo(0, yy); x.lineTo(W, yy); x.stroke(); }
      }
      if ((st === 'shop') && ground) {               // بند تابلو بالای ویترین
        x.fillStyle = css(S.trim); x.fillRect(0, y0, W, CH * .2);
        x.fillStyle = 'rgba(0,0,0,.25)'; x.fillRect(0, y0 + CH * .2, W, 3);
      }
      for (let i = 0; i < S.cols; i++) {
        const x0 = i * CW;
        let wx, wy, ww, wh, arch = false, mull = 0, shut = false, litP = S.lit;
        switch (st) {
          case 'shop':
            if (ground) { wx = x0 + CW * .07; ww = CW * .86; wy = y0 + CH * .27; wh = CH * .66; mull = 1; litP = .85; }
            else { ww = CW * .5; wh = CH * .52; wx = x0 + (CW - ww) / 2; wy = y0 + CH * .2; shut = r() < .55; }
            break;
          case 'modern':
            ww = CW; wx = x0; wh = CH * .64; wy = y0 + CH * .14; mull = 1;
            break;
          case 'classic':
            if (ground) { ww = CW * .4; wh = CH * .62; wx = x0 + (CW - ww) / 2; wy = y0 + CH * .26; arch = true; litP = .6; }
            else { ww = CW * .4; wh = CH * .7; wx = x0 + (CW - ww) / 2; wy = y0 + CH * .17; arch = true; }
            break;
          case 'curtain': case 'cyl':
            ww = CW * .96; wx = x0 + CW * .02; wh = CH * .72; wy = y0 + CH * .08; mull = 2;
            break;
          case 'brick':
            ww = CW * .46; wh = CH * .5; wx = x0 + (CW - ww) / 2; wy = y0 + CH * .24; shut = false;
            break;
          case 'dark':
            ww = CW * .9; wx = x0 + CW * .05; wh = CH * .5; wy = y0 + CH * .18; mull = 1;
            break;
          default: ww = CW * .5; wh = CH * .5; wx = x0 + (CW - ww) / 2; wy = y0 + CH * .2;
        }
        // قاب و بدنهٔ پنجره
        x.fillStyle = css(S.frame);
        if (arch) { archPath(x, wx - 3, wy - 3, ww + 6, wh + 6); x.fill(); } else x.fillRect(wx - 2, wy - 2, ww + 4, wh + 4);
        const gr = x.createLinearGradient(0, wy, 0, wy + wh);
        gr.addColorStop(0, css(S.glassTop)); gr.addColorStop(1, css(S.glassBot));
        x.fillStyle = gr;
        if (arch) { archPath(x, wx, wy, ww, wh); x.fill(); } else x.fillRect(wx, wy, ww, wh);
        // درخشش مورب شیشه
        x.save(); x.beginPath(); if (arch) archPath(x, wx, wy, ww, wh); else x.rect(wx, wy, ww, wh); x.clip();
        x.fillStyle = 'rgba(255,255,255,.14)';
        x.beginPath(); x.moveTo(wx, wy + wh * .55); x.lineTo(wx + ww, wy + wh * .1); x.lineTo(wx + ww, wy + wh * .3); x.lineTo(wx, wy + wh * .8); x.fill();
        // پرده/کرکره نیمه‌باز
        if (r() < .3 && !mull) { x.fillStyle = 'rgba(235,225,205,.75)'; x.fillRect(wx, wy, ww, wh * (.25 + r() * .35)); }
        x.restore();
        // قاب‌بندی
        x.strokeStyle = css(S.frame); x.lineWidth = 2;
        if (mull) { x.beginPath(); x.moveTo(wx + ww / 2, wy); x.lineTo(wx + ww / 2, wy + wh); x.stroke(); if (mull === 2) { x.beginPath(); x.moveTo(wx, wy + wh * .5); x.lineTo(wx + ww, wy + wh * .5); x.stroke(); } }
        else if (!arch) { x.beginPath(); x.moveTo(wx + ww / 2, wy); x.lineTo(wx + ww / 2, wy + wh); x.moveTo(wx, wy + wh * .5); x.lineTo(wx + ww, wy + wh * .5); x.stroke(); }
        // طاقچه
        if (S.sill) { x.fillStyle = css(S.sill); x.fillRect(wx - 4, wy + wh + 2, ww + 8, 4); }
        // کرکره‌های کناری
        if (shut) { x.fillStyle = css(S.shutter || 0x2f5d50); x.fillRect(wx - ww * .32, wy, ww * .28, wh); x.fillRect(wx + ww * 1.04, wy, ww * .28, wh); }
        // روشن شب
        if (r() < litP) {
          const col = WARM[(r() * WARM.length) | 0];
          ex.save(); ex.beginPath(); if (arch) archPath(ex, wx, wy, ww, wh); else ex.rect(wx, wy, ww, wh); ex.clip();
          const eg = ex.createLinearGradient(0, wy, 0, wy + wh);
          eg.addColorStop(0, col); eg.addColorStop(1, 'rgba(255,170,90,.85)');
          ex.fillStyle = eg; ex.fillRect(wx, wy, ww, wh);
          if (r() < .4) { ex.fillStyle = 'rgba(0,0,0,.45)'; ex.fillRect(wx + (r() < .5 ? 0 : ww * .6), wy, ww * .4, wh); }   // پرده
          if (mull) { ex.strokeStyle = 'rgba(0,0,0,.6)'; ex.lineWidth = 2; ex.beginPath(); ex.moveTo(wx + ww / 2, wy); ex.lineTo(wx + ww / 2, wy + wh); ex.stroke(); }
          ex.restore();
        }
      }
    }
    // سایهٔ زیر هر طبقه (حس عمق)
    x.fillStyle = 'rgba(0,0,0,.10)';
    for (let j = 1; j < S.rows; j++) x.fillRect(0, j * CH - 2, W, 3);
    return { c, e };
  }

  // متریال نما: کش بر اساس کلید
  function facadeMat(key, S, o = {}) {
    let t = TEXC.get(key);
    if (!t) {
      S.rnd = rng(hash(key));
      const p = paintFacade(S);
      t = { map: toTex(p.c), emissiveMap: toTex(p.e) };
      if (o.noflip) { t.map.flipY = false; t.emissiveMap.flipY = false; }
      if (o.repeat) for (const tx of [t.map, t.emissiveMap]) { tx.wrapS = tx.wrapT = THREE.RepeatWrapping; tx.repeat.set(o.repeat[0], o.repeat[1]); }
      TEXC.set(key, t);
    }
    return nightMat({
      map: t.map, emissiveMap: t.emissiveMap, emissive: 0xffffff, emissiveIntensity: 0,
      roughness: o.rough ?? .75, metalness: o.metal ?? .05, envMapIntensity: o.env ?? 1,
    }, o.k ?? 1.25);
  }
  function faceSpec(style, W, H, base, over = {}) {
    const cellM = over.cellM || 3.2, floorH = over.floorH || 3.4;
    return Object.assign({
      style, cols: clamp(Math.round(W / cellM), 2, 28), rows: clamp(Math.round(H / floorH), 1, 16),
      wall: 0xd8cfc0, trim: 0x8a2f2f, glassTop: 0x7fa6c4, glassBot: 0x2e4a63, frame: 0xf2ece0, lit: .4,
    }, base, over);
  }
  // مواد چهار وجه جعبه: [+x, -x, بالا, پایین, +z, -z]
  const ROOF = M(0x55595e, .95, .02);
  const GROUND = M(0x4a4c50, 1, 0);
  function boxMats(b, tag, W, D, H, style, base, o) {
    const mz = facadeMat(b.id + '|' + tag + 'z', faceSpec(style, W, H, base, o), o);
    const mx = facadeMat(b.id + '|' + tag + 'x', faceSpec(style, D, H, base, Object.assign({}, o, { cellM: (o && o.cellM) || 3.2 })), o);
    return [mx, mx, ROOF, GROUND, mz, mz];
  }

  // شیشهٔ بزرگ با پنجره‌های تک‌تک روشن (به‌جای بلوک تخت درخشان)
  function litGlass(key, cols, rows, tintHex, litP = .8) {
    const sp = faceSpec('curtain', 1, 1, { wall: 0x1e262e, frame: 0xc3ccd3, glassTop: lerpHex(tintHex, 0xffffff, .3), glassBot: lerpHex(tintHex, 0x000000, .6), lit: litP }, {});
    sp.cols = cols; sp.rows = rows;
    return facadeMat(key, sp, { rough: .12, metal: .65, env: 1.7, k: 1.3 });
  }

  // ---------- اجزای مشترک ----------
  function plinth(b, g, col = 0x9a9a96) { add(g, BG(b.w + 2.6, .24, b.d + 2.6), M(col, .95), 0, .12, 0); }
  let DOOR_MAT = null;
  function entrance(g, zFront, w = 3.4, h = 3.1, y0 = .24, canopy = true) {
    if (!DOOR_MAT) DOOR_MAT = nightMat({ color: 0x182633, roughness: .1, metalness: .85, emissive: 0xffd9a0, emissiveIntensity: 0 }, .9);
    add(g, BG(w + .6, h + .3, .3), M(0x2b2b2e, .6, .3), 0, y0 + h / 2 + .1, zFront - .02);
    add(g, BG(w, h, .12), DOOR_MAT, 0, y0 + h / 2, zFront + .14);
    add(g, BG(.08, h, .16), M(0x111214, .5, .6), 0, y0 + h / 2, zFront + .16);
    if (canopy) add(g, BG(w + 2.2, .2, 1.9), M(0x2b2b2e, .5, .5), 0, y0 + h + .55, zFront + .9, { cast: true });
  }
  function roofProps(g, y, w, d, r, o = {}) {
    const n = o.n ?? 2 + ((r() * 3) | 0);
    const px = () => (r() - .5) * (w - 4), pz = () => (r() - .5) * (d - 4);
    for (let i = 0; i < n; i++) {                                   // کولر گازی
      const x = px(), z = pz();
      add(g, BG(1.4, .75, .95), M(0xcfd4d8, .6, .3), x, y + .38, z, { cast: true });
      add(g, CG(.34, .34, .06, 12), M(0x454c54, .5, .6), x, y + .78, z);
    }
    if (o.tank !== false && r() < .8) {                              // منبع آب با پایه
      const x = px(), z = pz();
      add(g, CG(1, 1, 1.8, 14), M(0x9aa4ad, .55, .5), x, y + 1.5, z, { cast: true });
      add(g, CG(.1, .1, 1.2, 6), M(0x333, .5, .5), x - .5, y + .6, z - .5);
      add(g, CG(.1, .1, 1.2, 6), M(0x333, .5, .5), x + .5, y + .6, z + .5);
    }
    if (o.dish !== false) for (let i = 0; i < 2; i++) {              // ماهواره‌های پشت‌بومی تهران
      const x = px(), z = pz();
      add(g, CG(.05, .05, 1.2, 5), M(0x555, .5, .6), x, y + .6, z);
      add(g, geo('dish', () => new THREE.SphereGeometry(.55, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2)), M(0xe8e8e8, .45, .3, { side: THREE.DoubleSide }), x, y + 1.3, z, { rx: -1.0, ry: r() * 6 });
    }
    if (o.stair) add(g, BG(2.8, 2.4, 2.8), M(0xb8b2a6, .9), px() * .6, y + 1.2, pz() * .6, { cast: true });
  }
  function parapet(g, w, d, y, col = 0xcfc7b8, h = .7) {
    const m = M(col, .9), t = .35;
    add(g, BG(w + t, h, t), m, 0, y + h / 2, d / 2);
    add(g, BG(w + t, h, t), m, 0, y + h / 2, -d / 2);
    add(g, BG(t, h, d), m, w / 2, y + h / 2, 0);
    add(g, BG(t, h, d), m, -w / 2, y + h / 2, 0);
    add(g, BG(w, .15, d), ROOF, 0, y + .05, 0);
  }
  function stripedAwning(b, g, w, y, z, c1) {
    const key = 'awn' + c1;
    const t = geo(key, () => {
      const c = cvs(128, 32), x = c.getContext('2d');
      for (let i = 0; i < 8; i++) { x.fillStyle = i % 2 ? '#f6f0e6' : css(c1); x.fillRect(i * 16, 0, 16, 32); }
      const tex = toTex(c); tex.wrapS = THREE.RepeatWrapping; return tex;
    });
    const m = geo('awnm' + key, () => new THREE.MeshStandardMaterial({ map: t, roughness: .85 }));
    const mesh = add(g, BG(w, .12, 1.8), m, 0, y, z, { rx: .32, cast: true });
    add(g, BG(w, .3, .08), M(c1, .85), 0, y - .45, z + .85);
    return mesh;
  }
  function tree(g, x, z, s = 1) {
    add(g, CG(.12 * s, .17 * s, 1.6 * s, 6), M(0x5b4129, 1), x, .8 * s, z);
    add(g, geo('leaf', () => new THREE.IcosahedronGeometry(1, 1)), M(0x3b7d3c, .9), x, 2.4 * s, z, { sx: 1.2 * s, sy: 1.1 * s, sz: 1.2 * s, cast: true });
  }
  function finialSpire(g, x, y, z, h, col = 0xcccccc) {
    add(g, CG(.06, .14, h, 6), M(col, .3, .9), x, y + h / 2, z);
    add(g, geo('beacon', () => new THREE.SphereGeometry(.18, 8, 8)), nightMat({ color: 0x330000, emissive: 0xff2a2a, emissiveIntensity: .9 }, 1.2), x, y + h, z);
  }

  // =======================================================================
  // سبک ۱: مغازه / خانهٔ شهری  (home_red)
  // =======================================================================
  function buildShop(b, g, r) {
    plinth(b, g, 0x8d8d88);
    const gable = b.kind === 'gable';
    const roofRise = gable ? Math.min(3.2, b.w * .22) : 0;
    const H = Math.max(5, b.h - roofRise);
    const wall = lerpHex(b.color, 0xfff1de, b.id.startsWith('deco') ? .25 : .38);
    const brick = b.id === 'home' || b.kind === 'gable';
    const mats = boxMats(b, 's', b.w, b.d, H, 'shop', {
      wall: brick ? lerpHex(0xa24a38, b.color, .35) : wall, brick,
      trim: lerpHex(b.color, 0x000000, .45), frame: 0xf4efe6, sill: 0xe6dccb,
      shutter: lerpHex(b.color, 0x203a30, .6), lit: .45, glassBot: 0x34536b,
    }, { rough: .85, k: 1.25 });
    add(g, BG(b.w, H, b.d), mats, 0, .24 + H / 2, 0, { cast: true });
    entrance(g, b.d / 2, 2.6, 2.7, .24, true);
    if (b.kind === 'awning' || r() < .6) stripedAwning(b, g, b.w * .78, 3.1, b.d / 2 + .85, b.color);
    // فاسیای نئونی
    const fas = nightMat({ color: lerpHex(b.color, 0x000000, .35), roughness: .5, emissive: b.color, emissiveIntensity: 0 }, .6);
    add(g, BG(b.w * .9, .55, .22), fas, 0, 3.75, b.d / 2 + .14);
    const top = .24 + H;
    if (gable) {
      const run = b.d / 2 + .7, len = Math.hypot(run, roofRise);
      const ang = Math.atan2(roofRise, run);
      const rm = M(0x9c3f2c, .8, .05);
      for (const s of [-1, 1]) add(g, BG(b.w + 1.2, .28, len), rm, 0, top + roofRise / 2 + .1, s * run / 2, { rx: s * ang, cast: true });
      add(g, BG(b.w + 1.3, .3, .5), M(0x7a2f20), 0, top + roofRise + .12, 0);            // خط الراس
      const tri = geo('gab' + b.d.toFixed(1) + roofRise.toFixed(1), () => {
        const s = new THREE.Shape(); s.moveTo(-b.d / 2, 0); s.lineTo(b.d / 2, 0); s.lineTo(0, roofRise); return new THREE.ShapeGeometry(s);
      });
      for (const sx of [-1, 1]) add(g, tri, M(wall, .9), sx * (b.w / 2 + .02), top, 0, { ry: sx * Math.PI / 2, recv: false });
      // دودکش
      add(g, BG(.9, 2.2, .9), M(0x8a5a44, .9), b.w * .28, top + roofRise + .4, -b.d * .15, { cast: true });
      add(g, BG(1.1, .18, 1.1), M(0x444), b.w * .28, top + roofRise + 1.55, -b.d * .15);
    } else {
      parapet(g, b.w, b.d, top, lerpHex(wall, 0xffffff, .3));
      roofProps(g, top + .15, b.w, b.d, r, { stair: b.h > 8 && r() < .5 });
    }
    // ردیف گلدان/صندلی جلوی مغازه
    if (b.kind === 'awning') for (const sx of [-1, 1]) {
      add(g, BG(1, .6, .6), M(0x6a4a30, .9), sx * (b.w / 2 - 1.5), .5, b.d / 2 + 1.5);
      add(g, geo('shrub', () => new THREE.IcosahedronGeometry(.45, 1)), M(0x3f8a45, .9), sx * (b.w / 2 - 1.5), 1.05, b.d / 2 + 1.5);
    }
  }

  // =======================================================================
  // سبک ۲: مدرن — حجم‌های کنسول‌دار + نوار شیشه  (modern)
  // =======================================================================
  function buildModern(b, g, r) {
    plinth(b, g, 0xa0a09c);
    const Hs = Math.max(6, b.h);
    const h1 = Hs * .56, h2 = Hs * .44;
    const light = 0xdedbd4, dark = 0x30343a;
    const w1 = b.w * .64, d1 = b.d * .86, x1 = -b.w * .17;
    const w2 = b.w * .78, d2 = b.d * .96, x2 = b.w * .11;
    // طبقهٔ همکف: لابی شیشه‌ای تیره عقب‌نشسته + ستون
    const mA = boxMats(b, 'a', w1, d1, h1, 'modern', { wall: light, frame: 0x30343a, lit: .5, glassBot: 0x253e55 }, { rough: .6, metal: .1, k: 1.2 });
    add(g, BG(w1, h1, d1), mA, x1, .24 + h1 / 2, 0, { cast: true });
    const accent = lerpHex(b.color, 0x222222, .25);
    const mB = boxMats(b, 'b', w2, d2, h2, 'modern', { wall: dark, frame: 0x14161a, lit: .5, glassBot: 0x1f3550 }, { rough: .55, metal: .15, k: 1.3 });
    add(g, BG(w2, h2, d2), mB, x2, .24 + h1 + h2 / 2, 0, { cast: true });
    // تکیه‌گاه زیر کنسول: لابی شیشه‌ای + ستون
    const base = b.w * .36;
    const bm = litGlass(b.id + '|mb', clamp(Math.round(base / 3), 2, 8), 1, 0x2d5f86, .85);
    add(g, BG(base, h1 * .55, d1 * .9), [bm, bm, ROOF, GROUND, bm, bm], b.w * .30, .24 + h1 * .275, 0, { cast: true });
    for (const sz of [-1, 1]) add(g, CG(.28, .28, h1 * .55, 10), M(0xe7e4dc, .5, .2), x2 + w2 / 2 - .8, .24 + h1 * .275, sz * d2 * .46, { cast: true });
    // پنل رنگی و لوور
    add(g, BG(w1 * .34, 4.4, .3), M(accent, .55, .2), x1 - w1 * .26, .24 + 2.2, d1 / 2 + .16);          // دیوار شاخص رنگی
    add(g, BG(w1 + .6, .5, d1 + .6), M(accent, .55, .2), x1, .24 + h1 - .25, 0);                   // نوار رنگی زیر طبقه
    for (let i = 0; i < 6; i++) add(g, BG(.14, h2 * .85, .35), M(0xf0eee8, .5, .3), x2 - w2 * .35 + i * .45, .24 + h1 + h2 / 2, d2 / 2 + .2);
    // سقف: دال سفید با لبهٔ ناز + پنل خورشیدی
    const top = .24 + h1 + h2;
    add(g, BG(w2 + 1.2, .4, d2 + 1.2), M(0xf2f0ea, .6), x2, top + .2, 0, { cast: true });
    add(g, BG(w1 + .8, .35, d1 + .8), M(0xf2f0ea, .6), x1, .24 + h1 + .02, 0);
    for (let i = 0; i < 4; i++) add(g, BG(2.4, .08, 1.3), M(0x1a2740, .25, .7), x2 - w2 * .3 + (i % 2) * 2.6, top + .75, -d2 * .15 + Math.floor(i / 2) * 1.8, { rx: -.35 });
    roofProps(g, top + .4, w2, d2, r, { n: 2, tank: false });
    entrance(g, d1 / 2, 3.2, 3.0, .24, true);
  }

  // =======================================================================
  // سبک ۳: کلاسیک — ستون، سرستون، سردر، گنبد/مناره  (classic)
  // =======================================================================
  let TILE_TEX = null;
  function tileTexture() {
    if (TILE_TEX) return TILE_TEX;
    const c = cvs(128, 128), x = c.getContext('2d');
    x.fillStyle = '#1b4f8c'; x.fillRect(0, 0, 128, 128);
    x.strokeStyle = '#e9c46a'; x.lineWidth = 2;
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) {
      const cx = 32 + i * 64, cy = 32 + j * 64;
      x.save(); x.translate(cx, cy);
      for (let k = 0; k < 2; k++) { x.rotate(Math.PI / 4); x.strokeRect(-18, -18, 36, 36); }
      x.fillStyle = '#2ab7ae'; x.beginPath(); x.arc(0, 0, 8, 0, 7); x.fill();
      x.restore();
    }
    x.strokeStyle = '#f4f1de'; x.lineWidth = 3; x.strokeRect(1, 1, 126, 126);
    TILE_TEX = toTex(c); TILE_TEX.wrapS = TILE_TEX.wrapT = THREE.RepeatWrapping; TILE_TEX.repeat.set(.22, .22);
    return TILE_TEX;
  }
  function archShape(w, h) {
    const s = new THREE.Shape(), r = w / 2;
    s.moveTo(-r, 0); s.lineTo(-r, h - r); s.absarc(0, h - r, r, Math.PI, 0, true); s.lineTo(r, 0); s.lineTo(-r, 0);
    return s;
  }
  function minaret(g, x, z, H) {
    const body = M(0xf1e9d6, .8), turq = M(0x1fa59a, .4, .4, { envMapIntensity: 1.3 });
    add(g, CG(.9, 1.1, 2, 16), body, x, 1.24, z, { cast: true });
    add(g, CG(.62, .8, H * .62, 16), body, x, 2.2 + H * .31, z, { cast: true });
    add(g, CG(1.25, 1.1, .4, 16), turq, x, 2.2 + H * .62, z);
    add(g, CG(.55, .62, H * .22, 16), body, x, 2.2 + H * .73, z, { cast: true });
    add(g, CG(.95, .9, .3, 16), turq, x, 2.2 + H * .84, z);
    add(g, geo('mcone', () => new THREE.ConeGeometry(.7, 2.6, 16)), turq, x, 2.2 + H * .84 + 1.45, z, { cast: true });
    add(g, CG(.04, .04, 1.2, 4), M(0xd4af37, .3, .9), x, 2.2 + H * .84 + 3.2, z);
    for (let i = 0; i < 6; i++) add(g, BG(.5, .16, .05), M(0x1b4f8c, .5), x, 3 + i * H * .09, z + .62 - (i % 2) * 1.24, { ry: 0 });
  }
  function buildClassic(b, g, r) {
    const isMosque = b.id === 'mosque', isMansion = b.id === 'mansion';
    const stone = isMosque ? 0xe9dec2 : isMansion ? 0xe3c9a4 : lerpHex(0xe9ddc4, b.color, .1);
    const stoneDk = lerpHex(stone, 0x000000, .18);
    plinth(b, g, 0xa5a199);
    const baseH = .8, y0 = .24 + baseH;
    add(g, BG(b.w + 1.2, baseH, b.d + 1.2), M(stoneDk, .9), 0, .24 + baseH / 2, 0, { cast: true });
    const dome = b.kind === 'dome';
    const bodyH = b.h * (dome ? .6 : .76);
    const mats = boxMats(b, 'c', b.w, b.d, bodyH, 'classic', {
      wall: stone, frame: lerpHex(stone, 0xffffff, .35), glassTop: 0x6b8aa0, glassBot: 0x2a3d4f, lit: .5,
    }, { rough: .9, k: 1.2 });
    add(g, BG(b.w, bodyH, b.d), mats, 0, y0 + bodyH / 2, 0, { cast: true });
    add(g, BG(b.w + .5, .35, b.d + .5), M(stoneDk, .85), 0, y0 + bodyH - .25, 0);
    add(g, BG(b.w + 1, .6, b.d + 1), M(lerpHex(stone, 0xffffff, .2), .85), 0, y0 + bodyH + .3, 0, { cast: true });
    for (let i = 0; i < Math.floor(b.w / 1.1); i++) add(g, BG(.35, .3, .35), M(stoneDk, .9), -b.w / 2 + .6 + i * 1.1, y0 + bodyH - .55, b.d / 2 + .3);
    const top = y0 + bodyH + .6;
    add(g, BG(b.w - .6, .25, b.d - .6), ROOF, 0, top - .1, 0);
    for (let i = 0; i < 3; i++) add(g, BG(b.w * .55 + (2 - i) * 1.4, .22, 1.2 + (2 - i) * .55), M(stoneDk, .9), 0, .24 + .22 * (2 - i) + .22, b.d / 2 + 1.8 + (2 - i) * .5 - 1.3);
    // سردر ستون‌دار
    if (!isMosque) {
      const cols = isMansion ? 4 : 6, span = b.w * (isMansion ? .42 : .62);
      const colH = bodyH * .8;
      for (let i = 0; i < cols; i++) {
        const cx = -span / 2 + i * span / (cols - 1), cz = b.d / 2 + 1.7;
        add(g, CG(.5, .56, colH, 14), M(0xf5eddc, .75), cx, y0 + colH / 2, cz, { cast: true });
        add(g, BG(1.35, .3, 1.35), M(0xf5eddc, .8), cx, y0 + colH + .15, cz);
        add(g, BG(1.2, .26, 1.2), M(0xf5eddc, .8), cx, y0 + .13, cz);
      }
      const pw = span + 2.6;
      add(g, BG(pw, .85, 3.4), M(0xeee4cf, .8), 0, y0 + colH + .72, b.d / 2 + 1.6, { cast: true });
      const ph = pw * .13;
      const ped = geo('ped' + pw.toFixed(1), () => {
        const s = new THREE.Shape(); s.moveTo(-pw / 2, 0); s.lineTo(pw / 2, 0); s.lineTo(0, ph);
        return new THREE.ExtrudeGeometry(s, { depth: 3.4, bevelEnabled: false });
      });
      add(g, ped, M(0xf1e8d4, .8), 0, y0 + colH + 1.15, b.d / 2 - .1, { cast: true });
      entrance(g, b.d / 2 + .02, 3.6, 3.6, y0, false);
    }
    // گنبد / سقف
    if (dome) {
      const dr = Math.min(b.w, b.d) * (isMosque ? .3 : .2);
      add(g, CG(dr, dr * 1.04, isMosque ? 3.2 : 2.4, 28), M(stone, .85), 0, top + (isMosque ? 1.6 : 1.2), 0, { cast: true });
      const dm = isMosque ? M(0x1fa59a, .35, .45, { envMapIntensity: 1.4 }) : M(0xd4af37, .28, .85, { envMapIntensity: 1.6 });
      add(g, geo('dome' + dr.toFixed(1), () => new THREE.SphereGeometry(dr * 1.03, 32, 18, 0, Math.PI * 2, 0, Math.PI / 2)), dm, 0, top + (isMosque ? 3.2 : 2.4), 0, { cast: true });
      const dh = top + (isMosque ? 3.2 : 2.4) + dr * 1.03;
      add(g, CG(.07, .12, 2.2, 6), M(0xd4af37, .3, .9), 0, dh + 1, 0);
      add(g, geo('fin', () => new THREE.SphereGeometry(.28, 10, 10)), M(0xd4af37, .3, .9), 0, dh + 2.1, 0);
      if (!isMosque) for (const sx of [-1, 1]) for (const sz of [-1, 1]) {   // گنبدک‌های گوشه
        add(g, geo('dm2', () => new THREE.SphereGeometry(1.5, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2)), dm, sx * (b.w / 2 - 2), top, sz * (b.d / 2 - 2));
      }
    } else if (isMansion) {
      const rh = 3.4;
      add(g, geo('hip', () => new THREE.ConeGeometry(1, 1, 4)), M(0x8d3b2a, .8), 0, top + rh / 2 - .05, 0, { sx: (b.w + 1) / 1.4142, sy: rh, sz: (b.d + 1) / 1.4142, ry: Math.PI / 4, cast: true });
    } else {
      roofProps(g, top, b.w, b.d, r, { n: 3 });
    }
    if (isMosque) {
      // ایوان کاشی‌کاری‌شده
      const aw = b.w * .42, ah = bodyH * .95, zf = b.d / 2 + .08;
      const outer = new THREE.ShapeGeometry(archShape(aw, ah));
      add(g, outer, new THREE.MeshStandardMaterial({ map: tileTexture(), roughness: .6, metalness: .1, side: THREE.DoubleSide }), 0, y0, zf, { recv: false });
      const inner = new THREE.ShapeGeometry(archShape(aw * .66, ah * .8));
      add(g, inner, nightMat({ color: 0x0b1c33, roughness: .5, emissive: 0xffc977, emissiveIntensity: 0, side: THREE.DoubleSide }, .38), 0, y0, zf + .04, { recv: false });
      entrance(g, b.d / 2 + .06, 2.6, 3.0, y0, false);
      const mh = b.h * 1.7;
      minaret(g, -b.w / 2 - .4, b.d / 2 - 1.6, mh);
      minaret(g, b.w / 2 + .4, b.d / 2 - 1.6, mh);
    }
  }

  // =======================================================================
  // سبک ۴: برج پوستهٔ شیشه‌ای  (apartment_glass)
  // =======================================================================
  function glassTower(b, g, r, hasPodium = true) {
    plinth(b, g, 0x8e9094);
    const podH = hasPodium ? Math.min(4.6, b.h * .2) : 0;
    const tw = b.w * .84, td = b.d * .84;
    const cH = clamp(b.h * .08, 2.4, 4.2), spire = clamp(b.h * .1, 2.5, 4);
    const towerH = Math.max(6, b.h * 1.06 - podH - cH - spire - 3);      // کل ارتفاع ≈ b.h
    const tint = lerpHex(0x3b78a6, b.color, .15);
    if (podH) {
      const pm = boxMats(b, 'p', b.w * .98, b.d * .98, podH, 'curtain', { wall: 0x2a2f36, frame: 0xcfd6dc, glassTop: lerpHex(tint, 0xffffff, .3), glassBot: 0x16293a, lit: .8 }, { rough: .2, metal: .55, env: 1.5, k: 1.2 });
      add(g, BG(b.w * .98, podH, b.d * .98), pm, 0, .24 + podH / 2, 0, { cast: true });
      add(g, BG(b.w * 1.02, .3, b.d * 1.02), M(0xeceff1, .5, .3), 0, .24 + podH + .1, 0);
    }
    const m = boxMats(b, 't', tw, td, towerH, 'curtain', { wall: 0x242b33, frame: 0xc3ccd3, glassTop: lerpHex(tint, 0xffffff, .35), glassBot: lerpHex(tint, 0x000000, .55), lit: .42 }, { rough: .18, metal: .6, env: 1.7, k: 1.3 });
    const y1 = .24 + podH;
    add(g, BG(tw, towerH, td), m, 0, y1 + towerH / 2, 0, { cast: true });
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) add(g, BG(.35, towerH, .35), M(0xd9dee2, .35, .7), sx * tw / 2, y1 + towerH / 2, sz * td / 2);
    // تاج پلکانی
    const topY = y1 + towerH;
    add(g, BG(tw + .5, .5, td + .5), M(0xe8ecee, .5, .4), 0, topY + .25, 0, { cast: true });
    const cm = boxMats(b, 'c', tw * .6, td * .6, cH, 'curtain', { wall: 0x242b33, frame: 0xd9dee2, glassTop: 0xaed4ee, glassBot: 0x2d5a7c, lit: .6 }, { rough: .15, metal: .6, env: 1.6, k: 1.2 });
    add(g, BG(tw * .6, cH, td * .6), cm, 0, topY + .5 + cH / 2, 0, { cast: true });
    add(g, BG(tw * .66, .35, td * .66), M(0xe8ecee, .5, .4), 0, topY + .5 + cH + .17, 0);
    add(g, BG(2.4, 1.6, 2.4), M(0xaab2b8, .5, .5), 0, topY + .5 + cH + 1.1, 0);
    finialSpire(g, 0, topY + .5 + cH + 1.9, 0, spire);
    roofProps(g, topY + .5, tw, td, r, { n: 2, tank: false, dish: false });
    entrance(g, b.d * .49, 4.2, 3.4, .24, true);
    if (b.id === 'hospital') {
      const c = cvs(128, 128), x = c.getContext('2d');
      x.fillStyle = '#f4f7f8'; x.fillRect(0, 0, 128, 128);
      x.fillStyle = '#d62839'; x.fillRect(48, 16, 32, 96); x.fillRect(16, 48, 96, 32);
      const t = toTex(c);
      const sm = nightMat({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0, roughness: .5 }, .5);
      add(g, new THREE.PlaneGeometry(4.5, 4.5), sm, 0, y1 + towerH * .82, td / 2 + .06, { recv: false });
      add(g, new THREE.CircleGeometry(4, 28), M(0x3a3f45, .9), 0, topY + .5 + cH + .5, 0, { rx: -Math.PI / 2 });
    }
  }
  function buildCurtain(b, g, r) { glassTower(b, g, r, true); }

  // =======================================================================
  // سبک ۵: برج آجری با بالکن  (apartment_brick)
  // =======================================================================
  function buildBrick(b, g, r) {
    plinth(b, g, 0x8d8d88);
    const bw = b.w * .88, bd = b.d * .88, H = b.h * .95;
    const brickCol = lerpHex(0x9c4b36, b.color, .22);
    const m = boxMats(b, 'k', bw, bd, H, 'brick', { wall: brickCol, brick: true, frame: 0xf0eadf, sill: 0xdad2c2, glassBot: 0x2d4358, lit: .45 }, { rough: .9, k: 1.25 });
    add(g, BG(bw, H, bd), m, 0, .24 + H / 2, 0, { cast: true });
    const floors = Math.max(2, Math.round(H / 3.4)), fh = H / floors;
    // بالکن‌ها (نمونه‌برداری با InstancedMesh)
    const bal = [], per = Math.max(2, Math.round(bw / 6));
    for (let f = 1; f < floors; f++) for (const side of [1, -1]) for (let i = 0; i < per; i++) {
      bal.push([(-bw / 2 + (i + .5) * bw / per), .24 + f * fh - .05, side * (bd / 2 + .55), side]);
    }
    const slabG = BG(Math.min(4.2, bw / per * .8), .2, 1.1), railG = BG(Math.min(4.2, bw / per * .8), .55, .06);
    const slabs = new THREE.InstancedMesh(slabG, M(0xe3dccf, .85), bal.length);
    const rails = new THREE.InstancedMesh(railG, M(0x2f3a44, .4, .7), bal.length);
    const dm = new THREE.Object3D();
    bal.forEach(([x, y, z, s], i) => {
      dm.position.set(x, y, z); dm.updateMatrix(); slabs.setMatrixAt(i, dm.matrix);
      dm.position.set(x, y + .38, z + s * .5); dm.updateMatrix(); rails.setMatrixAt(i, dm.matrix);
    });
    slabs.castShadow = true; g.add(slabs, rails);
    // هستهٔ پله روشن
    add(g, BG(1.7, H * 1.005, .35), M(0xd3cbbb, .9), bw / 2 - 1.6, .24 + H / 2, bd / 2 + .08);
    add(g, BG(1.7, H * 1.005, .35), M(0xd3cbbb, .9), -bw / 2 + 1.6, .24 + H / 2, -bd / 2 - .08);
    const top = .24 + H;
    parapet(g, bw, bd, top, 0xd9d1c1, .9);
    roofProps(g, top + .1, bw, bd, r, { n: 3, stair: true });
    entrance(g, bd / 2, 3.4, 3.0, .24, true);
  }

  // =======================================================================
  // سبک ۶: برج استوانه‌ای  (cylinder_tower)
  // =======================================================================
  function buildCylinder(b, g, r) {
    const mn = Math.min(b.w, b.d);
    const podR = mn * .5, R = mn * .37, podH = 3.4;
    add(g, CG(podR + 1.3, podR + 1.5, .24, 40), M(0x9a9a96, .95), 0, .12, 0);
    for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2 + .3; tree(g, Math.cos(a) * (podR + .2), Math.sin(a) * (podR + .2), .9 + r() * .3); }
    const lobby = litGlass(b.id + '|lob', clamp(Math.round(podR * 2 * Math.PI / 3.4), 10, 40), 1, 0x2d5f86, .9);
    add(g, CG(podR, podR, podH, 40), lobby, 0, .24 + podH / 2, 0, { cast: true });
    add(g, CG(podR + .8, podR + .8, .3, 40), M(0xeceff1, .5, .3), 0, .24 + podH + .15, 0);
    const spireH = clamp(b.h * .12, 2.5, 3.6);
    const towerH = Math.max(8, b.h * 1.05 - podH - 4.6 - spireH);
    const tint = lerpHex(0x3b78a6, b.color, .2);
    const cols = clamp(Math.round(R * 2 * Math.PI / 3), 10, 28);
    const sp = faceSpec('cyl', 1, towerH, { wall: 0x1f2a36, frame: 0xc9d1d8, glassTop: lerpHex(tint, 0xffffff, .35), glassBot: lerpHex(tint, 0x000000, .5), lit: .42 }, {});
    sp.cols = cols;
    const mat = facadeMat(b.id + '|cyl', sp, { rough: .16, metal: .6, env: 1.7, k: 1.3 });
    const y1 = .24 + podH + .3;
    add(g, CG(R, R, towerH, 40), mat, 0, y1 + towerH / 2, 0, { cast: true });
    // حلقهٔ طبقات
    const floors = sp.rows, fh = towerH / floors;
    const ring = new THREE.InstancedMesh(geo('ring' + R.toFixed(1), () => new THREE.CylinderGeometry(R + .35, R + .35, .22, 40)), M(0xeceff1, .45, .4), floors);
    const dm = new THREE.Object3D();
    for (let i = 0; i < floors; i++) { dm.position.set(0, y1 + i * fh, 0); dm.updateMatrix(); ring.setMatrixAt(i, dm.matrix); }
    g.add(ring);
    const topY = y1 + towerH;
    add(g, CG(R + .5, R + .5, .5, 40), M(0xeceff1, .45, .4), 0, topY + .25, 0);
    add(g, CG(R * .72, R * .72, 3.2, 32), mat, 0, topY + .5 + 1.6, 0, { cast: true });
    add(g, CG(R * .78, R * .78, .3, 32), M(0xeceff1, .45, .4), 0, topY + .5 + 3.35, 0);
    finialSpire(g, 0, topY + 4, 0, spireH);
    entrance(g, podR + .02, 4.4, 3, .24, false);
  }

  // =======================================================================
  // سبک ۷: دفتر منحنی — دال‌های شناور  (office_curved)
  // =======================================================================
  function rrShape(w, d, rad) {
    const s = new THREE.Shape(), x = -w / 2, y = -d / 2;
    s.moveTo(x + rad, y); s.lineTo(x + w - rad, y); s.absarc(x + w - rad, y + rad, rad, -Math.PI / 2, 0, false);
    s.lineTo(x + w, y + d - rad); s.absarc(x + w - rad, y + d - rad, rad, 0, Math.PI / 2, false);
    s.lineTo(x + rad, y + d); s.absarc(x + rad, y + d - rad, rad, Math.PI / 2, Math.PI, false);
    s.lineTo(x, y + rad); s.absarc(x + rad, y + rad, rad, Math.PI, Math.PI * 1.5, false);
    return s;
  }
  function slabGeo(w, d, rad, depth) {
    return geo('slab' + w.toFixed(1) + '|' + d.toFixed(1) + '|' + rad.toFixed(1) + '|' + depth.toFixed(2), () => {
      const gg = new THREE.ExtrudeGeometry(rrShape(w, d, rad), { depth, bevelEnabled: false, curveSegments: 14 });
      gg.rotateX(-Math.PI / 2);
      return gg;
    });
  }
  function buildCurved(b, g, r) {
    plinth(b, g, 0x9a9a96);
    const n = clamp(Math.round(b.h / 3.7), 3, 7), fh = (b.h - 1) / n, rim = .42;
    const rad = Math.min(b.w, b.d) * .3;
    const tint = lerpHex(0x4a86b0, b.color, .22);
    const sp = faceSpec('curtain', 1, 1, { wall: 0x1e262e, frame: 0xdfe5e9, glassTop: lerpHex(tint, 0xffffff, .35), glassBot: lerpHex(tint, 0x000000, .55), lit: .5 }, {});
    sp.cols = 8; sp.rows = 1;
    const glass = facadeMat(b.id + '|crv', sp, { rough: .12, metal: .65, env: 1.7, k: 1.3, noflip: true, repeat: [1 / 25.6, 1 / (fh - rim)] });
    const rimM = M(0xf1f3f4, .4, .3);
    // لابی همکف عقب‌نشسته
    add(g, slabGeo(b.w * .8, b.d * .76, rad * .8, fh * .95), glass, 0, .24, 0, { cast: true });
    for (let i = 0; i < n; i++) {
      const sh = (i % 2 ? 1 : -1) * b.w * .04 * (i > 0 ? 1 : 0);
      const sc = 1 - (i > n - 3 ? (i - (n - 3)) * .06 : 0);
      const y = .24 + i * fh;
      const w = b.w * .96 * sc, d = b.d * .94 * sc;
      add(g, slabGeo(w, d, rad, rim), rimM, sh, y + (i === 0 ? fh * .95 - rim : fh - rim), 0, { cast: true });
      if (i > 0) add(g, slabGeo(w * .97, d * .97, rad * .97, fh - rim), glass, sh, y, 0, { cast: true });
    }
    // دیرک‌های عمودی نما
    const topY = .24 + n * fh;
    add(g, slabGeo(b.w * .5, b.d * .5, rad * .5, 1.2), M(0x99a3ab, .6, .4), 0, topY, 0, { cast: true });
    for (let i = 0; i < 5; i++) tree(g, (r() - .5) * b.w * .5, (r() - .5) * b.d * .4, .55);
    roofProps(g, topY, b.w * .6, b.d * .6, r, { n: 2, tank: false });
    finialSpire(g, 0, topY + 1.2, 0, 4.5);
    entrance(g, b.d * .38, 4.2, 3.2, .24, true);
  }

  // =======================================================================
  // سبک ۸: برج تیره با بالکن‌های شیشه‌ای + باغ بام  (tower_dark)
  // =======================================================================
  function buildDark(b, g, r) {
    plinth(b, g, 0x7f8084);
    const bw = b.w * .84, bd = b.d * .84, H = b.h * .9;
    const m = boxMats(b, 'd', bw, bd, H, 'dark', { wall: 0x454c55, frame: 0x14171b, glassTop: 0x8aa6b8, glassBot: 0x2a3d4d, lit: .5 }, { rough: .55, metal: .25, env: 1.2, k: 1.35 });
    add(g, BG(bw, H, bd), m, 0, .24 + H / 2, 0, { cast: true });
    const floors = Math.max(3, Math.round(H / 3.4)), fh = H / floors;
    const bal = [];
    for (let f = 1; f < floors; f++) for (const s of [1, -1]) bal.push([0, .24 + f * fh - .1, s * (bd / 2 + .6), s]);
    const slabs = new THREE.InstancedMesh(BG(bw * 1.02, .22, 1.3), M(0xc9c6bf, .8), bal.length);
    const rails = new THREE.InstancedMesh(BG(bw * 1.02, .8, .05), new THREE.MeshStandardMaterial({ color: 0x9fc4d6, roughness: .05, metalness: .3, transparent: true, opacity: .35 }), bal.length);
    const dm = new THREE.Object3D();
    bal.forEach(([x, y, z, s], i) => {
      dm.position.set(x, y, z); dm.updateMatrix(); slabs.setMatrixAt(i, dm.matrix);
      dm.position.set(x, y + .5, z + s * .6); dm.updateMatrix(); rails.setMatrixAt(i, dm.matrix);
    });
    slabs.castShadow = true; g.add(slabs, rails);
    // ستون‌های عمودی سایه‌دار
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) add(g, BG(.8, H * 1.005, .8), M(0x1b1e22, .6, .3), sx * bw / 2, .24 + H / 2, sz * bd / 2);
    const top = .24 + H;
    add(g, BG(bw + .6, .5, bd + 1.2), M(0x1b1e22, .5, .3), 0, top + .25, 0, { cast: true });
    // باغ بام
    add(g, BG(bw * .9, .35, bd * .9), M(0x3e7a3a, .95), 0, top + .65, 0);
    for (let i = 0; i < 7; i++) tree(g, (r() - .5) * bw * .75, (r() - .5) * bd * .7, .55 + r() * .25);
    add(g, BG(bw * .4, 2.6, bd * .4), new THREE.MeshStandardMaterial({ color: 0x5b88a3, roughness: .08, metalness: .8, envMapIntensity: 1.5, transparent: true, opacity: .7 }), 0, top + 2.1, 0);
    add(g, BG(bw * .46, .3, bd * .46), M(0x1b1e22, .5, .3), 0, top + 3.55, 0);
    entrance(g, bd / 2 + .6, 4, 3.1, .24, true);
  }


  // ---------- ادغام مش‌های هم‌متریال (کاهش draw call) ----------
  function mergeFrom(g, start) {
    const buckets = new Map();
    const kids = g.children.slice(start);
    for (const m of kids) {
      if (!m.isMesh || m.isInstancedMesh || Array.isArray(m.material) || !m.geometry.attributes.uv) continue;
      const k = m.material.uuid + '|' + (m.castShadow ? 1 : 0) + (m.receiveShadow ? 1 : 0);
      (buckets.get(k) || buckets.set(k, []).get(k)).push(m);
    }
    for (const list of buckets.values()) {
      if (list.length < 2) continue;
      let vCount = 0;
      const parts = list.map(m => {
        m.updateMatrix();
        const gg = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone();
        gg.applyMatrix4(m.matrix);
        vCount += gg.attributes.position.count;
        return gg;
      });
      const pos = new Float32Array(vCount * 3), nor = new Float32Array(vCount * 3), uv = new Float32Array(vCount * 2);
      let o = 0;
      for (const p of parts) {
        pos.set(p.attributes.position.array, o * 3); nor.set(p.attributes.normal.array, o * 3); uv.set(p.attributes.uv.array, o * 2);
        o += p.attributes.position.count; p.dispose();
      }
      const mg = new THREE.BufferGeometry();
      mg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      mg.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
      mg.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
      mg.computeBoundingSphere();
      const mesh = new THREE.Mesh(mg, list[0].material);
      mesh.castShadow = list[0].castShadow; mesh.receiveShadow = list[0].receiveShadow;
      for (const m of list) g.remove(m);
      g.add(mesh);
    }
  }

  // ---------- API ----------
  const STYLE = {
    home_red: buildShop, modern: buildModern, classic: buildClassic, apartment_glass: buildCurtain,
    apartment_brick: buildBrick, cylinder_tower: buildCylinder, office_curved: buildCurved, tower_dark: buildDark,
  };
  function build(b, g) {
    const key = ((b.img || '').match(/([a-z_]+)\.png/) || [])[1];
    const fn = STYLE[key] || buildShop;
    const start = g.children.length;          // بدنهٔ برخورد (پنهان) دست‌نخورده می‌ماند
    fn(b, g, rng(hash(b.id)));
    mergeFrom(g, start);
  }
  let _lastNight = -1;
  function setNight(daylight) {
    const raw = clamp(1 - daylight * 2.2, 0, 1), n = raw * raw * (3 - 2 * raw);   // نرم
    if (Math.abs(n - _lastNight) < .005) return;
    _lastNight = n;
    for (const o of NIGHT) o.m.emissiveIntensity = o.k * n;
  }
  window.ARCH3D = { build, setNight, styles: Object.keys(STYLE) };
})();
