// ===== rp-voice.js — موتور صدا: اگر صدای فارسی نبود، متن رو فینگلیش می‌کنه =====
// موتورهای انگلیسی متن فارسی رو *نمی‌خونن* (سکوت می‌کنن)؛ ولی همون متن رو
// اگر با حروف لاتین بنویسیم، با لهجهٔ بامزه می‌خونن. این فایل همین کارو می‌کنه.
'use strict';

/* ---------- جدول تبدیل فارسی به لاتین (خوانا برای موتور انگلیسی) ---------- */
const FA2LAT_WORDS = {
  // پرکاربردها که حرف‌به‌حرف بد خونده میشن
  'سلام':'salaam', 'خداحافظ':'khodaahaafez', 'ممنون':'mamnoon', 'مرسی':'merci',
  'چطوری':'chetori', 'خوبی':'khoobi', 'آره':'aare', 'نه':'na', 'باشه':'baashe',
  'بله':'bale', 'چرا':'cheraa', 'کجا':'kojaa', 'چیه':'chiye', 'چی':'chi',
  'من':'man', 'تو':'to', 'ما':'maa', 'شما':'shomaa', 'اون':'oon', 'این':'in',
  'خیلی':'kheyli', 'الان':'alaan', 'امروز':'emrooz', 'فردا':'fardaa', 'دیروز':'dirooz',
  'محله':'mahalle', 'تهران':'tehraan', 'خونه':'khoone', 'مغازه':'maghaaze',
  'پول':'pool', 'کار':'kaar', 'قهوه':'ghahve', 'نون':'noon', 'گوشت':'goosht',
  'داداش':'daadaash', 'جوون':'javoon', 'آقا':'aaghaa', 'خانم':'khaanoom',
  'مادر':'maadar', 'پدر':'pedar', 'بچه':'bache', 'دختر':'dokhtar', 'پسر':'pesar',
  'دوست':'doost', 'رفیق':'rafigh', 'عزیز':'aziz', 'قربونت':'ghorboonet',
  'هوووی':'hooooy', 'هی':'hey', 'آاااخ':'aaaakh', 'وای':'vaay', 'ای':'ey',
  'بدو':'bedo', 'بیا':'biyaa', 'برو':'boro', 'بگیر':'begir', 'بده':'bede',
  'ببخشید':'bebakhshid', 'لطفا':'lotfan', 'حتما':'hatman', 'شاید':'shaayad',
};
// نگاشت تک‌حرفی (تقریبی ولی قابل‌فهم)
const FA2LAT_CHARS = {
  'آ':'aa','ا':'a','ب':'b','پ':'p','ت':'t','ث':'s','ج':'j','چ':'ch','ح':'h','خ':'kh',
  'د':'d','ذ':'z','ر':'r','ز':'z','ژ':'zh','س':'s','ش':'sh','ص':'s','ض':'z','ط':'t',
  'ظ':'z','ع':'a','غ':'gh','ف':'f','ق':'gh','ک':'k','گ':'g','ل':'l','م':'m','ن':'n',
  'و':'oo','ه':'e','ی':'i','ي':'i','ك':'k','ئ':'e','ء':'','أ':'a','إ':'e','ؤ':'o',
  'ة':'e','َ':'a','ِ':'e','ُ':'o','ّ':'','ً':'an','ٍ':'en','ٌ':'on','ْ':'',
  '‌':' ', '،':',', '؛':';', '؟':'?', '٬':'',
  '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9',
};
// حروفی که خودشون واکه (مصوت) حساب میشن؛ بقیه صامت‌ان.
const FA_VOWEL_LETTERS = new Set(['آ','ا','و','ی','ي','ه','أ','إ','ؤ','ة']);
// خط فارسی معمولاً مصوت‌های کوتاه رو نمی‌نویسه (اعراب‌گذاری نمیشه)، برای همین تبدیل
// تک‌حرفی به‌تنهایی خیلی وقتا یه مشت صامت پشت‌سرهم تولید می‌کنه که موتور انگلیسی
// اصلاً نمی‌تونه بخونتش (مثلاً «ورزش» بدون این اصلاح میشه orzsh به‌جای varzesh).
// دو تا اصلاح اینجا انجام میشه:
//   ۱) «و» و «ی» اولِ کلمه معمولاً صامتِ v/y هستن، نه واکه.
//   ۲) بین دو صامتِ پشت‌سرهم که هیچ واکه‌ای فاصله‌شون نیست، یه واکهٔ کوتاه e می‌ذاریم.
function faToLatin(text) {
  if (!text) return '';
  // اول کلمه‌های کامل (واژه‌نامهٔ دستی، دقیق‌ترینه)
  let out = String(text);
  Object.keys(FA2LAT_WORDS).forEach(w => {
    out = out.split(w).join(' ' + FA2LAT_WORDS[w] + ' ');
  });
  const isBoundary = ch => ch === undefined || /\s/.test(ch) || ',;.!?،؛؟'.includes(ch);
  let res = '';
  let atWordStart = true;
  let prevWasConsonant = false;
  for (let i = 0; i < out.length; i++) {
    const ch = out[i];
    if (isBoundary(ch)) {
      res += (ch === '‌' ? ' ' : ch);
      atWordStart = true;
      prevWasConsonant = false;
      continue;
    }
    if (FA2LAT_CHARS[ch] === undefined) {
      if (/[؀-ۿ]/.test(ch)) { /* حرف عربی/فارسی ناشناخته، رد شو */ }
      else { res += ch; atWordStart = false; prevWasConsonant = false; }
      continue;
    }
    let lat = FA2LAT_CHARS[ch];
    let isVowel = FA_VOWEL_LETTERS.has(ch);
    if (atWordStart && (ch === 'و' || ch === 'ی' || ch === 'ي')) {
      // تک‌حرفیِ «و» به‌تنهایی یعنی حرف ربط «و» (va)
      if (ch === 'و' && isBoundary(out[i + 1])) { lat = 'va'; isVowel = true; }
      else { lat = ch === 'و' ? 'v' : 'y'; isVowel = false; }
    }
    if (lat && !isVowel && prevWasConsonant) res += 'e';
    res += lat;
    if (lat) prevWasConsonant = !isVowel;
    atWordStart = false;
  }
  return res.replace(/\s+/g, ' ').replace(/([a-z])\1{2,}/g, '$1$1').trim();
}

/* ---------- تشخیص اینکه صدای انتخاب‌شده فارسی می‌فهمه یا نه ---------- */
// آیا اصلاً می‌تونیم فارسیِ واقعی پخش کنیم؟
function hasPersianVoice() {
  const vs = (window.speechSynthesis && speechSynthesis.getVoices()) || [];
  return vs.some(v => /^fa/i.test(v.lang || '') || /persian|farsi/i.test(v.name || ''));
}
// یک بار در شروع بازی به کاربر بگو وضعیت صدا چیه
function voiceQualityNotice() {
  if (G._voiceNoticed) return;
  G._voiceNoticed = true;
  setTimeout(() => {
    if (!('speechSynthesis' in window)) {
      toast('🔇 مرورگرت از گفتار پشتیبانی نمی‌کنه — بازی بی‌صدای شخصیت اجرا میشه.');
      return;
    }
    if (hasPersianVoice()) {
      toast('🗣️ صدای فارسی پیدا شد! شخصیت‌ها با تلفظ درست حرف می‌زنن.');
    } else {
      toast('🗣️ صدای فارسی روی دستگاهت نیست — با تلفظ فینگلیش می‌خونیم. (تنظیمات → وضعیت صدا)');
    }
  }, 4000);
}

function voiceSpeaksPersian(v) {
  if (!v) return false;
  return /^fa/i.test(v.lang || '') || /persian|farsi/i.test(v.name || '');
}

/* ---------- گزارش وضعیت صدا برای کاربر ---------- */
function voiceStatus() {
  const vs = (window.speechSynthesis && speechSynthesis.getVoices()) || [];
  const fa_ = vs.filter(voiceSpeaksPersian);
  return {
    total: vs.length,
    persian: fa_.length,
    names: fa_.map(v => v.name),
    mode: fa_.length ? 'فارسی واقعی' : 'فینگلیش (لهجه‌دار)',
  };
}
function openVoiceHelp() {
  const st = voiceStatus();
  openPanel('🗣️ وضعیت صدای بازی', p => {
    if (st.persian) {
      noteP(p, '✅ عالی! ' + fa(st.persian) + ' صدای فارسی روی این دستگاه نصبه:');
      st.names.forEach(n => noteP(p, '• ' + n));
      noteP(p, 'شخصیت‌ها با تلفظ درست فارسی حرف می‌زنن.');
    } else {
      noteP(p, '⚠️ روی این دستگاه هیچ صدای فارسی نصب نیست.');
      noteP(p, 'موتورهای انگلیسی، متن فارسی رو اصلاً نمی‌خونن (سکوت می‌کنن) — برای همین بازی متن رو خودکار به فینگلیش تبدیل می‌کنه تا شنیده بشه. مثل: «سلام داداش» → «salaam daadaash»');
      const h = document.createElement('h4'); h.textContent = '🎯 برای صدای فارسی واقعی'; p.appendChild(h);
      noteP(p, '۱) ویندوز: Settings → Time & Language → Speech → Add voices → Persian رو نصب کن، بعد مرورگر رو ببند و باز کن.');
      noteP(p, '۲) اندروید: Settings → زبان‌ها → خروجی متن‌به‌گفتار → موتور Google → نصب زبان فارسی');
      noteP(p, '۳) آیفون/مک: Settings → Accessibility → Spoken Content → Voices → Persian');
      noteP(p, 'بازی خودکار تشخیص می‌ده و از همون استفاده می‌کنه — نیازی به تنظیم نیست.');
    }
    const h2 = document.createElement('h4'); h2.textContent = '🎤 تست'; p.appendChild(h2);
    actionRow(p, '👨 صدای مرد', 'یه جملهٔ نمونه', () => sayFa('سلام! من یکی از مردهای محله‌ام. حالت چطوره؟', 1, .8, 'm'));
    actionRow(p, '👩 صدای خانم', 'یه جملهٔ نمونه', () => sayFa('سلام! من یکی از خانم‌های محله‌ام. خوش اومدی!', 1.05, 1.4, 'f'));
    actionRow(p, '🧒 صدای بچه', 'یه جملهٔ نمونه', () => sayFa('سلام! من بچهٔ محله‌ام! بیا بازی کنیم!', 1.2, 1.85, 'k'));
    actionRow(p, '🔄 جستجوی دوبارهٔ صداها', 'اگه تازه فارسی نصب کردی', () => {
      pickFaVoice();
      const s2 = voiceStatus();
      toast(s2.persian ? '✅ ' + fa(s2.persian) + ' صدای فارسی پیدا شد!' : '⚠️ هنوز صدای فارسی نیست — فینگلیش فعاله.');
      closePanel(); openVoiceHelp();
    });
  });
}
