// ===== rp-extras.js — موسیقی، حیوان خانگی، عکاسی، حالت شب =====
'use strict';

/* ---------------------------------------------------------------
   🎵 موسیقی پس‌زمینه — ملودی ایرانی ساده با WebAudio
--------------------------------------------------------------- */
let musicTimer = null, musicCtx = null, musicGain = null;
// گام شور (حال‌وهوای ایرانی) — فرکانس‌ها
const SCALE_DAY   = [261.6, 277.2, 311.1, 349.2, 392.0, 415.3, 466.2, 523.3];
const SCALE_NIGHT = [196.0, 207.7, 233.1, 261.6, 293.7, 311.1, 349.2, 392.0];
function musicCtxInit() {
  if (musicCtx) return musicCtx;
  try {
    musicCtx = new (window.AudioContext || window.webkitAudioContext)();
    musicGain = musicCtx.createGain();
    musicGain.gain.value = .045;
    musicGain.connect(musicCtx.destination);
  } catch { musicCtx = null; }
  return musicCtx;
}
function musicNote(freq, dur, type) {
  if (!musicCtx) return;
  const o = musicCtx.createOscillator(), g = musicCtx.createGain();
  o.type = type || 'triangle';
  o.frequency.value = freq;
  g.gain.setValueAtTime(0, musicCtx.currentTime);
  g.gain.linearRampToValueAtTime(.5, musicCtx.currentTime + .06);
  g.gain.exponentialRampToValueAtTime(.001, musicCtx.currentTime + dur);
  o.connect(g); g.connect(musicGain);
  o.start(); o.stop(musicCtx.currentTime + dur + .05);
}
function startMusic() {
  if (!G.settings?.music || musicTimer) return;
  if (!musicCtxInit()) return;
  let i = 0;
  musicTimer = setInterval(() => {
    if (!gameStarted || gamePaused || !G.settings?.music) return;
    const night = G.hour >= 20 || G.hour < 6;
    const sc = night ? SCALE_NIGHT : SCALE_DAY;
    musicGain.gain.value = night ? .03 : .045;
    // ملودی نیمه‌تصادفی روی گام
    const steps = night ? [0, 2, 3, 2, 0, 5, 3, 2] : [0, 2, 4, 3, 5, 4, 2, 0];
    const n = sc[steps[i % steps.length]];
    musicNote(n, night ? 1.6 : 1, night ? 'sine' : 'triangle');
    if (i % 4 === 0) musicNote(sc[0] / 2, 2.2, 'sine');       // نت پایه
    i++;
  }, night_interval());
  function night_interval() { return 900; }
}
function stopMusic() {
  if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
}

/* ---------------------------------------------------------------
   🐱 حیوان خانگی
--------------------------------------------------------------- */
const PETS = {
  cat: { icon:'🐱', name:'گربه', price: 4000000, happy: 8,  food:'meat', desc:'مستقل و آروم — رو مبل می‌خوابه' },
  dog: { icon:'🐕', name:'سگ',   price: 6000000, happy: 12, food:'meat', desc:'وفادار — دنبالت میاد تو خیابون' },
  bird:{ icon:'🦜', name:'طوطی', price: 3000000, happy: 6,  food:'bread', desc:'حرف می‌زنه! تو خونه می‌مونه' },
};
const PET_NAMES = ['پشمک', 'مورچه', 'ببعی', 'نقی', 'شکلات', 'گلی', 'کاکو', 'میشو', 'پیشی', 'رعنا'];
function openPetShop() {
  openPanel('🐾 حیوون خونگی', p => {
    if (G.pet) {
      const pt = PETS[G.pet.type];
      noteP(p, pt.icon + ' ' + G.pet.name + ' — ' + pt.name + ' تو | شادی‌ش: ' + fa(G.pet.happy || 50) + '٪');
      actionRow(p, '🍖 غذا دادن', 'با ' + (ITEMS[pt.food]?.name || 'غذا') + ' از کوله | +شادی حیوون و خودت', () => {
        if (!bagTake(pt.food)) { toast('🥩 ' + (ITEMS[pt.food]?.name || 'غذا') + ' تو کوله نداری!'); return; }
        G.pet.happy = Math.min(100, (G.pet.happy || 50) + 25);
        G.happy += 6;
        toast(pt.icon + ' ' + G.pet.name + ' سیر شد و خودشو مالید بهت!');
        journal('🐾 به ' + G.pet.name + ' غذا دادم.');
        updateHUD(); openPetShop();
      });
      actionRow(p, '🎾 بازی کردن', '+۱۰ شادی خودت، +۱۵ شادی حیوون', () => {
        if (usedToday('pet', 'play')) { toast('🐾 امروز کلی بازی کردید! فردا دوباره.'); return; }
        useToday('pet', 'play');
        G.pet.happy = Math.min(100, (G.pet.happy || 50) + 15);
        G.happy += 10; G.energy -= 5;
        toast(pt.icon + ' با ' + G.pet.name + ' بازی کردی — کلی خندیدی!');
        journal('🎾 با ' + G.pet.name + ' بازی کردم.');
        updateHUD(); openPetShop();
      });
      actionRow(p, '✏️ عوض کردن اسم', 'اسم فعلی: ' + G.pet.name, () => {
        G.pet.name = PET_NAMES[Math.floor(Math.random() * PET_NAMES.length)];
        toast('✏️ اسم جدید: ' + G.pet.name); openPetShop();
      });
      return;
    }
    noteP(p, 'یه رفیق کوچولو بگیر! حیوون خونگی هر روز حالت رو بهتر می‌کنه.');
    Object.entries(PETS).forEach(([k, pt]) => {
      const price = typeof priceOf === 'function' ? priceOf(pt.price) : pt.price;
      actionRow(p, pt.icon + ' ' + pt.name, faMoney(price) + ' | ' + pt.desc, () => {
        if (G.money < price) { toast('💸 پولش رو نداری!'); return; }
        addMoney(-price);
        G.pet = { type: k, name: PET_NAMES[Math.floor(Math.random() * PET_NAMES.length)], happy: 70, day: G.dayIndex };
        G.happy += 15;
        showBanner(pt.icon + ' ' + G.pet.name + ' اومد خونه! از امروز رفیق جدیدته.', 6000);
        journal('🐾 یه ' + pt.name + ' گرفتم؛ اسمشو گذاشتم ' + G.pet.name + '.');
        window.WORLD?.refreshHome?.();
        window.WORLD?.spawnPet?.();
        updateHUD(); openPetShop();
      });
    });
  });
}
// هر روز: حیوون گشنه میشه
function petDailyTick() {
  if (!G.pet) return;
  G.pet.happy = Math.max(0, (G.pet.happy || 50) - 15);
  const pt = PETS[G.pet.type];
  if (G.pet.happy > 60) { G.happy += 4; addLog(pt.icon + ' ' + G.pet.name + ' سرحاله و کلی ذوق کرد وقتی دیدت!'); }
  else if (G.pet.happy < 25) { G.happy -= 3; addLog(pt.icon + ' ' + G.pet.name + ' گشنه‌ست و بی‌حاله... بهش غذا بده!'); }
}

/* ---------------------------------------------------------------
   📸 عکاسی و آلبوم
--------------------------------------------------------------- */
function takePhoto() {
  if (!G.phone || G.phoneBroken) { toast('📱 گوشی نداری یا خرابه!'); return; }
  const loc = window.WORLD?.insideOf?.();
  const place = loc ? (buildingById(loc)?.name || 'داخل') : 'خیابون‌های محله';
  const near = NPCS.filter(n => G.met?.[n.id] && Math.random() < .35).slice(0, 2).map(n => n.name.split(' (')[0]);
  const occ = typeof occasionOf === 'function' ? occasionOf(G.dayIndex) : null;
  const photo = {
    day: G.dayIndex,
    date: shamsiStr(G.dayIndex),
    hour: G.hour,
    place,
    people: near,
    weather: G.weather,
    occasion: occ ? occ.icon + ' ' + occ.name : null,
    gen: G.generation || 1,
  };
  G.album = G.album || [];
  G.album.unshift(photo);
  G.album = G.album.slice(0, 60);
  sfx.click();
  G.happy += 3;
  toast('📸 عکس گرفتی! (' + place + (near.length ? ' با ' + near.join(' و ') : '') + ')');
  journal('📸 یه عکس گرفتم تو ' + place + '.');
  updateHUD();
}
function openAlbum() {
  openPanel('📷 آلبوم عکس', p => {
    const al = G.album || [];
    noteP(p, 'با دکمهٔ «📸 عکس» یا از گوشی، از لحظه‌های زندگیت عکس بگیر! (' + fa(al.length) + ' عکس)');
    actionRow(p, '📸 همین الان عکس بگیر', 'از جایی که هستی', () => { takePhoto(); openAlbum(); });
    if (!al.length) { noteP(p, 'هنوز عکسی نگرفتی. برو یه جای قشنگ و ثبتش کن!'); return; }
    al.slice(0, 15).forEach(ph => {
      const w = ph.weather === 'rainy' ? '🌧️' : ph.weather === 'snowy' ? '❄️' : ph.weather === 'polluted' ? '😷' : ph.hour >= 19 || ph.hour < 6 ? '🌙' : '☀️';
      actionRow(p, w + ' ' + ph.place + (ph.occasion ? ' — ' + ph.occasion : ''),
        '📅 ' + ph.date + ' • ساعت ' + faDigits(ph.hour) +
        (ph.people.length ? ' • با ' + ph.people.join('، ') : '') +
        (ph.gen > 1 ? ' • نسل ' + fa(ph.gen) : ''),
        () => {}, true);
    });
  });
}

/* ---------------------------------------------------------------
   🌙 حالت شب — مغازه‌ها می‌بندند
--------------------------------------------------------------- */
function isNight() { return G.hour >= 22 || G.hour < 7; }
function shopOpenNow(id) {
  if (id === 'home' || id === 'park' || id === 'hospital' || id === 'policeStation' || id === 'apartment1') return true;
  if (id === 'gamenet') return G.hour >= 10;              // گیم‌نت تا دیروقت بازه
  if (id === 'bakery') return G.hour >= 5 && G.hour < 21; // نونوایی صبح زود
  return G.hour >= 8 && G.hour < 22;
}
function nightNotice(id) {
  const b = buildingById(id);
  if (G.hour >= 22 || G.hour < 5) return '🌙 ' + (b?.name || 'اینجا') + ' بسته‌ست. کرکره پایینه و چراغا خاموش... صبح بیا.';
  return '⏰ ' + (b?.name || 'اینجا') + ' هنوز باز نکرده. از ساعت ۸ صبح بازه.';
}
