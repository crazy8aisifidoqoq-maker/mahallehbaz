// ===== cars3d.js — ماشین‌های باحال: بدنهٔ واقعی، رینگ، چراغ، اسپویلر، نئون =====
'use strict';

window.CARS3D = function (THREE) {
  // ---------- استایل‌های بدنه ----------
  // z = طول (جلو مثبت)، y = ارتفاع. همهٔ اعداد متری
  const STYLES = {
    hatch: { L:3.95, W:1.72, belt:.84, roof:1.42, ride:.2, wr:.33, wbF:1.28, wbR:-1.2, cabF:.62, cabR:-1.0, rF:.05, rR:-1.0, rimR:.2 },
    sedan: { L:4.5,  W:1.8,  belt:.86, roof:1.4,  ride:.2, wr:.35, wbF:1.4,  wbR:-1.38, cabF:.55, cabR:-.75, rF:-.05, rR:-.55, rimR:.22 },
    sport: { L:4.6,  W:1.88, belt:.8,  roof:1.32, ride:.15, wr:.36, wbF:1.44, wbR:-1.4, cabF:.5,  cabR:-.8,  rF:-.1,  rR:-.6,  rimR:.25, spoiler:true, splitter:true },
    suv:   { L:4.6,  W:1.9,  belt:1.0, roof:1.62, ride:.3, wr:.4,  wbF:1.42, wbR:-1.35, cabF:.8,  cabR:-1.35, rF:.35, rR:-1.35, rimR:.25, rack:true, tall:true },
    taxi:  { L:4.4,  W:1.78, belt:.86, roof:1.4,  ride:.2, wr:.34, wbF:1.36, wbR:-1.34, cabF:.55, cabR:-.75, rF:-.05, rR:-.55, rimR:.21, taxiSign:true },
  };
  // هر ماشین بازی ← استایل + ویژگی‌ها
  const CAR_STYLE = {
    pride:  { s:'hatch', neon:0x38bdf8 },
    tiba:   { s:'hatch', neon:0x22d3ee },
    quick:  { s:'hatch', neon:0xff4d6d, stripe:0xffffff },
    p206:   { s:'hatch', neon:0xa78bfa },
    samand: { s:'sedan', neon:0x60a5fa },
    dena:   { s:'sport', neon:0xf97316, stripe:0xf97316, spoilerBig:false },
    l90:    { s:'sedan', neon:0xfbbf24 },
    haima:  { s:'suv',   neon:0x34d399 },
    camry:  { s:'sedan', neon:0x38bdf8, chrome:true },
    bmw:    { s:'sport', neon:0x3b82f6, stripe:0x3b82f6, spoilerBig:true, chrome:true },
  };

  // ---------- متریال و هندسهٔ مشترک ----------
  const M = {
    glass: new THREE.MeshPhysicalMaterial({ color: 0x0b1620, roughness: .04, metalness: .9, envMapIntensity: 2.4, clearcoat: 1 }),
    tire:  new THREE.MeshStandardMaterial({ color: 0x0b0b0d, roughness: .92 }),
    rim:   new THREE.MeshStandardMaterial({ color: 0xdfe5ee, roughness: .18, metalness: 1, envMapIntensity: 1.8 }),
    rimDark: new THREE.MeshStandardMaterial({ color: 0x1b1d22, roughness: .3, metalness: .9, envMapIntensity: 1.4 }),
    disc:  new THREE.MeshStandardMaterial({ color: 0x8a8f98, roughness: .4, metalness: .9 }),
    caliper: new THREE.MeshStandardMaterial({ color: 0xd62828, roughness: .4, metalness: .3 }),
    trim:  new THREE.MeshStandardMaterial({ color: 0x15171a, roughness: .55, metalness: .35 }),
    chrome: new THREE.MeshStandardMaterial({ color: 0xf2f4f8, roughness: .08, metalness: 1, envMapIntensity: 2 }),
    arch:  new THREE.MeshBasicMaterial({ color: 0x050506 }),
    carbon: new THREE.MeshStandardMaterial({ color: 0x0e0f12, roughness: .35, metalness: .6 }),
    headOn:  new THREE.MeshStandardMaterial({ color: 0xfffbe8, emissive: 0xfff0b8, emissiveIntensity: 2.4 }),
    headOff: new THREE.MeshStandardMaterial({ color: 0xdcd8c8, roughness: .1, metalness: .8, emissive: 0x222018, emissiveIntensity: .3 }),
    drl:     new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xdff3ff, emissiveIntensity: 1.6 }),
    tailOff: new THREE.MeshStandardMaterial({ color: 0x6d1018, emissive: 0xff1a22, emissiveIntensity: .35 }),
    tailLamp:new THREE.MeshStandardMaterial({ color: 0x9a1420, emissive: 0xff1f2a, emissiveIntensity: 1.3 }),
    tailBrake:new THREE.MeshStandardMaterial({ color: 0xc41a28, emissive: 0xff1822, emissiveIntensity: 3.6 }),
    exhaust: new THREE.MeshStandardMaterial({ color: 0xb8bcc4, roughness: .2, metalness: 1 }),
    plate: new THREE.MeshStandardMaterial({ color: 0xf3f3f3, roughness: .6 }),
    taxiSign: new THREE.MeshStandardMaterial({ color: 0xffe066, emissive: 0xffc800, emissiveIntensity: 1.2 }),
  };
  const G_ = {
    tire: new THREE.CylinderGeometry(1, 1, 1, 22),
    rimFace: new THREE.CylinderGeometry(1, 1, 1, 18),
    spoke: new THREE.BoxGeometry(.05, 1, .06),
    lip: new THREE.TorusGeometry(1, .06, 6, 20),
    box: new THREE.BoxGeometry(1, 1, 1),
    disc: new THREE.CircleGeometry(1, 20),
  };
  // نور جلوی ماشین روی زمین (مخروط نوری)
  const BEAM_TEX = (() => {
    const c = document.createElement('canvas'); c.width = 128; c.height = 256;
    const x = c.getContext('2d');
    for (let i = 0; i < 7; i++) {
      const wTop = 12 + i * 3, wBot = 36 + i * 8;
      const g = x.createLinearGradient(0, 0, 0, 256);
      g.addColorStop(0, 'rgba(255,244,205,.075)'); g.addColorStop(.5, 'rgba(255,240,190,.03)'); g.addColorStop(1, 'rgba(255,240,190,0)');
      x.fillStyle = g; x.beginPath();
      x.moveTo(64 - wTop/2, 0); x.lineTo(64 + wTop/2, 0); x.lineTo(64 + wBot, 256); x.lineTo(64 - wBot, 256); x.closePath(); x.fill();
    }
    return new THREE.CanvasTexture(c);
  })();
  const BEAM_GEO = new THREE.PlaneGeometry(4.6, 10);
  const GLOW_TEX = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d');
    const g = x.createRadialGradient(32, 32, 2, 32, 32, 31);
    g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(.35, 'rgba(255,255,255,.35)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  const SHADOW_TEX = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d');
    const g = x.createRadialGradient(32, 32, 4, 32, 32, 31);
    g.addColorStop(0, 'rgba(0,0,0,.55)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  const SHADOW_MAT = new THREE.MeshBasicMaterial({ map: SHADOW_TEX, transparent: true, depthWrite: false, opacity: .9 });

  // ---------- ابزار ----------
  function extrude(points, width, bevel) {
    const sh = new THREE.Shape();
    points.forEach((p, i) => i ? sh.lineTo(p[0], p[1]) : sh.moveTo(p[0], p[1]));
    const d = Math.max(.02, width - 2 * bevel);
    const g = new THREE.ExtrudeGeometry(sh, { depth: d, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, curveSegments: 1 });
    g.translate(0, 0, -d / 2);
    g.rotateY(-Math.PI / 2);          // طول → محور z
    return g;
  }
  function box(mat, w, h, d, x, y, z, parent) {
    const m = new THREE.Mesh(G_.box, mat);
    m.scale.set(w, h, d); m.position.set(x, y, z);
    if (parent) parent.add(m);
    return m;
  }

  // ---------- چرخ ----------
  function makeWheel(st, front, side, o) {
    const steer = new THREE.Group();
    const spin = new THREE.Group();
    steer.add(spin);
    const r = st.wr, tw = st.tall ? .3 : .26;
    const tire = new THREE.Mesh(G_.tire, M.tire);
    tire.scale.set(r, tw, r); tire.rotation.z = Math.PI / 2; tire.castShadow = true;
    spin.add(tire);
    const rimMat = o.darkRims ? M.rimDark : M.rim;
    const face = new THREE.Mesh(G_.rimFace, M.rimDark);
    face.scale.set(st.rimR * 1.02 + .08, tw * 1.02, st.rimR * 1.02 + .08); face.rotation.z = Math.PI / 2;
    spin.add(face);
    // لبهٔ رینگ + اسپوک (می‌چرخن!)
    const lip = new THREE.Mesh(G_.lip, rimMat);
    lip.scale.setScalar(r * .74); lip.rotation.y = Math.PI / 2; lip.position.x = side * tw * .5;
    spin.add(lip);
    const nSp = o.spokes || 5;
    for (let i = 0; i < nSp; i++) {
      const sp = new THREE.Mesh(G_.spoke, rimMat);
      sp.scale.set(1, r * 1.44, 1);
      sp.position.x = side * (tw * .5 - .005);
      sp.rotation.x = (i / nSp) * Math.PI;
      spin.add(sp);
    }
    const cap = new THREE.Mesh(G_.rimFace, M.chrome);
    cap.scale.set(.07, .03, .07); cap.rotation.z = Math.PI / 2; cap.position.x = side * (tw * .5 + .005);
    spin.add(cap);
    // دیسک ترمز + کالیپر (فقط پشت رینگ، از لای اسپوک پیداست)
    const disc = new THREE.Mesh(G_.rimFace, M.disc);
    disc.scale.set(r * .62, .03, r * .62); disc.rotation.z = Math.PI / 2; disc.position.x = side * (tw * .5 - .08);
    spin.add(disc);
    if (o.caliper) {
      const cal = new THREE.Mesh(G_.box, M.caliper);
      cal.scale.set(.07, r * .5, .16); cal.position.set(side * (tw * .5 - .11), r * .32, 0);
      steer.add(cal);               // کالیپر نمی‌چرخه
    }
    return { steer, spin };
  }

  // ---------- ساخت ماشین ----------
  // opts: { style:'bmw'|'hatch'|..., taxi, neon, player }
  function makeCar(color, key, opts) {
    opts = opts || {};
    const meta = CAR_STYLE[key] || {};
    const styleKey = opts.style || meta.s || 'sedan';
    const st = STYLES[styleKey] || STYLES.sedan;
    const L = st.L, W = st.W, zF = L / 2, zR = -L / 2;
    const root = new THREE.Group();
    const chassis = new THREE.Group();           // اینجا تیلت/رول می‌گیره
    root.add(chassis);

    const paint = new THREE.MeshPhysicalMaterial({
      color, roughness: .32, metalness: .62, clearcoat: 1, clearcoatRoughness: .08, envMapIntensity: .85,
    });

    // بدنهٔ اصلی (پروفایل کناری اکسترود می‌شه)
    const belt = st.belt, ride = st.ride;
    const lower = [
      [zR + .05, ride + .1], [zR + .02, belt - .08], [zR + .3, belt + .02],
      [st.cabR, belt + .05], [st.cabF, belt + .05], [zF - .55, belt - .05],
      [zF - .05, belt - .2], [zF - .02, ride + .14],
    ];
    const body = new THREE.Mesh(extrude(lower, W - .1, .1), paint);
    body.castShadow = true; chassis.add(body);

    // زیر بدنه (سیاه)، دیفیوزر
    box(M.trim, W - .25, .12, L - .5, 0, ride + .05, 0, chassis);

    // گلاس‌هاوس
    const gW = W - .24;
    const gh = [[st.cabR, belt + .03], [st.rR, st.roof - .02], [st.rF, st.roof - .02], [st.cabF + .02, belt + .03]];
    const glass = new THREE.Mesh(extrude(gh, gW, .06), M.glass);
    glass.castShadow = true; chassis.add(glass);
    // سقف رنگی
    const roofPts = [[st.rR - .04, st.roof - .03], [st.rR + .02, st.roof + .02], [st.rF - .02, st.roof + .02], [st.rF + .05, st.roof - .03]];
    const roof = new THREE.Mesh(extrude(roofPts, gW + .02, .025), opts.carbonRoof || meta.stripe && styleKey === 'sport' ? new THREE.MeshStandardMaterial({ color: 0x0c0d10, roughness: .3, metalness: .7 }) : paint);
    roof.castShadow = true; chassis.add(roof);
    // ستون‌ها (A/B/C)
    const pillarX = gW / 2 + .005;
    const pL = Math.hypot(st.cabF - st.rF, st.roof - belt);
    const aAng = Math.atan2(st.rF - st.cabF, st.roof - belt);
    [-1, 1].forEach(sd => {
      const a = box(paint, .07, pL + .04, .09, sd * pillarX, (belt + st.roof) / 2, (st.cabF + st.rF) / 2, chassis);
      a.rotation.x = aAng;
      const c = box(paint, .07, Math.hypot(st.rR - st.cabR, st.roof - belt) + .04, .12, sd * pillarX, (belt + st.roof) / 2, (st.cabR + st.rR) / 2, chassis);
      c.rotation.x = -Math.atan2(st.rR - st.cabR, st.roof - belt) * -1;
      const bz = (st.rF + st.rR) / 2 - .05;
      box(M.trim, .06, st.roof - belt - .02, .1, sd * pillarX, (belt + st.roof) / 2 + .01, bz, chassis);
    });

    // ---- جلو ----
    box(M.trim, W - .5, .3, .06, 0, ride + .34, zF - .01, chassis);                       // گریل پایین
    box(M.trim, W - .75, .2, .07, 0, belt - .16, zF - .03, chassis);                       // گریل بالا
    box(meta.chrome ? M.chrome : M.trim, W - .78, .035, .08, 0, belt - .05, zF - .03, chassis);
    box(M.carbon, W - .2, .09, .14, 0, ride + .1, zF - .06, chassis);                      // لب سپر جلو
    if (st.splitter) box(M.carbon, W - .1, .03, .32, 0, ride + .02, zF + .03, chassis);   // اسپلیتر
    // پلاک جلو
    const pY = ride + .42;
    // ---- چراغ جلو ----
    const heads = [], drls = [], tails = [];
    [-1, 1].forEach(sd => {
      const hx = sd * (W / 2 - .36);
      const h = box(M.headOff, .5, .14, .09, hx, belt - .15, zF - .06, chassis); h.rotation.y = sd * .12;
      heads.push(h);
      const d = box(M.drl, .46, .025, .09, hx, belt - .26, zF - .055, chassis); drls.push(d);
      // چراغ مه‌شکن
      box(M.headOff, .16, .08, .06, sd * (W / 2 - .3), ride + .26, zF - .05, chassis);
    });
    // ---- عقب ----
    const lightBar = styleKey === 'sport' || styleKey === 'sedan';
    [-1, 1].forEach(sd => {
      const tx = sd * (W / 2 - .33);
      const t = box(M.tailOff, .52, .14, .08, tx, belt - .06, zR + .02, chassis); t.rotation.y = -sd * .1;
      tails.push(t);
      // اگزوزها
      if (styleKey !== 'suv' && styleKey !== 'hatch') {
        const ex = new THREE.Mesh(G_.tire, M.exhaust);
        ex.scale.set(.065, .22, .065); ex.rotation.x = Math.PI / 2; ex.position.set(sd * (W / 2 - .55), ride + .13, zR - .05);
        chassis.add(ex);
        if (styleKey === 'sport') {
          const ex2 = ex.clone(); ex2.position.x = sd * (W / 2 - .78); chassis.add(ex2);
        }
      }
    });
    if (lightBar) { const lb = box(M.tailOff, W - .85, .05, .07, 0, belt - .06, zR + .0, chassis); tails.push(lb); }
    box(M.carbon, W - .2, .1, .14, 0, ride + .1, zR + .06, chassis);                         // لب سپر عقب
    if (styleKey === 'sport') box(M.carbon, W - .5, .16, .2, 0, ride + .12, zR + .02, chassis); // دیفیوزر

    // ---- پلاک‌ها (پایه — ترافیک رو می‌تونه عوض کنه) ----
    const plF = box(M.plate, .5, .12, .02, 0, pY, zF + .005, chassis);
    const plB = box(M.plate, .5, .12, .02, 0, belt - .2, zR - .005, chassis);

    // ---- آینه‌ها و دستگیره‌ها و خط درها ----
    [-1, 1].forEach(sd => {
      const mz = (st.cabF + st.rF) / 2 + .1;
      box(paint, .2, .11, .15, sd * (W / 2 + .06), belt + .22, mz, chassis);
      box(M.trim, .03, .14, .03, sd * (W / 2 - .02), belt + .16, mz, chassis);
      for (const dz of [(st.cabF + st.cabR) / 2 + .5, (st.cabF + st.cabR) / 2 - .55]) {
        box(M.chrome, .02, .025, .16, sd * (W / 2 + .005), belt - .03, dz, chassis);
      }
      box(M.trim, .012, belt - ride - .3, .018, sd * (W / 2 + .001), (belt + ride) / 2 + .02, (st.cabF + st.cabR) / 2 - .05 + (st.cabF - st.cabR) * .22, chassis);
      box(M.trim, .012, belt - ride - .3, .018, sd * (W / 2 + .001), (belt + ride) / 2 + .02, (st.cabF + st.cabR) / 2 - .05 - (st.cabF - st.cabR) * .22, chassis);
      // جلوپنجره/سیل پایین
      box(M.trim, .02, .05, (st.wbF - st.wbR) - st.wr * 2 - .16, sd * (W / 2 + .004), ride + .2, (st.wbF + st.wbR) / 2, chassis);
    });

    // ---- رگه‌های مسابقه‌ای ----
    if (meta.stripe && opts.stripes !== false) {
      const sm = new THREE.MeshStandardMaterial({ color: meta.stripe, roughness: .3, metalness: .3, emissive: meta.stripe, emissiveIntensity: .12 });
      const h = box(sm, .3, .012, 1.55, 0, belt + .018, (zF + st.cabF) / 2 - .1, chassis);
      box(sm, .3, .012, .9, 0, belt + .016, (zR + st.cabR) / 2 + .1, chassis);
      box(sm, .3, .01, st.rF - st.rR, 0, st.roof + .04, (st.rF + st.rR) / 2, chassis);
      [-1, 1].forEach(sd => box(sm, .012, .035, (st.wbF - st.wbR) - st.wr * 2 - .2, sd * (W / 2 + .003), ride + .3, (st.wbF + st.wbR) / 2, chassis));
    }

    // ---- اسپویلر ----
    if (st.spoiler) {
      const big = meta.spoilerBig;
      const wy = belt + (big ? .42 : .24);
      box(M.carbon, W - .3, .035, big ? .42 : .28, 0, wy, zR + (big ? .12 : .2), chassis);
      [-1, 1].forEach(sd => {
        box(M.carbon, .05, big ? .42 : .24, .2, sd * (W / 2 - .35), belt + (big ? .2 : .1), zR + (big ? .12 : .2), chassis);
        box(M.carbon, .03, .14, .44, sd * ((W - .3) / 2), wy + .03, zR + (big ? .12 : .2), chassis);
      });
    }
    // ---- باربند SUV ----
    if (st.rack) {
      [-1, 1].forEach(sd => box(M.chrome, .04, .04, st.rF - st.rR - .1, sd * (gW / 2 - .1), st.roof + .09, (st.rF + st.rR) / 2, chassis));
      [-.35, .35].forEach(t => box(M.chrome, gW - .15, .035, .04, 0, st.roof + .11, (st.rF + st.rR) / 2 + t, chassis));
    }
    // ---- تابلوی تاکسی ----
    if (st.taxiSign || opts.taxi) {
      const sg = new THREE.Group();
      box(M.taxiSign, .72, .17, .24, 0, 0, 0, sg);
      box(M.trim, .76, .03, .26, 0, -.1, 0, sg);
      sg.position.set(0, st.roof + .14, (st.rF + st.rR) / 2); chassis.add(sg);
      root.userData.sign = sg;
    }

    // ---- چرخ‌ها ----
    const wheelOpts = { darkRims: styleKey === 'sport' || styleKey === 'suv', spokes: styleKey === 'sport' ? 6 : 5, caliper: styleKey === 'sport' };
    const wheels = [], fronts = [];
    [[-1, st.wbF], [1, st.wbF], [-1, st.wbR], [1, st.wbR]].forEach(([sd, wz], i) => {
      const w = makeWheel(st, wz > 0, sd, wheelOpts);
      const wx = sd * (W / 2 - .13);
      w.steer.position.set(wx, st.wr, wz);
      if (sd === -1) w.spin.scale.x = 1;    // سمت چپ: اسپوک رو داخل آینه نمی‌کنیم
      chassis.add(w.steer);
      wheels.push(w.spin);
      if (wz > 0) fronts.push(w.steer);
      // قوس چرخ (دیسک مشکی روی بدنه)
      const arch = new THREE.Mesh(G_.disc, M.arch);
      arch.scale.setScalar(st.wr + .07); arch.position.set(sd * (W / 2 + .004), st.wr, wz);
      arch.rotation.y = sd * Math.PI / 2;
      chassis.add(arch);
      // گلگیر (بالای چرخ)
      const fender = box(paint, .1, .05, st.wr * 2.4, sd * (W / 2 + .0), st.wr * 2 + .1, wz, chassis);
    });

    // ---- نور جلو روی زمین + چراغ مه ----
    const beam = new THREE.Mesh(BEAM_GEO, new THREE.MeshBasicMaterial({
      map: BEAM_TEX, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, fog: false }));
    beam.rotation.x = -Math.PI / 2; beam.position.set(0, .05, zF + 4.7); beam.renderOrder = 3;
    root.add(beam);
    // درخشش چراغ عقب روی زمین
    const tg = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 3), new THREE.MeshBasicMaterial({
      map: GLOW_TEX, color: 0xff2030, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, fog: false }));
    tg.rotation.x = -Math.PI / 2; tg.position.set(0, .05, zR - 1.1); tg.renderOrder = 3;
    root.add(tg);

    // ---- نئون زیر ماشین ----
    const neonColor = opts.neon != null ? opts.neon : (meta.neon != null ? meta.neon : 0x38bdf8);
    const neon = new THREE.Mesh(new THREE.PlaneGeometry(W + 2.6, L + 2.4), new THREE.MeshBasicMaterial({
      map: GLOW_TEX, color: neonColor, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, fog: false }));
    neon.rotation.x = -Math.PI / 2; neon.position.y = .045; neon.renderOrder = 2;
    root.add(neon);

    // ---- سایهٔ تماسی ----
    const blob = new THREE.Mesh(new THREE.PlaneGeometry(W + 1.2, L + 1.4), SHADOW_MAT);
    blob.rotation.x = -Math.PI / 2; blob.position.y = .021; blob.renderOrder = 1;
    root.add(blob);

    // ---- دود/شعلهٔ اگزوز (برای نیترو) ----
    const flames = [];
    [-1, 1].forEach(sd => {
      const fl = new THREE.Mesh(new THREE.ConeGeometry(.09, 1.1, 8, 1, true), new THREE.MeshBasicMaterial({
        color: 0x5ec8ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false }));
      fl.rotation.x = -Math.PI / 2;              // نوک به عقب
      fl.position.set(sd * (W / 2 - .55), ride + .13, zR - .7);
      chassis.add(fl); flames.push(fl);
    });

    // ---- وضعیت ----
    const state = { lamps: false, brake: false, spin: 0, steer: 0, roll: 0, pitch: 0, nitro: 0, neonBase: 0 };
    const setHeadMats = on => heads.forEach(h => { h.material = on ? M.headOn : M.headOff; });
    const setTailMats = () => tails.forEach(t => { t.material = state.brake ? M.tailBrake : (state.lamps ? M.tailLamp : M.tailOff); });
    const api = {
      L, W, zF, zR, plateY: pY, plateYBack: belt - .2, styleKey,
      wheels, fronts, paint, chassis, neon, beam, tailGlow: tg, flames, plF, plB,
      head: heads, tail: tails,
      setLamps(on) {
        state.lamps = !!on; setHeadMats(on); setTailMats();
        beam.material.opacity = on ? .85 : 0;
        tg.material.opacity = on ? .35 : 0;
        neon.material.opacity = (on ? .95 : .4) * state.neonBase;
      },
      setBrake(on) {
        if (state.brake === !!on) return;
        state.brake = !!on; setTailMats();
        tg.material.opacity = on ? .85 : (state.lamps ? .35 : 0);
      },
      setNeon(v) { state.neonBase = v; neon.material.opacity = (state.lamps ? .95 : .4) * v; },
      setColor(c) { paint.color.setHex(c); },
      // سرعت (m/s)، فرمان (-1..1)، شتاب طولی/عرضی برای تیلت، نیترو
      update(dt, speed, steerIn, accel, lat, nitro) {
        state.spin += (speed / st.wr) * dt;
        wheels.forEach(w => { w.rotation.x = state.spin; });
        state.steer += (steerIn - state.steer) * Math.min(1, dt * 10);
        fronts.forEach(f => { f.rotation.y = state.steer * .5; });
        const tr = -lat * .05, tp = -accel * .012;
        state.roll += (tr - state.roll) * Math.min(1, dt * 7);
        state.pitch += (tp - state.pitch) * Math.min(1, dt * 7);
        chassis.rotation.z = state.roll;
        chassis.rotation.x = state.pitch;
        if (nitro !== undefined) {
          state.nitro += ((nitro ? 1 : 0) - state.nitro) * Math.min(1, dt * 12);
          flames.forEach(f => {
            f.material.opacity = state.nitro * .85;
            const fl = .7 + Math.random() * .6;
            f.scale.set(1, fl * state.nitro + .001, 1);
          });
        }
      },
    };
    root.userData = Object.assign(root.userData, api, {
      wheels, paint, head: heads, tail: tails, setLamps: api.setLamps,
    });
    root.userData.api = api;
    api.setLamps(false);
    api.setNeon(opts.neon === false ? 0 : (opts.player ? 1 : 0));
    return root;
  }

  return { makeCar, STYLES, CAR_STYLE };
};
