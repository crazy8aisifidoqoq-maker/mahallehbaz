// ===== interiors.js — فضای داخلی ساختمون‌ها (سه‌بعدی) =====
// هر ساختمون یه اتاق واقعی داره: کف، دیوار، دخل، صاحب‌مغازه پشت دخل، وسایل.
// اتاق‌ها زیر شهر ساخته میشن (y = -100) و بازیکن تلپورت میشه اون پایین.
'use strict';

const INTERIOR_Y = -100;

// رنگ و وسایل هر جا
const ROOM_STYLE = {
  home:       { floor:0x8d6e58, wall:0xe8d9c5, light:0xffd9a0, kind:'home' },
  cafe:       { floor:0x5a3a2a, wall:0xd9b892, light:0xffcb8a, kind:'cafe' },
  market:     { floor:0xd9d9d9, wall:0xeaf3ef, light:0xffffff, kind:'shelves' },
  bakery:     { floor:0xc9a86a, wall:0xf3e6c8, light:0xffdca0, kind:'bakery' },
  restaurant: { floor:0x6b3b3b, wall:0xf0d9c0, light:0xffcf9a, kind:'tables' },
  university: { floor:0xb9c6cf, wall:0xeef3f7, light:0xffffff, kind:'desks' },
  bank:       { floor:0xc9ccd6, wall:0xe6ebf2, light:0xffffff, kind:'counterline' },
  hospital:   { floor:0xdfe9ee, wall:0xf6fbff, light:0xffffff, kind:'beds' },
  mobile:     { floor:0x3a2f4a, wall:0xe4dcf0, light:0xd8c8ff, kind:'glass' },
  clothes:    { floor:0xe6c8c8, wall:0xfaeaea, light:0xffe6e6, kind:'racks' },
  dealership: { floor:0xcfd6da, wall:0xeaf2f6, light:0xffffff, kind:'cars' },
  repair:     { floor:0x565c66, wall:0xa9b0bb, light:0xfff0c0, kind:'garage' },
  gym:        { floor:0x6e2020, wall:0xf0dcdc, light:0xffe0d0, kind:'gym' },
  airport:    { floor:0xb7c2cc, wall:0xeaf1f6, light:0xffffff, kind:'seats' },
  terminal:   { floor:0xd8c07a, wall:0xf6ecd0, light:0xfff0c8, kind:'seats' },
  apartment1: { floor:0x9c7c5c, wall:0xe6dccc, light:0xffe0b0, kind:'lobby' },
  flower:     { floor:0xd8f0d8, wall:0xfbe8f2, light:0xffe8f4, kind:'flowers' },
  book:       { floor:0x8a7a5e, wall:0xefe6d4, light:0xffe8c0, kind:'books' },
  pastry:     { floor:0xe8d6f0, wall:0xfaeefc, light:0xffe8ff, kind:'cakes' },
  juice:      { floor:0xd6f5e0, wall:0xeafbf0, light:0xe8fff0, kind:'juice' },
  gamenet:    { floor:0x1c2233, wall:0x2a3550, light:0x7fd0ff, kind:'pcs' },
  salon:      { floor:0x2e6b66, wall:0xdff0ee, light:0xfff0d0, kind:'salon' },
  mosque:     { floor:0x1f5f57, wall:0xf2ead6, light:0xffe9b0, kind:'mosque' },
  robotics:   { floor:0x241c38, wall:0x3a2f56, light:0xb08cff, kind:'robots' },
  dairy:      { floor:0xeef0e8, wall:0xfbfcf6, light:0xffffff, kind:'fridge' },
  mansion:    { floor:0x7a5c3e, wall:0xe8dcc2, light:0xffdfa0, kind:'museum' },
  realty:     { floor:0xa5895f, wall:0xf0e6d2, light:0xffe6b0, kind:'desks' },
  policeStation: { floor:0xcdd5df, wall:0xe8eef6, light:0xffffff, kind:'police' },
  butcher:    { floor:0xe8dede, wall:0xf6ecec, light:0xffe0d0, kind:'butcher' },
};

function createInteriors(api) {
  const { THREE, scene, mat, makePerson, makeLabel3D, player, camera } = api;
  const S = {
    group: null, id: null, colliders: [], targets: [], lights: [],
    seatMode: null, waiter: null, guest: null, animals: [],
  };

  const box = (w, h, d, color, x, y, z, rotY = 0) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(color));
    m.position.set(x, INTERIOR_Y + y, z);
    m.rotation.y = rotY;
    m.castShadow = m.receiveShadow = true;
    S.group.add(m);
    return m;
  };
  const cyl = (r1, r2, h, color, x, y, z) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r2, h, 14), mat(color));
    m.position.set(x, INTERIOR_Y + y, z);
    S.group.add(m);
    return m;
  };
  const solid = (x, z, hx, hz) => S.colliders.push({ x, z, hx, hz });

  // ---------- میز و صندلی ----------
  function table(x, z, color = 0x7a4a2a) {
    const top = box(1.6, .12, 1.6, color, x, 1.0, z);
    cyl(.12, .18, 1.0, 0x4a3020, x, .5, z);
    solid(x, z, .9, .9);
    return top;
  }
  function chair(x, z, rotY, color = 0x8a5a3a) {
    box(.6, .1, .6, color, x, .58, z, rotY);
    box(.6, .7, .1, color, x - Math.sin(rotY) * .28, .95, z - Math.cos(rotY) * .28, rotY);
    [[-.24, -.24], [.24, -.24], [-.24, .24], [.24, .24]].forEach(([ox, oz]) =>
      cyl(.05, .05, .55, 0x4a3020, x + ox, .28, z + oz));
  }
  function shelf(x, z, w, rotY, color, items = 0xffffff) {
    box(w, .18, .7, color, x, .6, z, rotY);
    box(w, .18, .7, color, x, 1.25, z, rotY);
    box(w, .18, .7, color, x, 1.9, z, rotY);
    box(w, .1, .7, color, x, 2.35, z, rotY);
    solid(x, z, Math.abs(Math.cos(rotY)) * w / 2 + .2, Math.abs(Math.sin(rotY)) * w / 2 + .45);
    for (let i = 0; i < Math.floor(w / .55); i++) {
      const ox = (-w / 2 + .35 + i * .55);
      [.85, 1.5, 2.15].forEach(h => {
        const c = new THREE.Mesh(new THREE.BoxGeometry(.3, .34, .3),
          mat([items, 0xff7f50, 0x6ab04c, 0xf9ca24, 0x686de0][(i + Math.round(h * 2)) % 5]));
        c.position.set(x + Math.cos(rotY) * ox, INTERIOR_Y + h, z - Math.sin(rotY) * ox);
        S.group.add(c);
      });
    }
  }

  // ---------- ساخت اتاق ----------
  function buildRoom(b) {
    const st = ROOM_STYLE[b.id] || { floor: 0xb0a08c, wall: 0xece2d2, light: 0xffe8c0, kind: 'plain' };
    const W = Math.max(17, b.w + 8), D = Math.max(15, b.d + 7), H = 5.2;

    // کف
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), mat(st.floor, .95, 0));
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, INTERIOR_Y, 0);
    floor.receiveShadow = true;
    S.group.add(floor);
    // فرش/کاشی وسط
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(W * .55, D * .5), mat(st.wall, 1, 0));
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0, INTERIOR_Y + .02, 0);
    S.group.add(rug);

    // دیوارها (جلو با درِ باز)
    const wallMat = st.wall;
    box(W, H, .3, wallMat, 0, H / 2, -D / 2);            // پشت
    box(.3, H, D, wallMat, -W / 2, H / 2, 0);            // چپ
    box(.3, H, D, wallMat, W / 2, H / 2, 0);             // راست
    const gap = 3.2;
    box((W - gap) / 2, H, .3, wallMat, -(W + gap) / 4, H / 2, D / 2);
    box((W - gap) / 2, H, .3, wallMat, (W + gap) / 4, H / 2, D / 2);
    solid(0, -D / 2, W / 2, .4); solid(-W / 2, 0, .4, D / 2); solid(W / 2, 0, .4, D / 2);
    solid(-(W + gap) / 4, D / 2, (W - gap) / 4, .4);
    solid((W + gap) / 4, D / 2, (W - gap) / 4, .4);
    solid(0, D / 2, gap / 2 + .3, .4);   // درِ باز هم دیوار نامرئی داره — خروج فقط با E

    // در خروج
    const door = box(gap - .3, 2.6, .16, 0x5c3a21, 0, 1.3, D / 2 - .02);
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(gap - .5, 2.4),
      new THREE.MeshBasicMaterial({ color: 0xffd166, transparent: true, opacity: .22 }));
    glow.position.set(0, INTERIOR_Y + 1.3, D / 2 - .16);
    S.group.add(glow);
    S.targets.push({ type: 'exit', x: 0, z: D / 2 - 1.6, r: 2.6, label: '🚪 برگرد به خیابون' });

    // سقف (که آسمون تو اتاق دیده نشه)
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(W, D), mat(st.wall, 1, 0));
    ceil.rotation.x = Math.PI / 2;
    ceil.position.set(0, INTERIOR_Y + H, 0);
    S.group.add(ceil);

    // نور سقف
    for (const px of [-W / 4, W / 4]) {
      const l = new THREE.PointLight(st.light, 1.5, 26, 1.6);
      l.position.set(px, INTERIOR_Y + H - .5, 0);
      S.group.add(l); S.lights.push(l);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(.22, 8, 8),
        new THREE.MeshStandardMaterial({ color: 0xfff6d8, emissive: st.light, emissiveIntensity: 1.4 }));
      bulb.position.set(px, INTERIOR_Y + H - .45, 0);
      S.group.add(bulb);
    }
    const amb = new THREE.HemisphereLight(0xffffff, st.floor, .55);
    amb.position.set(0, INTERIOR_Y + H, 0);
    S.group.add(amb); S.lights.push(amb);

    // تابلوی اسم
    const lbl = makeLabel3D(b.icon + ' ' + b.name);
    lbl.position.set(0, INTERIOR_Y + H - .6, -D / 2 + .5);
    lbl.scale.set(7, 1.7, 1);
    S.group.add(lbl);

    const R = { W, D, H, st };
    commonDecor(b, R);
    return R;
  }

  // ---------- دکور مشترک همهٔ اتاق‌ها: قاب عکس، پنجره، گلدون، قرنیز، ساعت ----------
  function commonDecor(b, R) {
    const { W, D, H, st } = R;
    // قرنیز دور دیوارها
    box(W - .4, .22, .1, 0x4a3b2e, 0, .11, -D / 2 + .22);
    box(.1, .22, D - .4, 0x4a3b2e, -W / 2 + .22, .11, 0);
    box(.1, .22, D - .4, 0x4a3b2e, W / 2 - .22, .11, 0);
    // دو قاب عکس روی دیوار پشتی (رنگ‌ها از حال‌وهوای همون مغازه)
    const artColors = [st.light, st.floor, 0xe07a5f, 0x457b9d];
    [-W / 4 - 1.5, W / 4 + 1.5].forEach((x, i) => {
      box(1.3, 1.0, .08, 0x3b2f24, x, 3.1, -D / 2 + .35);
      box(1.05, .78, .05, artColors[(i * 2 + b.id.length) % 4], x, 3.1, -D / 2 + .42);
    });
    // پنجره‌های دیوار کناری با شیشهٔ روشن
    for (const sx of [-W / 2 + .22, W / 2 - .22]) {
      const win = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.5),
        new THREE.MeshStandardMaterial({ color: 0xbfe3ff, emissive: 0x9ecbff, emissiveIntensity: .4 }));
      win.position.set(sx + (sx < 0 ? .12 : -.12), INTERIOR_Y + 2.7, D / 4 - 1);
      win.rotation.y = sx < 0 ? Math.PI / 2 : -Math.PI / 2;
      S.group.add(win);
      box(2.8, .12, .16, 0x4a3b2e, sx, 1.9, D / 4 - 1);
    }
    // گلدون‌های کنج
    [[-W / 2 + 1.2, D / 2 - 1.6], [W / 2 - 1.2, D / 2 - 1.6]].forEach(([x, z]) => {
      cyl(.34, .26, .55, 0x9c6644, x, .28, z);
      const leaf = new THREE.Mesh(new THREE.SphereGeometry(.5, 8, 7), mat(0x2d6a4f));
      leaf.scale.set(1, 1.5, 1);
      leaf.position.set(x, INTERIOR_Y + 1.15, z);
      S.group.add(leaf);
    });
    // ساعت دیواری
    const clock = cyl(.42, .42, .07, 0xf1faee, W / 4 - 1, 0, -D / 2 + .4);
    clock.rotation.x = Math.PI / 2;
    clock.position.set(W / 4 - 1, INTERIOR_Y + 3.6, -D / 2 + .35);
    box(.05, .28, .03, 0x222222, W / 4 - 1, 3.65, -D / 2 + .3);
  }

  // ---------- دخل + صاحب‌مغازه ----------
  function buildCounter(b, R, npc) {
    const cz = -R.D / 2 + 3.2;
    box(6.4, 1.05, .9, 0x6b4a2f, 0, .52, cz);
    box(6.6, .12, 1.1, 0x8a6540, 0, 1.12, cz);
    solid(0, cz, 3.3, .8);
    // صندوق
    box(.8, .5, .6, 0x2b2b33, 2.2, 1.4, cz);
    box(.7, .05, .5, 0x111318, 2.2, 1.67, cz);
    if (npc) {
      const m = makePerson(npc.color, npc.look);
      m.position.set(-.6, INTERIOR_Y, cz - 1.5);
      m.rotation.y = 0;                           // رو به مشتری (0 = رو به درِ ورودی)
      const lbl = makeLabel3D(npc.name.split(' (')[0]);
      lbl.position.y = 3.3; lbl.scale.set(5.5, 1.4, 1);
      m.add(lbl);
      S.group.add(m);
      S.targets.push({ type: 'npc', npc, x: 0, z: cz - .2, r: 3.4, label: '💬 گفتگو با ' + npc.name.split(' (')[0], mesh: m });
      S.shopkeeperMesh = m;
      (S.lookers = S.lookers || []).push(m);
    }
    S.targets.push({ type: 'shop', b, x: 0, z: cz + 1.6, r: 2.4, label: '🛒 ' + b.name });
  }

  // ---------- وسایل مخصوص هر جا ----------
  function buildProps(b, R) {
    const k = R.st.kind, W = R.W, D = R.D, H = R.H;
    switch (k) {
      case 'home': {
        box(2.2, .5, 3.4, 0x9c5f4a, -W / 2 + 2.4, .3, -D / 2 + 3.2);          // تخت
        box(2.0, .25, 1.4, 0xf1faee, -W / 2 + 2.4, .62, -D / 2 + 2.2);        // بالش/پتو
        solid(-W / 2 + 2.4, -D / 2 + 3.2, 1.3, 1.9);
        box(3.2, .9, 1.2, 0x3d5a80, W / 2 - 3, .55, -D / 2 + 2.6);            // مبل
        solid(W / 2 - 3, -D / 2 + 2.6, 1.7, .8);
        box(1.6, 1.0, .12, 0x14161f, W / 2 - 3, 1.6, -D / 2 + .6);            // تلویزیون
        box(3.0, .9, .8, 0x8d6a4f, -W / 2 + 2.5, .5, D / 2 - 3);              // آشپزخونه
        solid(-W / 2 + 2.5, D / 2 - 3, 1.6, .6);
        table(1.5, 1.5); chair(1.5, 2.8, 0); chair(1.5, .2, Math.PI);
        // 🛋️ مبلمانی که خریدی واقعاً تو خونه دیده میشه
        if (G.home && G.home.items) {
          const it = G.home.items;
          if (it.sofa)   { box(3.6, 1, 1.4, 0x3d5a80, -W/2 + 4, .6, 2.5); solid(-W/2 + 4, 2.5, 1.9, .8); }
          if (it.tv)     { box(2.6, 1.5, .16, 0x14161f, 0, 2, -D/2 + .6); box(.5, .5, .4, 0x2b2b33, 0, 1.1, -D/2 + .8); }
          if (it.carpet) { const rg = new THREE.Mesh(new THREE.PlaneGeometry(6, 4.4), mat(0x8a2b2b, 1, 0)); rg.rotation.x = -Math.PI/2; rg.position.set(0, INTERIOR_Y + .04, 1.5); S.group.add(rg); }
          if (it.plant)  { cyl(.5, .4, .8, 0x9c6644, W/2 - 2, .4, 3); const lf = new THREE.Mesh(new THREE.SphereGeometry(.8, 9, 8), mat(0x2d6a4f)); lf.scale.set(1, 1.5, 1); lf.position.set(W/2 - 2, INTERIOR_Y + 1.6, 3); S.group.add(lf); }
          if (it.fridge) { box(1.6, 3, 1.4, 0xdff3ff, -W/2 + 2, 1.5, -D/2 + 4); solid(-W/2 + 2, -D/2 + 4, 1, .9); }
          if (it.bed)    { box(3, .7, 4.4, 0x9c5f4a, W/2 - 3.5, .4, -D/2 + 4); box(2.7, .3, 2, 0xf1faee, W/2 - 3.5, .85, -D/2 + 3); solid(W/2 - 3.5, -D/2 + 4, 1.7, 2.4); }
          if (it.desk)   { box(2.4, .12, 1.2, 0x8b7456, -W/2 + 5, 1.1, -D/2 + 2.5); box(1, .7, .08, 0x0b1020, -W/2 + 5, 1.6, -D/2 + 2.2); }
          if (it.lamp)   { cyl(.06, .06, 1.6, 0x555555, W/2 - 5, .8, -D/2 + 2.4); const bl = new THREE.Mesh(new THREE.SphereGeometry(.22, 8, 8), new THREE.MeshStandardMaterial({ color: 0xfff6d8, emissive: 0xffd166, emissiveIntensity: 1.6 })); bl.position.set(W/2 - 5, INTERIOR_Y + 1.7, -D/2 + 2.4); S.group.add(bl); }
        }
        if (G.childName) {
          box(1.5, .4, 2.2, 0xffb703, W / 2 - 2.4, .26, D / 2 - 3.4);          // تخت بچه
          solid(W / 2 - 2.4, D / 2 - 3.4, .9, 1.2);
          const kid = makePerson(0x06d6a0, { style: 'hair', hair: 0x1f1710 });
          kid.scale.set(.62, .62, .62);
          kid.position.set(W / 2 - 3.6, INTERIOR_Y, D / 2 - 4.6);
          kid.rotation.y = -2.2;
          const lbl = makeLabel3D('👶 ' + G.childName);
          lbl.position.y = 3.4; lbl.scale.set(5, 1.3, 1);
          kid.add(lbl);
          S.group.add(kid);
          S.targets.push({ type: 'child', x: W / 2 - 3.6, z: D / 2 - 4.6, r: 3, label: '👶 بازی با ' + G.childName, mesh: kid });
        }
        if (G.married) {
          const wife = NPCS.find(n => n.id === G.married);
          if (wife) {
            const wm = makePerson(wife.color, wife.look);
            wm.position.set(W / 2 - 4.4, INTERIOR_Y, -D / 2 + 3.6);
            wm.rotation.y = -1.2;
            const lbl = makeLabel3D('💍 ' + wife.name.split(' (')[0]);
            lbl.position.y = 3.3; lbl.scale.set(5.5, 1.4, 1);
            wm.add(lbl);
            S.group.add(wm);
            S.targets.push({ type: 'npc', npc: wife, x: W / 2 - 4.4, z: -D / 2 + 3.6, r: 3.2, label: '💬 گفتگو با ' + wife.name.split(' (')[0], mesh: wm });
            (S.lookers = S.lookers || []).push(wm);
          }
        }
        break;
      }
      case 'cafe': {
        S.tables = [];
        // فرش گرم زیر میزها
        const cafeRug = new THREE.Mesh(new THREE.PlaneGeometry(10.5, 6.5), mat(0x7a4030, 1, 0));
        cafeRug.rotation.x = -Math.PI / 2;
        cafeRug.position.set(0, INTERIOR_Y + .03, 0);
        S.group.add(cafeRug);
        [[-3.6, 1.2], [3.6, 1.2], [-3.6, -1.6], [3.6, -1.6]].forEach(([x, z], ti) => {
          table(x, z, 0x4a2f20);
          chair(x, z + 1.25, 0); chair(x, z - 1.25, Math.PI);
          S.tables.push({ x, z });
          // فنجون و شمع روی هر میز
          cyl(.09, .08, .12, 0xf1faee, x + .35, 1.13, z + .3);
          cyl(.06, .06, .18, 0xffd166, x - .3, 1.16, z - .25);
          const flame = new THREE.Mesh(new THREE.SphereGeometry(.05, 6, 6),
            new THREE.MeshStandardMaterial({ color: 0xffb703, emissive: 0xff9505, emissiveIntensity: 2 }));
          flame.position.set(x - .3, INTERIOR_Y + 1.3, z - .25);
          S.group.add(flame);
        });
        box(1.2, 1.1, .7, 0xb0b6bd, -2.2, 1.6, -D / 2 + 3.1);                 // اسپرسوساز
        box(.5, .5, .5, 0x8b5e34, -1.2, 1.4, -D / 2 + 3.1);
        for (let i = 0; i < 4; i++) box(.28, .34, .28, 0xf1faee, .6 + i * .4, 1.35, -D / 2 + 3.1);
        // تابلوی منو پشت دخل
        box(2.6, 1.6, .08, 0x1f1b16, 0, 3.3, -D / 2 + .35);
        for (let i = 0; i < 4; i++) box(1.9, .1, .04, 0xd9b892, -0.1, 3.75 - i * .3, -D / 2 + .42);
        // چراغ‌های آویز بالای میزها
        [[-3.6, 0], [3.6, 0]].forEach(([x, z]) => {
          cyl(.03, .03, 1.4, 0x2b2b2b, x, H - .7, z);
          const shade2 = cyl(.42, .2, .4, 0xc9722e, x, H - 1.55, z);
          const pl = new THREE.PointLight(0xffcb8a, 1.2, 9, 2);
          pl.position.set(x, INTERIOR_Y + H - 1.8, z);
          S.group.add(pl); S.lights.push(pl);
        });
        // ویترین کیک کنار دخل
        box(1.8, 1.05, .9, 0x8a6540, 3.4, .55, -D / 2 + 3.1);
        box(1.7, .5, .8, 0xcfe8f0, 3.4, 1.3, -D / 2 + 3.1);
        for (let i = 0; i < 3; i++) cyl(.2, .2, .2, [0xffd166, 0xff8fab, 0x8b5e34][i], 2.9 + i * .5, 1.2, -D / 2 + 3.1);
        solid(3.4, -D / 2 + 3.1, 1, .6);
        // مهمون‌های رندم امروز: هر روز چند نفر از اهالی سر میزها نشستن (میشه باهاشون حرف زد)
        if (typeof NPCS !== 'undefined') {
          const keeperId = (typeof shopkeeperOf === 'function' && shopkeeperOf('cafe')?.id) || null;
          const pool = NPCS.filter(n => !n.kid && n.id !== keeperId && npcHereToday(n) && !npcInShopToday(n));
          const count = 1 + (G.dayIndex % 3);                     // ۱ تا ۳ مهمون
          const used = new Set();
          for (let i = 0; i < count && pool.length; i++) {
            let idx = (G.dayIndex * 7 + i * 13) % pool.length;
            while (used.has(idx)) idx = (idx + 1) % pool.length;
            used.add(idx);
            const npc = pool[idx];
            const tb = S.tables[(i + 1) % S.tables.length];        // میز اول برای قراره
            const side = i % 2 ? 1 : -1;
            const gm = makePerson(npc.color, npc.look);
            sit(gm, tb.x, tb.z + side * 1.3, side > 0 ? Math.PI : 0);
            const gl = makeLabel3D(npc.name.split(' (')[0]);
            gl.position.y = 3.3; gl.scale.set(5.5, 1.4, 1);
            gm.add(gl);
            S.group.add(gm);
            S.targets.push({ type: 'npc', npc, x: tb.x, z: tb.z + side * 1.3, r: 2.6,
              label: '💬 گفتگو با ' + npc.name.split(' (')[0], mesh: gm });
            (S.lookers = S.lookers || []).push(gm);
          }
        }
        break;
      }
      case 'tables': {
        [[-4, 2], [0, 2], [4, 2], [-4, -1.5], [0, -1.5], [4, -1.5]].forEach(([x, z]) => {
          table(x, z, 0x7a3f2a); chair(x, z + 1.2, 0); chair(x, z - 1.2, Math.PI);
          // رومیزی و بشقاب و لیوان
          box(1.3, .03, 1.3, 0xf6ecd0, x, 1.08, z);
          cyl(.22, .22, .04, 0xffffff, x + .3, 1.13, z + .25);
          cyl(.07, .06, .16, 0x9adcff, x - .3, 1.18, z - .2);
        });
        // سماور بزرگ و قوری کنار دخل
        cyl(.45, .55, 1.1, 0xd4af37, W / 2 - 2.2, 1.7, -D / 2 + 3.1);
        cyl(.2, .24, .3, 0xb08968, W / 2 - 2.2, 2.4, -D / 2 + 3.1);
        // دیگ‌های غذا روی اجاق
        box(2.6, .95, 1, 0x4a4a55, -W / 2 + 2.6, 1.55, -D / 2 + 3);
        [0, 1].forEach(i => cyl(.4, .4, .35, 0xcfd6da, -W / 2 + 2 + i * 1.3, 2.2, -D / 2 + 3));
        break;
      }
      case 'shelves': case 'fridge': {
        shelf(-W / 2 + 2, 0, D - 5, Math.PI / 2, 0xbfc7cf);
        shelf(W / 2 - 2, 0, D - 5, Math.PI / 2, 0xbfc7cf);
        shelf(0, -1.5, W - 8, 0, 0xbfc7cf);
        // جعبه‌های میوه جلوی مغازه + یخچال نوشابه
        [[0xff6b35, 'پرتقال'], [0xd62828, 'گوجه'], [0x80ed99, 'خیار'], [0xffd166, 'موز']].forEach(([c], i) => {
          const bx = -3.5 + i * 2.3, bz = D / 2 - 3.2;
          box(1.6, .5, 1.1, 0x9c6644, bx, .3, bz);
          for (let j = 0; j < 6; j++) {
            const fr = new THREE.Mesh(new THREE.SphereGeometry(.16, 7, 6), mat(c));
            fr.position.set(bx - .5 + (j % 3) * .5, INTERIOR_Y + .66, bz - .2 + Math.floor(j / 3) * .4);
            S.group.add(fr);
          }
          solid(bx, bz, .9, .65);
        });
        box(1.4, 2.6, .9, 0xd62828, W / 2 - 1.6, 1.3, -D / 2 + 4.5);          // یخچال نوشابه
        box(1.1, 1.9, .1, 0x9adcff, W / 2 - 1.6, 1.45, -D / 2 + 4.02);
        solid(W / 2 - 1.6, -D / 2 + 4.5, .8, .6);
        if (k === 'fridge') for (let i = 0; i < 3; i++) box(1.6, 2.4, 1, 0xdff3ff, -3 + i * 3, 1.2, D / 2 - 3);
        break;
      }
      case 'bakery': {
        box(4.2, 2.6, 1.6, 0x8a4b2a, -W / 2 + 3.4, 1.3, -1);                  // تنور
        solid(-W / 2 + 3.4, -1, 2.2, .9);
        const fire = new THREE.PointLight(0xff8a3c, 2.4, 12, 2);
        fire.position.set(-W / 2 + 3.4, INTERIOR_Y + 1.2, .2);
        S.group.add(fire); S.lights.push(fire);
        for (let i = 0; i < 8; i++) {
          const n = new THREE.Mesh(new THREE.SphereGeometry(.28, 8, 6), mat(0xd9a441));
          n.scale.set(1.6, .5, 1);
          n.position.set(1 + (i % 4) * .9, INTERIOR_Y + 1.35 + Math.floor(i / 4) * .65, D / 2 - 3.5);
          S.group.add(n);
        }
        box(4.4, .12, 1.2, 0x8a6540, 2.6, 1.25, D / 2 - 3.5);
        box(4.4, .12, 1.2, 0x8a6540, 2.6, 1.9, D / 2 - 3.5);
        break;
      }
      case 'desks': {
        for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
          box(1.8, .1, .9, 0xa9764a, -4 + c * 4, .85, -2 + r * 2.4);
          cyl(.08, .08, .8, 0x555, -4.7 + c * 4, .4, -2 + r * 2.4);
          cyl(.08, .08, .8, 0x555, -3.3 + c * 4, .4, -2 + r * 2.4);
          chair(-4 + c * 4, -1.2 + r * 2.4, 0, 0x4a6fa5);
        }
        box(W - 4, 2.2, .12, 0x2f4f3f, 0, 2.2, -D / 2 + .45);                  // تخته
        break;
      }
      case 'counterline': {
        box(W - 5, 1.1, 1, 0xa8b0bd, 0, .55, -1.5);
        solid(0, -1.5, (W - 5) / 2, .8);
        for (let i = 0; i < 3; i++) box(.7, .5, .5, 0x2b2b33, -3 + i * 3, 1.4, -1.5);
        for (let i = 0; i < 4; i++) chair(-4.5 + i * 3, 3, Math.PI, 0x556677);
        break;
      }
      case 'beds': {
        for (let i = 0; i < 4; i++) {
          const x = -W / 2 + 3 + i * 3.4;
          box(1.5, .55, 3, 0xf1faee, x, .35, -D / 2 + 3.4);
          box(1.4, .2, 1, 0x9fd3e8, x, .68, -D / 2 + 2.4);
          solid(x, -D / 2 + 3.4, .9, 1.7);
          box(.4, 1.6, .4, 0xc9ccd1, x + 1.1, .8, -D / 2 + 2);
        }
        break;
      }
      case 'glass': {
        for (let i = 0; i < 3; i++) {
          box(3.4, 1.1, .9, 0x2b2140, -4.5 + i * 4.5, .6, -1);
          box(3.4, .1, .9, 0x9ad8ff, -4.5 + i * 4.5, 1.2, -1);
          solid(-4.5 + i * 4.5, -1, 1.8, .7);
          for (let j = 0; j < 4; j++) box(.28, .05, .5, 0x1a1a22, -5.6 + i * 4.5 + j * .7, 1.28, -1);
        }
        break;
      }
      case 'racks': {
        const buyIt = (cost, msg, extra) => () => {
          const c = Math.round(cost * G.eco.housingCoef);
          if (G.money < c) { toast('💸 فروشنده: «قابل شما رو نداره» (داره)'); return; }
          addMoney(-c); (extra || (() => G.happy += 8))(); toast(msg); updateHUD();
        };
        const price = c => faMoney(Math.round(c * G.eco.housingCoef));
        // — رگال پیراهن و کت (چپ)
        const shirtX = -W / 2 + 2.6;
        cyl(.06, .06, 2.2, 0xaaaaaa, shirtX, 1.1, -1.5);
        box(.1, .1, 3.4, 0xaaaaaa, shirtX, 2.15, -1.5);
        for (let j = 0; j < 6; j++)
          box(.5, 1.1, .12, [0xef476f, 0x118ab2, 0xffd166, 0x06d6a0, 0xf78c6b, 0x9b5de5][j], shirtX, 1.5, -3.1 + j * .55);
        solid(shirtX, -1.5, .5, 1.8);
        S.targets.push({ type: 'buy', x: shirtX + 1.2, z: -1.5, r: 2.2, label: '👔 خرید پیراهن و کت', say: 'اینا تازه رسیدن! یه دست کامل بپوشی، محله برات سوت میزنه!', goods: [
          { label: '👔 دست لباس کامل', sub: () => price(6000000 * (G.clothesLevel + 1)) + ' | +۱۲ شادی، تیپ بهتر', buy: () => {
            const c = Math.round(6000000 * (G.clothesLevel + 1) * G.eco.housingCoef);
            if (G.money < c) { toast('💸 فروشنده: «قابل شما رو نداره» (داره)'); return; }
            addMoney(-c); G.clothesLevel++; G.happy += 12; toast('👔 چه تیپی زدی!'); updateHUD();
          } },
          { label: '👕 پیراهن اسپرت', sub: () => price(2500000) + ' | +۸ شادی', buy: buyIt(2500000, '👕 چه رنگی بهت میاد!') },
        ]});
        // — میز شلوار (وسط)
        box(2.4, .9, 1.2, 0x8a6a52, 0, .45, -1.5);
        for (let j = 0; j < 4; j++) box(.5, .14, 1, [0x264653, 0x1d3557, 0x555b6e, 0x6b4a2f][j], -.9 + j * .6, .98, -1.5);
        solid(0, -1.5, 1.3, .8);
        S.targets.push({ type: 'buy', x: 0, z: 0, r: 2, label: '👖 خرید شلوار', say: 'جین، پارچه‌ای، کتان — کدوم مدلی هستی؟', goods: [
          { label: '👖 شلوار جین', sub: () => price(3200000) + ' | +۸ شادی', buy: buyIt(3200000, '👖 قالب تنته!') },
          { label: '👖 شلوار پارچه‌ای رسمی', sub: () => price(4200000) + ' | +۹ شادی', buy: buyIt(4200000, '👖 رسمی و شیک!', () => G.happy += 9) },
        ]});
        // — استند کلاه (راست، جلو)
        cyl(.08, .08, 2, 0x8a6a52, W / 2 - 3, 1, 1.8);
        [[-.35, 1.9, 0x264653], [.35, 1.75, 0xd62828], [0, 2.1, 0x2a9d8f]].forEach(([ox, h, c]) => {
          const crown = new THREE.Mesh(new THREE.SphereGeometry(.24, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(c));
          crown.position.set(W / 2 - 3 + ox, INTERIOR_Y + h, 1.8);
          S.group.add(crown);
          cyl(.32, .32, .05, c, W / 2 - 3 + ox, h - .02, 1.8);
        });
        solid(W / 2 - 3, 1.8, .5, .5);
        S.targets.push({ type: 'buy', x: W / 2 - 3, z: 2.8, r: 2, label: '🧢 خرید کلاه', say: 'کلاه نقاب‌دار، شاپو، بافتنی — سرت رو خوش‌تیپ کن!', goods: [
          { label: '🧢 کلاه نقاب‌دار', sub: () => price(1200000) + ' | +۶ شادی', buy: buyIt(1200000, '🧢 چه کلاهی!', () => G.happy += 6) },
          { label: '🎩 کلاه شاپو', sub: () => price(2800000) + ' | +۸ شادی', buy: buyIt(2800000, '🎩 آقای محترم!') },
        ]});
        // — قفسه کفش (راست، عقب)
        const shoeX = W / 2 - 2.2;
        box(.9, 2.2, 3, 0x6b4a2f, shoeX, 1.1, -1.5);
        for (let r2 = 0; r2 < 3; r2++) for (let j = 0; j < 3; j++) {
          const sh = new THREE.Mesh(new THREE.BoxGeometry(.5, .2, .25), mat([0x1a1a1a, 0xffffff, 0xd62828, 0x1d3557][((r2 * 3 + j) % 4)]));
          sh.position.set(shoeX - .5, INTERIOR_Y + .55 + r2 * .7, -2.6 + j * 1.1);
          S.group.add(sh);
        }
        solid(shoeX, -1.5, .6, 1.7);
        S.targets.push({ type: 'buy', x: shoeX - 1.4, z: -1.5, r: 2, label: '👟 خرید کفش', say: 'کتونی راحت یا چرم مجلسی؟ پات رو کن تو کفش ما!', goods: [
          { label: '👟 کتونی', sub: () => price(3800000) + ' | +۸ شادی', buy: buyIt(3800000, '👟 حالا بدو که می‌تونی!') },
          { label: '👞 کفش چرم مجلسی', sub: () => price(5200000) + ' | +۱۰ شادی', buy: buyIt(5200000, '👞 قِر تو کمرت فراوونه!', () => G.happy += 10) },
        ]});
        // آینه قدی
        const mirror = box(1.4, 2.4, .12, 0xcfe8f0, W / 2 - 1.5, 1.4, 3.5, -Math.PI / 2);
        mirror.material.metalness = .7;
        break;
      }
      case 'cars': {
        for (let i = 0; i < 2; i++) {
          const cx = -3.5 + i * 7;
          box(2.1, .9, 4.4, [0xe63946, 0x1d3557][i], cx, .75, -1);
          box(1.9, .75, 2.3, [0xe63946, 0x1d3557][i], cx, 1.55, -1.2);
          box(1.7, .55, 2.35, 0x223344, cx, 1.55, -1.2);
          [[-1.05, -2.4], [1.05, -2.4], [-1.05, .4], [1.05, .4]].forEach(([ox, oz]) => {
            const w = cyl(.42, .42, .32, 0x111111, cx + ox, .42, -1 + oz);
            w.rotation.z = Math.PI / 2;
          });
          solid(cx, -1, 1.3, 2.4);
        }
        break;
      }
      case 'garage': {
        box(3, .4, 5, 0x7a828c, -3, .2, 0);                                    // جک
        box(2.1, .9, 4.4, 0x8a8f96, -3, .85, 0);
        solid(-3, 0, 1.6, 2.4);
        for (let i = 0; i < 6; i++) box(.3, .3, .3, [0xd62828, 0xffb703, 0x2a9d8f][i % 3], 3 + (i % 3) * .6, 1.35 + Math.floor(i / 3) * .7, -D / 2 + 2.4);
        box(3.4, .12, 1, 0x5b636e, 3.6, 1.2, -D / 2 + 2.4);
        box(3.4, .12, 1, 0x5b636e, 3.6, 1.9, -D / 2 + 2.4);
        break;
      }
      case 'gym': {
        for (let i = 0; i < 3; i++) {
          box(1.2, .5, 2.4, 0x2b2b33, -4 + i * 4, .35, -1);                   // تردمیل
          box(1.2, 1.2, .18, 0x4a4a55, -4 + i * 4, 1.1, -2.1);
          solid(-4 + i * 4, -1, .8, 1.4);
        }
        for (let i = 0; i < 4; i++) {
          cyl(.35, .35, .22, 0x1a1a1a, -3 + i * 2, .2, 3);
          cyl(.35, .35, .22, 0x1a1a1a, -2.4 + i * 2, .2, 3);
          box(1.4, .09, .09, 0xaaaaaa, -2.7 + i * 2, .2, 3);
        }
        // فعالیت‌ها: جلوی هر دستگاه E بزن
        S.targets.push({ type: 'gymact', act: 'run', x: 0, z: .6, r: 2.2, label: '🏃 دویدن روی تردمیل' });
        S.targets.push({ type: 'gymact', act: 'lift', x: 0, z: 4.2, r: 2.4, label: '🏋️ وزنه زدن' });
        // تشک نرمش و پرش
        const mt = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 2.4), mat(0x3577b2, 1, 0));
        mt.rotation.x = -Math.PI / 2;
        mt.position.set(W / 2 - 3, INTERIOR_Y + .03, -3);
        S.group.add(mt);
        S.targets.push({ type: 'gymact', act: 'jump', x: W / 2 - 3, z: -3, r: 2.2, label: '🤸 پرش و نرمش' });
        break;
      }
      case 'butcher': {
        // چرخ گوشت و ساطور روی پیشخوان
        box(.9, .6, .6, 0x8a8f96, 2.4, 1.45, -D / 2 + 3.2);
        // لاشه‌های آویزون از سقف (به سبک قصابی‌های واقعی!)
        for (let i = 0; i < 4; i++) {
          const hx = -4 + i * 2.6;
          cyl(.03, .03, 1.2, 0x555f6b, hx, H - .7, -1);
          const meat = new THREE.Mesh(new THREE.CylinderGeometry(.32, .42, 1.5, 8), mat(0xb5453c));
          meat.position.set(hx, INTERIOR_Y + H - 2.1, -1);
          S.group.add(meat);
        }
        // یخچال ویترینی گوشت
        box(5, 1.1, 1.2, 0xd9e5e3, 0, .55, 1.5);
        box(4.8, .5, 1, 0xbfe3ff, 0, 1.35, 1.5);
        for (let i = 0; i < 5; i++) {
          const cut = new THREE.Mesh(new THREE.BoxGeometry(.7, .3, .5), mat([0xc0392b, 0xe08283, 0xa93226][i % 3]));
          cut.position.set(-1.8 + i * .9, INTERIOR_Y + 1.25, 1.5);
          S.group.add(cut);
        }
        solid(0, 1.5, 2.7, .8);
        // ترازو
        box(.7, .5, .5, 0xc0c6d4, -2.4, 1.45, -D / 2 + 3.2);
        break;
      }
      case 'police': {
        // پرچم و تابلو
        box(.08, 2.6, .08, 0x8a8f96, -W / 2 + 1.4, 1.3, -D / 2 + 1.2);
        box(1.2, .7, .05, 0x2f9e44, -W / 2 + 2.05, 2.35, -D / 2 + 1.2);
        box(1.2, .35, .05, 0xffffff, -W / 2 + 2.05, 1.83, -D / 2 + 1.2);
        box(1.2, .7, .05, 0xd62828, -W / 2 + 2.05, 1.3, -D / 2 + 1.2);
        // سلول بازداشت با میله‌ها (خالی، خداروشکر!)
        for (let i = 0; i < 7; i++) cyl(.05, .05, 3.2, 0x555f6b, W / 2 - 4 + i * .55, 1.6, -1.2);
        box(3.8, .12, .1, 0x555f6b, W / 2 - 2.35, 3.15, -1.2);
        box(1.4, .5, 2.6, 0x6b7686, W / 2 - 2.2, .3, -3.2);                 // تخت سلول
        solid(W / 2 - 2.35, -1.2, 2, .3);
        // میز کار و صندلی‌های انتظار
        box(2.2, .95, 1, 0x3a4a63, -3, .5, 1.5);
        solid(-3, 1.5, 1.2, .7);
        for (let i = 0; i < 3; i++) { box(.9, .12, .9, 0x4a6fa5, -4 + i * 2.2, .55, 4.2); box(.9, .8, .12, 0x4a6fa5, -4 + i * 2.2, .95, 3.85); }
        // افسر نگهبان پشت دخل (همیشه یکی سر پسته)
        const officer = makePerson(0x2f4b7c, { style: 'cap', accColor: 0x1b2f52, moustache: true });
        officer.position.set(-.6, INTERIOR_Y, -D / 2 + 1.7);
        officer.rotation.y = 0;                 // رو به مراجعین
        const ol = makeLabel3D('👮 افسر نگهبان');
        ol.position.y = 3.3; ol.scale.set(5.5, 1.4, 1);
        officer.add(ol);
        S.group.add(officer);
        (S.lookers = S.lookers || []).push(officer);
        break;
      }
      case 'seats': {
        for (let r = 0; r < 3; r++) for (let i = 0; i < 5; i++) {
          box(.9, .12, .9, 0x4a6fa5, -5 + i * 2.4, .55, -2 + r * 2.6);
          box(.9, .8, .12, 0x4a6fa5, -5 + i * 2.4, .95, -2.35 + r * 2.6);
        }
        box(W - 6, 1.6, .2, 0x1a2333, 0, 2.6, -D / 2 + .5);
        break;
      }
      case 'lobby': {
        box(3.4, .9, 1.2, 0x6b4a2f, -W / 2 + 3, .55, -D / 2 + 2.6);
        solid(-W / 2 + 3, -D / 2 + 2.6, 1.8, .8);
        box(2.4, 3, .3, 0x9aa4ae, W / 2 - 2.6, 1.5, -D / 2 + .5);              // آسانسور
        box(2, 2.6, .1, 0x5f6b76, W / 2 - 2.6, 1.3, -D / 2 + .35);
        for (let i = 0; i < 4; i++) box(.5, .5, .5, 0x2d6a4f, -2 + i * 1.6, .3, D / 2 - 2.6);
        break;
      }
      case 'flowers': {
        for (let i = 0; i < 10; i++) {
          const x = -W / 2 + 2 + (i % 5) * 2.6, z = -2 + Math.floor(i / 5) * 3.4;
          cyl(.35, .28, .5, 0x8a5a3a, x, .25, z);
          for (let j = 0; j < 5; j++) {
            const st2 = cyl(.04, .04, .9, 0x2d6a4f, x + (j - 2) * .12, .8, z);
            const fl = new THREE.Mesh(new THREE.SphereGeometry(.16, 8, 6),
              mat([0xff2d78, 0xffd166, 0xffffff, 0xc084fc, 0xff6b35][j]));
            fl.position.set(x + (j - 2) * .12, INTERIOR_Y + 1.28, z);
            S.group.add(fl);
          }
          solid(x, z, .5, .5);
        }
        break;
      }
      case 'books': {
        shelf(-W / 2 + 2, 0, D - 5, Math.PI / 2, 0x6b4a2f, 0x264653);
        shelf(W / 2 - 2, 0, D - 5, Math.PI / 2, 0x6b4a2f, 0x2a9d8f);
        shelf(0, -D / 2 + 4.5, W - 8, 0, 0x6b4a2f, 0xe76f51);
        table(0, 2.5, 0x6b4a2f); chair(0, 3.7, 0); chair(0, 1.3, Math.PI);
        break;
      }
      case 'cakes': {
        box(6, 1.1, 1.1, 0xf0e0f8, 0, .6, -1.5);
        box(6, .1, 1.1, 0xffffff, 0, 1.2, -1.5);
        solid(0, -1.5, 3, .8);
        for (let i = 0; i < 6; i++) {
          cyl(.32, .32, .3, [0xffd166, 0xff8fab, 0xf1faee][i % 3], -2.4 + i * 1, 1.4, -1.5);
          cyl(.12, .12, .1, 0xd62828, -2.4 + i * 1, 1.6, -1.5);
        }
        break;
      }
      case 'juice': {
        box(5, 1.1, 1, 0x9ae6b4, 0, .6, -1.5);
        solid(0, -1.5, 2.5, .8);
        for (let i = 0; i < 5; i++) cyl(.22, .18, .8, [0xff9f1c, 0xff477e, 0xffd166, 0x80ed99, 0xa06cd5][i], -2 + i * 1, 1.6, -1.5);
        for (let i = 0; i < 3; i++) box(.6, .8, .6, 0xdddddd, -1.5 + i * 1.5, 1.6, -D / 2 + 2.8);
        break;
      }
      case 'pcs': {
        for (let r = 0; r < 2; r++) for (let i = 0; i < 4; i++) {
          const x = -4.8 + i * 3.2, z = -2 + r * 3.6;
          box(1.6, .1, .8, 0x2a3550, x, .85, z);
          box(1.2, .7, .06, 0x0b1020, x, 1.32, z - .3);
          const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.1, .6),
            new THREE.MeshBasicMaterial({ color: [0x2ec5ff, 0x9b5de5, 0x00f5d4, 0xff477e][i % 4] }));
          scr.position.set(x, INTERIOR_Y + 1.32, z - .26);
          S.group.add(scr);
          chair(x, z + 1, 0, 0x1f2a44);
          solid(x, z, .9, .5);
        }
        break;
      }
      case 'salon': {
        for (let i = 0; i < 3; i++) {
          const x = -4 + i * 4;
          cyl(.5, .6, .4, 0x333a44, x, .2, -1);
          box(.9, 1.4, .9, 0x14746f, x, 1, -1);
          box(1.4, 2, .12, 0xcfe8f0, x, 1.6, -D / 2 + .6);
          solid(x, -1, .7, .7);
        }
        box(6, 1, .8, 0x6b4a2f, 0, .5, D / 2 - 3);
        break;
      }
      case 'mosque': {
        for (let i = 0; i < 4; i++) cyl(.4, .4, 3.6, 0xf2ead6, -W / 2 + 3 + i * 3.4, 1.8, -D / 2 + 3);
        const rug = new THREE.Mesh(new THREE.PlaneGeometry(W - 4, D - 5), mat(0x1f5f57, 1, 0));
        rug.rotation.x = -Math.PI / 2; rug.position.set(0, INTERIOR_Y + .04, 1);
        S.group.add(rug);
        box(2, 3, .4, 0x0f766e, 0, 1.5, -D / 2 + .6);                          // محراب
        break;
      }
      case 'robots': {
        // سکوهای نمایش ربات (ردیف عقب)
        for (let i = 0; i < 3; i++) {
          const x = -4 + i * 4;
          box(1.4, .1, 1.4, 0x3a2f56, x, .9, -3.2);
          const r = makePerson(0x9a8cff, { style: 'helmet', accColor: 0x6a4c93 });
          r.scale.set(.55, .55, .55);
          r.position.set(x, INTERIOR_Y + .95, -3.2);
          S.group.add(r);
          solid(x, -3.2, .8, .8);
        }
        // میزهای کار: بچه‌ها نشسته‌ن، مانیتور روشن جلوشونه و یه ربات کوچیک رو میز
        const kidColors = [0x3aa7d8, 0xff7eb6, 0x6ab04c, 0xffd166];
        const kidNames = ['🧒 دانیال', '🧒 ترنم', '🧒 آرش', '🧒 پرنیا'];
        for (let i = 0; i < 4; i++) {
          const x = -4.8 + i * 3.2, z = .8;
          // میز + مانیتور
          box(1.8, .1, .9, 0x2c2344, x, .85, z);
          box(1.2, .7, .06, 0x0b1020, x, 1.35, z - .3);
          const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.05, .58),
            new THREE.MeshBasicMaterial({ color: [0x9a5df0, 0x2ec5ff, 0x00f5d4, 0xffb703][i] }));
          scr.position.set(x, INTERIOR_Y + 1.35, z - .26);
          S.group.add(scr);
          solid(x, z, .95, .5);
          // ربات کوچیک روی میز (بدنه + سر + چشم‌چراغ)
          box(.24, .3, .2, 0xc0c6d4, x + .6, 1.05, z + .1);
          box(.18, .16, .16, 0xd9dee8, x + .6, 1.28, z + .1);
          const eye = new THREE.Mesh(new THREE.SphereGeometry(.035, 6, 6),
            new THREE.MeshStandardMaterial({ color: 0xff4444, emissive: 0xff2222, emissiveIntensity: 2 }));
          eye.position.set(x + .6, INTERIOR_Y + 1.29, z + .19);
          S.group.add(eye);
          // بچهٔ نشسته پشت میز
          const kid = makePerson(kidColors[i], { style: 'hair', hair: 0x1f1710 });
          kid.scale.set(.62, .62, .62);
          sit(kid, x, z + .95, Math.PI);
          kid.position.y = INTERIOR_Y - .35;
          const kl = makeLabel3D(kidNames[i]);
          kl.position.y = 3.6; kl.scale.set(4.6, 1.2, 1);
          kid.add(kl);
          S.group.add(kid);
        }
        const neon = new THREE.PointLight(0xb08cff, 2.2, 20, 2);
        neon.position.set(0, INTERIOR_Y + 2.6, 0);
        S.group.add(neon); S.lights.push(neon);
        // — ربات خوش‌آمدگو دم در ورودی (دست بالا، سلام میده)
        const greeter = new THREE.Group();
        const gb = new THREE.Mesh(new THREE.CylinderGeometry(.34, .42, .95, 10), mat(0xc9d2e0, .4, .5));
        gb.position.y = 1.15;
        const gh = new THREE.Mesh(new THREE.BoxGeometry(.5, .42, .42), mat(0xe2e8f2, .4, .5));
        gh.position.y = 1.95;
        const ge1 = new THREE.Mesh(new THREE.SphereGeometry(.06, 8, 8),
          new THREE.MeshStandardMaterial({ color: 0x40c4ff, emissive: 0x2aa8e0, emissiveIntensity: 2.5 }));
        ge1.position.set(-.12, 1.98, .22);
        const ge2 = ge1.clone(); ge2.position.x = .12;
        const antenna = new THREE.Mesh(new THREE.CylinderGeometry(.03, .03, .3), mat(0x888888));
        antenna.position.y = 2.3;
        const antTip = new THREE.Mesh(new THREE.SphereGeometry(.06, 8, 8),
          new THREE.MeshStandardMaterial({ color: 0xff5577, emissive: 0xff2255, emissiveIntensity: 2 }));
        antTip.position.y = 2.48;
        // دست راست بالا (حالت سلام)
        const armUp = new THREE.Mesh(new THREE.CylinderGeometry(.07, .07, .7, 8), mat(0xc9d2e0, .4, .5));
        armUp.position.set(.46, 1.75, 0); armUp.rotation.z = -.6;
        const armDn = armUp.clone(); armDn.position.x = -.42; armDn.rotation.z = -.25;
        const wheel = new THREE.Mesh(new THREE.SphereGeometry(.22, 10, 8), mat(0x333a44, .5, .4));
        wheel.position.y = .42;
        greeter.add(gb, gh, ge1, ge2, antenna, antTip, armUp, armDn, wheel);
        greeter.position.set(2.4, INTERIOR_Y, D / 2 - 3);
        greeter.rotation.y = Math.PI * .85;
        S.group.add(greeter);
        solid(2.4, D / 2 - 3, .6, .6);
        S.targets.push({ type: 'npc-robot', x: 2.4, z: D / 2 - 3, r: 2.6, label: '🤖 سلام به ربات', mesh: greeter });
        setTimeout(() => toast('🤖 «بیپ-بوپ! سلام انسان! به آکادمی رباتیک نوین‌ذهن خوش اومدی! 🎉»'), 600);
        // — کامپیوتر نمایش سایت NOVINZEHN.COM (صفحهٔ بزرگ کنار دیوار)
        const siteX = W / 2 - 2.4, siteZ = 1.5;
        box(2.2, .95, 1, 0x2c2344, siteX, .5, siteZ);
        const sc2 = document.createElement('canvas');
        sc2.width = 512; sc2.height = 288;
        const sx2 = sc2.getContext('2d');
        const grad = sx2.createLinearGradient(0, 0, 512, 288);
        grad.addColorStop(0, '#1a1230'); grad.addColorStop(1, '#2c1a4e');
        sx2.fillStyle = grad; sx2.fillRect(0, 0, 512, 288);
        sx2.shadowBlur = 24; sx2.shadowColor = '#b08cff';
        sx2.fillStyle = '#e8dbff'; sx2.font = 'bold 52px Arial'; sx2.textAlign = 'center';
        sx2.fillText('NOVINZEHN.COM', 256, 130);
        sx2.shadowBlur = 8; sx2.fillStyle = '#9a86c8'; sx2.font = '26px Vazirmatn, Tahoma';
        sx2.fillText('آکادمی رباتیک نوین‌ذهن', 256, 185);
        sx2.fillStyle = '#e8a83c'; sx2.font = '20px Vazirmatn, Tahoma';
        sx2.fillText('برای دیدن سایت، E بزن', 256, 240);
        const siteScr = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.5),
          new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(sc2) }));
        siteScr.position.set(siteX, INTERIOR_Y + 1.9, siteZ - .1);
        siteScr.rotation.y = Math.PI;
        const siteScr2 = siteScr.clone(); siteScr2.rotation.y = 0; siteScr2.position.z = siteZ + .1;
        S.group.add(siteScr, siteScr2);
        solid(siteX, siteZ, 1.2, .7);
        S.targets.push({ type: 'site', x: siteX, z: siteZ + 1.6, r: 2.4, label: '🖥️ دیدن سایت NOVINZEHN.COM' });
        break;
      }
      case 'museum': {
        for (let i = 0; i < 4; i++) {
          const x = -4.5 + i * 3;
          box(1.1, 1.2, 1.1, 0xd9c9a8, x, .6, -2);
          cyl(.35, .45, .9, 0xb08968, x, 1.65, -2);
          solid(x, -2, .7, .7);
        }
        box(W - 5, .18, D - 6, 0x8a6a48, 0, .09, 2);
        break;
      }
      default: {
        table(-3, 0); chair(-3, 1.2, 0);
        table(3, 0); chair(3, 1.2, 0);
        shelf(0, -D / 2 + 2.2, W - 8, 0, 0xa08868);
      }
    }
  }

  // ---------- ورود / خروج ----------
  function clear() {
    if (!S.group) return;
    S.group.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => m.dispose());
    });
    scene.remove(S.group);
    S.group = null; S.id = null;
    S.colliders = []; S.targets = []; S.lights = [];
    S.seatMode = null; S.waiter = null; S.guest = null; S.shopkeeperMesh = null; S.tables = null; S.lookers = null;
  }

  function enter(buildingId, opts = {}) {
    const b = buildingById(buildingId);
    if (!b || b.kind === 'open') return false;
    clear();
    S.group = new THREE.Group();
    scene.add(S.group);
    S.id = buildingId;
    const R = buildRoom(b);
    const keeper = opts.noKeeper ? null : shopkeeperOf(buildingId);
    if (buildingId !== 'home') buildCounter(b, R, keeper);
    buildProps(b, R);
    S.room = R;
    // بازیکن دم در
    player.position.set(0, INTERIOR_Y, R.D / 2 - 4.2);
    player.rotation.y = Math.PI;
    player.visible = true;
    return true;
  }

  // ---------- قرار کافه: هر دو می‌شینن سر میز، گارسون میاد ----------
  function sit(mesh, x, z, faceZ) {
    // دقیقاً روی صندلی: لگن هم‌سطح نشیمن، ران‌ها رو به میز، دست‌ها روی میز
    mesh.position.set(x, INTERIOR_Y - .2, z);
    mesh.rotation.y = faceZ;
    const L = mesh.userData.limbs;
    if (L) {
      L.legL.rotation.x = -Math.PI / 2; L.legR.rotation.x = -Math.PI / 2;
      L.armL.rotation.x = -.75; L.armR.rotation.x = -.75;
    }
  }
  function unsit(mesh) {
    const L = mesh.userData.limbs;
    if (L) { L.legL.rotation.x = L.legR.rotation.x = 0; L.armL.rotation.x = L.armR.rotation.x = 0; }
    mesh.position.y = 0;
  }

  function cafeDate(npc, done) {
    enter('cafe', { noKeeper: true });
    const tb = (S.tables && S.tables[0]) || { x: -3.6, z: 1.2 };
    // هر کدوم روی صندلی خودش (صندلی‌ها تو z±1.25 ساخته میشن)
    sit(player, tb.x, tb.z + 1.3, Math.PI);
    const guest = makePerson(npc.color, npc.look);
    const lbl = makeLabel3D(npc.name.split(' (')[0]);
    lbl.position.y = 3.3; lbl.scale.set(5.5, 1.4, 1);
    guest.add(lbl);
    S.group.add(guest);
    sit(guest, tb.x, tb.z - 1.3, 0);
    S.guest = guest;
    S.seatMode = { npc, tb };
    // گارسون از پشت دخل میاد سمت میز
    const waiter = makePerson(0x2b2b33, { style: 'hair', hair: 0x1a1a1a });
    waiter.position.set(0, INTERIOR_Y, -S.room.D / 2 + 3.2);
    S.group.add(waiter);
    S.waiter = { mesh: waiter, target: new THREE.Vector3(tb.x - 2.1, INTERIOR_Y, tb.z + .2), t: 0, arrived: false, done };
    return true;
  }

  function endDate() {
    if (S.guest) unsit(S.guest);
    unsit(player);
    S.seatMode = null;
  }

  function update(dt) {
    if (!S.group) return;
    // 👁️ همهٔ آدم‌های داخل مغازه با سر (و کمی بدن) بازیکن رو نگاه می‌کنن
    for (const m of (S.lookers || [])) {
      const dx = player.position.x - m.position.x, dz = player.position.z - m.position.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 12) continue;
      const want = Math.atan2(dx, dz);
      const head = m.userData.characterParts?.head;
      if (head) {
        let local = want - m.rotation.y;
        local = Math.atan2(Math.sin(local), Math.cos(local));
        head.rotation.y += (Math.max(-.7, Math.min(.7, local)) - head.rotation.y) * .1;
        if (Math.abs(local) > .7) {       // خیلی زاویه‌دار شد، بدنش هم بچرخه
          let d = want - m.rotation.y;
          d = Math.atan2(Math.sin(d), Math.cos(d));
          m.rotation.y += d * .05;
        }
      } else {
        let d = want - m.rotation.y;
        d = Math.atan2(Math.sin(d), Math.cos(d));
        m.rotation.y += d * .07;
      }
    }
    // راه رفتن گارسون
    const w = S.waiter;
    if (w && !w.arrived) {
      const d = w.target.clone().sub(w.mesh.position); d.y = 0;
      if (d.length() > .3) {
        d.normalize();
        w.mesh.position.addScaledVector(d, dt * 3.2);
        w.mesh.rotation.y = Math.atan2(d.x, d.z);
        const L = w.mesh.userData.limbs;
        w.t += dt * 10;
        L.legL.rotation.x = Math.sin(w.t) * .6;
        L.legR.rotation.x = -Math.sin(w.t) * .6;
      } else {
        w.arrived = true;
        const L = w.mesh.userData.limbs;
        L.legL.rotation.x = L.legR.rotation.x = 0;
        L.armR.rotation.x = -.9;                                    // سینی به دست
        w.mesh.rotation.y = Math.atan2(player.position.x - w.mesh.position.x, player.position.z - w.mesh.position.z);
        // دو تا فنجون قهوه روی میز
        if (S.seatMode) {
          const tb = S.seatMode.tb;
          [[tb.x, tb.z + .45], [tb.x, tb.z - .45]].forEach(([cx, cz]) => {
            cyl(.11, .09, .14, 0xf1faee, cx, 1.14, cz);
            cyl(.07, .07, .03, 0x6b4226, cx, 1.22, cz);              // قهوهٔ داخلش
          });
          cyl(.3, .3, .04, 0xd9c9a8, tb.x, 1.09, tb.z);              // سینی وسط
        }
        toast('🧑‍🍳 گارسون اومد سر میز و قهوه‌ها رو گذاشت!');
        setTimeout(() => w.done && w.done(), 700);
      }
    }
  }

  function nearestInside(pos) {
    let best = null, bd = 1e9;
    for (const t of S.targets) {
      const d = Math.hypot(pos.x - t.x, pos.z - t.z);
      if (d < t.r && d < bd) { bd = d; best = t; }
    }
    return best;
  }

  return {
    enter, exit: clear, update, cafeDate, endDate, nearestInside, sit, unsit,
    isInside: () => !!S.group,
    group: () => S.group,
    seatCenter: () => (S.seatMode ? S.seatMode.tb : null),
    id: () => S.id,
    colliders: () => S.colliders,
    seated: () => !!S.seatMode,
    room: () => S.room,
  };
}
