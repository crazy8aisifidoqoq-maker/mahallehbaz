// ===== rp-core.js — هستهٔ رول‌پلی: کوله، حافظهٔ NPC، دفتر خاطرات، پیامک، فصل‌ها، پیامد شرافت =====
// بعد از ui.js لود میشه.
'use strict';

/* ---------------------------------------------------------------
   🎒 کوله‌پشتی
--------------------------------------------------------------- */
const ITEMS = {
  flower:   { icon: '🌹', name: 'دسته‌گل',        gift: true,  aff: 12, desc: 'هدیهٔ همیشه‌کارساز' },
  sweet:    { icon: '🍬', name: 'جعبه شیرینی',    gift: true,  aff: 10, desc: 'برای آشتی و مهمونی' },
  choc:     { icon: '🍫', name: 'شکلات',          gift: true,  aff: 6,  desc: 'کوچیک ولی به‌دل‌نشین' },
  perfume:  { icon: '🧴', name: 'عطر',            gift: true,  aff: 18, desc: 'هدیهٔ خاص و گرون' },
  book:     { icon: '📕', name: 'کتاب',           gift: true,  aff: 14, desc: 'برای اهل مطالعه عالیه' },
  teddy:    { icon: '🧸', name: 'عروسک',          gift: true,  aff: 9,  desc: 'بچه‌ها عاشقشن' },
  bread:    { icon: '🥖', name: 'نون تازه',       food: true,  energy: 12, desc: 'گرم از تنور' },
  meat:     { icon: '🥩', name: 'گوشت',           food: true,  health: 18, desc: 'برای آبگوشت خونه' },
  juice:    { icon: '🥤', name: 'معجون',          food: true,  energy: 16, desc: 'انرژی فوری' },
  cake:     { icon: '🍰', name: 'کیک',            food: true,  happy: 10, desc: 'شیرینی روز' },
  medicine: { icon: '💊', name: 'دارو',           food: true,  health: 25, desc: 'وقتی حالت بده' },
  toolkit:  { icon: '🧰', name: 'جعبه‌ابزار',     desc: 'برای تعمیرات خونه' },
};
function bagCount(id) { return (G.bag && G.bag[id]) || 0; }
function bagAdd(id, n = 1) {
  G.bag = G.bag || {};
  G.bag[id] = (G.bag[id] || 0) + n;
  const it = ITEMS[id];
  if (it) toast('🎒 ' + it.icon + ' ' + it.name + ' گذاشتی تو کوله (' + fa(G.bag[id]) + ')');
  updateHUD();
}
function bagTake(id, n = 1) {
  if (bagCount(id) < n) return false;
  G.bag[id] -= n;
  if (G.bag[id] <= 0) delete G.bag[id];
  return true;
}
function openBag() {
  openPanel('🎒 کوله‌پشتی', p => {
    const keys = Object.keys(G.bag || {}).filter(k => ITEMS[k] && G.bag[k] > 0);
    if (!keys.length) { noteP(p, 'کوله‌ت خالیه! از مغازه‌های محله خرید کن — بعداً هدیه بده یا مصرف کن.'); return; }
    noteP(p, 'هدیه‌ها رو موقع گفتگو با آدم‌ها می‌تونی بدی؛ خوراکی‌ها رو همین‌جا مصرف کن.');
    keys.forEach(k => {
      const it = ITEMS[k];
      actionRow(p, it.icon + ' ' + it.name + ' × ' + fa(G.bag[k]),
        it.gift ? '🎁 هدیه (+' + fa(it.aff) + ' علاقه) — موقع گفتگو بده' : it.desc,
        () => {
          if (it.gift) { toast('🎁 موقع گفتگو با یکی، گزینهٔ «هدیه» رو بزن!'); return; }
          if (!bagTake(k)) return;
          if (it.energy) G.energy += it.energy;
          if (it.health) G.health += it.health;
          if (it.happy) G.happy += it.happy;
          toast(it.icon + ' ' + it.name + ' مصرف شد. جون گرفتی!');
          journal('🎒 یه ' + it.name + ' مصرف کردم.');
          updateHUD(); openBag();
        }, !!it.gift);
    });
  });
}

/* ---------------------------------------------------------------
   🧠 حافظهٔ NPC — یادشون می‌مونه چی گفتی و چی دادی
--------------------------------------------------------------- */
function npcMem(id) {
  G.npcMem = G.npcMem || {};
  return (G.npcMem[id] = G.npcMem[id] || { notes: [], gifts: 0, lastGift: null, met: null, talks: 0, lastSeen: null });
}
function rememberNPC(id, note) {
  const m = npcMem(id);
  m.notes.unshift({ d: G.dayIndex, t: note });
  m.notes = m.notes.slice(0, 6);
}
// جملهٔ یادآوری که NPC اول گفتگو می‌گه
function npcRecallLine(npc) {
  const m = npcMem(npc.id);
  const bits = [];
  if (m.lastGift) bits.push('راستی هنوز اون ' + m.lastGift + 'ی که بهم دادی یادمه، ممنون!');
  if (m.met != null && G.dayIndex - m.met >= 5) bits.push('چقدر زود گذشت! از روزی که آشنا شدیم ' + fa(G.dayIndex - m.met) + ' روز می‌گذره.');
  if (m.lastSeen != null && G.dayIndex - m.lastSeen >= 3) bits.push('کجایی تو؟ ' + fa(G.dayIndex - m.lastSeen) + ' روزه ندیدمت!');
  if (m.talks >= 12) bits.push('دیگه از دوستای قدیمی محله‌ای برام!');
  if (m.notes[0] && Math.random() < .5) bits.push('یادمه ' + m.notes[0].t + '.');
  return bits.length ? bits[Math.floor(Math.random() * bits.length)] : null;
}

/* ---------------------------------------------------------------
   📔 دفتر خاطرات — خودش می‌نویسه
--------------------------------------------------------------- */
function journal(text) {
  G.journal = G.journal || [];
  const day = G.journal.find(d => d.day === G.dayIndex);
  if (day) { if (!day.lines.includes(text)) day.lines.push(text); }
  else G.journal.unshift({ day: G.dayIndex, date: shamsiStr(G.dayIndex), lines: [text] });
  G.journal = G.journal.slice(0, 40);
}
function openJournal() {
  openPanel('📔 دفتر خاطرات', p => {
    const j = G.journal || [];
    if (!j.length) { noteP(p, 'هنوز چیزی ننوشتی! برو تو محله بگرد، خودش پر میشه.'); return; }
    noteP(p, 'هر اتفاق مهم روز، خودکار اینجا ثبت میشه.');
    j.slice(0, 12).forEach(d => {
      const h = document.createElement('h4');
      h.textContent = '📅 ' + d.date + (d.day === G.dayIndex ? ' (امروز)' : '');
      p.appendChild(h);
      d.lines.forEach(l => noteP(p, '• ' + l));
    });
  });
}

/* ---------------------------------------------------------------
   📱 پیامک ورودی — NPCها خودشون بهت پیام میدن
--------------------------------------------------------------- */
const SMS_TEMPLATES = [
  'سلام! امروز میای کافه؟ من از ۵ اونجام.',
  'چه خبر؟ چند روزه ندیدمت، همه‌چی خوبه؟',
  'یه چیز جالب بهت نشون بدم! فردا بیا مغازه.',
  'راستی اون حرفی که زدی هنوز تو ذهنمه!',
  'اگه گذرت افتاد یه سر بزن، دلم برات تنگ شده.',
  'امروز حالم خوب نیست... یه کم حرف بزنیم؟',
  'دیدم رد شدی صدات کردم نشنیدی! هدفون داشتی؟',
  'یه سلام گرم فرستادم، لبخند بزن! 🌸',
  'هوا خوبه‌ها، پیاده‌روی نمیای؟',
  'اگه بیکاری بیا کمکم کن، کلی کار دارم! 😅',
];
function pushSMS(npcId, text) {
  G.sms = G.sms || [];
  G.sms.unshift({ id: npcId, text, day: G.dayIndex, read: false });
  G.sms = G.sms.slice(0, 25);
  sfx.ring();
  const n = NPCS.find(x => x.id === npcId);
  toast('📩 پیام از ' + (n ? n.name.split(' (')[0] : 'یه نفر') + ': «' + text + '»');
}
function smsUnread() { return (G.sms || []).filter(m => !m.read).length; }
function openSMS() {
  openPanel('📩 پیام‌ها' + (smsUnread() ? ' (' + fa(smsUnread()) + ' جدید)' : ''), p => {
    const list = G.sms || [];
    if (!list.length) { noteP(p, 'هنوز پیامی نداری. با اهالی محله بیشتر رفیق شو!'); return; }
    list.forEach(m => {
      const n = NPCS.find(x => x.id === m.id);
      actionRow(p, (m.read ? '' : '🔵 ') + (n ? n.name.split(' (')[0] : 'ناشناس'),
        '«' + m.text + '» — ' + (m.day === G.dayIndex ? 'امروز' : fa(G.dayIndex - m.day) + ' روز پیش'),
        () => {
          m.read = true;
          if (n) { addAffection(n.id, 1); toast('✅ جواب دادی! (+۱ علاقه)'); }
          openSMS();
        }, false);
    });
    list.forEach(m => m.read = true);
  });
}
// هر روز چند نفر که دوستشونی پیام میدن
function dailySMS() {
  const friends = NPCS.filter(n => !n.kid && getAffection(n.id) >= 15 && !isUpset(n.id));
  if (!friends.length) return;
  const count = Math.min(friends.length, 1 + Math.floor(Math.random() * 2));
  for (let i = 0; i < count; i++) {
    const n = friends[Math.floor(Math.random() * friends.length)];
    const t = SMS_TEMPLATES[Math.floor(Math.random() * SMS_TEMPLATES.length)];
    setTimeout(() => pushSMS(n.id, t), 3000 + i * 12000);
  }
}

/* ---------------------------------------------------------------
   🍂 فصل‌ها و مناسبت‌ها
--------------------------------------------------------------- */
function seasonOf(dayIndex) {
  const m = shamsiDate(dayIndex).month;
  return m <= 2 ? 'بهار' : m <= 5 ? 'تابستان' : m <= 8 ? 'پاییز' : 'زمستان';
}
function occasionOf(dayIndex) {
  const d = shamsiDate(dayIndex);
  if (d.month === 0 && d.day <= 4) return { id:'nowruz', icon:'🌱', name:'نوروز', msg:'سال نو مبارک! کل محله عیدی می‌ده و بوی سبزه و سنبل همه‌جا پیچیده.' };
  if (d.month === 0 && d.day === 13) return { id:'sizdah', icon:'🌿', name:'سیزده‌بدر', msg:'سیزده‌بدر! همه رفتن پارک، سبزه گره می‌زنن.' };
  if (d.month === 8 && d.day === 30) return { id:'yalda', icon:'🍉', name:'شب یلدا', msg:'شب یلداست! هندونه و آجیل و حافظ — بلندترین شب سال.' };
  if (d.month === 11 && d.day >= 25) return { id:'preNowruz', icon:'🧹', name:'خانه‌تکانی', msg:'آخر ساله! همه در حال خانه‌تکانی و خرید عیدن.' };
  return null;
}
function applySeasonEffects() {
  const occ = occasionOf(G.dayIndex);
  const season = seasonOf(G.dayIndex);
  G.season = season;
  if (season === 'زمستان' && Math.random() < .3) G.weather = 'snowy';
  if (season === 'تابستان' && Math.random() < .3) G.weather = 'sunny';
  if (occ && G.lastOccasion !== occ.id) {
    G.lastOccasion = occ.id;
    showBanner(occ.icon + ' ' + occ.name + ' — ' + occ.msg, 8000);
    addNews(occ.icon + ' ' + occ.name + ' در محله');
    journal(occ.icon + ' ' + occ.name + ' بود.');
    if (occ.id === 'nowruz') { addMoney(5000000); G.happy += 20; toast('🧧 عیدی گرفتی: ۵ میلیون! سال نو مبارک!'); }
    if (occ.id === 'yalda') { G.happy += 15; bagAdd('cake'); toast('🍉 شب یلدا: همه دور هم! (+۱۵ شادی)'); }
    if (occ.id === 'sizdah') { G.happy += 12; toast('🌿 سیزده‌بدر تو پارک! (+۱۲ شادی)'); }
  }
}

/* ---------------------------------------------------------------
   ⚖️ پیامد ماندگار شرافت
--------------------------------------------------------------- */
function honorPriceFactor() {
  const h = G.honor ?? 50;
  return h >= 80 ? .88 : h >= 60 ? .95 : h <= 20 ? 1.25 : h <= 40 ? 1.1 : 1;   // شرافت بالا = تخفیف
}
function honorLabel() {
  const h = G.honor ?? 50;
  return h >= 80 ? 'شریفِ محله 😇' : h >= 60 ? 'آدم‌حسابی' : h >= 40 ? 'معمولی' : h >= 20 ? 'بدنام' : 'رسوای محله 😈';
}
function honorGreetLine(npc) {
  const h = G.honor ?? 50;
  if (h >= 80) return 'به‌به! ' + (npc.gender === 'f' ? 'خوش اومدی' : 'خوش اومدی پهلوون') + '! همه از خوبیت می‌گن.';
  if (h <= 20) return 'هوم... تویی؟ حرفایی ازت شنیدم که خوشم نیومد.';
  return null;
}
