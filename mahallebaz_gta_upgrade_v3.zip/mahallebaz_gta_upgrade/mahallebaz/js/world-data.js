// ===== world-data.js — نقشه شهر: ساختمون‌ها (مشترک بین دوبعدی و سه‌بعدی) =====
'use strict';

// kind: gable(شیروونی) | flat | dome | tower | awning(سایبون) | modern | open
// شهر جادار: بلوارها در x,z = -80/0/80 — هر بلوک فقط ۱-۲ ساختمون با فاصلهٔ زیاد
const BUILDINGS = [
  // بلوک مرکزی جنوب‌غربی: خونه و بنگاه
  { id:'home',       name:'اتاقک اجاره‌ای من', icon:'🏠', color:0xe07a5f, img:'assets/buildings/home_red.png', photoW:0.99, photoH:1.05, x:-120, z:-120, w:13, d:11, h:6,  kind:'gable' },
  { id:'realty',     name:'بنگاه املاک',      icon:'🏘️', color:0x8d6a4f, img:'assets/buildings/home_red.png', x:-40, z:-40, w:19, d:17, h:9,  kind:'awning' },
  // بلوک مرکزی جنوب‌شرقی: خوراک
  { id:'market',     name:'سوپرمارکت',        icon:'🏪', color:0x2a9d8f, img:'assets/buildings/home_red.png', x:40, z:-120, w:23, d:17, h:9,  kind:'awning' },
  { id:'bakery',     name:'نانوایی',          icon:'🍞', color:0xc9a227, img:'assets/buildings/home_red.png', x:120, z:-40, w:17, d:15, h:8,  kind:'gable' },
  // بلوک مرکزی شمال‌غربی: کافه و رستوران
  { id:'cafe',       name:'کافه تورم',        icon:'☕', color:0x6d4c41, img:'assets/buildings/home_red.png', x:-120, z:40,  w:17, d:15, h:9,  kind:'awning' },
  { id:'restaurant', name:'رستوران باباقوری', icon:'🍽️', color:0xbc4749, img:'assets/buildings/home_red.png', x:-40, z:120,  w:23, d:19, h:10,  kind:'gable' },
  // بلوک مرکزی شمال‌شرقی: بانک و موبایل
  { id:'bank',       name:'بانک ملّی محل',    icon:'🏦', color:0x1d3557, img:'assets/buildings/classic.png', x:40, z:40,  w:23, d:19, h:14,  kind:'dome' },
  { id:'mobile',     name:'موبایل‌فروشی',     icon:'📱', color:0x7209b7, img:'assets/buildings/modern.png', x:120, z:120,  w:15, d:15, h:9,  kind:'flat' },
  // غرب: درمان و پوشاک
  { id:'hospital',   name:'بیمارستان',        icon:'🏥', color:0xf1faee, img:'assets/buildings/apartment_glass.png', x:-304, z:-128, w:27, d:23, h:18, kind:'modern' },
  { id:'clothes',    name:'پوشاک شیک‌پوش',   icon:'👔', color:0xf28482, img:'assets/buildings/home_red.png', x:-212, z:-32, w:17, d:15, h:9,  kind:'awning' },
  // غرب-شمال: دانشگاه و باشگاه
  { id:'university', name:'دانشگاه',          icon:'🎓', color:0x457b9d, img:'assets/buildings/classic.png', x:-304, z:32,  w:34, d:27, h:18, kind:'dome' },
  { id:'gym',        name:'باشگاه بدنسازی',   icon:'💪', color:0x9b2226, img:'assets/buildings/modern.png', x:-212, z:128,  w:21, d:17, h:10,  kind:'flat' },
  // شرق: خودرو
  { id:'dealership', name:'نمایشگاه اتومبیل', icon:'🚗', color:0x00b4d8, img:'assets/buildings/office_curved.png', photoW:0.98, photoH:0.85, x:212, z:-128, w:34, d:23, h:10,  kind:'modern' },
  { id:'repair',     name:'تعمیرگاه ممد',     icon:'🔧', color:0x555b6e, img:'assets/buildings/modern.png', x:304, z:-32, w:19, d:19, h:8,  kind:'flat' },
  // شرق-شمال: سفر
  { id:'airport',    name:'فرودگاه',          icon:'✈️', color:0x8899aa, img:'assets/buildings/office_curved.png', x:220, z:32,  w:46, d:27, h:14,  kind:'tower' },
  { id:'terminal',   name:'پایانه مسافربری',  icon:'🚌', color:0xe9c46a, img:'assets/buildings/apartment_glass.png', x:304, z:128,  w:30, d:21, h:9,  kind:'modern' },
  // جنوب: پارک و گل
  { id:'park',       name:'پارک محله',        icon:'🌳', color:0x2d6a4f, x:-104, z:-304, w:49, d:42, h:0,  kind:'open' },
  { id:'flower',     name:'گل‌فروشی رؤیا',    icon:'🌹', color:0xff70a6, img:'assets/buildings/home_red.png', x:-32, z:-212, w:15, d:15, h:8,  kind:'awning' },
  // جنوب-شرق: شیرینی
  { id:'pastry',     name:'قنادی یاس',        icon:'🍰', color:0xc77dff, img:'assets/buildings/home_red.png', x:32, z:-304, w:17, d:15, h:8,  kind:'awning' },
  { id:'juice',      name:'آبمیوه بستنی',     icon:'🍹', color:0x80ed99, img:'assets/buildings/home_red.png', x:128, z:-212, w:15, d:15, h:8,  kind:'awning' },
  // شمال: مسکونی و کتاب
  { id:'apartment1', name:'آپارتمان گلستان',  icon:'🏢', color:0x9c6644, img:'assets/buildings/apartment_glass.png', x:-128, z:212,  w:23, d:19, h:27, kind:'tower' },
  { id:'book',       name:'کتاب‌فروشی',       icon:'📚', color:0x577590, img:'assets/buildings/home_red.png', x:-32, z:304,  w:17, d:15, h:9,  kind:'flat' },
  // شمال-شرق: تفریح
  { id:'gamenet',    name:'گیم‌نت ستاره',     icon:'🎮', color:0x48bfe3, img:'assets/buildings/modern.png', x:32, z:212,  w:17, d:17, h:9,  kind:'flat' },
  { id:'salon',      name:'آرایشگاه مردانه',  icon:'💈', color:0x14746f, img:'assets/buildings/home_red.png', x:128, z:304,  w:15, d:15, h:8,  kind:'flat' },
  // گوشه‌ها
  { id:'mosque',     name:'مسجد محله',        icon:'🕌', color:0x0f766e, img:'assets/buildings/classic.png', x:-304, z:-304, w:25, d:21, h:14,  kind:'dome' },
  { id:'policeStation', name:'کلانتری محله',  icon:'🚓', color:0x27436e, img:'assets/buildings/modern.png', x:-212, z:-212, w:21, d:17, h:10,  kind:'modern' },
  { id:'robotics',   name:'آکادمی رباتیک نوین‌ذهن', icon:'🤖', color:0x2b2140, img:'assets/buildings/modern.png', x:212, z:-212, w:19, d:17, h:12, kind:'modern' },
  { id:'dairy',      name:'لبنیاتی برکت',     icon:'🥛', color:0xf4f1de, img:'assets/buildings/home_red.png', x:304, z:-304, w:15, d:15, h:8,  kind:'awning' },
  { id:'mansion',    name:'عمارت تاریخی محله', icon:'🏛️', color:0xb08968, img:'assets/buildings/classic.png', photoW:0.99, photoH:1.0, x:-304, z:212, w:27, d:21, h:15, kind:'dome' },
  // دکوری (قابل ورود نیستن)
  { id:'deco1', name:'', color:0x81b29a, img:'assets/buildings/apartment_brick.png', x:-212, z:304, w:19, d:17, h:21, kind:'tower', deco:true },
  { id:'deco2', name:'', color:0xf2cc8f, img:'assets/buildings/apartment_glass.png', x:212, z:212, w:17, d:17, h:16, kind:'flat',  deco:true },
  { id:'deco3', name:'', color:0x6d9dc5, img:'assets/buildings/cylinder_tower.png', x:304, z:304, w:19, d:17, h:24, kind:'tower', deco:true },
  { id:'deco4', name:'', color:0xb5838d, img:'assets/buildings/modern.png', photoW:0.99, photoH:0.92, x:-128, z:-32, w:19, d:17, h:18, kind:'flat',  deco:true },
  { id:'butcher',    name:'قصابی اصغرآقا',    icon:'🥩', color:0xa4161a, x:-304, z:120, w:15, d:13, h:8, kind:'awning' },
  // ساختمون‌های جدید برای پر شدن شهر (منظرهٔ شهری، قابل ورود نیستن)
  { id:'deco5',  name:'', color:0x8d99ae, img:'assets/buildings/tower_dark.png', x:-40,  z:-120, w:26, d:22, h:36, kind:'tower', deco:true },
  { id:'deco6',  name:'', color:0xc9ada7, img:'assets/buildings/apartment_brick.png', x:40,   z:120,  w:24, d:20, h:30, kind:'tower', deco:true },
  { id:'deco7',  name:'', color:0xa3b18a, img:'assets/buildings/apartment_glass.png', x:120,  z:40,   w:24, d:20, h:18, kind:'flat',  deco:true },
  { id:'deco8',  name:'', color:0xe9c46a, img:'assets/buildings/office_curved.png', x:40,   z:-40,  w:20, d:20, h:16, kind:'flat',  deco:true },
  { id:'deco9',  name:'', color:0x6d9dc5, img:'assets/buildings/cylinder_tower.png', x:-40,  z:40,   w:20, d:20, h:26, kind:'tower', deco:true },
  { id:'deco10', name:'', color:0xb5838d, img:'assets/buildings/tower_dark.png', x:120,  z:-120, w:24, d:20, h:32, kind:'tower', deco:true },
  { id:'deco11', name:'', color:0x81b29a, img:'assets/buildings/apartment_brick.png', x:-120, z:120,  w:24, d:20, h:20, kind:'flat',  deco:true },
  { id:'deco12', name:'', color:0xf2cc8f, img:'assets/buildings/office_curved.png', x:212,  z:-40,  w:26, d:22, h:16, kind:'flat',  deco:true },
  { id:'deco13', name:'', color:0x9c89b8, img:'assets/buildings/cylinder_tower.png', x:-212, z:40,   w:24, d:20, h:28, kind:'tower', deco:true },
  { id:'deco14', name:'', color:0xd5a021, img:'assets/buildings/home_red.png', x:-212, z:-120, w:26, d:20, h:14, kind:'flat',  deco:true },
  { id:'deco15', name:'', color:0x577590, img:'assets/buildings/tower_dark.png', x:212,  z:120,  w:24, d:22, h:34, kind:'tower', deco:true },
  { id:'deco16', name:'', color:0xbc6c25, img:'assets/buildings/apartment_brick.png', x:40,   z:-212, w:24, d:20, h:16, kind:'flat',  deco:true },
  { id:'deco17', name:'', color:0x748cab, img:'assets/buildings/apartment_glass.png', x:-40,  z:212,  w:24, d:20, h:30, kind:'tower', deco:true },
  { id:'deco18', name:'', color:0x99582a, img:'assets/buildings/tower_dark.png', x:304,  z:40,   w:26, d:20, h:26, kind:'tower', deco:true },
];

function buildingById(id) { return BUILDINGS.find(b => b.id === id); }

// نقاط درخت برای پارک و خیابون‌ها
const TREE_SPOTS = [
  [-104,-292],[-116,-312],[-92,-316],[-104,-324],[-88,-296],[-120,-296], // پارک
  [-28,24],[28,24],[-28,-24],[28,-24],[-80,80],[80,80],[80,-80],[-80,-80],
  [-200,60],[200,60],[-200,-80],[200,-80],[-60,200],[60,200],[-60,-200],[60,-200],
];

// ---------- شبکه خیابون‌ها (فقط دوبعدی) ----------
// dir: 'h' افقی (z ثابت) | 'v' عمودی (x ثابت) | hw: نصف عرض | main: بلوار اصلی
// این باندها با هیچ ساختمونی تداخل ندارن (بررسی‌شده)
const ROADS = [
  { dir:'h', c:-1.3, hw:7.4, from:-370, to:370, main:true, name:'بلوار انقلابِ محله' },
  { dir:'v', c:0,    hw:6.1, from:-370, to:370, main:true, name:'خیابان ولیعصرِ محله' },
  { dir:'h', c:-160,  hw:6,   from:-370, to:370, main:true, name:'کمربندی جنوبی' },
  { dir:'h', c:160,   hw:6,   from:-370, to:370, main:true, name:'کمربندی شمالی' },
  { dir:'v', c:-160,  hw:6,   from:-370, to:370, main:true, name:'کمربندی غربی' },
  { dir:'v', c:160,   hw:6,   from:-370, to:370, main:true, name:'کمربندی شرقی' },
];

// 🚸 هر چیزی جز ماشین نباید وسط خیابون باشه — هولش بده کنار جدول (پیاده‌رو)
// خروجی: {x, z, moved}  — اگه وسط خیابون بود، به نزدیک‌ترین لبه منتقل میشه
function clampOffStreetCenter(x, z, margin = 1.6) {
  let nx = x, nz = z, moved = false;
  for (const r of ROADS) {
    if (r.dir === 'h') {
      if (Math.abs(nz - r.c) < r.hw && nx > r.from && nx < r.to) {
        nz = nz >= r.c ? r.c + r.hw + margin : r.c - r.hw - margin;   // به نزدیک‌ترین پیاده‌رو
        moved = true;
      }
    } else {
      if (Math.abs(nx - r.c) < r.hw && nz > r.from && nz < r.to) {
        nx = nx >= r.c ? r.c + r.hw + margin : r.c - r.hw - margin;
        moved = true;
      }
    }
  }
  return { x: nx, z: nz, moved };
}
function isOnStreet(x, z) { return !!onRoad(x, z); }

function onRoad(x, z, pad = 0) {
  for (const r of ROADS) {
    if (r.dir === 'h') { if (Math.abs(z - r.c) < r.hw + pad && x > r.from - pad && x < r.to + pad) return r; }
    else { if (Math.abs(x - r.c) < r.hw + pad && z > r.from - pad && z < r.to + pad) return r; }
  }
  return null;
}

window.BUILDINGS = BUILDINGS;   // دسترسی دیباگ/تست
