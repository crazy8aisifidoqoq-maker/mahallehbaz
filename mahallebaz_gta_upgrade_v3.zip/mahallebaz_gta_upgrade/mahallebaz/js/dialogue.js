// ===== dialogue.js — گفتگوی رودررو: قیافه‌ها + حباب حرف بالای سر (سبک د سیمز) =====
'use strict';

let dialogueOpen = false;
let talkCtx = null;          // { npc, els }
let talkClose = null;        // هوک بعد از بسته شدن گفتگو (مثلاً NPC بره تو مغازه‌ش)
let talkFollowRAF = 0;

// ---------------------------------------------------------------
//  کشیدن قیافه: از روی look خود شخصیت ساخته میشه
// ---------------------------------------------------------------
const FACE_CACHE = {};
function faceCanvas(look = {}, shirt = 0x888888, mood = 'idle', size = 128) {
  const key = JSON.stringify(look) + '|' + shirt + '|' + mood + '|' + size;
  if (FACE_CACHE[key]) return FACE_CACHE[key];

  const c = document.createElement('canvas');
  c.width = c.height = size;
  const x = c.getContext('2d');
  const S = size / 128;
  const hex = n => '#' + (n >>> 0).toString(16).padStart(6, '0');
  const skin = look.skin ? hex(look.skin) : '#f0c8a0';
  const hair = hex(look.hair ?? 0x2b1d0e);
  const acc = hex(look.accColor ?? 0x264653);

  x.save();
  x.scale(S, S);

  // پس‌زمینهٔ گرد
  const g = x.createLinearGradient(0, 0, 0, 128);
  g.addColorStop(0, 'rgba(255,255,255,.16)');
  g.addColorStop(1, 'rgba(0,0,0,.18)');
  x.fillStyle = g;
  x.beginPath(); x.arc(64, 64, 62, 0, 7); x.fill();

  // شونه‌ها با رنگ لباس خودش
  x.fillStyle = hex(shirt);
  x.beginPath(); x.ellipse(64, 138, 46, 40, 0, 0, 7); x.fill();
  x.fillStyle = 'rgba(0,0,0,.18)';
  x.beginPath(); x.ellipse(64, 138, 46, 40, 0, Math.PI * 1.1, Math.PI * 1.9); x.fill();

  // گردن
  x.fillStyle = skin;
  x.fillRect(54, 86, 20, 20);

  // صورت
  x.fillStyle = skin;
  x.beginPath(); x.ellipse(64, 62, 30, 34, 0, 0, 7); x.fill();
  x.fillStyle = 'rgba(0,0,0,.07)';
  x.beginPath(); x.ellipse(74, 64, 20, 32, 0, 0, 7); x.fill();

  // گوش‌ها
  x.fillStyle = skin;
  [34, 94].forEach(ex => { x.beginPath(); x.ellipse(ex, 64, 5, 8, 0, 0, 7); x.fill(); });

  // ابرو + چشم (بسته به حال)
  const browY = mood === 'sad' ? 44 : mood === 'angry' ? 46 : 42;
  x.strokeStyle = hair; x.lineWidth = 3.4; x.lineCap = 'round';
  [[50, -1], [78, 1]].forEach(([bx, dir]) => {
    x.beginPath();
    if (mood === 'angry') { x.moveTo(bx - 8 * dir, browY - 3); x.lineTo(bx + 8 * dir, browY + 3); }
    else if (mood === 'sad') { x.moveTo(bx - 8 * dir, browY + 3); x.lineTo(bx + 8 * dir, browY - 2); }
    else { x.moveTo(bx - 8, browY); x.lineTo(bx + 8, browY - 1); }
    x.stroke();
  });

  const eyeY = 58;
  if (mood === 'love') {
    // فقط موقع عاشقی چشما هلالی میشه
    x.strokeStyle = '#2a2118'; x.lineWidth = 3.2;
    [50, 78].forEach(ex => { x.beginPath(); x.arc(ex, eyeY + 2, 6, Math.PI * 1.15, Math.PI * 1.85); x.stroke(); });
  } else {
    // 👁️ چشم تو چشم: مردمک‌ها دقیقاً وسط و رو به بیننده، با دو برقِ نور
    [50, 78].forEach(ex => {
      x.fillStyle = '#fff';
      x.beginPath(); x.ellipse(ex, eyeY, 7.6, 6.4, 0, 0, 7); x.fill();
      x.strokeStyle = 'rgba(60,45,30,.35)'; x.lineWidth = 1;
      x.beginPath(); x.ellipse(ex, eyeY, 7.6, 6.4, 0, 0, 7); x.stroke();
      // عنبیه (رنگ چشم) + مردمک
      x.fillStyle = mood === 'angry' ? '#5b4636' : '#4a6b7c';
      x.beginPath(); x.arc(ex, eyeY + (mood === 'sad' ? 1.2 : 0), 4.1, 0, 7); x.fill();
      x.fillStyle = '#161210';
      x.beginPath(); x.arc(ex, eyeY + (mood === 'sad' ? 1.2 : 0), 2.3, 0, 7); x.fill();
      // برقِ نگاه
      x.fillStyle = 'rgba(255,255,255,.95)';
      x.beginPath(); x.arc(ex - 1.6, eyeY - 2, 1.5, 0, 7); x.fill();
      x.fillStyle = 'rgba(255,255,255,.5)';
      x.beginPath(); x.arc(ex + 1.8, eyeY + 1.6, .8, 0, 7); x.fill();
      // پلک بالا (کمی سایه که زنده‌تر باشه)
      x.strokeStyle = 'rgba(40,30,20,.5)'; x.lineWidth = 1.6;
      x.beginPath(); x.arc(ex, eyeY, 7.2, Math.PI * 1.1, Math.PI * 1.9); x.stroke();
    });
  }

  // دماغ
  x.strokeStyle = 'rgba(150,105,70,.75)'; x.lineWidth = 2.6;
  x.beginPath(); x.moveTo(64, 62); x.lineTo(61, 72); x.lineTo(66, 73); x.stroke();

  // دهن
  x.strokeStyle = '#a44a4a'; x.lineWidth = 3;
  x.beginPath();
  if (mood === 'happy' || mood === 'love') x.arc(64, 76, 11, .25, Math.PI - .25);
  else if (mood === 'sad' || mood === 'angry') x.arc(64, 92, 11, Math.PI + .3, -.3);
  else if (mood === 'talk') { x.ellipse(64, 82, 7, 6, 0, 0, 7); x.fillStyle = '#7d3a3a'; x.fill(); }
  else { x.moveTo(56, 82); x.lineTo(72, 82); }
  x.stroke();

  if (look.moustache) {
    x.fillStyle = '#2b2018';
    x.beginPath(); x.ellipse(64, 76, 13, 4.2, 0, 0, 7); x.fill();
  }

  // مو / کلاه / روسری
  const st = look.style || 'hair';
  if (st === 'scarf') {
    x.fillStyle = acc;
    x.beginPath(); x.ellipse(64, 56, 40, 42, 0, Math.PI, 0); x.fill();
    x.beginPath(); x.moveTo(24, 56); x.quadraticCurveTo(20, 108, 44, 116);
    x.lineTo(84, 116); x.quadraticCurveTo(108, 108, 104, 56); x.closePath(); x.fill();
    x.fillStyle = skin;
    x.beginPath(); x.ellipse(64, 64, 27, 31, 0, 0, 7); x.fill();
    // دوباره اجزای صورت روی روسری
    faceParts(x, mood, hair, skin);
    if (look.moustache) { x.fillStyle = '#2b2018'; x.beginPath(); x.ellipse(64, 76, 13, 4.2, 0, 0, 7); x.fill(); }
  } else if (st === 'cap') {
    x.fillStyle = hair;
    x.beginPath(); x.ellipse(64, 40, 31, 20, 0, Math.PI, 0); x.fill();
    x.fillStyle = acc;
    x.beginPath(); x.ellipse(64, 36, 33, 24, 0, Math.PI, 0); x.fill();
    x.beginPath(); x.ellipse(64, 36, 44, 9, 0, Math.PI * 1.02, Math.PI * 1.98); x.fill();
    x.fillStyle = 'rgba(255,255,255,.16)';
    x.beginPath(); x.ellipse(54, 26, 12, 6, -.4, 0, 7); x.fill();
  } else if (st === 'helmet') {
    x.fillStyle = acc;
    x.beginPath(); x.ellipse(64, 52, 36, 38, 0, Math.PI, 0); x.fill();
    x.fillRect(28, 50, 72, 6);
    x.fillStyle = 'rgba(255,255,255,.3)';
    x.beginPath(); x.ellipse(52, 36, 12, 7, -.4, 0, 7); x.fill();
  } else if (st === 'bald') {
    x.strokeStyle = '#b9b9b9'; x.lineWidth = 6;
    x.beginPath(); x.arc(64, 58, 31, Math.PI * 1.06, Math.PI * 1.94, true); x.stroke();
  } else {
    x.fillStyle = hair;
    x.beginPath(); x.ellipse(64, 42, 32, 24, 0, Math.PI, 0); x.fill();
    x.beginPath(); x.ellipse(36, 60, 7, 22, .12, 0, 7); x.fill();
    x.beginPath(); x.ellipse(92, 60, 7, 22, -.12, 0, 7); x.fill();
    x.fillStyle = 'rgba(255,255,255,.12)';
    x.beginPath(); x.ellipse(52, 32, 13, 6, -.35, 0, 7); x.fill();
  }

  if (mood === 'love') {
    x.fillStyle = '#ff5d8f';
    [[24, 30, 9], [104, 36, 7]].forEach(([hx, hy, r]) => {
      x.beginPath();
      x.moveTo(hx, hy + r * .8);
      x.bezierCurveTo(hx - r, hy - r * .4, hx - r * .35, hy - r, hx, hy - r * .35);
      x.bezierCurveTo(hx + r * .35, hy - r, hx + r, hy - r * .4, hx, hy + r * .8);
      x.fill();
    });
  }
  x.restore();
  FACE_CACHE[key] = c;
  return c;
}
// اجزای صورت (برای وقتی روسری روی صورت کشیده میشه)
function faceParts(x, mood, hair, skin) {
  const eyeY = 58;
  x.strokeStyle = hair; x.lineWidth = 3.2; x.lineCap = 'round';
  [50, 78].forEach(bx => { x.beginPath(); x.moveTo(bx - 7, 44); x.lineTo(bx + 7, 43); x.stroke(); });
  if (mood === 'love') {
    x.strokeStyle = '#2a2118';
    [50, 78].forEach(ex => { x.beginPath(); x.arc(ex, eyeY + 2, 6, Math.PI * 1.15, Math.PI * 1.85); x.stroke(); });
  } else {
    [50, 78].forEach(ex => {
      x.fillStyle = '#fff'; x.beginPath(); x.ellipse(ex, eyeY, 7.2, 6.1, 0, 0, 7); x.fill();
      x.fillStyle = '#4a6b7c'; x.beginPath(); x.arc(ex, eyeY, 4, 0, 7); x.fill();
      x.fillStyle = '#161210'; x.beginPath(); x.arc(ex, eyeY, 2.2, 0, 7); x.fill();
      x.fillStyle = 'rgba(255,255,255,.95)'; x.beginPath(); x.arc(ex - 1.5, eyeY - 1.9, 1.4, 0, 7); x.fill();
    });
  }
  x.strokeStyle = 'rgba(150,105,70,.75)'; x.lineWidth = 2.4;
  x.beginPath(); x.moveTo(64, 62); x.lineTo(61, 71); x.lineTo(66, 72); x.stroke();
  x.strokeStyle = '#a44a4a'; x.lineWidth = 2.8;
  x.beginPath();
  if (mood === 'happy' || mood === 'love') x.arc(64, 75, 10, .25, Math.PI - .25);
  else if (mood === 'sad' || mood === 'angry') x.arc(64, 90, 10, Math.PI + .3, -.3);
  else { x.moveTo(57, 81); x.lineTo(71, 81); }
  x.stroke();
}

function playerLook() {
  if (G.child) return { style: 'hair', hair: 0x1f1710 };
  // به همون کلاهی که تو کمد لباس پوشیده وفادار بمون؛ پیش‌فرض «بدون کلاه» یعنی مو
  const hatKey = (G.outfit && G.outfit.hat) || 'none';
  const hatOpt = (typeof WEARABLES !== 'undefined' && WEARABLES.hat.opts[hatKey]) || { style: 'hair' };
  const st = hatOpt.style === 'hair' ? 'hair' : (hatOpt.style === 'helmet' ? 'helmet' : 'cap');
  return { style: st, hair: 0x1f1710, accColor: hatOpt.color ?? 0x1d3557 };
}
function faceInto(el, look, shirt, mood) {
  el.innerHTML = '';
  const c = faceCanvas(look, shirt, mood, 128);
  const img = document.createElement('img');
  img.src = c.toDataURL();
  el.appendChild(img);
}

// ---------------------------------------------------------------
//  لایهٔ گفتگو
// ---------------------------------------------------------------
function buildTalkLayer() {
  if ($id('talkLayer')) return;
  const L = document.createElement('div');
  L.id = 'talkLayer';
  L.dataset.wired = '1';
  L.innerHTML = `
    <div id="talkBubble">
      <button id="talkX" title="بیخیال گفتگو (Esc)" aria-label="بستن گفتگو">✕</button>
      <div class="head"><div class="face" id="talkFace"></div><div class="who"><b id="talkName"></b><small id="talkSub"></small></div></div>
      <p id="talkLine"></p>
      <div class="tail"></div>
    </div>
    <div id="talkMine"><div class="face" id="talkMyFace"></div><p id="talkMyLine"></p></div>
    <div id="talkOpts"></div>`;
  document.body.appendChild(L);
  // ضربدر: وسط هر گفتگویی بی‌خیال شو
  $id('talkX').onclick = e => { e.stopPropagation(); closeTalk(); };
}

function followBubble() {
  if (!dialogueOpen || !talkCtx) return;
  const b = $id('talkBubble'), o = $id('talkOpts'), me = $id('talkMine');
  const pos = window.WORLD?.screenOf?.(talkCtx.npc.id);
  if (pos) {
    const bw = b.offsetWidth || 320, bh = b.offsetHeight || 90;
    const bx = Math.max(12, Math.min(innerWidth - bw - 12, pos.x - bw / 2));
    // حباب بالای سر با فاصله؛ هیچ‌وقت روی کله نیفته
    const by = Math.max(12, Math.min(innerHeight - bh - 200, pos.y - bh - 40));
    b.style.transform = `translate(${bx}px, ${by}px)`;
    b.style.opacity = '1';
  } else {
    b.style.transform = `translate(${innerWidth / 2 - (b.offsetWidth || 320) / 2}px, 90px)`;
    b.style.opacity = '1';
  }
  // گزینه‌ها با CSS پایینِ وسط ثابتن — جابه‌جایی لازم ندارن
  const mp = window.WORLD?.screenOf?.('player');
  if (mp && me.classList.contains('show')) {
    const mw = me.offsetWidth || 260;
    me.style.transform = `translate(${Math.max(12, Math.min(innerWidth - mw - 12, mp.x - mw / 2))}px, ${Math.max(12, mp.y - (me.offsetHeight || 70) - 14)}px)`;
  }
  talkFollowRAF = requestAnimationFrame(followBubble);
}

// t.say / t.option / t.note — به‌جای پنل متنی
function talkOpen(npc, build) {
  buildTalkLayer();
  closePanel();
  dialogueOpen = true;
  talkCtx = { npc };
  talkClose = null;
  $id('talkLayer').classList.add('show');
  $id('interactHint').style.display = 'none';
  const aff = getAffection(npc.id);
  $id('talkName').textContent = npc.name.split(' (')[0];
  $id('talkSub').textContent = (G.knownJobs?.[npc.id] ? npc.job + ' • ' : '') +
    (npc.marriageable ? '❤ ' + fa(aff) + '٪' : G.met?.[npc.id] ? 'همسایه' : 'تازه دیدیش');
  faceInto($id('talkFace'), npc.look, npc.color, 'idle');
  faceInto($id('talkMyFace'), playerLook(), 0xe63946, 'idle');
  $id('talkMine').classList.remove('show');
  talkRebuild(build);
  cancelAnimationFrame(talkFollowRAF);
  followBubble();
}

let talkBuilder = null;
let suppressSay = false;      // موقع بازسازی گزینه‌ها، جملهٔ فعلی پاک نشه
function talkRebuild(build) {
  if (!dialogueOpen || !talkCtx) return;      // گفتگو بسته شده، تایمرهای قدیمی کاری نکنن
  const isRefresh = !build;
  if (build) talkBuilder = build;
  const opts = $id('talkOpts');
  opts.innerHTML = '';
  const t = {
    npc: talkCtx.npc,
    say: (text, mood) => talkSay(text, mood),
    me: text => talkMe(text),
    option: (label, sub, fn, disabled) => {
      const b = document.createElement('button');
      b.className = 'talkOpt' + (disabled ? ' off' : '');
      b.innerHTML = `<span>${label}</span>` + (sub ? `<small>${sub}</small>` : '');
      if (!disabled) b.onclick = () => fn(t);
      opts.appendChild(b);
      return b;
    },
    group: title => {
      const h = document.createElement('div');
      h.className = 'talkGroup'; h.textContent = title;
      opts.appendChild(h);
    },
    refresh: () => talkRebuild(),
    close: () => closeTalk(),
  };
  suppressSay = isRefresh;
  talkBuilder(t);
  suppressSay = false;
  const bye = document.createElement('button');
  bye.className = 'talkOpt bye';
  bye.innerHTML = '<span>👋 خداحافظی</span>';
  bye.onclick = () => closeTalk();
  opts.appendChild(bye);
}

// حرف طرف مقابل — همیشه جایگزین میشه، هیچ‌وقت روی هم انباشته نمیشه
function talkSay(text, mood = 'talk') {
  if (!dialogueOpen || !talkCtx) { toast(text); return; }
  if (suppressSay) return;
  // صدای طرف مقابل: بچه‌ها زیر، دخترا زیرتر از آقایون
  if (typeof sayFa === 'function' && talkCtx?.npc)
    // صدای ضبط‌شدهٔ خودت اولویت داره؛ نبود → گفتار مصنوعی
    if (!(typeof sayWithClip === 'function' && sayWithClip(talkCtx.npc, text, mood)))
      sayAs(talkCtx.npc, text);
    // گادمود: نوار ضبط همین جمله
    if (typeof liveRecShow === 'function') liveRecShow(talkCtx.npc, text);
  const line = $id('talkLine');
  line.classList.remove('pop');
  void line.offsetWidth;
  line.textContent = '«' + text + '»';
  line.classList.add('pop');
  faceInto($id('talkFace'), talkCtx.npc.look, talkCtx.npc.color, mood);
  const aff = getAffection(talkCtx.npc.id);
  if (talkCtx.npc.marriageable)
    $id('talkSub').textContent = (G.knownJobs?.[talkCtx.npc.id] ? talkCtx.npc.job + ' • ' : '') + '❤ ' + fa(aff) + '٪';
}

// حرف خودم (حباب کوچیک بالای سر خودم)
function talkMe(text) {
  const me = $id('talkMine');
  if (!me) return;
  // صدای خود بازیکن (نسل جاری)
  if (typeof sayFa === 'function') sayFa(text, 1.06, G.child ? 1.7 : .88, G.child ? 'k' : 'm');
  faceInto($id('talkMyFace'), playerLook(), 0xe63946, 'talk');
  $id('talkMyLine').textContent = text;
  me.classList.add('show');
  clearTimeout(me._t);
  me._t = setTimeout(() => me.classList.remove('show'), 2600);
}


// آیا الان دقیقاً با همین نفر حرف می‌زنیم؟ (جلوگیری از تایمرهای قدیمی که گفتگوی جدید رو خراب کنن)
function talkIsWith(npc) { return dialogueOpen && talkCtx && talkCtx.npc === npc; }
function talkRebuildFor(npc, build) { if (talkIsWith(npc)) talkRebuild(build); }
function talkSayFor(npc, text, mood) { if (talkIsWith(npc)) talkSay(text, mood); }
function closeTalkFor(npc) { if (talkIsWith(npc)) closeTalk(); }

function closeTalk() {
  if (typeof liveRecHide === 'function') liveRecHide();
  dialogueOpen = false;
  talkCtx = null;
  cancelAnimationFrame(talkFollowRAF);
  const L = $id('talkLayer');
  if (L) L.classList.remove('show');
  window.WORLD?.endTalk?.();
  window.WORLD?.requestLock?.();
  if (talkClose) { const f = talkClose; talkClose = null; try { f(); } catch {} }
}
