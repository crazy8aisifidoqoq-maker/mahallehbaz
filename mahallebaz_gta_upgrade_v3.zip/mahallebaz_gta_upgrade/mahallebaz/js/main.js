// ===== main.js — منوها، شروع بازی، انتخاب حالت دوبعدی/سه‌بعدی =====
'use strict';

window.WORLD = null;
const threeIsReady = () => !!window.THREE;

function show(id, on = true) { $id(id).classList.toggle('show', on); }

// ---------- بوت سینمایی: ویدیوی واقعی، سپس KIAN PRESENTS ----------
let bootDone = false;
let bootStarted = false;
function finishBoot() {
  if (bootDone) return;
  bootDone = true;
  const boot = $id('cinematicBoot');
  const kp = $id('kianPresents');
  if (boot) boot.classList.add('bootHidden');
  setTimeout(() => {
    if (boot) boot.style.display = 'none';
    if (kp) {
      kp.classList.add('show');
      setTimeout(() => {
        kp.style.opacity = '0';
        kp.style.transition = 'opacity .55s ease';
        setTimeout(() => {
          kp.style.display = 'none';
          show('startScreen', true);
          refreshContinue();
        }, 250);
      }, 1200);
    } else {
      show('startScreen', true);
      refreshContinue();
    }
  }, 0);
}
function startCinematicBoot() {
  if (bootStarted) return;
  bootStarted = true;
  const boot = $id('cinematicBoot');
  const video = $id('bootVideo');
  const fill = $id('bootFill');
  const pct = $id('bootPct');
  if (!boot || !video) { show('startScreen', true); return; }
  show('startScreen', false);
  boot.classList.remove('bootHidden');
  boot.style.display = 'flex';
  const update = () => {
    if (!isFinite(video.duration) || video.duration <= 0) return;
    const p = Math.min(1, video.currentTime / video.duration);
    if (fill) fill.style.width = (p * 100).toFixed(2) + '%';
    if (pct) pct.textContent = Math.round(p * 100) + '%';
  };
  video.addEventListener('timeupdate', update);
  video.addEventListener('loadedmetadata', update, {once:true});
  video.addEventListener('ended', finishBoot, {once:true});
  video.addEventListener('error', () => {
    // اگر فایل ویدیو به هر دلیل در مرورگر لود نشد، منو قفل نمی‌شود.
    finishBoot();
  }, {once:true});
  video.muted = false;
  video.volume = 1;
  const p = video.play();
  if (p && typeof p.catch === 'function') p.catch(() => {
    // autoplay صدادار ممکن است توسط مرورگر مسدود شود؛ اولین کلیک آن را فعال می‌کند.
    const unlock = () => { video.play().catch(()=>{}); window.removeEventListener('pointerdown', unlock); window.removeEventListener('keydown', unlock); };
    window.addEventListener('pointerdown', unlock, {once:true});
    window.addEventListener('keydown', unlock, {once:true});
  });
}

function showMainMenu() {
  gameStarted = false; gamePaused = false;
  if (typeof stopMusic === 'function') stopMusic();
  closePanel();
  document.exitPointerLock?.();
  if (window.WORLD) { window.WORLD.destroy(); window.WORLD = null; }
  show('pauseMenu', false);
  show('modeSelect', false);
  show('startScreen', true);
  refreshContinue();
  $id('hudWrap').style.display = 'none';
}

function launchGame(mode, fromLoad) {
  if (!fromLoad) { G = defaultGameState(); }
  G.mode = mode;
  if (typeof applyGenNames === 'function') applyGenNames();
  G.challenge = null;   // چالش نیمه‌کاره بعد از لود از نو
  if (mode === '3d' && !threeIsReady()) { toast('⏳ موتور سه‌بعدی هنوز لود نشده... چند لحظه دیگه دوباره بزن!'); return; }
  show('startScreen', false); show('modeSelect', false); show('pauseMenu', false);
  closePanel();
  // یه فریم صبر می‌کنیم تا صفحهٔ لودینگ واقعاً رندر بشه، بعد کار سنگین ساخت دنیا رو شروع می‌کنیم
  requestAnimationFrame(() => setTimeout(() => {
    if (window.WORLD) { window.WORLD.destroy(); window.WORLD = null; }
    gameStarted = true; gamePaused = false;
    window.WORLD = mode === '3d' ? createWorld3D() : createWorld2D();
    $id('hudWrap').style.display = 'block';
    updateHUD();
    addLog(fromLoad ? '💾 بازی لود شد. خوش برگشتی به تهران!' : '🏙️ به تهران ۱۴۰۵ خوش اومدی! با E وارد ساختمون‌ها شو.');
    if (typeof ensureSettings === 'function') ensureSettings();
    setTimeout(() => window.WORLD?.applyQuality?.(G.settings?.quality || 'high'), 200);
    if (typeof startMusic === 'function') setTimeout(startMusic, 1500);
    if (typeof voiceQualityNotice === 'function') voiceQualityNotice();
    if (!fromLoad && typeof startTutorial === 'function' && !G.tutorial) setTimeout(startTutorial, 2500);
    else if (typeof tickTutorial === 'function') setTimeout(tickTutorial, 1500);
    addNews('🏙️ روز جدیدی در تهران... دلار: ' + faMoney(G.eco.dollar));
    if (mode === '3d') window.WORLD.requestLock();
  }, 30));
}

function openPause() {
  if (!gameStarted || gamePaused) return;
  gamePaused = true;
  document.exitPointerLock?.();
  show('pauseMenu', true);
}
function resumeGame() {
  gamePaused = false;
  show('pauseMenu', false);
  if (G.mode === '3d') window.WORLD?.requestLock();
}

// Esc: بستن پنل/گفتگو، وگرنه منوی توقف (دوبعدی خودش تو world2d هندل می‌کنه)
// کلید N: اخبار
addEventListener('keydown', e => {
  if (e.code === 'KeyN' && gameStarted && !gamePaused) {
    if (panelOpen) closePanel(); else openNews();
  }
  if (e.code === 'KeyM' && gameStarted && !gamePaused) openCityMap();   // خودش باز/بسته می‌کنه
  // کنسول تقلب مخفی: دکمهٔ ` (زیر Esc، بغل 1) — یا دوبار پشت هم Tab برای کیبوردهایی که ` ندارن
  if (e.code === 'Backquote' && gameStarted && !gamePaused) {
    e.preventDefault();
    if (panelOpen) closePanel(); else openCheatPanel();
  }
  if (e.code === 'Tab') {
    e.preventDefault();                                    // فوکوس صفحه هم به‌هم نریزه
    const now = Date.now();
    if (gameStarted && !gamePaused && now - (window.__lastTab || 0) < 450) {
      if (panelOpen) closePanel(); else openCheatPanel();
      window.__lastTab = 0;
    } else window.__lastTab = now;
  }
  if (e.code === 'Escape') {
    if (typeof cityMapEl !== 'undefined' && cityMapEl) closeCityMap();
    else if (panelOpen) closePanel();
    else if (typeof dialogueOpen !== 'undefined' && dialogueOpen) closeTalk();
    else if (G.mode === '3d' && gameStarted && !gamePaused && !G.traveling) openPause();
  }
});

// ---------- دکمه‌ها ----------
function wire() {
  $id('btnNewGame').onclick = () => { show('startScreen', false); show('modeSelect', true); };
  $id('btnContinue').onclick = () => {
    const slot = latestSlot();
    if (!slot) { toast('📂 هنوز هیچ بازی ذخیره‌شده‌ای نداری!'); return; }
    if (loadFromSlot(slot)) launchGame(G.mode, true);
  };
  $id('btnMode3d').onclick = () => launchGame('3d', false);
  $id('btnMode2d').onclick = () => launchGame('2d', false);
  $id('btnModeBack').onclick = () => { show('modeSelect', false); show('startScreen', true); };
  $id('btnLoad').onclick = () => openSaveMenu('load');
  $id('btnAbout').onclick = () => openPanel('ℹ️ درباره بازی', p => {
    noteP(p, '🎬 کیان تقدیم می‌کند');
    noteP(p, '🏙️ تهران ۱۴۰۵ — شبیه‌ساز طنز زندگی روزمره در تهران. کار کن، بخر، سفر برو، عاشق شو، و با تورم بجنگ!');
    noteP(p, document.body.classList.contains('touch')
      ? '📱 کنترل: جوی‌استیک حرکت | دکمهٔ E ورود/گفتگو | دکمهٔ F سوار/پیاده شدن ماشین | نوار بالا: اخبار و منو'
      : '⌨️ کنترل: WASD حرکت | E ورود/گفتگو | F سوار/پیاده شدن ماشین | N اخبار | Esc منو');
    noteP(p, '💾 سه اسلات ذخیره | دو حالت دوبعدی و سه‌بعدی');
    noteP(p, '👨‍💻 ساخته‌شده با Three.js و Canvas 2D — نسخه ۱.۰');
  });
  $id('btnExit').onclick = () => { toast('👋 خداحافظ! می‌تونی تب رو ببندی.'); setTimeout(() => window.close(), 1200); };
  $id('btnResume').onclick = resumeGame;
  $id('btnSaveMenu').onclick = () => openSaveMenu('save');
  $id('btnLoadMenu').onclick = () => openSaveMenu('load');
  $id('btnToMain').onclick = showMainMenu;
  $id('btnBadges').onclick = () => { show('pauseMenu', false); gamePaused = false; openBadges(); };
  $id('btnSettings').onclick = () => { show('pauseMenu', false); gamePaused = false; openSettings(); };
  $id('btnHelp').onclick = () => { show('pauseMenu', false); gamePaused = false; openHelpBook(); };
  $id('btnPauseExit').onclick = () => { toast('👋 اول سیو کن بعد برو!'); };
  $id('panelClose').onclick = closePanel;
  $id('newsBtn').onclick = () => { if (panelOpen) closePanel(); else openNews(); };
  $id('workBtn').onclick = doWork;
  $id('lbBtn').onclick = () => { if (panelOpen) closePanel(); else openLeaderboard(); };
  $id('taxiBtn').onclick = () => {
    if (panelOpen) { closePanel(); return; }
    if (!gameStarted || G.traveling) return;
    if (window.WORLD?.nearTaxi?.()) openTaxi(false);
    else if (G.phone && !G.phoneBroken) openTaxi(true);
    else toast('🚕 نه تاکسی نزدیکته نه گوشی داری زنگ بزنی! برو کنار خیابون تاکسی زرد پیدا کن!');
  };
  $id('phoneBtn').onclick = () => { if (panelOpen) closePanel(); else if (gameStarted && !G.traveling) openPhone(); };
  $id('pauseBtn').onclick = openPause;
  $id('missionBtn').onclick = () => { if (panelOpen) closePanel(); else if (gameStarted) openMissions(); };
  $id('bagBtn').onclick = () => { if (panelOpen) closePanel(); else if (gameStarted) openBag(); };
  $id('journalBtn').onclick = () => { if (panelOpen) closePanel(); else if (gameStarted) openJournal(); };
}

// ---------- کنترل لمسی ----------
const touchInput = { mx: 0, mz: 0, run: false };
window.touchInput = touchInput;

function setupTouch() {
  const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0 ||
                  (window.matchMedia && matchMedia('(pointer: coarse)').matches);
  if (!isTouch) return;
  document.body.classList.add('touch');

  const joy = $id('joy'), knob = $id('joyKnob');
  let joyId = null;
  const joyCenter = () => {
    const r = joy.getBoundingClientRect();
    return { x: r.left + r.width/2, y: r.top + r.height/2, rad: r.width/2 };
  };
  joy.addEventListener('pointerdown', e => { joyId = e.pointerId; joy.setPointerCapture(joyId); moveJoy(e); });
  joy.addEventListener('pointermove', e => { if (e.pointerId === joyId) moveJoy(e); });
  const endJoy = e => {
    if (e.pointerId !== joyId) return;
    joyId = null;
    touchInput.mx = touchInput.mz = 0;
    knob.style.transform = 'translate(-50%,-50%)';
  };
  joy.addEventListener('pointerup', endJoy);
  joy.addEventListener('pointercancel', endJoy);
  function moveJoy(e) {
    const c = joyCenter();
    let dx = (e.clientX - c.x) / c.rad, dy = (e.clientY - c.y) / c.rad;
    let len = Math.hypot(dx, dy);
    if (len > 1) { dx /= len; dy /= len; len = 1; }
    if (len < .18) { dx = 0; dy = 0; }      // ناحیهٔ مرده که لرزش انگشت حرکت نده
    touchInput.mx = dx; touchInput.mz = dy;
    knob.style.transform = `translate(calc(-50% + ${dx * c.rad * .55}px), calc(-50% + ${dy * c.rad * .55}px))`;
  }

  const fireKey = code => {
    dispatchEvent(new KeyboardEvent('keydown', { code }));
    setTimeout(() => dispatchEvent(new KeyboardEvent('keyup', { code })), 80);
  };
  $id('btnTouchE').addEventListener('pointerdown', e => { e.preventDefault(); fireKey('KeyE'); });
  $id('btnTouchF').addEventListener('pointerdown', e => { e.preventDefault(); fireKey('KeyF'); });
  const runBtn = $id('btnTouchRun');
  runBtn.addEventListener('pointerdown', e => {
    e.preventDefault();
    touchInput.run = !touchInput.run;
    runBtn.style.background = touchInput.run ? 'rgba(255,209,102,.5)' : 'rgba(255,255,255,.12)';
  });
}

// ---------- بوت ----------
document.addEventListener('DOMContentLoaded', () => {
  wire();
  setupTouch();
  show('startScreen', false);
  refreshContinue();
  // بوت کامل فقط یک‌بار در اولین باز شدن فایل اجرا می‌شود.
  startCinematicBoot();
  // مسیر پیش‌نمایش برای تست و طراحی سریع: ?preview=3d
  if (new URLSearchParams(location.search).get('preview') === '3d') {
    const go = () => launchGame('3d', false);
    if (threeIsReady()) go(); else addEventListener('three-ready', go, { once:true });
  }
});

// دکمهٔ «ادامهٔ آخرین بازی» فقط وقتی سیو داری فعاله
function refreshContinue() {
  const btn = $id('btnContinue');
  if (!btn) return;
  const slot = latestSlot();
  btn.disabled = !slot;
  const info = slot ? slotInfo(slot) : null;
  btn.textContent = info
    ? 'ادامهٔ آخرین بازی — ' + info.date
    : 'ادامهٔ آخرین بازی';
}

// Enter روی صفحهٔ شروع = بازی جدید
addEventListener('keydown', e => {
  if (e.code !== 'Enter' && e.code !== 'NumpadEnter') return;
  if (gameStarted || !$id('startScreen').classList.contains('show')) return;
  $id('btnNewGame').click();
});
