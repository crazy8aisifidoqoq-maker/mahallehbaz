// ===== economy.js — اقتصاد شبیه‌سازی‌شده: random walk روزانه، مشاغل، ماشین‌ها، سفر =====
'use strict';

// ضریب تورم روزانه از تورم سالانه
function dailyInflationFactor() { return 1 + (G.eco.inflation / 100) / 365; }

// قدم تصادفی روزانه‌ی اقتصاد + تولید خبر
function economyDailyTick() {
  const news = [];
  const e = G.eco;

  const dollarPct = (Math.random() - .42) * .06; // بایاس صعودی!
  const oldDollar = e.dollar;
  e.dollar = Math.max(60000, Math.round(e.dollar * (1 + dollarPct)));
  if (Math.abs(e.dollar - oldDollar) / oldDollar > .02)
    news.push(e.dollar > oldDollar
      ? '📈 دلار ' + fa(e.dollar - oldDollar) + ' تومن گرون شد! صرافی‌ها شلوغن.'
      : '📉 دلار ریخت! کانال‌های تلگرامی: «فرصت خریده!»');

  if (Math.random() < .08) {
    e.benzin = Math.round(e.benzin * (1.1 + Math.random() * .4));
    news.push('⛽ قیمت بنزین شد ' + faMoney(e.benzin) + '! (سهمیه‌ها فعلاً سر جاشونه... فعلاً)');
  }

  e.inflation = Math.max(15, Math.min(90, e.inflation + (Math.random() - .45) * 3));
  if (Math.random() < .15)
    news.push('📊 مرکز آمار: تورم ' + fa(e.inflation) + '٪ شد. مسئولین: «کنترل شده است.»');

  e.housingCoef = Math.max(.7, e.housingCoef * (1 + (Math.random() - .40) * .02));
  if (Math.random() < .12)
    news.push('🏠 قیمت مسکن باز هم رشد کرد. مستاجرها به فکر چادر زدن در پارک افتادند!');

  e.carCoef = Math.max(.7, e.carCoef * (1 + (Math.random() - .42) * .025));
  if (Math.random() < .1)
    news.push('🚗 بازار خودرو داغ شد؛ پراید دوباره رکورد زد!');

  return news;
}

// ---- مشاغل ----
const JOBS = [
  { id:'barista',   name:'☕ باریستا',            base:900000,  hours:6, needPhone:false, needCar:false, needEdu:false, remote:false, place:'cafe' },
  { id:'dev',       name:'💻 برنامه‌نویس دورکار', base:4500000, hours:8, needPhone:true,  needCar:false, needEdu:true,  remote:true,  place:null },
  { id:'carpenter', name:'🪚 نجار',               base:1800000, hours:8, needPhone:false, needCar:false, needEdu:false, remote:false, place:'repair' },
  { id:'taxi',      name:'🚕 راننده تاکسی',       base:1500000, hours:8, needPhone:false, needCar:true,  needEdu:false, remote:false, place:null },
  { id:'courier',   name:'🛵 پیک موتوری',         base:1200000, hours:8, needPhone:true,  needCar:true,  needEdu:false, remote:false, place:null },
  { id:'teacher',   name:'📚 معلم',               base:2000000, hours:6, needPhone:false, needCar:false, needEdu:true,  remote:false, place:'university' },
  { id:'shop',      name:'🏪 مغازه‌دار',          base:1600000, hours:10, needPhone:false, needCar:false, needEdu:false, remote:false, place:'market' },
  { id:'cafeowner', name:'🏦 صاحب کافه',          base:3500000, hours:10, needPhone:false, needCar:false, needEdu:false, remote:false, place:'cafe', capital:150000000 },
  { id:'youtuber',  name:'🎬 یوتیوبر',            base:2500000, hours:5, needPhone:true,  needCar:false, needEdu:false, remote:true,  place:null, volatile:true },
  { id:'streamer',  name:'🎮 استریمر',            base:2200000, hours:6, needPhone:true,  needCar:false, needEdu:false, remote:true,  place:null, volatile:true },
  { id:'exchange',  name:'💱 کارمند صرافی',       base:2600000, hours:8, needPhone:false, needCar:false, needEdu:false, remote:false, place:'bank' },
];

function jobSalaryToday(job) {
  // حقوق با تورم رشد می‌کنه
  let s = job.base * Math.pow(dailyInflationFactor(), G.dayIndex);
  if (job.volatile) s *= .3 + Math.random() * 1.8; // درآمد یوتیوبر قابل پیش‌بینی نیست!
  if (job.id === 'dev' && (G.robotics || 0) >= 2) s *= 1.5; // مدرک رباتیک نوین‌ذهن!
  return Math.round(s);
}

function canTakeJob(job) {
  if (job.needEdu && !G.education) return 'مدرک دانشگاه لازمه! برو دانشگاه.';
  if (job.needPhone && (!G.phone || G.phoneBroken)) return 'گوشی سالم لازمه!';
  if (job.needCar && G.cars.length === 0) return 'وسیله نقلیه لازمه!';
  if (job.capital && G.money < job.capital) return 'سرمایه اولیه: ' + faMoney(job.capital);
  return null;
}

// ---- ماشین‌ها ----
const CARS = [
  { id:'pride',   name:'پراید ۱۳۱',        base:250000000,  speed:12, tank:37, fragility:.30, color:0xdddddd },
  { id:'tiba',    name:'تیبا ۲',           base:330000000,  speed:13, tank:40, fragility:.25, color:0x4a90d9 },
  { id:'quick',   name:'کوییک R',          base:380000000,  speed:14, tank:40, fragility:.22, color:0xe63946 },
  { id:'p206',    name:'پژو ۲۰۶',          base:480000000,  speed:15, tank:50, fragility:.18, color:0xbbbbbb },
  { id:'samand',  name:'سمند LX',          base:450000000,  speed:14, tank:60, fragility:.20, color:0x333344 },
  { id:'dena',    name:'دنا پلاس توربو',   base:750000000,  speed:17, tank:60, fragility:.15, color:0x222222 },
  { id:'l90',     name:'رنو ال۹۰',         base:700000000,  speed:15, tank:50, fragility:.12, color:0xf2cc8f },
  { id:'haima',   name:'هایما S7',         base:1300000000, speed:17, tank:60, fragility:.13, color:0x2d4a3e },
  { id:'camry',   name:'تویوتا کمری',      base:4200000000, speed:19, tank:60, fragility:.07, color:0x8899aa },
  { id:'bmw',     name:'بی‌ام‌و 330i',     base:9500000000, speed:23, tank:59, fragility:.05, color:0x1d3557 },
];
function carPrice(car) { return Math.round(car.base * G.eco.carCoef); }
function carById(id) { return CARS.find(c => c.id === id); }
function activeCarData() { return G.activeCar ? carById(G.activeCar) : null; }

// ---- سفر ----
const TRIPS_INTERNAL = [
  { id:'mashhad', name:'مشهد',   price: 4000000, dur:12, happy:20 },
  { id:'isfahan', name:'اصفهان', price: 3000000, dur:9,  happy:15 },
  { id:'shiraz',  name:'شیراز',  price: 3500000, dur:10, happy:16 },
  { id:'rasht',   name:'رشت',    price: 2500000, dur:8,  happy:18 },
  { id:'kish',    name:'کیش',    price: 9000000, dur:12, happy:25 },
];
const TRIPS_EXTERNAL = [
  { id:'istanbul', name:'استانبول', priceUsd: 450, dur:16, happy:30 },
  { id:'dubai',    name:'دبی',      priceUsd: 550, dur:15, happy:28 },
  { id:'baku',     name:'باکو',     priceUsd: 300, dur:13, happy:22 },
  { id:'tbilisi',  name:'تفلیس',    priceUsd: 320, dur:14, happy:24 },
];
function tripPrice(t) { return t.priceUsd ? Math.round(t.priceUsd * G.eco.dollar) : t.price; }

// ---- هزینه‌های ثابت ----
function rentToday() { return Math.round(25000000 * G.eco.housingCoef); } // اجاره ماهانه
function housePrice() { return Math.round(8000000000 * G.eco.housingCoef); }
const PHONES = [
  { id:'nokia',  name:'نوکیا ساده (فقط زنگ!)', priceUsd: 40 },
  { id:'xiaomi', name:'شیائومی ردمی',          priceUsd: 250 },
  { id:'iphone', name:'آیفون (قسطی هم نمیشه)', priceUsd: 1400 },
];
