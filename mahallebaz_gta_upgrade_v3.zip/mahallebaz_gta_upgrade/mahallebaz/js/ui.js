// ===== ui.js — تمام رابط کاربری: HUD، پنل‌ها، منوها، دیالوگ، سیو =====
'use strict';

const $id = id => document.getElementById(id);
let gameStarted = false, gamePaused = false;

// ---------- صدا (WebAudio — بدون فایل) ----------
let audioCtx = null;
function beep(freq, dur = .15, type = 'square', vol = .07) {
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + dur);
    o.connect(g); g.connect(audioCtx.destination);
    o.start(); o.stop(audioCtx.currentTime + dur);
  } catch {}
}
const sfxOn = () => G.settings ? G.settings.sfx !== false : true;
const sfx = {
  alert:  () => { beep(880,.12); setTimeout(()=>beep(660,.12),130); setTimeout(()=>beep(880,.2),260); },
  party:  () => [523,659,784,1047,1319].forEach((f,i)=>setTimeout(()=>beep(f,.22,'triangle',.09), i*130)),
  sad:    () => { beep(392,.25,'sine'); setTimeout(()=>beep(311,.4,'sine'),260); },
  money:  () => { beep(1047,.1,'sine',.06); setTimeout(()=>beep(1319,.15,'sine',.06),100); },
  click:  () => beep(600,.05,'sine',.03),
  ring:   () => { beep(1200,.1,'sine',.05); setTimeout(()=>beep(1200,.1,'sine',.05),200); },
  honk:   () => { beep(340,.16,'square',.045); setTimeout(()=>beep(340,.24,'square',.05),230); },
  chirp:  () => { beep(2700,.06,'sine',.02); setTimeout(()=>beep(3300,.05,'sine',.017),90); setTimeout(()=>beep(3000,.07,'sine',.014),200); },
  step:   () => beep(170 + Math.random()*50, .03, 'sine', .011),
  door:   () => { beep(500,.06,'sine',.03); setTimeout(()=>beep(720,.08,'sine',.03),90); },
  cry:    () => { [0,550,1100,1700].forEach(t => setTimeout(() => { beep(760,.28,'sawtooth',.04); setTimeout(()=>beep(520,.22,'sawtooth',.035),240); }, t)); },
};

// صدای فارسی AI با موتور گفتار مرورگر (اگه صدای fa موجود باشه)
let faVoice = null;          // بهترین صدای فارسی موجود
let voiceMale = null, voiceFemale = null;   // صدای مرد و زن
// نام‌های رایج صداهای زنانه/مردانه در ویندوز، اج، اندروید، iOS
const FEMALE_HINT = /female|zira|dilara|hoda|salma|aria|jenny|samantha|karen|moira|tessa|victoria|fiona|google (uk|us) english female|زن|خانم/i;
const MALE_HINT   = /male|david|mark|george|guy|daniel|alex|fred|rishi|tom|ravi|مرد|آقا/i;
function pickFaVoice() {
  const vs = speechSynthesis.getVoices() || [];
  const fa_ = vs.filter(v => v.lang?.startsWith('fa') || /persian|farsi/i.test(v.name));
  faVoice = fa_[0] || null;
  // اول بین صداهای فارسی دنبال زن و مرد بگرد
  voiceFemale = fa_.find(v => FEMALE_HINT.test(v.name)) || null;
  voiceMale   = fa_.find(v => MALE_HINT.test(v.name))   || null;
  // اگه نبود، از بقیهٔ صداهای سیستم (متن فارسی رو با لهجه می‌خونن ولی جنسیت درست میشه)
  if (!voiceFemale) voiceFemale = vs.find(v => FEMALE_HINT.test(v.name)) || null;
  if (!voiceMale)   voiceMale   = vs.find(v => MALE_HINT.test(v.name))   || null;
  if (!voiceFemale && fa_.length > 1) voiceFemale = fa_[1];
  if (!voiceMale) voiceMale = faVoice;
  if (!voiceFemale) voiceFemale = faVoice;
}

/* ---------------------------------------------------------------
   🗣️ صدای اختصاصی هر شخصیت
   هر نفر یک «امضای صوتی» ثابت دارد: جنسیت + زیر و بمی + سرعت
--------------------------------------------------------------- */
function voiceOf(npc) {
  if (!npc) return { gender: 'm', pitch: 1, rate: 1.05 };
  // امضای دستیِ چند شخصیت شاخص
  const CUSTOM = {
    ghasem:   { pitch: .72, rate: .95 },   // بقال مسن، بم و آروم
    gholam:   { pitch: .68, rate: .88 },   // پیرمرد، خیلی بم و کند
    ghassab:  { pitch: .66, rate: 1.0  },  // قصاب سبیل‌کلفت، بم‌ترین
    akbar:    { pitch: .70, rate: 1.0  },  // مربی، بم و پرانرژی
    police:   { pitch: .80, rate: .98 },   // افسر، جدی و شمرده
    asghar:   { pitch: .95, rate: 1.30 },  // پیک موتوری، تند و تیز
    amir:     { pitch: .92, rate: 1.15 },  // برنامه‌نویس جوان
    navid:    { pitch: .88, rate: 1.08 },  // باریستا
    reza:     { pitch: .76, rate: 1.0  },  // مکانیک
    fezzeh:   { pitch: 1.55, rate: 1.25 }, // ملوک‌خانم، تیز و پرحرف
    ghamar:   { pitch: 1.25, rate: .92 },  // ننه‌قمر، گرم و آروم
    shirin:   { pitch: 1.45, rate: 1.10 },
    nazanin:  { pitch: 1.30, rate: 1.12 },
    maryam:   { pitch: 1.35, rate: 1.02 },
    elnaz:    { pitch: 1.50, rate: 1.18 },
    roya:     { pitch: 1.40, rate: .98 },
    yasi:     { pitch: 1.52, rate: 1.14 },
    niloofar: { pitch: 1.48, rate: 1.22 },
    setare:   { pitch: 1.42, rate: 1.28 },
    parisa:   { pitch: 1.28, rate: .95 },
    leila:    { pitch: 1.33, rate: 1.0  },
    sara:     { pitch: 1.38, rate: 1.06 },
    niloofar_ax: { pitch: 1.36, rate: 1.08 },
    kid_hooman: { pitch: 1.85, rate: 1.25 },
    kid_nika:   { pitch: 1.95, rate: 1.22 },
    kid_sam:    { pitch: 1.80, rate: 1.30 },
  };
  const female = npc.gender === 'f';
  let sig = CUSTOM[npc.id];
  if (!sig) {
    // بقیه: امضای ثابت از روی id (هر بار همون صدا)
    let h = 0;
    for (const ch of (npc.id || 'x')) h = (h * 31 + ch.charCodeAt(0)) & 0xffff;
    const base = npc.kid ? 1.8 : female ? 1.35 : .78;
    sig = { pitch: base + ((h % 20) - 10) / 100, rate: (npc.kid ? 1.22 : 1.03) + ((h >> 5) % 16 - 8) / 100 };
  }
  return { gender: npc.kid ? 'k' : female ? 'f' : 'm', pitch: sig.pitch, rate: sig.rate };
}

// حرف زدن با صدای خودِ شخصیت
function sayAs(npc, text) {
  const v = voiceOf(npc);
  sayFa(text, v.rate, v.pitch, v.gender);
}
if ('speechSynthesis' in window) {
  pickFaVoice();
  speechSynthesis.onvoiceschanged = pickFaVoice;
}
// تقسیم متن به تکه‌های کوتاه سرِ نشونه‌های نگارشی، تا موتور گفتار سرِ هرکدوم
// یه مکث طبیعی بذاره (خیلی از موتورها فقط سرِ پایان جمله مکث می‌کنن، نه وسط جمله).
function splitForSpeech(text) {
  if (!text) return [];
  let t = String(text).trim();
  if (!t) return [];
  // اگه جمله با نشونهٔ پایانی تموم نشده، یه نقطه بذار تا آهنگ صدا درست پایین بیاد.
  if (!/[.!؟?…]$/.test(t)) t += '.';
  // اول سرِ پایان‌جمله‌ها (نقطه/تعجب/سوال/سه‌نقطه) بشکن، نشونه رو هم نگه‌دار.
  const sentences = t.match(/[^.!؟?…]+[.!؟?…]*/g) || [t];
  const parts = [];
  sentences.forEach(s => {
    s = s.trim();
    if (!s) return;
    // جمله‌های بلند رو سرِ ویرگول/نقطه‌ویرگول هم بشکن که وسط جمله هم نفس بگیره.
    if (s.length > 42 && /[،,؛;]/.test(s)) {
      s.split(/([،,؛;])/).reduce((acc, chunk, i, arr) => {
        acc += chunk;
        const isPunct = /^[،,؛;]$/.test(chunk);
        const next = arr[i + 1];
        if (isPunct || i === arr.length - 1) {
          if (acc.trim()) parts.push(acc.trim());
          return '';
        }
        return acc;
      }, '');
    } else {
      parts.push(s);
    }
  });
  return parts.length ? parts : [t];
}

function sayFa(text, rate = 1.15, pitch = 1, gender) {
  try {
    if (!('speechSynthesis' in window)) return;
    if (G.settings && G.settings.voice === false) return;
    if (!faVoice && !voiceMale && !voiceFemale) pickFaVoice();
    const v = gender === 'f' || gender === 'k' ? (voiceFemale || faVoice)
            : gender === 'm' ? (voiceMale || faVoice)
            : faVoice;
    const persianCapable = typeof voiceSpeaksPersian === 'function' ? voiceSpeaksPersian(v) : !!faVoice;
    speechSynthesis.cancel();
    const chunks = splitForSpeech(text);
    chunks.forEach((chunk, i) => {
      const u = new SpeechSynthesisUtterance(chunk);
      if (v) u.voice = v;
      // موتور انگلیسی متن فارسی رو نمی‌خونه (سکوت می‌کنه) → خودکار فینگلیش‌ش می‌کنیم
      if (!persianCapable && typeof faToLatin === 'function') {
        u.text = faToLatin(chunk);
        u.lang = (v && v.lang) || 'en-US';
      } else u.lang = 'fa-IR';
      u.rate = Math.max(.5, Math.min(2, rate));
      u.pitch = Math.max(0, Math.min(2, pitch));
      // آخرین تکه صداش کامل، تکه‌های وسط یه‌ذره آروم‌تر که مکث طبیعی‌تر حس بشه
      u.volume = i < chunks.length - 1 ? .82 : .85;
      speechSynthesis.speak(u);
    });
  } catch {}
}

// پلاک ماشین خاطی: لحظهٔ زدن یه نظر می‌بینی؛ اگه دنبالش بدویی بهتر و طولانی‌تر
function showPlateFlash(plate, ms = 2500) {
  let el = $id('plateFlash');
  if (!el) {
    el = document.createElement('div');
    el.id = 'plateFlash';
    el.style.cssText = 'position:fixed;top:170px;right:50%;transform:translateX(50%);z-index:80;display:flex;align-items:stretch;border:3px solid #111;border-radius:8px;overflow:hidden;box-shadow:0 8px 30px rgba(0,0,0,.6);font-family:inherit';
    document.body.appendChild(el);
  }
  el.innerHTML = '<div style="background:#1d3557;color:#fff;padding:6px 8px;font-size:11px;display:flex;align-items:center">ایران</div>' +
    '<div style="background:#fff;color:#111;padding:6px 20px;font-size:26px;font-weight:bold;letter-spacing:3px;direction:ltr">' + plate + '</div>';
  el.style.display = 'flex';
  clearTimeout(el._t);
  el._t = setTimeout(() => el.style.display = 'none', ms);
}
document.addEventListener('click', e => { if (e.target.tagName === 'BUTTON') sfx.click(); });

// ---------- HUD ----------
function updateHUD() {
  clampStats();
  $id('hudMoney').textContent = faMoney(G.money);
  $id('hudDate').textContent = weekdayStr(G.dayIndex) + ' ' + shamsiStr(G.dayIndex);
  $id('hudClock').textContent = fa(G.hour).padStart(2,'۰') + ':' + fa(Math.floor(G.minute)).padStart(2,'۰');
  $id('hudWeather').textContent = weatherName(G.weather);
  $id('hudDollar').textContent = fa(G.eco.dollar);
  $id('barHealth').style.width = G.health + '%';
  $id('barEnergy').style.width = G.energy + '%';
  $id('barHappy').style.width = G.happy + '%';
  $id('hudJob').textContent = G.job ? JOBS.find(j=>j.id===G.job).name : 'بیکار';
  const hon = G.honor ?? 50;
  $id('hudHonor').textContent = fa(hon) + ' ' + (typeof honorLabel === 'function' ? honorLabel().replace(/[^\u0600-\u06FF\s😇😈]/g,'') : '');
  const fam = G.married ? ('💍 ' + NPCS.find(n=>n.id===G.married).name + (G.childName ? ' — 👶 ' + G.childName : '')) : '';
  $id('hudFamily').textContent = fam;
  $id('workBtn').style.display = G.job && !G.workedToday ? 'block' : 'none';
  const car = activeCarData();
  $id('hudCar').textContent = car ? ('🚗 ' + car.name + ' | ⛽ ' + fa(G.fuel) + 'ل | 🔧 ' + fa(G.damage) + '٪') : '';
}

function addLog(msg) {
  const log = $id('log');
  const e = document.createElement('div');
  e.className = 'entry';
  e.textContent = msg;
  log.prepend(e);
  while (log.children.length > 6) log.lastChild.remove();
  setTimeout(() => { e.style.opacity = '0'; setTimeout(()=>e.remove(), 900); }, 14000);
}
const newsList = [];
function addNews(msg) {
  newsList.unshift('【' + shamsiStr(G.dayIndex) + '】 ' + msg);
  if (newsList.length > 40) newsList.pop();
  $id('newsBadge').style.display = 'inline-block';
}
function showBanner(msg, ms = 5000) {
  sfx.alert();
  const b = $id('banner');
  b.textContent = msg;
  b.style.display = 'block';
  clearTimeout(b._t);
  b._t = setTimeout(() => b.style.display = 'none', ms);
}
function toast(msg) {
  const t = $id('toast');
  t.textContent = msg;
  t.style.display = 'block';
  clearTimeout(t._t);
  t._t = setTimeout(() => t.style.display = 'none', 2200);
}

// ---------- زمان ----------
function advanceTime(hours) {
  G.hour += hours;
  while (G.hour >= 24) { G.hour -= 24; runDailyTick(); }
  updateHUD();
}
function runDailyTick() {
  // birth: a few days after marriage, one morning you wake to crying!
  if (G.married && !G.childName && G.dueDay != null && G.dayIndex >= G.dueDay) {
    G.childName = CHILD_NAMES[Math.floor(Math.random() * CHILD_NAMES.length)];
    G.childBornDay = G.dayIndex;
    G.childStage = 'infant';
    const wname = (NPCS.find(n => n.id === G.married)?.name || 'همسرت').split(' (')[0];
    sfx.cry();
    if (typeof sayFa === 'function') sayFa('انگع... انگع... انگع!', .9, 1.9, 'k');
    showBanner('👶 صبح با صدای گریهٔ نوزاد از خواب پریدی! ' + wname + ': «مبارکه! اسمشو گذاشتم ' + G.childName + '!» 🎉', 9000);
    addLog('👶 ' + G.childName + ' به دنیا اومد! (شیرخواره‌ست — صبح‌ها براش از سوپرمارکت خرید کن)');
    addNews('👶 محله یه عضو جدید داره: ' + G.childName + '!');
    sfx.party();
    window.WORLD?.onChild?.();
  }
  // growth stages
  if (G.childName && !G.childGrown && G.childBornDay != null) {
    const age = G.dayIndex - G.childBornDay;
    if (age >= 4 && G.childStage === 'infant') {
      G.childStage = 'kid';
      showBanner('🍼→🧒 ' + G.childName + ' از شیرخوارگی دراومد! دیگه راه میره و همه‌جا رو بهم می‌ریزه!', 6000);
    }
    if (age >= 10 && G.childStage !== 'school') {
      G.childStage = 'school';
      showBanner('🎒 ' + G.childName + ' رو مدرسه ثبت‌نام کردیم + کلاس رباتیک آکادمی نوین‌ذهن! 🤖', 7000);
      addLog('🤖 ' + G.childName + ' تو آکادمی نوین‌ذهن ثبت‌نام شد — هر روز بعد مدرسه میره اونجا.');
    }
    if (G.childStage === 'school') addLog('🎒 ' + G.childName + ' رفت مدرسه و بعدش آکادمی نوین‌ذهن.');
  }
  // 🎪 چالش‌های محله: هر ۳-۴ روز یکی
  if (G.nextChallengeDay == null) G.nextChallengeDay = G.dayIndex + 3;
  if (G.dayIndex >= G.nextChallengeDay && !G.challenge) {
    // ۱۶ مأموریت، دقیقاً هر ۳ روز یکی — از شرط‌دارها رد میشه تا وقتی شرطش جور شه
    let idx = G.challengeIdx || 0, type = null;
    for (let k = 0; k < CH_ORDER.length; k++) {
      const cand = CH_ORDER[(idx + k) % CH_ORDER.length];
      if (typeof questAvailable !== 'function' || questAvailable(cand)) { type = cand; idx = idx + k + 1; break; }
    }
    if (type) {
      G.challengeIdx = idx;
      G.nextChallengeDay = G.dayIndex + 3;
      setTimeout(() => offerChallenge(type), 3000);
    } else G.nextChallengeDay = G.dayIndex + 3;
  }
  if (typeof dailyExpenses === 'function') dailyExpenses();
  if (typeof petDailyTick === 'function') petDailyTick();
  if (typeof applySeasonEffects === 'function') applySeasonEffects();
  if (typeof dailySMS === 'function') dailySMS();
  if (typeof journal === 'function') journal('📅 روز تازه: ' + (typeof seasonOf === 'function' ? seasonOf(G.dayIndex) + '، ' : '') + faMoney(G.money) + ' تو جیبم.');
  const msgs = dailyTick();
  setTimeout(checkChildGrowth, 800);
  msgs.forEach(m => { addNews(m); });
  if (msgs.length) { addLog(msgs[msgs.length-1]); showBanner(msgs[Math.min(1, msgs.length-1)], 4500); }
  window.WORLD?.onNewDay?.();
  updateHUD();
}

// ---------- پنل عمومی ----------
let panelOpen = false;
function openPanel(title, bodyBuilder) {
  panelOpen = true;
  document.exitPointerLock?.();
  $id('panelTitle').textContent = title;
  const body = $id('panelBody');
  body.innerHTML = '';
  bodyBuilder(body);
  $id('panelWrap').classList.add('show');
}
function closePanel() {
  panelOpen = false;
  $id('panelWrap').classList.remove('show');
  $id('panel').style.width = '';           // پنل‌های پهن (مثل سایت آکادمی) برگردن به سایز عادی
}
function priceOf(base) {
  return Math.round(base * (typeof honorPriceFactor === 'function' ? honorPriceFactor() : 1));
}
function actionRow(parent, label, sub, onClick, disabled) {
  const row = document.createElement('div');
  row.className = 'act';
  const info = document.createElement('div');
  const b = document.createElement('b'); b.textContent = label;
  const s = document.createElement('small'); s.textContent = sub || '';
  info.append(b, s);
  const btn = document.createElement('button');
  btn.textContent = 'انجام';
  btn.disabled = !!disabled;
  btn.onclick = () => onClick(row, btn);
  row.append(info, btn);
  parent.appendChild(row);
  return row;
}
function noteP(parent, text) {
  const p = document.createElement('p');
  p.className = 'note'; p.textContent = text;
  parent.appendChild(p);
}

// ---------- شغل ----------
function jobRow(parent, job) {
  // اگه همین‌جا شاغلی: فقط اطلاع بده. اگه جای دیگه شاغلی: اول باید استعفا بدی.
  if (G.job === job.id) {
    actionRow(parent, '✅ ' + job.name, 'شغل فعلیته! هر روز ساعت ۱۰ برو سر کار.', () => {}, true);
    return;
  }
  if (G.job) {
    const cur = JOBS.find(j => j.id === G.job);
    actionRow(parent, job.name, '⛔ الان ' + (cur ? cur.name : 'یه شغل دیگه') + ' هستی — اول از منوی «روابط/شغل» استعفا بده.', () => {
      toast('⛔ دو شغله نمی‌تونی باشی! اول از شغل فعلیت استعفا بده.');
    }, false);
    return;
  }
  const err = canTakeJob(job);
  const salary = jobSalaryToday(job);
  actionRow(parent, job.name, 'حقوق روزانه ~' + faMoney(salary) + ' | ' + fa(job.hours) + ' ساعت کار' + (err ? ' | ⛔ ' + err : ''),
    () => {
      const e2 = canTakeJob(job);
      if (e2) { toast('⛔ ' + e2); return; }
      if (G.job) { toast('⛔ اول از شغل فعلیت استعفا بده!'); return; }
      if (job.capital) addMoney(-job.capital);
      G.job = job.id;
      G.missedWork = 0;
      toast('🧰 استخدام شدی: ' + job.name);
      addLog('🧰 شغل جدید: ' + job.name);
      if (!job.remote) {
        showBanner('👔 رئیس: «هر روز ساعت ۱۰ صبح اینجا باش! دیر بیای از حقوقت کم میشه!»', 6000);
        addLog('👔 قانون کار: هر روز ساعت ۱۰ صبح، سر کار!');
      }
      updateHUD(); closePanel();
    }, G.job === job.id);
}
// ---------- شیفت کاری تعاملی: مشتری میاد، تسک میدیم، انجام میدی! ----------
const WORK_TASKS = {
  barista: [
    ['مشتری: «یه آیس کارامل ماکیاتو، بدون کارامل، بدون شیر، بدون یخ!»', 'دادی بهش یه اسپرسو. گفت «همینو می‌خواستم!» 🤝'],
    ['مشتری: «وای‌فای رمزش چیه؟» — هیچی سفارش نداده!', 'رمزو دادی، یه لبخند گرفتی. اقتصاد کافه همینه!'],
    ['مشتری: «قهوه‌ای بده که بیدارم کنه ولی استرس نده!»', 'یه لاته دادی با یه جمله انگیزشی روی لیوان. گریه کرد! 😢'],
    ['یه نفر سه ساعته با یه اسپرسو نشسته و جلسه آنلاین داره!', 'یه لیوان آب بردی براش. گفت «حقوقمو بریزم برات؟» شوخی بود. نریخت.'],
  ],
  shop: [
    ['مشتری: «رب دارید؟» — قیمتو شنید...', 'گفت «نمی‌خواستم بخرم، فقط پرسیدم!» مش‌قاسم: بازم بیا! 😄'],
    ['پیرمرد اومده پنیر بخره، پول خرد نداره!', 'مش‌قاسم گفت «بنویس پای دفتر» — دفتره پُر شده، جلد دوم زدیم!'],
    ['بچه اومده با ده تومن پفک می‌خواد!', 'بهش گفتی این پول مال ده سال پیشه! گفت «باشه، نسیه بده!» عین باباش!'],
    ['یه خانم اومده جنسو یکی یکی قیمت می‌پرسه و تو گوشی می‌نویسه!', 'معلوم شد از مغازه بغلی اومده قیمتا رو چک کنه! جاسوسی اقتصادی!'],
  ],
  exchange: [
    ['مشتری: «دلار بخرم یا بفروشم؟!»', 'تا خواستی جواب بدی قیمت عوض شد! گفتی «الان دیگه سوال شما هم قیمتش رفته بالا!»'],
    ['یه آقا با کیسه پول نقد اومده، میگه دلار می‌خوام، همه‌شو!', 'شمردی... سه ساعت طول کشید. آخرش گفت «حالا شاید فردا بیام!» 😑'],
    ['مشتری: «چرا قیمت تابلو با سایت فرق داره؟!»', 'گفتی «تابلو آپدیتش دستیه، دلار آپدیتش قلبیه!» خندید و خرید!'],
    ['یه نفر زنگ زده میگه نرخ فردا رو بگو!', 'گفتی «اگه بلد بودم الان اینور میز نبودم!» رئیس تشویقت کرد!'],
  ],
  courier: [
    ['سفارش پیتزا، طبقه پنجم، بدون آسانسور!', 'رسوندی! مشتری گفت «چرا سرد شده؟» — پنج طبقه‌ست داداش! ۵ ستاره داد آخرش.'],
    ['مشتری آدرس داده «کوچه سوم، در آبی» — شیش تا در آبی هست!', 'زنگ زدی، گفت «همونی که خودم جلوشم!» — از پشت تلفن؟!'],
    ['سفارش آبمیوه‌ست، ترافیک قفله!', 'از کوچه پس‌کوچه‌ها رفتی! اصغر بهت افتخار می‌کنه!'],
    ['مشتری سفارشو قبول نمی‌کنه میگه «من چیزی نخواستم»!', 'معلوم شد بچه‌ش با گوشیش سفارش داده! بچه رو صدا زد، کلی خندیدیم!'],
  ],
  dev: 'computer', teacher: [
    ['دانش‌آموز: «آقا اجازه! اینترنت نبود تکلیفو آپلود کنم!»', 'راست می‌گفت! این بهونه دیگه همیشه قبوله! نمره‌شو دادی.'],
    ['وسط کلاس برق رفت!', 'کلاسو با نور گوشی ادامه دادی! بچه‌ها گفتن «کمپ‌فایره!» درسو با قصه تموم کردی.'],
    ['یه دانش‌آموز میگه «درس بخونیم که چی بشیم؟»', 'گفتی «که مثل من معلم شید!» ... مکث کردی... «درستون رو بخونید!»'],
  ],
  cafeowner: [
    ['کارمندت میگه شیر تموم شده، وسط شلوغی!', 'خودت دویدی از سوپری مش‌قاسم شیر خریدی! مدیریت جهادی!'],
    ['مشتری میگه «قیمتا چرا هر هفته عوض میشه؟»', 'منو رو با مداد نوشتی از این به بعد! پاک‌کن هم آماده‌ست!'],
  ],
  taxi: [
    ['مسافر: «دربست! فقط از اتوبان نرو، عجله دارم!»', 'از کوچه‌ها رفتی، زودتر رسیدی! گفت «تو نقشه‌ی زنده‌ای!»'],
    ['مسافر کرایه رو کارت‌به‌کارت زده... رسید نیومده!', 'گفت «تراکنش در انتظاره!» — مثل کل زندگیمون!'],
  ],
  youtuber: 'computer', streamer: 'computer',
};
const GENERIC_TASKS = [
  ['یه مشتری اومده و کلی سوال داره!', 'همه رو جواب دادی! خسته نباشی!'],
  ['همکارت مرخصی گرفته، کار اونم افتاده گردنت!', 'انجامش دادی! رئیس گفت «دمت گرم» — همین! دمت گرم خالی!'],
];

const WORK_START = 10, WORK_LAST = 15;
function doWork() {
  if (!G.job || G.workedToday) return;
  const job = JOBS.find(j => j.id === G.job);
  if (G.energy < 25) { toast('😴 انرژی کافی نداری! اول بخواب یا یه چیزی بخور.'); return; }
  if (job.remote && G.internetDown) { toast('📵 اینترنت قطعه! دورکاری امروز تعطیل.'); return; }
  if (job.needCar && !G.cars.length) { toast('🚗 ماشین لازمه!'); return; }
  if (job.needPhone && (!G.phone || G.phoneBroken)) { toast('📱 گوشی سالم لازمه!'); return; }
  if (!job.remote) {
    if (G.hour < 8) { toast('🕗 هنوز خیلی زوده! مغازه بسته‌ست. شیفت از ساعت ۱۰ شروع میشه.'); return; }
    if (G.hour > WORK_LAST) { toast('🌆 دیگه دیره! رئیس: «فردا ساعت ۱۰، نه یه دقیقه دیرتر!»'); return; }
  }
  // کات‌سین: بریم پشت میز!
  const caption = job.remote
    ? '💻 نشستی پشت سیستمت... چایی هم ریختی. بسم‌الله!'
    : '🧰 رسیدی سر کار و رفتی پشت میز... شیفت شروع شد!';
  playCutscene(caption, 3400, () => {});
  if (window.WORLD?.workCutscene) window.WORLD.workCutscene(job, () => openShift(job));
  else setTimeout(() => openShift(job), 3400);
}

// 🎮 مینی‌گیم شغلی: سفارش/قطعه درست رو انتخاب کن
const JOB_MINIGAME = {
  barista:  { title:'☕ سفارش رو درست کن', prompt:['یه لاتهٔ داغ با شیر بادوم!','اسپرسو دبل بدون شکر!','کاپوچینو با دارچین!','قهوهٔ ترک، هم نزنی‌ها!'],
              opts:['☕ لاته','⚡ اسپرسو دبل','🥛 کاپوچینو','🫖 قهوهٔ ترک'] },
  shop:     { title:'🏪 جنس رو پیدا کن', prompt:['رب گوجه کجاست؟','یه بسته چایی می‌خوام!','شیر کم‌چرب دارید؟','ماکارونی!'],
              opts:['🥫 رب گوجه','🍵 چایی','🥛 شیر','🍝 ماکارونی'] },
  carpenter:{ title:'🪚 ابزار درست رو بردار', prompt:['این پیچ رو محکم کن!','این تخته رو ببر!','این میخ رو بکوب!','اندازه بگیر!'],
              opts:['🪛 پیچ‌گوشتی','🪚 اره','🔨 چکش','📏 متر'] },
  exchange: { title:'💱 نرخ رو بگو', prompt:['دلار امروز چنده؟','یورو می‌خوام!','سکه چنده؟','درهم دارید؟'],
              opts:['💵 دلار','💶 یورو','🪙 سکه','🇦🇪 درهم'] },
  teacher:  { title:'📚 جواب سوال بچه', prompt:['خانم/آقا، پایتخت ایران کجاست؟','۷ ضربدر ۸ چند میشه؟','فعل «رفتن» ماضیش چی میشه؟','آب در چند درجه می‌جوشه؟'],
              opts:['🏙️ تهران','🔢 ۵۶','📖 رفت','🌡️ ۱۰۰'] },
};
function playJobMinigame(job, done) {
  const g = JOB_MINIGAME[job.id];
  if (!g) { done(true); return; }
  const i = Math.floor(Math.random() * g.prompt.length);
  openPanel(g.title, p => {
    noteP(p, '🗣️ مشتری: «' + g.prompt[i] + '»');
    noteP(p, 'سریع انتخاب کن! جواب درست = دستمزد بیشتر.');
    [...g.opts.keys()].sort(() => Math.random() - .5).forEach(k => {
      actionRow(p, g.opts[k], '', () => {
        const ok = k === i;
        if (ok) { toast('✅ درست بود! مشتری راضی رفت.'); G.happy += 3; }
        else { toast('❌ اشتباه شد! مشتری غر زد...'); G.happy -= 2; }
        closePanel(); done(ok);
      });
    });
  });
}

function openShift(job) {
  G.startedShiftAt = G.hour;
  if (!job.remote && G.hour > WORK_START)
    toast('⏰ رئیس ساعتو نگاه کرد... چیزی نگفت. ولی نگاهش همه‌چیو گفت!');
  const spec = WORK_TASKS[job.id] || GENERIC_TASKS;
  let done = 0, gamesPlayed = 0;
  const isComputer = spec === 'computer';
  const tasks = isComputer ? [] : [...spec].sort(() => Math.random() - .5).slice(0, 3);
  // بعضی وقتا یه دختر آشنا (یا غریبه!) میاد سر کارت!
  if (!isComputer && Math.random() < .35) {
    const girls = NPCS.filter(n => n.marriageable && !isUpset(n.id));
    const g = girls[Math.floor(Math.random() * girls.length)];
    if (g) {
      const met = G.met?.[g.id];
      tasks.push([
        met
          ? '☕ ' + g.name + ' اومده تو محل کارت! دست تکون میده و میاد سمتت...'
          : '☕ یه دختر ناشناس اومده تو محل کارت و داره نگات می‌کنه...',
        (() => {
          G.met = G.met || {};
          if (!met) { G.met[g.id] = true; addAffection(g.id, 6); return 'خودشو معرفی کرد: «' + g.name + 'م!» — کلی گپ زدید! شماره‌ها رد و بدل شد! 😍 (+۶ علاقه)'; }
          addAffection(g.id, 5);
          return g.name + ': «داشتم رد می‌شدم گفتم یه سلامی بکنم!» — رئیس اخم کرد ولی می‌ارزید! 😄 (+۵ علاقه)';
        }),
      ]);
    }
  }

  function render() {
    openPanel('🧰 سر کار — ' + job.name, p => {
      if (isComputer) {
        noteP(p, '🖥️ پشت سیستمی... رو مانیتور چیه؟ بازی البته! کار؟ اونم هست... یه جایی همین‌جاها!');
        if (gamesPlayed < 2) {
          actionRow(p, '🎮 یه دست دیگه بازی', '+۳ شادی — کسی نمی‌فهمه!', () => {
            gamesPlayed++; G.happy += 3;
            npcSayShift(p, gamesPlayed === 1 ? 'بردی! ... صدای پا! Alt+Tab! اکسل باز شد! 😅' : 'اینم بردی! دیگه بسه، وجدان درد گرفتی!');
            render();
          });
        }
        actionRow(p, '✅ اعلام کن «کارتون انجام شد!»', 'پایان شیفت و دریافت دستمزد', () => finishShift(job, p));
      } else {
        noteP(p, '👥 مردم میان و میرن... تسک ' + fa(done + 1) + ' از ' + fa(tasks.length) + ':');
        if (done < tasks.length) {
          const [ask, result] = tasks[done];
          noteP(p, '🔔 ' + ask);
          actionRow(p, '⚙️ انجامش بده!', 'ثبت تو سیستم', () => {
            done++;
            npcSayShift(p, typeof result === 'function' ? result() : result);
            updateHUD();
            setTimeout(render, 1400);
          });
        } else {
          noteP(p, '🎉 همه‌ی تسک‌ها انجام شد! چه شیفتی بود!');
          actionRow(p, '💰 پایان شیفت و دریافت دستمزد', '', () => finishShift(job, p));
        }
      }
    });
  }
  function npcSayShift(p, text) {
    const d = document.createElement('p');
    d.className = 'npcSaid';
    d.textContent = text;
    p.prepend(d);
  }
  render();
}
function finishShift(job, p) {
  // 🎮 آخرین کار شیفت: یه مینی‌گیم واقعی
  if (JOB_MINIGAME[job.id] && !G._mgDone) {
    G._mgDone = true;
    playJobMinigame(job, ok => { G.shiftBonus = ok ? 1.25 : .85; finishShift(job, p); });
    return;
  }
  G._mgDone = false;
  let salary = Math.round(jobSalaryToday(job) * (G.shiftBonus || 1));
  G.shiftBonus = 1;
  if (G.trafficJam && !job.remote) salary = Math.round(salary * .85);
  if (!job.remote && G.startedShiftAt > WORK_START) {
    salary = Math.round(salary * .7);
    addLog('⏰ دیر رسیدی سر کار! رئیس آخر روز ۳۰٪ کم کرد: «ساعت ۱۰ یعنی ۱۰!»');
  }
  G.missedWork = 0;
  sfx.money();
  addMoney(salary);
  G.energy -= 25; G.happy -= 3;
  if (G.job === 'taxi' || G.job === 'courier') G.fuel = Math.max(0, G.fuel - 8);
  G.workedToday = true;
  journal('💼 امروز رفتم سر کار (' + job.name.replace(/^\S+\s/, '') + ') و ' + faMoney(salary) + ' گرفتم.');
  advanceTime(job.hours);
  addLog('💼 شیفت تموم شد. دستمزد: ' + faMoney(salary));
  toast('💼 +' + faMoney(salary));
  missionTick('work');
  updateHUD(); closePanel();
}

// ---------- پنل ساختمون‌ها ----------
function openBuilding(id) {
  const b = buildingById(id);
  if (!b) return;
  // تو نسخهٔ سه‌بعدی: صفحه عوض میشه و واقعاً می‌ری داخل
  if (window.WORLD?.enterInterior && !window.WORLD.insideOf?.() && b.kind !== 'open') {
    window.WORLD.enterInterior(id);
    return;
  }
  openShopPanel(id);
}

function openShopPanel(id) {
  const b = buildingById(id);
  if (!b) return;
  if (typeof shopOpenNow === 'function' && !shopOpenNow(id)) { toast(nightNotice(id)); return; }
  openPanel(b.icon + ' ' + b.name, body => buildShopBody(id, body));
}

// محتوای هر مغازه (هم برای پنل دوبعدی، هم برای حباب سه‌بعدی)
function buildShopBody(id, body) {
  ((body) => {
    switch (id) {
      case 'home': openHome(); break;
      case 'realty': panelRealty(body); break;
      case 'market': panelMarket(body); break;
      case 'bakery': panelBakery(body); break;
      case 'cafe': panelCafe(body); break;
      case 'restaurant': panelRestaurant(body); break;
      case 'university': panelUniversity(body); break;
      case 'bank': panelBank(body); break;
      case 'hospital': panelHospital(body); break;
      case 'mobile': panelMobile(body); break;
      case 'clothes': panelClothes(body); break;
      case 'dealership': panelDealership(body); break;
      case 'repair': panelRepair(body); break;
      case 'gym': panelGym(body); break;
      case 'park': panelPark(body); break;
      case 'airport': panelAirport(body); break;
      case 'terminal': panelTerminal(body); break;
      case 'apartment1': panelApartment(body); break;
      case 'flower': panelFlower(body); break;
      case 'book': panelBook(body); break;
      case 'pastry': panelPastry(body); break;
      case 'juice': panelJuice(body); break;
      case 'gamenet': panelGamenet(body); break;
      case 'salon': panelSalon(body); break;
      case 'mosque': panelMosque(body); break;
      case 'robotics': panelRobotics(body); break;
      case 'dairy': panelDairy(body); break;
      case 'mansion': panelMansion(body); break;
      case 'policeStation': panelPolice(body); break;
      case 'butcher': panelButcher(body); break;
    }
  })(body);
}

// ---------- گزارش پلاک: سه گزینه، فقط یکیش درسته ----------
function plateChoices(real) {
  // دو پلاک قلابی شبیه به واقعی بساز
  const mutate = s => s.replace(/[۰-۹]/g, d => Math.random() < .45 ? '۰۱۲۳۴۵۶۷۸۹'[Math.floor(Math.random() * 10)] : d);
  let a = mutate(real), b = mutate(real);
  while (a === real) a = mutate(real);
  while (b === real || b === a) b = mutate(real);
  const arr = [real, a, b];
  // بر زدن
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  return arr;
}
function resolveHitReport(chosen, sayFn) {
  const correct = G.lastHitPlate && chosen === G.lastHitPlate.plate;
  G.lastHitPlate = null;
  if (correct) {
    addMoney(4000000); G.happy += 10;
    const line = 'بررسی کردیم... درسته! راننده‌ش رو آوردیم کلانتری، کلی عذرخواهی کرد و خسارتت رو نقد داد: ۴ میلیون تومن! ⚖️';
    sayFn ? sayFn(line, 'happy') : toast('👮 ' + line);
    addLog('⚖️ راننده خاطی پیدا شد و خسارت داد: ۴٬۰۰۰٬۰۰۰ تومن');
  } else {
    addMoney(-1500000); G.happy -= 5;
    G.honor = Math.max(0, (G.honor ?? 50) - 5);
    const line = 'بررسی کردیم... این پلاک مال حاج‌آقا کریمیه که اون ساعت مسجد بوده! گزارش خلاف واقع جریمه داره: یک و نیم میلیون! دفعه بعد دقت کن! 😠';
    sayFn ? sayFn(line, 'angry') : toast('👮 ' + line);
    addLog('⚖️ پلاک رو اشتباه گفتی؛ ۱٬۵۰۰٬۰۰۰ تومن جریمهٔ گزارش خلاف واقع!');
  }
  updateHUD();
}

// ---------- شکایت رسمی از اهالی: پلیس رسیدگی می‌کنه، شاید حق با تو نباشه! ----------
function fileComplaint(npc) {
  G.complaints = G.complaints || {};
  if (G.complaints[npc.id] === G.dayIndex) { toast('👮 «امروز یه بار ازش شکایت کردی! پرونده‌سازی نکن!»'); return; }
  G.complaints[npc.id] = G.dayIndex;
  const name = npc.name.split(' (')[0];
  const aff = getAffection(npc.id);
  if (aff >= 50) {
    toast('👮 «' + name + '؟! ایشون که از دوستای صمیمیته! برید یه چایی بخورید حلش کنید. پروندت رو بستم!» (-۳ علاقه)');
    addAffection(npc.id, -3);
  } else if (Math.random() < .35 + ((G.honor ?? 50) / 100) * .3) {   // شرافت بالا = حرفت بیشتر خریدار داره
    addMoney(2000000); G.happy += 8;
    toast('⚖️ افسر: «رسیدگی کردیم — حق با تو بود! ' + name + ' اومد عذرخواهی کرد و ۲ میلیون رضایت داد.»');
    addLog('⚖️ شکایتت از ' + name + ' به نتیجه رسید؛ حق با تو بود!');
  } else {
    addMoney(-1000000); G.happy -= 5;
    G.honor = Math.max(0, (G.honor ?? 50) - 4);
    addAffection(npc.id, -5);
    toast('⚖️ افسر: «رسیدگی کردیم — حق با ' + name + ' بود! شکایت بی‌مورد یه میلیون جریمه داره. برو دلشو به دست بیار!»');
    addLog('⚖️ شکایتت از ' + name + ' رد شد؛ جریمه شدی!');
  }
  updateHUD();
}

function panelButcher(p) {
  noteP(p, '🥩 اصغرآقا با سبیل چخماقی‌ش ساطور رو تیز می‌کنه: «به‌به! چی بکشم برات جوون؟»');
  const price = c => faMoney(Math.round(c * G.eco.housingCoef));
  actionRow(p, '🥩 یه کیلو گوشت گوسفندی', price(9000000) + ' | +۲۰ سلامتی +۱۰ انرژی', () => {
    const c = Math.round(9000000 * G.eco.housingCoef);
    if (G.money < c) { toast('💸 اصغرآقا: «گوشت شده کیمیا جوون! برو ماهیچه بگیر... اونم نه!»'); return; }
    addMoney(-c); G.health += 20; G.energy += 10;
    toast('🥩 آبگوشت امشب به راهه!'); bagAdd('meat'); updateHUD();
  });
  actionRow(p, '🍗 مرغ کامل', price(3500000) + ' | +۱۲ سلامتی +۸ انرژی', () => {
    const c = Math.round(3500000 * G.eco.housingCoef);
    if (G.money < c) { toast('💸 پول کم داری!'); return; }
    addMoney(-c); G.health += 12; G.energy += 8;
    toast('🍗 مرغش تازه‌ست!'); updateHUD();
  });
  actionRow(p, '🌭 کالباس و سوسیس', price(1800000) + ' | +۶ انرژی +۵ شادی', () => {
    const c = Math.round(1800000 * G.eco.housingCoef);
    if (G.money < c) { toast('💸 پول کم داری!'); return; }
    addMoney(-c); G.energy += 6; G.happy += 5;
    toast('🌭 اصغرآقا: «اینم از ساندویچ شبت!»'); updateHUD();
  });
}

function panelPolice(p) {
  noteP(p, '👮 افسر نگهبان: «سلام شهروند عزیز! کلانتری محله در خدمتته. چه کمکی از دستم برمیاد؟»');
  // — گزارش تصادف با آزمون پلاک
  if (G.lastHitPlate) {
    const h = document.createElement('h4'); h.textContent = '🚨 گزارش تصادف — پلاکش کدوم بود؟ (غلط بگی جریمه میشی!)'; p.appendChild(h);
    plateChoices(G.lastHitPlate.plate).forEach(pl => {
      actionRow(p, '🚗 پلاک: ' + pl, '', () => { resolveHitReport(pl); closePanel(); });
    });
  } else {
    actionRow(p, '🚨 گزارش تصادف', 'فعلاً پلاکی تو ذهنت نیست', () => {
      toast('👮 «اگه ماشینی بهت زد، پلاکشو خوب نگاه کن و بیا اینجا. حافظه‌ت رو محک می‌زنیم!»');
    });
  }
  // — شکایت رسمی از اهالی
  const known = NPCS.filter(n => !n.kid && !n.officer && G.met?.[n.id]);
  if (known.length) {
    const h2 = document.createElement('h4'); h2.textContent = '⚖️ شکایت رسمی از اهالی — پلیس رسیدگی می‌کنه؛ شاید حق با تو نباشه!'; p.appendChild(h2);
    known.slice(0, 8).forEach(n => {
      actionRow(p, '⚖️ شکایت از ' + n.name.split(' (')[0], n.job, () => { fileComplaint(n); closePanel(); });
    });
  } else {
    noteP(p, '⚖️ برای شکایت اول باید کسی رو بشناسی! برو با اهالی آشنا شو (بعد بیا شکایت کن! 😄)');
  }
  // — گپ با افسر نگهبان
  const CHIT = [
    '👮 «دیشب گشت بودم، فقط یه گربه از چراغ قرمز رد شد. جریمه‌ش نکردم، قسمش دادم!»',
    '👮 «مهم‌ترین پروندهٔ این ماه؟ دوچرخهٔ گمشدهٔ هومن! پیداش کردیم، پشت نونوایی بود!»',
    '👮 «ملوک‌خانم هفته‌ای سه بار میاد گزارش میده. نصفش شایعه‌ست ولی خب... اطلاعاتش دقیقه!»',
    '👮 «آرزوم یه محله‌ست که توش فقط پروندهٔ کیک‌های گمشدهٔ قنادی باشه!»',
    '👮 «این سلول رو می‌بینی؟ سه ساله خالیه. افتخار محله همینه!»',
  ];
  actionRow(p, '💬 گپ با افسر نگهبان', 'قصه‌های کلانتری', () => { G.happy += 2; toast(CHIT[Math.floor(Math.random() * CHIT.length)]); updateHUD(); });
  actionRow(p, '🙏 «خسته نباشید»', '+۳ شادی', () => { G.happy += 3; toast('👮 «زنده باشی! مردم خوب، پلیس خوشحال!»'); updateHUD(); });
  actionRow(p, '❓ «محله امنه؟»', '', () => toast('👮 «امن‌ترین محلهٔ تهرونه! فقط حواست به ماشینای تندرو باشه.»'));
}

// ---------- مأموریت‌های روزانه ----------
const MISSION_POOL = [
  { id:'chat',   text:'💬 با ۲ نفر از اهالی گپ بزن', need:2 },
  { id:'coffee', text:'☕ یه چیزی از کافه تورم سفارش بده', need:1 },
  { id:'bread',  text:'🍞 از نانوایی نون تازه بگیر', need:1 },
  { id:'gym',    text:'💪 یه تمرین تو باشگاه انجام بده', need:1 },
  { id:'work',   text:'🧰 برو سر کار و شیفتت رو بزن', need:1 },
  { id:'park',   text:'🌳 یه سر به پارک محله بزن', need:1 },
  { id:'gift',   text:'🌹 به یه نفر گل هدیه بده', need:1 },
  { id:'memory', text:'🧠 یه خاطره از یکی از اهالی بشنو', need:1 },
];
const MISSION_REWARD = 1500000;
// ترتیب چرخشی ۱۶ مأموریت محله (هر ۳ روز یکی)
const CH_ORDER = ['race', 'purse', 'lostkid', 'fire', 'paintball', 'ring', 'cat', 'moving',
                  'medicine', 'delivery', 'thief', 'carrace', 'festival', 'dog', 'power', 'robotics'];
function ensureMissions() {
  if (G.missions && G.missions.day === G.dayIndex) return;
  // انتخاب ۳ مأموریت متفاوت بر اساس روز
  const pool = [...MISSION_POOL];
  const picks = [];
  let seed = G.dayIndex * 37 + 11;
  for (let i = 0; i < 3; i++) {
    seed = (seed * 9301 + 49297) % 233280;
    picks.push(pool.splice(seed % pool.length, 1)[0]);
  }
  const list = picks.map(m => ({ id: m.id, text: m.text, need: m.need, got: 0, done: false }));
  if (G.childStage === 'infant')
    list[0] = { id: 'baby', text: '🍼 صبح برای ' + G.childName + ' شیرخشک و پوشک از سوپرمارکت بگیر', need: 1, got: 0, done: false };
  G.missions = { day: G.dayIndex, list, bonus: false };
}
function missionTick(type) {
  if (!gameStarted) return;
  ensureMissions();
  const m = G.missions.list.find(x => x.id === type && !x.done);
  if (!m) return;
  m.got++;
  if (m.got >= m.need) {
    m.done = true;
    addMoney(MISSION_REWARD); G.happy += 5;
    sfx.money();
    toast('📋 مأموریت انجام شد: ' + m.text + ' | +' + faMoney(MISSION_REWARD));
    addLog('📋 ' + m.text + ' ✅');
    if (G.missions.list.every(x => x.done) && !G.missions.bonus) {
      G.missions.bonus = true;
      addHonor(5);
      setTimeout(() => toast('🏆 هر سه مأموریت امروز تموم شد! +۵ شرافت'), 2200);
    }
  } else toast('📋 ' + m.text + ' (' + fa(m.got) + '/' + fa(m.need) + ')');
  updateHUD();
}
function openMissions() {
  mergeQuests();
  G._tutMission = true;
  ensureMissions();
  openPanel('📋 مأموریت‌های امروز', p => {
    noteP(p, 'هر مأموریت ' + faMoney(MISSION_REWARD) + ' جایزه داره؛ هر سه‌تا = ۵+ شرافت!');
    // 📅 تقویم چالش‌های محله
    const nextType = CH_ORDER[(G.challengeIdx || 0) % CH_ORDER.length];
    const nb = CH_BADGES[nextType];
    const left = Math.max(0, (G.nextChallengeDay ?? G.dayIndex + 3) - G.dayIndex);
    const h = document.createElement('h4'); h.textContent = '🎪 چالش بعدی محله'; p.appendChild(h);
    actionRow(p, nb.icon + ' ' + nb.name,
      G.challenge ? '🔴 همین الان در جریانه!' : left === 0 ? '📣 امروز! منتظر باش سراغت میان' : '📅 ' + fa(left) + ' روز دیگه (روز ' + fa(G.nextChallengeDay) + ')',
      () => {}, true);
    const done = Object.keys(G.badges || {}).length;
    noteP(p, '🏅 نشان‌های گرفته‌شده: ' + fa(done) + ' از ' + fa(Object.keys(CH_BADGES).length) + ' — چالش‌ها هر ۳ تا ۴ روز یک‌بار میان.');
    const h2 = document.createElement('h4'); h2.textContent = '📋 کارهای امروز'; p.appendChild(h2);
    G.missions.list.forEach(m => {
      actionRow(p, (m.done ? '✅ ' : '⬜ ') + m.text,
        m.done ? 'انجام شد!' : (m.need > 1 ? fa(m.got) + ' از ' + fa(m.need) : 'در انتظار...'),
        () => {}, true);
    });
  });
}

// ---------- 🎪 چالش‌ها: شروع و پایان با دیالوگ + نشان (Badge) ----------
const CH_BADGES = {
  race:      { icon: '🏃', name: 'قهرمان دوِ محله',    desc: 'مسابقهٔ دور کمربندی رو بردی' },
  purse:     { icon: '👜', name: 'ناجی کیف',           desc: 'کیف ملوک‌خانم رو از کیف‌قاپ پس گرفتی' },
  lostkid:   { icon: '🧒', name: 'قهرمان هومن',        desc: 'هومنِ گم‌شده رو پیدا کردی' },
  paintball: { icon: '🎨', name: 'هفت‌تیرکشِ رنگی',    desc: 'هر سه دزد رو با پینت‌بال رنگی کردی' },
  cat:       { icon: '🐱', name: 'ناجی پشمک',          desc: 'گربهٔ ننه‌قمر رو از درخت آوردی پایین' },
  delivery:  { icon: '🍕', name: 'پیک برق‌آسا',        desc: 'هر سه سفارش اصغر رو به‌موقع رسوندی' },
};
// ۱۰ مأموریت جدید به سیستم اضافه میشن (تنبل — چون rp-quests بعد از ui لود میشه)
function mergeQuests() {
  if (typeof QUEST_BADGES !== 'undefined' && !CH_BADGES.fire) {
    Object.assign(CH_BADGES, QUEST_BADGES);
    Object.assign(CH_INTRO, QUEST_INTRO);
    Object.assign(CH_DONE, QUEST_DONE);
  }
}
const HOOMAN_MOM = { id: 'hooman_mom', name: 'مامانِ هومن', job: 'همسایه', color: 0xc06c84, gender: 'f', look: { style: 'scarf', accColor: 0x8d5a97 } };
function challengeGiver(type) {
  const map = { race: 'akbar', purse: 'fezzeh', paintball: 'police', cat: 'ghamar', delivery: 'asghar' };
  if (typeof QUEST_GIVER !== 'undefined' && QUEST_GIVER[type]) {
    const g = NPCS.find(n => n.id === QUEST_GIVER[type]);
    if (g) return g;
  }
  return type === 'lostkid' ? HOOMAN_MOM : NPCS.find(n => n.id === map[type]);
}
const CH_INTRO = {
  race:      'پهلوون! مسابقهٔ سالانهٔ دوِ محله همین الانه! چهار گوشهٔ کمربندی رو به ترتیب رد کن. جایزه‌ش ۵ میلیونه! هستی؟',
  purse:     'آاای جوون!! همین الان یه دزد کیفمو قاپید و در رفت!! کل زندگیم تو اون کیفه! می‌دویی بگیریش؟!',
  lostkid:   'تو رو خدا کمکم کن... هومنم از مدرسه برنگشته! هیچ‌جا نیست! از اهالی بپرس، یکی حتماً دیدتش...',
  paintball: 'خدا رو شکر پیدات کردم! سه نفر از طلافروشی دزدی کردن و دارن فرار می‌کنن. این تفنگ پینت‌بال — رنگیشون کن تا تو شلوغی گمشون نکنیم. کمک می‌کنی؟',
  cat:       'مادر! پشمکم رفته بالای درخت، میو میو می‌کنه دلم ریش شد! تو جوونی، می‌پری میاریش پایین؟ یه قابلمه آش مهمون من!',
  delivery:  'داداش موتورم ریخت به هم، سه تا سفارش رو دستم مونده! تو برسونشون، انعامش مال خودت! هستی؟',
};
const CH_DONE = {
  race:      ['ایوَل پهلوون! اول شدی! این ۵ میلیون حلالت — از امروز اسمت رو تابلوی باشگاهه!', 'دیر رسیدی ولی مهم اینه که دوییدی! بیا باشگاه تمرین کن، سال دیگه مال توئه!'],
  purse:     ['الهی خیر ببینی مادر!! کیفم برگشت! همه‌جا تعریفتو می‌کنم — از امروز تو نوهٔ خودمی!', 'در رفت؟ عیب نداره مادر، تو تلاشتو کردی... خدا ازش نگذره!'],
  lostkid:   ['پیداش کردی!! الهی قربونت برم! تا عمر دارم دعات می‌کنم... هومن! دیگه بی‌خبر جایی نرو!', 'هنوز پیداش نکردی؟... باشه، من به گشتن ادامه می‌دم.'],
  paintball: ['هر سه‌شون دستگیر شدن! تحویل قانون داده شدن و اموال مردم برگشت. محله بهت افتخار می‌کنه شهروند نمونه!', 'فرار کردن ولی پلاکاشون رو داریم. ممنون که کمک کردی — این نصف پاداشه.'],
  cat:       ['پشمکم برگشت! بیا مادر، این آش داغ نوش جونت. دستت درد نکنه!', 'نشد؟ عیب نداره مادر، خودش گشنه‌ش بشه میاد پایین!'],
  delivery:  ['همه رو گرم رسوندی؟! تو از من پیک‌تری داداش! این انعام‌ها مال خودت!', 'سرد شد؟ فدای سرت، منم روز اولم همین بود!'],
};
// پیشنهاد چالش: با دیالوگ شروع میشه — قبول یا رد با خودته
function offerChallenge(type) {
  mergeQuests();
  if (G.challenge || !gameStarted || G.traveling) return;
  if (typeof dialogueOpen !== 'undefined' && dialogueOpen) { setTimeout(() => offerChallenge(type), 8000); return; }
  const giver = challengeGiver(type);
  sfx.alert();
  const declinedBefore = G.challengeDeclined === type;
  talkOpen(giver, t => {
    t.group('🎪 چالش جدید: ' + CH_BADGES[type].icon + ' ' + CH_BADGES[type].name);
    if (declinedBefore) {
      G.challengeDeclined = null;
      t.say('جوون! دیروز که قبول نکردی، امروز دیگه قبول کن! ' + CH_INTRO[type], 'idle');
    } else
      t.say(CH_INTRO[type], type === 'purse' || type === 'lostkid' ? 'sad' : 'happy');
    t.option('✅ «قبوله! بزن بریم!»', 'شروع چالش', () => {
      closeTalk();
      window.WORLD?.challengeStart?.(type);
    });
    t.option('❌ «الان نمی‌تونم، شرمنده»', 'فردا دوباره می‌پرسه', () => {
      t.say('باشه... پس فردا دوباره سراغتو می‌گیرم!', 'idle');
      G.challengeIdx = Math.max(0, (G.challengeIdx || 1) - 1);
      G.nextChallengeDay = G.dayIndex + 1;
      G.challengeDeclined = type;
      setTimeout(closeTalk, 1800);
    });
  });
}
// پایان چالش: دیالوگ اختتامیه + نشان
function challengeEndDialog(type, ok) {
  mergeQuests();
  const giver = challengeGiver(type);
  const line = CH_DONE[type][ok ? 0 : 1];
  talkOpen(giver, t => {
    t.say(line, ok ? 'happy' : 'sad');
    if (ok) {
      t.group('✅ چالش «' + CH_BADGES[type].name + '» با موفقیت انجام شد!');
      G.badges = G.badges || {};
      if (!G.badges[type]) {
        G.badges[type] = { day: G.dayIndex, gen: G.generation || 1 };
        setTimeout(() => {
          sfx.party();
          toast('🏅 نشان جدید گرفتی: ' + CH_BADGES[type].icon + ' «' + CH_BADGES[type].name + '» — تو بخش نشان‌ها ببینش!');
        }, 900);
      }
      t.option('🏅 دیدن نشان‌هام', '', () => { closeTalk(); openBadges(); });
    } else {
      t.group('❌ این بار نشد — چالش دوباره برمی‌گرده!');
    }
  });
}
window.challengeEndDialog = challengeEndDialog;
// جایزهٔ مأموریت‌های جدید
function questReward(type) {
  mergeQuests();
  const rw = (typeof QUEST_REWARD !== 'undefined' && QUEST_REWARD[type]) || null;
  if (!rw) return;
  if (rw.money) addMoney(rw.money);
  if (rw.honor) addHonor(rw.honor);
  if (rw.happy) G.happy += rw.happy;
  if (rw.item && typeof bagAdd === 'function') bagAdd(rw.item);
  journal('🎪 مأموریت «' + (CH_BADGES[type]?.name || type) + '» رو تموم کردم.');
  updateHUD();
}
window.questReward = questReward;
// پنل نشان‌ها
function openBadges() {
  mergeQuests();
  openPanel('🏅 نشان‌های افتخار', p => {
    const earned = Object.keys(G.badges || {}).length;
    noteP(p, 'با انجام موفق چالش‌های محله نشان بگیر! (' + fa(earned) + ' از ' + fa(Object.keys(CH_BADGES).length) + ')');
    Object.entries(CH_BADGES).forEach(([k, b]) => {
      const got = G.badges?.[k];
      actionRow(p, (got ? b.icon : '🔒') + ' ' + b.name,
        got ? '✅ ' + b.desc + ' — روز ' + fa(got.day) + (got.gen > 1 ? ' (نسل ' + fa(got.gen) + ')' : '') : '🔒 ' + b.desc,
        () => {}, true);
    });
  });
}

// ---------- شرافت (Honor): کار خوب بالا می‌بردش، کار بد پایین ----------
function addHonor(n) {
  G.honor = Math.max(0, Math.min(100, (G.honor ?? 50) + n));
  if (n > 0) toast('⭐ شرافتت رفت بالا! (+' + fa(n) + ')');
  else toast('😈 شرافتت لکه‌دار شد! (' + fa(n) + ') — ملوک‌خانم تا شب خبرش می‌کنه!');
  updateHUD();
}

// ---------- کیف پول پیداشده: امتحان وجدان! ----------
function openWalletChoice() {
  const cash = 2000000 + Math.floor(Math.random() * 4) * 1000000;
  openPanel('👛 کیف پول پیدا کردی!', p => {
    noteP(p, 'یه کیف پول رو زمین افتاده! توش ' + faMoney(cash) + ' نقده با یه کارت ملی. چیکار می‌کنی؟');
    actionRow(p, '😇 «می‌برمش کلانتری»', '+۱۰ شرافت | شاید مژدگانی هم بدن', () => {
      addHonor(10);
      if (Math.random() < .5) { addMoney(1000000); toast('🎁 صاحبش پیدا شد و یه میلیون مژدگانی داد! دعات هم کرد!'); }
      else toast('👮 افسر: «آفرین شهروند نمونه! اسمت رفت تو لیست افتخار کلانتری.»');
      addLog('😇 کیف پول رو تحویل کلانتری دادی.');
      G.happy += 5; updateHUD(); closePanel();
    });
    actionRow(p, '😈 «می‌ذارمش تو جیبم!»', '+' + faMoney(cash) + ' | -۱۵ شرافت', () => {
      addMoney(cash); addHonor(-15);
      addLog('😈 کیف پول مردم رو برداشتی... ' + faMoney(cash));
      if (Math.random() < .3) setTimeout(() => toast('👀 حس می‌کنی یکی دیدت... ملوک‌خانم بود؟!'), 2500);
      updateHUD(); closePanel();
    });
    actionRow(p, '🚶 «به من چه! رد میشم»', 'نه ثواب نه گناه', () => { toast('🚶 رد شدی. شاید یکی دیگه پیداش کنه.'); closePanel(); });
  });
}

// ---------- 🛠 منوی گاد مود ----------
function openGodMenu() {
  openPanel('🛠 گاد مود', p => {
    noteP(p, 'ابزارهای سازنده — هر وقت «god mode» رو تو کنسول بزنی همین باز میشه.');
    actionRow(p, (G._godLive ? '🔴 ضبط درجا: روشن' : '⚫ ضبط درجا: خاموش'),
      'با هر کی حرف بزنی، نوار ضبط همون جمله میاد بالا', () => {
        if (typeof godLiveToggle === 'function') godLiveToggle();
        closePanel(); openGodMenu();
      });
    actionRow(p, '🎙️ استودیوی صداگذاری', 'همهٔ جمله‌های هر شخصیت — تک‌تک ضبط کن', () => {
      closePanel();
      if (typeof openVoiceStudio === 'function') openVoiceStudio(null);
      else toast('⚠️ ماژول صدا لود نشده.');
    });
    actionRow(p, '🏗️ ادیتور دنیا (جابه‌جایی/چرخش)', 'ساختمون، آدم، وسیله، خیابون', () => {
      closePanel();
      if (window.WORLD?.godToggle) window.WORLD.godToggle();
      else toast('🛠 ادیتور فقط تو حالت سه‌بعدی کار می‌کنه!');
    });
    actionRow(p, '💰 پول بی‌نهایت', '', () => {
      G.money = 999999999999; toast('💰 پولت بی‌نهایت شد!'); updateHUD(); closePanel();
    });
    actionRow(p, '⚡ انرژی و سلامتی کامل', '', () => {
      G.energy = 100; G.health = 100; G.happy = 100; toast('⚡ فول شدی!'); updateHUD();
    });
    actionRow(p, '⏭️ رفتن به روز بعد', 'یه روز جلو', () => {
      G.hour = 7; runDailyTick(); toast('⏭️ روز ' + fa(G.dayIndex)); updateHUD();
    });
    actionRow(p, '🎪 اجرای فوری یه مأموریت', 'مأموریت بعدی رو همین الان بیار', () => {
      mergeQuests();
      const t2 = CH_ORDER[(G.challengeIdx || 0) % CH_ORDER.length];
      closePanel(); offerChallenge(t2);
    });
    actionRow(p, '❤️ علاقهٔ همه ۱۰۰', 'برای تست دیالوگ‌ها', () => {
      NPCS.forEach(n => { G.met = G.met || {}; G.met[n.id] = true; G.affection[n.id] = 100; });
      toast('❤️ همه عاشقتن!'); updateHUD();
    });
    actionRow(p, '🗣️ وضعیت صدا', '', () => { closePanel(); openVoiceHelp(); });
    actionRow(p, '📊 اطلاعات فنی', 'FPS و تعداد اشیا', () => {
      const info = window.WORLD?.perfInfo?.();
      toast(info ? '📊 ' + info : 'اطلاعاتی نیست');
    });
  });
}

// ---------- کد تقلب: رمز درست بزنی، پول بی‌نهایت! ----------
const CHEAT_CODES = ['OSTAD NAZARI IS THE GOAT', 'HESOOYAM'];
function openCheatPanel() {
  openPanel('🎁 کد تقلب', p => {
    noteP(p, 'رمز مخفی رو بنویس... اگه بلدی! 😏');
    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'کد تقلب...';
    input.dir = 'ltr';
    input.style.cssText = 'width:100%;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,209,102,.4);background:rgba(255,255,255,.08);color:#fff;font-size:14px;font-family:inherit;outline:none;margin-bottom:10px;text-align:center';
    p.appendChild(input);
    const apply = () => {
      const code = input.value.trim().toUpperCase();
      if (!code) return;
      if (code === 'GODMODE' || code === 'GOD MODE') {
        closePanel();
        openGodMenu();
        return;
      }
      if (CHEAT_CODES.includes(code)) {
        G.money = 999999999999;           // پول بی‌نهایت!
        G.happy = 100;
        toast('💰🎉 کد درست بود! پولت بی‌نهایت شد — دیگه تورم هم حریفت نیست!');
        addLog('🎁 کد تقلب فعال شد: پول بی‌نهایت!');
        updateHUD(); closePanel();
      } else {
        input.value = '';
        toast('❌ کد غلطه!');
      }
    };
    input.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') apply(); });
    input.addEventListener('keyup', e => e.stopPropagation());
    actionRow(p, '✅ اعمال کد', '', apply);
    setTimeout(() => input.focus(), 100);
  });
}

// ---------- سایت آکادمی نوین‌ذهن: نمایش زندهٔ NOVINZEHN.COM پای کامپیوتر ----------
function openNovinzehnSite() {
  openPanel('🖥️ NOVINZEHN.COM', p => {
    p.closest('#panel').style.width = 'min(760px, 94vw)';
    noteP(p, '🤖 سایت رسمی آکادمی رباتیک نوین‌ذهن — همین‌جا زنده ببینش:');
    const frame = document.createElement('iframe');
    frame.src = 'https://novinzehn.com';
    frame.style.cssText = 'width:100%;height:min(48vh,420px);border:1px solid rgba(176,140,255,.4);border-radius:10px;background:#fff';
    frame.setAttribute('loading', 'lazy');
    p.appendChild(frame);
    // اگه سایت اجازهٔ نمایش تو قاب نده، این پیام زیرش هست
    const alt = document.createElement('p');
    alt.className = 'note';
    alt.textContent = 'اگه صفحه بالا خالی موند، سایت اجازهٔ نمایش داخل بازی رو نداده — با دکمهٔ زیر تو تب جدید بازش کن.';
    p.appendChild(alt);
    actionRow(p, '🌐 باز کردن سایت در تب جدید', 'novinzehn.com', () => window.open('https://novinzehn.com', '_blank'));
  });
}

// بخش‌های داخل مغازه (استند کلاه، قفسه کفش، ...) — جلوی هر کدوم فقط همون رو می‌خری
function openBuySpot(spot) {
  const b = buildingById(window.WORLD?.insideOf?.());
  const keeper = b && shopkeeperOf(b.id);
  const seller = keeper || {
    id: 'clerk_' + (b?.id || 'shop'), name: b ? 'فروشندهٔ ' + b.name : 'فروشنده', job: 'فروشنده',
    color: 0x8a6540, look: CLERK_LOOKS,
  };
  talkOpen(seller, t => {
    t.say(spot.say || 'اینا رو داریم، کدومو می‌خوای؟', 'happy');
    (spot.goods || []).forEach(g => t.option(g.label, typeof g.sub === 'function' ? g.sub() : g.sub, () => {
      g.buy();
      t.say(['مبارکِ تنت!', 'قشنگ‌ترینش رو برداشتی!', 'به سلامتی بپوشی!', 'چشم همه رو درمیاری!'][Math.floor(Math.random() * 4)], 'happy');
      t.refresh();      // قیمت‌ها (مثل دست لباس) به‌روز شن
    }));
  });
}

// ---------- دخل سه‌بعدی: به‌جای پنل متنی، فروشنده با حباب حرف سفارش می‌گیره (سبک د سیمز) ----------
const CLERK_LOOKS = { style: 'hair', hair: 0x3a2a1a };
function openCounterTalk(b) {
  const keeper = shopkeeperOf(b.id);
  const seller = keeper || {
    id: 'clerk_' + b.id, name: 'فروشندهٔ ' + b.name, job: 'فروشنده',
    color: 0x8a6540, look: CLERK_LOOKS,
  };
  // پنل رو تو حافظه بساز و ردیف‌هاش رو تبدیل کن به گزینه‌های زیر حباب
  talkOpen(seller, t => {
    const tmp = document.createElement('div');
    buildShopBody(b.id, tmp);
    const note = tmp.querySelector('p.note');
    t.say(keeper?.greet || note?.textContent || ('سلام! خوش اومدی به ' + b.name + '. چی میل داری؟'), 'happy');
    tmp.querySelectorAll('.act').forEach(row => {
      const label = row.querySelector('b')?.textContent || 'گزینه';
      const sub = row.querySelector('small')?.textContent || '';
      const btn = row.querySelector('button');
      t.option(label, sub, () => {
        btn?.click();
        t.say(['قربونت! نوش جونت!', 'اینم از این! چیز دیگه‌ای نمی‌خوای؟', 'به روی چشم!', 'قابل نداره... ولی حسابش کن!'][Math.floor(Math.random() * 4)], 'happy');
        t.refresh();      // گزینه‌ها به‌روز شن (مثلاً بعد استخدام، دکمهٔ استخدام بمونه غلطه)
      }, btn?.disabled);
    });
    if (keeper) t.option('💬 گپ و احوال‌پرسی', 'حرف‌های خودش', () => openNPC(keeper, { inside: true, noWalk: true }));
  });
}

function panelMosque(p) {
  noteP(p, '🕌 فضای آروم و خنک... بوی فرش و گلاب. حاج‌آقا با لبخند سلام می‌کنه.');
  actionRow(p, '🤲 نماز و نیایش', 'رایگان | +۱۵ شادی، آرامش دل', () => {
    G.happy += 15; advanceTime(1);
    toast('🕌 دلت سبک شد... آرامش واقعی تو این شهر شلوغ!'); updateHUD();
  });
  actionRow(p, '💝 کمک به صندوق خیریه محله', faMoney(2000000) + ' | +۱۰ شادی +۴ شرافت', () => {
    if (G.money < 2000000) { toast('💸 هر وقت داشتی... نیت هم ثوابه!'); return; }
    addMoney(-2000000); G.happy += 10;
    addHonor(4);
    toast('💝 حاج‌آقا: «خیر ببینی جوون! عاقبت‌بخیر شی!»'); updateHUD();
  });
}
function panelRobotics(p) {
  noteP(p, '🤖 تابلوی نئونی «نوین‌ذهن» می‌درخشه — مغز بنفش‌طلایی با «ن» وسطش. داخل پر از ربات و بچه‌های باهوش!');
  G.robotics = G.robotics || 0;
  const fee = Math.round(20000000 * dailyInflationFactor() ** G.dayIndex);
  actionRow(p, '🎓 دوره رباتیک (' + fa(G.robotics) + ' از ۲)', faMoney(fee) + ' | ۲ دوره = مهارت تخصصی، حقوق برنامه‌نویسی ×۱.۵', () => {
    if (G.robotics >= 2) { toast('🤖 مدرک پیشرفته داری! رباتا بهت سلام نظامی میدن!'); return; }
    if (G.money < fee) { toast('💸 شهریه آکادمی! رباتیک ارزون نیست!'); return; }
    if (G.energy < 25) { toast('😴 با این انرژی لحیم‌کاری خطرناکه!'); return; }
    addMoney(-fee); G.energy -= 15; G.robotics++;
    advanceTime(4);
    if (G.robotics >= 2) { showBanner('🤖 مدرک رباتیک نوین‌ذهن گرفتی! حقوق برنامه‌نویسی ×۱.۵ شد!'); addLog('🤖 متخصص رباتیک شدی!'); }
    else toast('🎓 دوره اول تموم شد! رباتت راه رفت... سه قدم. بعد افتاد. ولی راه رفت!');
    closePanel(); updateHUD();
  }, G.robotics >= 2);
  actionRow(p, '👀 بازدید از نمایشگاه ربات‌ها', faMoney(1000000) + ' | +۱۰ شادی', () => {
    if (G.money < 1000000) { toast('💸!'); return; }
    addMoney(-1000000); G.happy += 10; advanceTime(1);
    toast('🤖 یه ربات بهت چایی تعارف کرد! نصفش ریخت ولی نیتش پاک بود!'); updateHUD();
  });
}
function panelDairy(p) {
  actionRow(p, '🥛 شیر و ماست و پنیر محلی', faMoney(1800000) + ' | +۱۲ سلامتی', () => {
    if (G.money < 1800000) { toast('💸 لبنیات شده کالای لوکس!'); return; }
    addMoney(-1800000); G.health += 12; toast('🥛 مشتی: «اینا رو از گاوای خوشحال گرفتم!»'); updateHUD();
  });
  actionRow(p, '🥤 دوغ خنک محلی', faMoney(500000) + ' | +۸ شادی', () => {
    if (G.money < 500000) { toast('💸!'); return; }
    addMoney(-500000); G.happy += 8; toast('🥤 با نعنا! خنک شدی!'); updateHUD();
  });
}
function panelMansion(p) {
  noteP(p, '🏛️ عمارت قاجاریِ محله با آینه‌کاری و حوض فیروزه‌ای — قدیمیا میگن اینجا یه شب عروسی صد ساله!');
  actionRow(p, '🎟️ بازدید با راهنما', faMoney(1500000) + ' | +۱۲ شادی', () => {
    if (G.money < 1500000) { toast('💸 راهنما: «از پشت نرده‌ها هم قشنگه!»'); return; }
    addMoney(-1500000); G.happy += 12; advanceTime(1);
    toast('🏛️ راهنما: «این آینه‌ها ۱۵۰ سالشونه و هنوز از آینه‌ی خونه‌ی شما تمیزترن!»'); updateHUD();
  });
  actionRow(p, '📸 عکس یادگاری تو حیاط', 'رایگان! +۵ شادی', () => {
    G.happy += 5;
    toast('📸 عکست با حوض فیروزه‌ای عالی شد! بذار پروفایل!'); updateHUD();
  });
}

function panelFlower(p) {
  noteP(p, '🌹 گل داری: ' + fa(G.flowers) + ' شاخه — گل برای هدیه دادن و عذرخواهی معجزه می‌کنه!');
  const c = Math.round(1200000 * G.eco.housingCoef);
  actionRow(p, '🌹 خرید دسته‌گل رز', faMoney(c) + ' | برای هدیه یا آشتی', () => {
    if (G.money < c) { toast('💸 عشق مجانیه، گلش نه!'); return; }
    addMoney(-c); G.flowers++; bagAdd('flower'); toast('🌹 دسته‌گل خریدی!'); openBuilding('flower');
  });
  actionRow(p, '🌼 گل برای خونه', faMoney(600000) + ' | +۸ شادی', () => {
    if (G.money < 600000) { toast('💸!'); return; }
    addMoney(-600000); G.happy += 8; toast('🌼 خونه معطر شد!'); updateHUD();
  });
}
function panelBook(p) {
  actionRow(p, '📖 خرید و خوندن کتاب', faMoney(2000000) + ' | +۱۲ شادی، آرامش', () => {
    if (G.money < 2000000) { toast('💸 کتاب هم لاکچری شد!'); return; }
    addMoney(-2000000); G.happy += 12; advanceTime(2);
    toast('📖 «قیمت پشت جلد» دیگه یه شوخی قدیمیه!'); updateHUD();
  });
  actionRow(p, '📰 مجله اقتصادی', faMoney(500000) + ' | تیترش: «همه چیز درست می‌شود»', () => {
    if (G.money < 500000) { toast('💸!'); return; }
    addMoney(-500000); G.happy += 3; toast('😄 حداقل خندیدیم!'); updateHUD();
  });
}
function panelPastry(p) {
  noteP(p, '🍰 جعبه شیرینی داری: ' + fa(G.sweets) + ' — برای هدیه و مهمونی عالیه!');
  const c = Math.round(1800000 * G.eco.housingCoef);
  actionRow(p, '🍰 خرید جعبه شیرینی', faMoney(c) + ' | برای هدیه دادن', () => {
    if (G.money < c) { toast('💸 خامه گرونه!'); return; }
    addMoney(-c); G.sweets++; toast('🍰 جعبه شیرینی گرفتی!'); openBuilding('pastry');
  });
  actionRow(p, '🧁 نون‌خامه‌ای همینجا', faMoney(400000) + ' | +۱۰ شادی', () => {
    if (G.money < 400000) { toast('💸!'); return; }
    addMoney(-400000); G.happy += 10; toast('🧁 به‌به!'); updateHUD();
  });
}
function panelJuice(p) {
  actionRow(p, '🥤 معجون انرژی', faMoney(1200000) + ' | +۲۰ انرژی', () => {
    if (G.money < 1200000) { toast('💸 موز شده طلا!'); return; }
    addMoney(-1200000); G.energy += 20; bagAdd('juice'); toast('🥤 جون گرفتی!'); updateHUD();
  });
  actionRow(p, '🍨 بستنی سنتی', faMoney(900000) + ' | +۱۰ شادی', () => {
    if (G.money < 900000) { toast('💸!'); return; }
    addMoney(-900000); G.happy += 10; toast('🍨 با طعم زعفرونِ... کم!'); updateHUD();
  });
}
function panelGamenet(p) {
  actionRow(p, '🎮 دو ساعت گیم', faMoney(1500000) + ' | +۱۵ شادی -۱۰ انرژی' + (G.internetDown ? ' | ⛔ نت قطعه!' : ''), () => {
    if (G.internetDown) { toast('📵 اینترنت قطعه! ستاره: «بیا لودو آفلاین بزنیم!»'); return; }
    if (G.money < 1500000) { toast('💸!'); return; }
    addMoney(-1500000); G.happy += 15; G.energy -= 10; advanceTime(2);
    toast('🎮 خوش گذشت! پینگ بالا بود ولی خندیدیم!'); updateHUD();
  });
  const h = document.createElement('h4'); h.textContent = '💼 استخدام'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'streamer'));
  jobRow(p, JOBS.find(j => j.id === 'youtuber'));
}
function panelSalon(p) {
  actionRow(p, '💈 اصلاح مو و صورت', faMoney(1500000) + ' | +۱۰ شادی، تیپ تازه', () => {
    if (G.money < 1500000) { toast('💸 آرایشگر: «سرت با کلاه هم قشنگه!»'); return; }
    addMoney(-1500000); G.happy += 10; advanceTime(1);
    toast('💈 آقا رو باش! برق افتادی!'); updateHUD();
  });
}

function panelHome(p) {
  noteP(p, G.homeOwned
    ? 'خونه‌ی خودته! دیگه اجاره نمیدی. 🎉'
    : '🛏️ یه اتاقک که فقط یه تخت توش جا میشه! پاهاتو دراز کنی از پنجره بیرون می‌زنه! اجاره اول هر ماه: ' + faMoney(rentToday()));
  actionRow(p, '😴 خواب تا صبح', 'انرژی کامل، +۵ سلامتی — روز جدید شروع میشه', () => {
    G.energy = G.childName ? 80 : 100; G.health += 5;
    G.hour = 7; G.minute = 0;
    runDailyTick();
    toast('☀️ صبح شد!'); closePanel();
  });
  actionRow(p, '🛋️ چرت ۲ ساعته', '+۲۵ انرژی', () => { G.energy += 25; advanceTime(2); toast('+۲۵ انرژی'); });
  actionRow(p, '📺 تماشای سریال', '+۱۰ شادی' + (G.powerOut ? ' | ⛔ برق قطعه!' : ''), () => {
    if (G.powerOut) { toast('⚡ برق نیست! شمع روشن کن حافظ بخون.'); return; }
    G.happy += 10; advanceTime(2); toast('+۱۰ شادی'); updateHUD();
  });
  const h = document.createElement('h4'); h.textContent = '💼 کاریابی آنلاین'; p.appendChild(h);
  if (!G.phone) noteP(p, '📱 برای دیدن آگهی‌ها گوشی لازمه! (موبایل‌فروشی)');
  else if (G.internetDown) noteP(p, '📵 اینترنت قطعه، آگهی‌ها لود نمیشن!');
  else JOBS.forEach(j => jobRow(p, j));
  if (G.job) actionRow(p, '🚪 استعفا', 'بیکار میشی ولی آزاد!', () => { G.job = null; toast('استعفا دادی!'); updateHUD(); closePanel(); });
}
function panelRealty(p) {
  noteP(p, 'مشاور: «الان بهترین وقت خریده! فردا گرون‌تره!» (همیشه همینو میگه)');
  const price = housePrice();
  actionRow(p, '🏠 خرید خونه', faMoney(price) + ' — دیگه اجاره بی اجاره!', () => {
    if (G.homeOwned) { toast('خونه داری دیگه!'); return; }
    if (G.money < price) { toast('💸 پول کافی نیست! فقط ' + faMoney(price - G.money) + ' کم داری!'); return; }
    addMoney(-price); G.homeOwned = true; G.happy += 30;
    addLog('🎉 صاحب‌خونه شدی! محال ممکن شد!');
    showBanner('🎉 خونه خریدی! همسایه‌ها باورشون نمیشه!');
    closePanel(); updateHUD();
  }, G.homeOwned);
}
function panelMarket(p) {
  if (G.childName && G.childStage === 'infant') {
    actionRow(p, '🍼 شیرخشک و پوشک برای ' + G.childName, faMoney(1200000) + ' | +۱۰ شادی — بچه منتظره!', () => {
      if (G.money >= 1200000) addMoney(-1200000);
      else toast('💸 مش‌قاسم: «برای بچه نسیه هم میدم! ببر!»');
      G.happy += 10;
      toast('🍼 خرید بچه انجام شد! ' + G.childName + ' سیر و خوشحاله.');
      missionTick('baby'); updateHUD();
    });
  }
  const c1 = Math.round(4000000 * G.eco.housingCoef);
  actionRow(p, '🛒 خرید هفتگی', faMoney(c1) + ' | +۱۵ سلامتی +۱۰ انرژی', () => {
    if (G.money < c1) { toast('💸 پول کم داری!'); return; }
    addMoney(-c1); G.health += 15; G.energy += 10; advanceTime(1);
    toast('🛒 یخچال پر شد!'); updateHUD();
  });
  actionRow(p, '🍫 تنقلات', faMoney(500000) + ' | +۸ شادی', () => {
    if (G.money < 500000) { toast('💸 پول کم داری!'); return; }
    addMoney(-500000); G.happy += 8; toast('+۸ شادی'); updateHUD();
  });
  const h = document.createElement('h4'); h.textContent = '💼 استخدام'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'shop'));
}
function panelBakery(p) {
  noteP(p, 'بوی نون تازه... صف طولانیه ولی می‌ارزه!');
  actionRow(p, '🍞 نون سنگک تازه', faMoney(150000) + ' | +۱۰ انرژی +۵ شادی', () => {
    if (G.money < 150000) { toast('💸!'); return; }
    addMoney(-150000); G.energy += 10; G.happy += 5; toast('🍞 آخ که چه نونی!'); missionTick('bread'); bagAdd('bread'); updateHUD();
  });
}
function panelCafe(p) {
  const drink = (label, cost, fx, msg) => actionRow(p, label, faMoney(cost) + ' | ' + fx.txt, () => {
    if (G.money < cost) { toast('💸 شیرین: «دفتر نسیه نداریم متأسفانه!»'); return; }
    addMoney(-cost); fx.fn(); toast(msg); missionTick('coffee'); updateHUD();
  });
  drink('☕ قهوه', 800000, { txt: '+۱۵ انرژی +۵ شادی', fn: () => { G.energy += 15; G.happy += 5; } }, '☕ جون گرفتی!');
  drink('☕ اسپرسو دبل', 1100000, { txt: '+۲۲ انرژی', fn: () => { G.energy += 22; } }, '☕ حالا تا شب بیداری!');
  drink('🍵 چای و قندپهلو', 500000, { txt: '+۸ انرژی +۵ شادی', fn: () => { G.energy += 8; G.happy += 5; } }, '🍵 چسبید!');
  drink('🥛 لاته با طرح قلب', 950000, { txt: '+۱۲ انرژی +۸ شادی', fn: () => { G.energy += 12; G.happy += 8; } }, '🥛 طرح قلبش حیف بود بخوری!');
  drink('☕ هات چاکلت', 1000000, { txt: '+۸ انرژی +۱۰ شادی', fn: () => { G.energy += 8; G.happy += 10; } }, '🍫 شیرینِ داغ!');
  drink('🍰 کیک شکلاتی', 1200000, { txt: '+۱۰ شادی +۵ انرژی', fn: () => { G.happy += 10; G.energy += 5; } }, '🍰 قاشق آخرش بهترین بود!');
  drink('🍪 کوکی خونگی', 600000, { txt: '+۶ شادی', fn: () => { G.happy += 6; } }, '🍪 ترد و تازه!');
  const h = document.createElement('h4'); h.textContent = '💼 استخدام / سرمایه‌گذاری'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'barista'));
  jobRow(p, JOBS.find(j => j.id === 'cafeowner'));
}
function panelRestaurant(p) {
  const c = Math.round(2500000 * G.eco.housingCoef);
  actionRow(p, '🍽️ غذای کامل', faMoney(c) + ' | +۲۰ انرژی +۱۰ سلامتی +۱۰ شادی', () => {
    if (G.money < c) { toast('💸 پول کم داری! برو نانوایی!'); return; }
    addMoney(-c); G.energy += 20; G.health += 10; G.happy += 10; advanceTime(1);
    toast('🍽️ به‌به!'); updateHUD();
  });
  const h = document.createElement('h4'); h.textContent = '💼 کار با اصغر (پیک رستوران)'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'courier'));
  jobRow(p, JOBS.find(j => j.id === 'taxi'));
}
function panelUniversity(p) {
  const fee = Math.round(30000000 * dailyInflationFactor() ** G.dayIndex);
  noteP(p, G.education ? '🎓 مدرک داری! (برنامه‌نویس و معلم برات بازه)' : 'ترم گذرونده: ' + fa(G.studying) + ' از ۳');
  actionRow(p, '📚 گذروندن یک ترم', faMoney(fee) + ' | -۲۰ انرژی — ۳ ترم = مدرک', () => {
    if (G.education) { toast('مدرک داری دیگه!'); return; }
    if (G.money < fee) { toast('💸 شهریه رو نداری! دانشگاه: «قسطی هم می‌شه» (نمی‌شه)'); return; }
    if (G.energy < 25) { toast('😴 با این انرژی سر کلاس خوابت می‌بره!'); return; }
    addMoney(-fee); G.energy -= 20; G.studying++;
    advanceTime(5);
    if (G.studying >= 3) { G.education = true; showBanner('🎓 فارغ‌التحصیل شدی! مبارکه!'); addLog('🎓 مدرک گرفتی!'); }
    else toast('📚 ترم ' + fa(G.studying) + ' تموم شد!');
    closePanel(); updateHUD();
  }, G.education);
  const h = document.createElement('h4'); h.textContent = '💼 استخدام'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'teacher'));
  jobRow(p, JOBS.find(j => j.id === 'dev'));
}
function panelBank(p) {
  noteP(p, '💰 سپرده: ' + faMoney(G.bank.deposit) + ' (سود ۲۰٪ سالانه) | 💳 وام: ' + faMoney(G.bank.loan));
  actionRow(p, '📥 سپرده‌گذاری ۵۰ میلیون', 'سود روزانه می‌گیره', () => {
    if (G.money < 50000000) { toast('💸 موجودی کمه!'); return; }
    addMoney(-50000000); G.bank.deposit += 50000000; toast('📥 سپرده شد'); openBuilding('bank');
  });
  actionRow(p, '📤 برداشت کل سپرده', faMoney(G.bank.deposit), () => {
    addMoney(G.bank.deposit); G.bank.deposit = 0; toast('📤 برداشت شد'); openBuilding('bank');
  }, G.bank.deposit <= 0);
  actionRow(p, '💳 وام ۲۰۰ میلیونی', 'قسط روزانه داره! ضامن نمی‌خواد (فعلاً)', () => {
    if (G.bank.loan > 0) { toast('اول وام قبلی رو صاف کن!'); return; }
    G.bank.loan = 200000000; addMoney(200000000);
    toast('💳 وام واریز شد. مبارکه... و تسلیت.'); openBuilding('bank');
  }, G.bank.loan > 0);
  actionRow(p, '✅ تسویه وام', faMoney(G.bank.loan), () => {
    if (G.money < G.bank.loan) { toast('💸 نمی‌رسه!'); return; }
    addMoney(-G.bank.loan); G.bank.loan = 0; toast('✅ تسویه شد! نفس راحت.'); openBuilding('bank');
  }, G.bank.loan <= 0);
  const h = document.createElement('h4'); h.textContent = '💼 استخدام صرافی (طبقه بالا)'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'exchange'));
}
function panelHospital(p) {
  const cost = Math.round((100 - G.health) * 400000 + 2000000);
  actionRow(p, '🩺 درمان کامل', faMoney(cost) + ' | سلامتی → ۱۰۰', () => {
    if (G.money < cost) { toast('💸 بیمه هم که نداری...'); return; }
    addMoney(-cost); G.health = 100; advanceTime(3);
    toast('🩺 مثل روز اولت شدی!'); updateHUD(); closePanel();
  }, G.health >= 95);
  actionRow(p, '💊 چکاپ سریع', faMoney(1500000) + ' | +۱۰ سلامتی', () => {
    if (G.money < 1500000) { toast('💸!'); return; }
    addMoney(-1500000); G.health += 10; advanceTime(1); toast('+۱۰ سلامتی'); updateHUD();
  });
}
function panelMobile(p) {
  if (G.phone) noteP(p, '📱 گوشی فعلی: ' + PHONES.find(ph=>ph.id===G.phone).name + (G.phoneBroken ? ' (شکسته! 💔)' : ' ✅'));
  PHONES.forEach(ph => {
    const price = Math.round(ph.priceUsd * G.eco.dollar);
    actionRow(p, '📱 ' + ph.name, faMoney(price) + ' (' + fa(ph.priceUsd) + ' دلار)', () => {
      if (G.money < price) { toast('💸 قیمت دلاریه، حقوقت ریالی!'); return; }
      addMoney(-price); G.phone = ph.id; G.phoneBroken = false; G.happy += 10;
      toast('📱 مبارکه!'); updateHUD(); openBuilding('mobile');
    }, G.phone === ph.id && !G.phoneBroken);
  });
  if (G.phoneBroken) {
    const rep = Math.round(80 * G.eco.dollar);
    actionRow(p, '🔧 تعمیر صفحه', faMoney(rep), () => {
      if (G.money < rep) { toast('💸!'); return; }
      addMoney(-rep); G.phoneBroken = false; toast('🔧 مثل نو شد (تقریباً)'); updateHUD(); openBuilding('mobile');
    });
  }
}
function panelClothes(p) {
  actionRow(p, '👔 کمد لباس من', 'لباس بخر و بپوش — روی خودت دیده میشه!', () => { closePanel(); openWardrobe(); });
  const cost = Math.round(6000000 * (G.clothesLevel + 1) * G.eco.housingCoef);
  actionRow(p, '👔 دست لباس جدید', faMoney(cost) + ' | +۱۲ شادی، تیپ بهتر', () => {
    if (G.money < cost) { toast('💸 فروشنده: «قابل شما رو نداره» (داره)'); return; }
    addMoney(-cost); G.clothesLevel++; G.happy += 12;
    toast('👔 چه تیپی زدی!'); updateHUD();
  });
}
function panelDealership(p) {
  noteP(p, 'فروشنده: «همه قیمت‌ها روزانه‌ست، فردا تماس بگیری فرق کرده!»');
  CARS.forEach(car => {
    const price = carPrice(car);
    const owned = G.cars.includes(car.id);
    actionRow(p, '🚗 ' + car.name, faMoney(price) + ' | سرعت ' + fa(car.speed) + ' | باک ' + fa(car.tank) + 'ل',
      () => {
        if (G.money < price) { toast('💸 فعلاً تو حسرت ' + car.name + ' بمون!'); return; }
        addMoney(-price); G.cars.push(car.id); G.activeCar = car.id;
        G.fuel = car.tank; G.damage = 0; G.happy += 20;
        addLog('🚗 ' + car.name + ' خریدی!');
        showBanner('🚗 مبارکه! ' + car.name + ' سوار شدی!');
        window.WORLD?.onCarChanged?.();
        closePanel(); updateHUD();
      }, owned);
  });
}
function panelRepair(p) {
  const car = activeCarData();
  if (!car) { noteP(p, 'ماشین نداری! ممد: «پس اینجا چیکار می‌کنی داداش؟»'); }
  else {
    const fix = Math.round(G.damage * 800000 * G.eco.carCoef);
    actionRow(p, '🔧 تعمیر کامل', faMoney(fix) + ' | خرابی → ۰٪', () => {
      if (G.money < fix) { toast('💸 ممد: «نسیه نداریم داداش»'); return; }
      addMoney(-fix); G.damage = 0; advanceTime(2); toast('🔧 مثل ساعت کار می‌کنه!'); updateHUD(); openBuilding('repair');
    }, G.damage <= 0);
    const liters = car.tank - G.fuel;
    const fuelCost = Math.round(liters * G.eco.benzin);
    actionRow(p, '⛽ باک پر', fa(liters) + ' لیتر × ' + faMoney(G.eco.benzin) + ' = ' + faMoney(fuelCost), () => {
      if (G.money < fuelCost) { toast('💸 بنزین از آب معدنی گرون‌تره!'); return; }
      addMoney(-fuelCost); G.fuel = car.tank; toast('⛽ پر شد!'); updateHUD(); openBuilding('repair');
    }, liters <= 0);
  }
  const h = document.createElement('h4'); h.textContent = '💼 استخدام'; p.appendChild(h);
  jobRow(p, JOBS.find(j => j.id === 'carpenter'));
}
function panelGym(p) {
  actionRow(p, '💪 تمرین بدنسازی', faMoney(1000000) + ' | -۲۰ انرژی، +۱۵ سلامتی +۸ شادی', () => {
    if (G.money < 1000000) { toast('💸 شهریه باشگاه!'); return; }
    if (G.energy < 25) { toast('😴 با این انرژی هالتر می‌افته روت!'); return; }
    addMoney(-1000000); G.energy -= 20; G.health += 15; G.happy += 8;
    advanceTime(2); toast('💪 عضله‌ها فعال شدن!'); updateHUD();
  });
}
function panelPark(p) {
  missionTick('park');
  actionRow(p, '🚶 قدم زدن', 'رایگان! +۱۰ شادی +۵ سلامتی', () => {
    G.happy += 10; G.health += 5; advanceTime(1);
    toast('🌳 هوای خنک... البته اگه آلوده نباشه!'); updateHUD();
  });
  actionRow(p, '🪑 نشستن رو نیمکت با عمو غلام', '+۵ شادی و کلی غر شنیدن', () => {
    G.happy += 5; addAffection('gholam', 5); advanceTime(1);
    toast('عمو غلام: «زمان ما این پارک باغ بود، باغ!»'); updateHUD();
  });
}
function panelAirport(p) {
  if (!G.passport) {
    const cost = 5000000;
    actionRow(p, '🛂 گرفتن پاسپورت', faMoney(cost) + ' | برای سفر خارجی لازمه', () => {
      if (G.money < cost) { toast('💸!'); return; }
      addMoney(-cost); G.passport = true; toast('🛂 پاسپورت آماده‌ست!'); openBuilding('airport');
    });
    noteP(p, 'بدون پاسپورت فقط می‌تونی به تابلوی پروازها نگاه کنی و آه بکشی.');
    return;
  }
  TRIPS_EXTERNAL.forEach(t => {
    const price = tripPrice(t);
    actionRow(p, '✈️ ' + t.name, faMoney(price) + ' (' + fa(t.priceUsd) + '$) | +' + fa(t.happy) + ' شادی', () => startTrip(t, price));
  });
}
function panelTerminal(p) {
  noteP(p, 'بلندگو: «مسافرین محترمِ اتوبوس ساعت ۸... اتوبوس ساعت ۸ با تاخیر حرکت می‌کند.»');
  TRIPS_INTERNAL.forEach(t => {
    const price = tripPrice(t);
    actionRow(p, '🚌 ' + t.name, faMoney(price) + ' | +' + fa(t.happy) + ' شادی', () => startTrip(t, price));
  });
}
function panelApartment(p) {
  noteP(p, 'تابلوی ورودی: «لطفاً شارژ ساختمان را پرداخت نمایید» (با ۷ تا علامت تعجب)');
  actionRow(p, '🚪 سر زدن به خانم فضّه', 'آخرین اخبار محله + چایی', () => {
    addAffection('fezzeh', 5); G.happy += 5; advanceTime(1);
    toast('فضّه‌خانم: «بشین تا برات تعریف کنم چی شده!»'); updateHUD();
  });
}

// ---------- سفر ----------
function startTrip(trip, price) {
  if (G.money < price) { toast('💸 پول بلیط رو نداری!'); return; }
  addMoney(-price);
  closePanel();
  G.traveling = { name: trip.name, left: trip.dur, happy: trip.happy };
  $id('travelName').textContent = trip.name;
  $id('travelWrap').classList.add('show');
  addLog('🧳 راهی ' + trip.name + ' شدی! سفر بخیر!');
  const iv = setInterval(() => {
    if (!G.traveling) { clearInterval(iv); return; }
    G.traveling.left--;
    $id('travelTimer').textContent = fa(G.traveling.left) + ' ثانیه تا برگشت';
    if (G.traveling.left <= 0) {
      clearInterval(iv);
      G.happy += G.traveling.happy; G.energy -= 10;
      advanceTime(10);
      addLog('🧳 از سفر ' + G.traveling.name + ' برگشتی! (+' + fa(G.traveling.happy) + ' شادی)');
      showBanner('🏙️ به تهران خوش برگشتی! (ترافیکش سر جاشه)');
      G.traveling = null;
      $id('travelWrap').classList.remove('show');
      updateHUD();
    }
  }, 1000);
}

// ---------- دیالوگ NPC (دیالوگ‌محور!) ----------
function npcSay(npc, text) {
  const p = $id('panelBody');
  const d = document.createElement('p');
  d.className = 'npcSaid';
  d.textContent = '«' + text + '»';
  p.prepend(d);
  while (p.querySelectorAll('.npcSaid').length > 2) [...p.querySelectorAll('.npcSaid')].pop().remove();
}
function maybeJealousy(npcId) {
  const msg = jealousyCheck(npcId);
  if (msg) { showBanner(msg, 6000); addLog(msg); updateHUD(); }
}
// ---------- کمکی‌های اجتماعی ----------
// یکی دو نفر از دخترها «دل‌نازک»ن و به درخواست زودهنگام جواب مثبت می‌دن؛ بقیه نه!
function softHearts() {
  if (!G.softHearts) {
    const girls = NPCS.filter(n => n.marriageable).map(n => n.id);
    const pick = [];
    const count = 1 + Math.floor(Math.random() * 2);
    while (pick.length < count && girls.length) pick.push(girls.splice(Math.floor(Math.random() * girls.length), 1)[0]);
    G.softHearts = pick;
  }
  return G.softHearts;
}
// بعد از ازدواج، دو نفر از دخترها میشن رفیقای زنت — چشمشون بهته!
function wifeFriends() {
  if (!G.married) return [];
  if (!G.wifeFriends) {
    const girls = NPCS.filter(n => n.marriageable && n.id !== G.married).map(n => n.id);
    const pick = [];
    while (pick.length < 2 && girls.length) pick.push(girls.splice(Math.floor(Math.random() * girls.length), 1)[0]);
    G.wifeFriends = pick;
  }
  return G.wifeFriends;
}
// زنت مچتو گرفت؟ طلاق و مهریه — این بار اون می‌گیره، نه تو!
function wifeCatchCheck(npcId) {
  if (!G.married || G.married === npcId) return null;
  const heat = getAffection(npcId);
  const chance = wifeFriends().includes(npcId) ? .55 : .22 + heat / 400;
  if (Math.random() > chance) return null;
  const wife = NPCS.find(n => n.id === G.married);
  const other = NPCS.find(n => n.id === npcId);
  const mehrieh = Math.round(650000000 * G.eco.housingCoef);
  const paid = Math.min(G.money, mehrieh);
  addMoney(-paid);
  G.debt = (G.debt || 0) + (mehrieh - paid);
  G.married = null;
  G.happy -= 25;
  addAffection(wife.id, -70);
  addAffection(npcId, -25);
  G.upset = G.upset || {};
  G.upset[wife.id] = G.dayIndex + 14;
  G.upset[npcId] = G.dayIndex + 4;
  sfx.sad();
  const msg = '💔 ' + wife.name.split(' (')[0] + ' تو رو با ' + other.name.split(' (')[0] +
    ' دید! همون‌جا وکیل گرفت: طلاق + مهریه ' + faMoney(mehrieh) +
    (mehrieh - paid > 0 ? ' (بدهکار موندی!)' : '') + ' — کل محل هم فهمیدن!';
  showBanner(msg, 8000); addLog(msg); addNews(msg);
  updateHUD();
  return msg;
}

// ---------- سناریوی آشنایی: هر دختر یه جور پیدا میشه، یه قلقی داره! ----------
function openIntro(npc) {
  const go = () => talkOpen(npc, t => {
    t.say(npc.intro.scene, 'idle');
    [...npc.intro.options].sort(() => Math.random() - .5).forEach(opt => {
      t.option(opt.label, '', () => {
        t.me(opt.label.replace(/^«|»$/g, ''));
        const score = toneScore(npc, opt.tone);
        G.met = G.met || {};
        G.met[npc.id] = true;
        addAffection(npc.id, affGainFor(npc, Math.max(0, 5 + score)));
        t.say('اسمم ' + npc.name.split(' (')[0] + 'ئه! — ' + toneReact(npc, score),
              score >= 3 ? 'happy' : score < 0 ? 'sad' : 'idle');
        addLog('👋 با ' + npc.name + ' آشنا شدی!');
        updateHUD();
        setTimeout(() => { if (talkIsWith(npc)) openNPC(npc, { keep: true, noWalk: true, inside: true }); }, 1900);
      });
    });
  });
  if (window.WORLD?.approach) window.WORLD.approach(npc.id, go); else go();
}

// ---------- گفتگوی اصلی ----------
function openNPC(npc, opts = {}) {
  if (!npcHereToday(npc)) {
    toast('👀 ' + npc.name.split(' (')[0] + ' این روزا کم پیداست... ' + fa(nextVisitIn(npc)) + ' روز دیگه میاد.');
    return;
  }
  // اولین برخورد با دخترها: سناریوی آشنایی — فقط تو محل خودش
  // سناریوی آشنایی فقط تو محل خودش اجرا میشه (وسط خیابون «رفتی بیمارستان» بی‌معنیه!)
  if (npc.marriageable && npc.intro && !G.met?.[npc.id] &&
      window.WORLD?.insideOf?.() === (npc.introAt || npc.hangout)) {
    G.met = G.met || {};
    openIntro(npc);
    return;
  }
  G.met = G.met || {}; G.met[npc.id] = true;
  if (typeof npcMem === 'function') {
    const mm = npcMem(npc.id);
    if (mm.met == null) mm.met = G.dayIndex;
    mm.talks = (mm.talks || 0) + 1;
    mm.lastSeen = G.dayIndex;
  }
  if (!opts.keep) resetVisit(npc.id);

  // تو خیابون عجله داره؛ گفتگوی کامل فقط پشت دخل مغازه‌ش
  const hang = buildingById(npc.hangout);
  const hurried = !opts.inside && !npc.officer && !npc.rare && hang && hang.kind !== 'open' && !npcInShopToday(npc);

  const go = () => talkOpen(npc, t => hurried ? buildHurried(t, npc) : buildTalk(t, npc));
  if (window.WORLD?.approach && !opts.noWalk) window.WORLD.approach(npc.id, go); else go();
}

// حوصله‌ی طرف تو یک دیدار محدوده — بعد از چند تا حرف میره سر کارش
function spend(t, npc) {
  if (bumpVisit(npc.id) >= PATIENCE) {
    setTimeout(() => {
      if (talkIsWith(npc)) { talkSay(leaveLine(), 'idle'); setTimeout(() => closeTalkFor(npc), 2000); }
    }, 1500);
    return false;
  }
  return true;
}

// ---------- نسخهٔ کوتاه: تو خیابون، عجله داره ----------
function buildHurried(t, npc) {
  const shop = buildingById(npc.hangout);
  // هر جور که گفتگو تموم شه، واقعاً راه میفته میره تو مغازه‌ش و همون‌جا در دسترسه
  if (shop) talkClose = () => {
    G.forcedShop = G.forcedShop || {};
    G.forcedShop[npc.id] = G.dayIndex;
    window.WORLD?.npcGoShop?.(npc.id);
    toast('🚶 ' + npc.name.split(' (')[0] + ' رفت سمت ' + shop.name + ' — اونجا می‌تونی کامل باهاش حرف بزنی.');
  };
  t.say('سلام! ببخشید عجله دارم، دارم می‌رم ' + (shop ? shop.name : 'سر کار') + '. اونجا بیا سرِ فرصت حرف بزنیم!', 'idle');
  t.option('👋 سلام کوتاه', '+۱ علاقه', () => {
    if (usedToday(npc.id, 'hi')) { t.say('همین الان که سلام کردی! 😄', 'happy'); return; }
    useToday(npc.id, 'hi');
    addAffection(npc.id, affGainFor(npc, 1));
    t.me('سلام! خسته نباشی.');
    t.say(npc.greet, 'happy');
    updateHUD();
  });
  t.option('❓ «کجا میری؟»', '', () => {
    t.me('کجا میری با این عجله؟');
    t.say('دارم می‌رم ' + (shop ? shop.name : 'سر کار') + '! از صبح دیر کردم. بیا اونجا، یه چایی می‌زنیم.', 'talk');
  });
  if (shop) t.option('🚪 «باشه، میام مغازه‌ت»', 'محل کارش: ' + shop.name, () => {
    t.say('منتظرتم! 👋', 'happy');
    setTimeout(closeTalk, 1200);   // بعد از بسته شدن، هوک بالا خودش می‌فرستدش تو مغازه
  });
}

// ---------- گفتگوی کامل ----------
function buildTalk(t, npc) {
  const aff = getAffection(npc.id);
  // 🧠 یادآوری خاطره + واکنش به شرافت
  if (typeof npcRecallLine === 'function' && !t._recalled) {
    t._recalled = true;
    const hg = typeof honorGreetLine === 'function' ? honorGreetLine(npc) : null;
    const rc = npcRecallLine(npc);
    if (hg || rc) setTimeout(() => talkSayFor(npc, hg || rc, hg && (G.honor ?? 50) <= 20 ? 'angry' : 'happy'), 700);
  }
  // 🎁 هدیه از کوله
  if (typeof ITEMS !== 'undefined') {
    const gifts = Object.keys(ITEMS).filter(k => ITEMS[k].gift && bagCount(k) > 0);
    if (gifts.length) {
      t.group('🎁 هدیه از کوله');
      gifts.forEach(k => {
        const it = ITEMS[k];
        const done = usedToday(npc.id, 'gift_' + k);
        t.option(it.icon + ' ' + it.name, done ? '✅ امروز دادی' : '+' + fa(it.aff) + ' علاقه', () => {
          if (!bagTake(k)) return;
          useToday(npc.id, 'gift_' + k);
          const bonus = npc.kid && k === 'teddy' ? 8 : 0;
          addAffection(npc.id, affGainFor(npc, it.aff + bonus));
          const mm = npcMem(npc.id); mm.gifts = (mm.gifts || 0) + 1; mm.lastGift = it.name;
          rememberNPC(npc.id, 'یه ' + it.name + ' بهم هدیه دادی');
          journal('🎁 به ' + npc.name.split(' (')[0] + ' ' + it.name + ' هدیه دادم.');
          missionTick('gift');
          t.say(['وای! ' + it.name + '؟! ذوق کردم! ممنونم ازت 🥹', 'چقدر به فکرمی! این رو نگه می‌دارم.', 'دستت درد نکنه... واقعاً غافلگیر شدم!'][Math.floor(Math.random()*3)], 'happy');
          updateHUD(); setTimeout(t.refresh, 1800);
        }, done);
      });
    }
  }
  // 🤝 منوی رفاقت برای غیرِدخترها
  if (typeof buildBroMenu === 'function' && !npc.marriageable && !npc.kid && aff >= 5) buildBroMenu(t, npc);

  // ---- قهر ----
  if (isUpset(npc.id)) {
    t.say('😤 باهات قهرم! روشو اونور می‌کنه...', 'angry');
    t.option('🙏 عذرخواهی با گل', G.flowers > 0 ? '۱ شاخه گل | آشتی +۱۰ علاقه' : '⛔ گل نداری (گل‌فروشی رؤیا)', () => {
      if (G.flowers <= 0) { toast('🌹 اول برو گل بخر!'); return; }
      G.flowers--; delete G.upset[npc.id];
      addAffection(npc.id, 10);
      window.WORLD?.giftAnim?.(npc.id, 'flower');
      t.say('هووم... فقط به خاطر گله‌ها! دفعه آخرت باشه! 🌹', 'happy');
      updateHUD(); setTimeout(t.refresh, 1400);
    }, G.flowers <= 0);
    t.option('🍰 عذرخواهی با شیرینی', G.sweets > 0 ? '۱ جعبه | آشتی +۵ علاقه' : '⛔ شیرینی نداری (قنادی یاس)', () => {
      if (G.sweets <= 0) { toast('🍰 اول برو قنادی!'); return; }
      G.sweets--; delete G.upset[npc.id];
      addAffection(npc.id, 5);
      window.WORLD?.giftAnim?.(npc.id, 'sweet');
      t.say('شکمو خودتی!... باشه، بخشیدمت. نصفشو خودم می‌خورم! 🍰', 'happy');
      updateHUD(); setTimeout(t.refresh, 1400);
    }, G.sweets <= 0);
    return;
  }

  t.say(npc.greet, 'idle');

  // ---- گپ روزانه ----
  G.chatCount = G.chatCount || {};
  if (G.chatCount.day !== G.dayIndex) { G.chatCount = { day: G.dayIndex }; }
  const chatDone = usedToday(npc.id, 'chat');
  t.option('💬 گپ زدن', chatDone ? '✅ امروز گپ زدید — فردا حرف تازه داره' : '+۳ علاقه (روزی یک بار)', () => {
    useToday(npc.id, 'chat');
    addAffection(npc.id, affGainFor(npc, 3)); G.happy += 2;
    t.me('خب... چه خبر؟');
    // گپ رندم و بدون تکرار — تا وقتی همهٔ گپ‌هاش رو نشنیدی، تکرار نمیشه
    G.lastChat = G.lastChat || {};
    G.chatSeen = G.chatSeen || {};
    const seen = G.chatSeen[npc.id] = G.chatSeen[npc.id] || [];
    let pool = npc.chats.map((_, i) => i).filter(i => !seen.includes(i));
    if (!pool.length) { seen.length = 0; pool = npc.chats.map((_, i) => i); }   // دور بعدی
    let ci = pool[Math.floor(Math.random() * pool.length)];
    seen.push(ci);
    G.lastChat[npc.id] = ci;
    t.say(npc.chats[ci], 'talk');
    if (Math.random() < .25) rememberNPC(npc.id, 'دربارهٔ «' + npc.chats[ci].slice(0, 22) + '...» حرف زدیم');
    missionTick('chat');
    updateHUD(); spend(t, npc); setTimeout(t.refresh, 900);
  }, chatDone);

  // ---- خاطره روزانه ----
  G.memCount = G.memCount || {};
  if (G.memCount.day !== G.dayIndex) G.memCount = { day: G.dayIndex };
  const memDone = usedToday(npc.id, 'memory');
  if (npc.memories && npc.memories.length) {
    t.option('🧠 «یه خاطره تعریف کن»', memDone ? '✅ امروز تعریف کرد — فردا خاطرهٔ تازه' : '+۵ علاقه (روزی یک بار)', () => {
      useToday(npc.id, 'memory');
      addAffection(npc.id, affGainFor(npc, 5)); G.happy += 3;
      t.me('یه خاطره تعریف کن برام.');
      G.memSeen = G.memSeen || {};
      const ms = G.memSeen[npc.id] = G.memSeen[npc.id] || [];
      let mp = npc.memories.map((_, i) => i).filter(i => !ms.includes(i));
      if (!mp.length) { ms.length = 0; mp = npc.memories.map((_, i) => i); }
      const mi = mp[Math.floor(Math.random() * mp.length)];
      ms.push(mi);
      t.say(npc.memories[mi], 'idle');
      journal('🧠 ' + npc.name.split(' (')[0] + ' یه خاطره تعریف کرد.');
      missionTick('memory');
      updateHUD(); spend(t, npc); setTimeout(t.refresh, 900);
    }, memDone);
  }

  // ---- سوال‌ها (هر سوال روزی یک بار) ----
  // گزارش تصادف به پلیس: باید پلاک رو درست بگی! (درست = خسارت، غلط = جریمه)
  if (npc.officer && G.lastHitPlate) {
    t.group('🚨 گزارش ماشینی که بهت زد — پلاکش کدوم بود؟ (درست بگی خسارت می‌گیری، غلط بگی جریمه میشی!)');
    plateChoices(G.lastHitPlate.plate).forEach(p => {
      t.option('🚗 پلاک: ' + p, '', () => {
        t.me('جناب سروان، پلاکش این بود: ' + p);
        resolveHitReport(p, (line, mood) => t.say(line, mood));
        t.refresh();
      });
    });
  }
  if (npc.officer) {
    t.option('⚖️ «می‌خوام از یه نفر شکایت کنم»', 'شکایت رسمی', () => {
      t.me('می‌خوام از یه نفر شکایت کنم!');
      t.say('شکایت رسمی رو باید تو کلانتری ثبت کنی پسرم. برو کلانتری محله، من هماهنگ می‌کنم رسیدگی شه.', 'idle');
    });
  }
  // 🧒 چالش گم‌شدن هومن: از اهالی سراغشو بگیر
  if (G.challenge?.type === 'lostkid' && !npc.kid && !G.challenge.found) {
    t.option('🧒 «هومن کوچولو رو ندیدی؟ گم شده!»', 'سرنخ جمع کن', () => {
      G.challenge.asked = (G.challenge.asked || 0) + 1;
      t.me('هومن کوچولو رو ندیدی؟ مامانش نگرانشه!');
      if (G.challenge.asked === 1)
        t.say('هومن؟... چرا! صبح دیدمش با یه پاکت چیپس می‌دویید. فکر کنم سمت شمال محله رفت!', 'talk');
      else if (G.challenge.asked === 2)
        t.say('آهان هومن! دیدمش رفت تو گیم‌نت ستاره! برو اونجا، صددرصد پای بازیه!', 'happy');
      else
        t.say('گفتم که، گیم‌نت! بدو تا مامانش سکته نکرده!', 'talk');
      if (G.challenge.asked >= 2) toast('🕹️ سرنخ کامل شد: هومن تو «گیم‌نت ستاره»ست! برو داخلش.');
      t.refresh();
    });
  }
  (npc.qa || []).forEach(([q, a], i) => {
    const k = 'q' + i, done = usedToday(npc.id, k);
    t.option('❓ ' + q, done ? '✅ امروز پرسیدی' : '+۲ علاقه', () => {
      useToday(npc.id, k);
      addAffection(npc.id, affGainFor(npc, 2));
      t.me(q);
      t.say(a, 'talk');
      updateHUD(); spend(t, npc); setTimeout(t.refresh, 900);
    }, done);
  });

  // ---- هدیه ----
  t.group('🎁 هدیه');
  if (G.flowers > 0) t.option('🌹 یه شاخه گل بده', 'داری: ' + fa(G.flowers) + ' | +۱۲ علاقه', () => {
    G.flowers--; addAffection(npc.id, affGainFor(npc, 12)); missionTick('gift'); G.honor = Math.min(100, (G.honor ?? 50) + 1);
    window.WORLD?.giftAnim?.(npc.id, 'flower');
    t.me('اینو برای تو گرفتم.');
    t.say(npc.marriageable ? 'واای... برای منه؟! 🌹 قلبم!' : 'گل برای من؟! دستت درد نکنه!', 'love');
    if (npc.marriageable) { maybeJealousy(npc.id); wifeCatchCheck(npc.id); }
    updateHUD(); spend(t, npc); setTimeout(t.refresh, 1400);
  });
  if (G.sweets > 0) t.option('🍰 تعارف شیرینی', 'داری: ' + fa(G.sweets) + ' | +۸ علاقه', () => {
    G.sweets--; addAffection(npc.id, affGainFor(npc, 8));
    window.WORLD?.giftAnim?.(npc.id, 'sweet');
    t.me('بفرما، تازه‌ست.');
    t.say('به‌به! نون‌خامه‌ای! از کجا می‌دونستی ضعف دارم؟! 🍰', 'happy');
    updateHUD(); spend(t, npc); setTimeout(t.refresh, 1400);
  });
  const gc = giftCost();
  const gDone = usedToday(npc.id, 'gift');
  t.option('🎁 هدیه خریدنی', gDone ? '✅ امروز هدیه دادی' : faMoney(gc) + ' | +۱۰ علاقه', () => {
    if (G.money < gc) { toast('💸 با دست خالی که نمیشه!'); return; }
    useToday(npc.id, 'gift');
    addMoney(-gc); addAffection(npc.id, affGainFor(npc, 10));
    window.WORLD?.giftAnim?.(npc.id, 'box');
    t.me('یه چیز کوچیک برات گرفتم.');
    t.say('وای این چیه؟! نباید زحمت می‌کشیدی! (خیلی هم خوب کردی!) 🎁', 'love');
    if (npc.marriageable) { maybeJealousy(npc.id); wifeCatchCheck(npc.id); }
    updateHUD(); spend(t, npc); setTimeout(t.refresh, 1400);
  }, gDone);

  // ---- پلیس ----
  if (npc.officer) {
    t.group('👮 خدمات');
    t.option('🗺️ «آدرس می‌خوام»', 'راهنمایی رایگان', () => {
      const list = BUILDINGS.filter(x => !x.deco && x.name);
      const b = list[Math.floor(Math.random() * list.length)];
      t.me('ببخشید، ' + b.name + ' کجاست؟');
      t.say(b.name + '؟ از همین خیابون مستقیم برو، دستِ ' + (Math.random() < .5 ? 'راست' : 'چپ') + '. پیداش می‌کنی. مواظب خودت باش!', 'happy');
      spend(t, npc);
    });
    t.option('☀️ «روز خوبی داشته باشید»', '+۳ شادی', () => {
      G.happy += 3;
      t.me('روز خوبی داشته باشید جناب سروان!');
      t.say('زنده باشی پسرم! تو هم روز خوبی داشته باشی. مواظب خودت باش! 👮', 'happy');
      updateHUD(); spend(t, npc);
    });
  }

  // ---- عاشقانه ----
  if (npc.marriageable && G.married !== npc.id) {
    t.group('💕 عاشقانه — قرارها: ' + fa(datesWith(npc.id)) + ' از ' + fa(DATES_NEEDED) +
            (G.married ? ' ⚠️ متأهلی!' : '') + (npc.hardMode ? ' (سخت‌گیره!)' : ''));

    if (wifeFriends().includes(npc.id)) {
      t.option('⚠️ رفیقِ زنته!', 'هر حرکت عاشقانه = خبر می‌رسه به زنت', () => {}, true);
    }

    const loveMin = npc.hardMode ? 40 : 25;
    if (aff >= loveMin) {
      const lDone = usedToday(npc.id, 'love');
      t.option('💕 حرف دل', lDone ? '✅ امروز گفتی — فردا بیا' : '+۴ علاقه', () => {
        useToday(npc.id, 'love');
        addAffection(npc.id, affGainFor(npc, 4)); G.happy += 3;
        t.me('یه چیزی بگم؟ ازت خوشم میاد...');
        t.say(npc.loves[Math.floor(Math.random() * npc.loves.length)], 'love');
        maybeJealousy(npc.id);
        const caught = wifeCatchCheck(npc.id);
        if (caught) setTimeout(closeTalk, 2400);
        else if (wifeFriends().includes(npc.id)) {
          const wn = NPCS.find(n => n.id === G.married)?.name.split(' (')[0] || 'زنت';
          setTimeout(() => talkSayFor(npc, 'وایسا ببینم! تو که زن داری! من همین امشب به ' + wn + ' می‌گم! 😤', 'angry'), 2200);
          addAffection(npc.id, -12);
        }
        updateHUD(); spend(t, npc); setTimeout(t.refresh, 1600);
      }, lDone);
    } else {
      // زوده — گزینهٔ حرف دل اصلاً نشون داده نمیشه تا علاقه برسه
    }

    if (!G.knownJobs?.[npc.id]) {
      t.option('💬 «راستی... کارت چیه؟»', '+۲ علاقه', () => {
        G.knownJobs = G.knownJobs || {}; G.knownJobs[npc.id] = true;
        addAffection(npc.id, 2);
        t.me('راستی کارت چیه؟');
        t.say(npc.jobReveal || ('من ' + npc.job + 'م!'), 'talk');
        updateHUD(); spend(t, npc); setTimeout(t.refresh, 1500);
      });
    }

    // 💞 گپ دونفره: هر روز ۳ سوال فلرت‌گونه از طرف خودش — جوابت روی دلش اثر داره!
    const FQ = [
      { q: 'اگه یه روز کل تهران مال تو بود، اولین کاری که می‌کردی چی بود؟', a: [
        ['«یه جای دنج پیدا می‌کردم که با تو قهوه بخورم.»', 'kind'],
        ['«ترافیک رو ممنوع می‌کردم! بعدش نون سنگک مجانی برای همه!»', 'funny'],
        ['«اول یه برنامهٔ درست برای محله می‌ریختم.»', 'polite'],
        ['«به تو ربطی داره؟»', 'rude']]},
      { q: 'به نظرت آدم شانسشو خودش می‌سازه یا از آسمون میاد؟', a: [
        ['«شانس یعنی همین که الان دارم با تو حرف می‌زنم.»', 'kind'],
        ['«شانس من که همیشه ته صفه! ولی امروز انگار اول صف بودم!»', 'funny'],
        ['«به نظرم تلاش مهم‌تر از شانسه.»', 'polite'],
        ['«سوالای فلسفی نپرس حوصله ندارم.»', 'rude']]},
      { q: 'صبحا اول چایی یا اول گوشی؟ راستشو بگو!', a: [
        ['«اول یه فکر خوب... مثلاً به همین گفتگو!»', 'kind'],
        ['«اول گوشی، بعد چایی، بعد پشیمونی از هر دوتاش!»', 'funny'],
        ['«چایی. صبح بدون چایی شروع نمیشه.»', 'polite'],
        ['«چه سوال بی‌خودی.»', 'rude']]},
      { q: 'اگه یه سفر مجانی بهت بدن کجا میری؟', a: [
        ['«جایی که یه هم‌صحبت خوب مثل تو باشه.»', 'kind'],
        ['«اول شیراز که شکمو راه بندازم، بعد هرجا شد!»', 'funny'],
        ['«شمال. جنگل و دریا آرومم می‌کنه.»', 'polite'],
        ['«با پول خودم می‌رم، منت مجانی نمی‌کشم.»', 'rude']]},
      { q: 'یه چیزی بگو که هیچکس تو محله نمی‌دونه!', a: [
        ['«اینکه از وقتی تو رو دیدم محله برام قشنگ‌تر شده.»', 'kind'],
        ['«من ساعت سه صبح یخچالو چک می‌کنم ببینم چیزی جا نمونده!»', 'funny'],
        ['«رازها رو باید نگه داشت، ولی برای تو یه استثنا قائل میشم... به وقتش!»', 'polite'],
        ['«فضولی نکن.»', 'rude']]},
      { q: 'به نظرت خوشبختی یعنی چی؟', a: [
        ['«یعنی لحظه‌هایی مثل همین. ساده ولی واقعی.»', 'kind'],
        ['«یعنی جای پارک جلوی خونه پیدا کنی! تو تهران یعنی معجزه!»', 'funny'],
        ['«یعنی آرامش. بقیه‌ش اضافه‌ست.»', 'polite'],
        ['«این چرت و پرتا چیه می‌پرسی؟»', 'rude']]},
      { q: 'اگه بارون بگیره و چتر نداشته باشی چیکار می‌کنی؟', a: [
        ['«اگه تو هم باشی، بذار بباره! قدم می‌زنیم.»', 'kind'],
        ['«می‌دوئم زیر سایبون نونوایی، هم خشکه هم بوی نون میاد!»', 'funny'],
        ['«یه جا منتظر می‌مونم بند بیاد. عجله برای چی؟»', 'polite'],
        ['«خب خیس میشم دیگه، سوال داره؟»', 'rude']]},
      { q: 'فیلم غمگین یا فیلم خنده‌دار؟', a: [
        ['«فرقی نداره، مهم اینه با کی ببینی.»', 'kind'],
        ['«خنده‌دار! غم تو تورم به اندازه کافی هست!»', 'funny'],
        ['«فیلم خوب. ژانرش مهم نیست، حرفش مهمه.»', 'polite'],
        ['«فیلم دیدن اتلاف وقته.»', 'rude']]},
      { q: 'اگه ده سال دیگه منو تو محله ببینی، فکر می‌کنی چی شدم؟', a: [
        ['«هر چی شده باشی، مطمئنم همین‌قدر خاص موندی.»', 'kind'],
        ['«صاحب کل محله! منم میام ازت تخفیف می‌گیرم!»', 'funny'],
        ['«یه آدم موفق. معلومه هدف داری.»', 'polite'],
        ['«ده سال دیگه کی حوصله محله رو داره.»', 'rude']]},
    ];
    G.flirt = G.flirt || {};
    const fst = G.flirt[npc.id] || {};
    if (fst.day !== G.dayIndex) { fst.day = G.dayIndex; fst.used = 0; G.flirt[npc.id] = fst; }
    if (fst.used < 3) {
      t.option('💞 گپ دونفره', 'خودش یه سوال می‌پرسه! (' + fa(fst.used + 1) + ' از ۳ امروز) — جوابت مهمه!', () => {
        let h = 0; for (const ch of npc.id) h = (h + ch.charCodeAt(0)) % 97;
        const fq = FQ[(G.dayIndex * 3 + fst.used + h) % FQ.length];
        t.say(fq.q, 'talk');
        // گزینه‌ها فقط جواب‌های همین سوال (بُر خورده)
        const opts = $id('talkOpts'); opts.innerHTML = '';
        [...fq.a].sort(() => Math.random() - .5).forEach(([label, tone]) => {
          const b = document.createElement('button');
          b.className = 'talkOpt';
          b.innerHTML = '<span>' + label + '</span>';
          b.onclick = () => {
            fst.used++;
            talkMe(label.replace(/^«|»$/g, ''));
            if (tone === 'rude') {
              addAffection(npc.id, -14);
              G.upset = G.upset || {}; G.upset[npc.id] = G.dayIndex + 1;
              G.happy -= 5;
              talkSay('چی؟!... باشه. خیلی ممنون از وقتی که گذاشتی. خداحافظ!', 'angry');
              setTimeout(() => {
                closeTalk();
                if (window.WORLD?.insideOf?.() === npc.hangout) {
                  window.WORLD.exitInterior();
                  toast('🚪 از مغازه انداختت بیرون! (-۱۴ علاقه، تا فردا قهره)');
                } else toast('😤 رفت! (-۱۴ علاقه، تا فردا قهره)');
                updateHUD();
              }, 2000);
              return;
            }
            const score = toneScore(npc, tone);
            const gain = score >= 8 ? affGainFor(npc, 7) : score >= 3 ? affGainFor(npc, 4) : score >= 0 ? 1 : -6;
            addAffection(npc.id, gain);
            setTimeout(() => {
              talkSay(toneReact(npc, score), score >= 3 ? 'happy' : score >= 0 ? 'idle' : 'sad');
              updateHUD();
              setTimeout(() => talkRebuildFor(npc, tt => buildTalk(tt, npc)), 2100);
            }, 900);
          };
          opts.appendChild(b);
        });
      });
    } else {
      t.option('💞 گپ دونفره', '✅ سه سوال امروز تموم شد — فردا بازم!', () => {}, true);
    }
    const dateDone = usedToday(npc.id, 'date');
    t.option('☕ «میای بریم کافه؟»', dateDone ? '✅ امروز رفتید — فردا دوباره' : 'روزی فقط یک قرار!', () => {
      askDate(npc, t);
    }, dateDone);

    const walkDone = usedToday(npc.id, 'walk');
    t.option('🌳 دور زدن تو پارک', walkDone ? '✅ امروز رفتید' : faMoney(500000) + ' (بستنی) | +۵ علاقه', () => {
      if (getAffection(npc.id) < 12) { confirmEarly(t, npc, () => doWalk(t, npc)); return; }
      doWalk(t, npc);
    }, walkDone);
  }

  // ---- ازدواج / بچه / طلاق ----
  if (G.married === npc.id) {
    t.group('💍 زندگی مشترک');
    if (!G.childName) t.option('👶 «بچه؟»', 'هر وقت قسمت باشه! صبر کن...', () => {
      t.say('ان‌شاءالله به وقتش! این چیزا خبر نمی‌کنه... 😊', 'happy');
    });
    const mehrieh = Math.round(500000000 * G.eco.housingCoef);
    t.option('💔 طلاق', 'مهریه: ' + faMoney(mehrieh), () => {
      if (G.money < mehrieh) { toast('💸 مهریه رو نداری!'); return; }
      addMoney(-mehrieh); G.married = null;
      addAffection(npc.id, -60);
      G.upset = G.upset || {}; G.upset[npc.id] = G.dayIndex + 7;
      G.happy -= 15; sfx.sad();
      showBanner('💔 طلاق گرفتید! ملوک‌خانم تا شب خبرش رو به کل محل رسوند!', 6000);
      addLog('💔 از ' + npc.name + ' جدا شدی. مهریه: ' + faMoney(mehrieh));
      updateHUD(); closeTalk();
    });
  } else if (!G.married && (!npc.marriageable || getAffection(npc.id) >= 70)) {
    // خواستگاری برای دخترا فقط وقتی ظاهر میشه که علاقه به ۷۰+ رسیده باشه
    t.option('💍 خواستگاری', npc.marriageable ? fa(DATES_NEEDED) + '+ قرار و علاقه ۹۵+' : 'مطمئنی؟! 🤨', () => {
      const r = tryMarry(npc);
      if (r.ok) {
        showBanner(r.msg); addLog(r.msg); window.WORLD?.onMarried?.(npc); throwParty();
        t.say('بله! 💍 قبولت دارم!', 'love');
        setTimeout(closeTalk, 2500);
      } else {
        sfx.sad();
        t.say(r.msg.replace(npc.name + ': ', '').replace(/[«»]/g, ''), 'sad');
        if (!npc.marriageable) { G.happy -= 2; addLog('😅 سوتی دادی جلوی ' + npc.name + '!'); }
      }
      updateHUD();
    });
  }
}

function doWalk(t, npc) {
  if (G.money < 500000) { toast('💸 پول بستنی هم نداری؟!'); return; }
  useToday(npc.id, 'walk');
  addMoney(-500000); addAffection(npc.id, affGainFor(npc, 5)); G.happy += 4;
  G.dates[npc.id] = datesWith(npc.id) + 1;
  t.me('بریم یه دور تو پارک بزنیم؟');
  t.say('چه هوایی! قدم زدن با تو حال میده... حتی تو هوای آلوده! 😄', 'happy');
  advanceTime(2);
  maybeJealousy(npc.id);
  wifeCatchCheck(npc.id);
  updateHUD(); setTimeout(t.refresh, 1600);
}

// ---------- تذکر «خیلی زوده، مطمئنی؟» ----------
function confirmEarly(t, npc, onYes) {
  talkSay('هوم... ما که تازه همو دیدیم. مطمئنی می‌خوای همین الان بپرسی؟ 🤨', 'idle');
  const opts = $id('talkOpts');
  opts.innerHTML = '';
  const mk = (label, sub, fn, cls) => {
    const b = document.createElement('button');
    b.className = 'talkOpt' + (cls || '');
    b.innerHTML = '<span>' + label + '</span>' + (sub ? '<small>' + sub + '</small>' : '');
    b.onclick = fn;
    opts.appendChild(b);
  };
  mk('✅ آره مطمئنم، می‌پرسم', 'ممکنه بد بشه ها!', () => onYes());
  mk('↩️ نه بابا، بی‌خیال', 'برگرد به گفتگو', () => t.refresh(), ' bye');
}

// ---------- درخواست قرار ----------
function askDate(npc, t) {
  if (isUpset(npc.id)) { talkSay('😤 قهرم! اول آشتی کن.', 'angry'); return; }
  if (usedToday(npc.id, 'date')) { talkSay('امروز که رفتیم! فردا دوباره. 😊', 'happy'); return; }
  const aff = getAffection(npc.id);
  const early = aff < (npc.hardMode ? 45 : 25);
  const ask = () => {
    talkMe('میای بریم کافه؟');
    if (early) {
      if (softHearts().includes(npc.id) && aff >= 8) {
        talkSay('راستش... خیلی زوده ها! ولی باشه، فقط یه قهوه. 😊', 'happy');
        setTimeout(() => { if (talkIsWith(npc)) startDate(npc); }, 1600);
        return;
      }
      const burn = -8 - Math.floor(Math.random() * 8);
      addAffection(npc.id, burn);
      G.happy -= 4;
      const lines = [
        'خیلی زوده! ما تازه دو کلمه حرف زدیم. تو چقدر عجله داری؟! 😒',
        'ببخشید ولی هنوز هیچی نشده! برو آقا مزاحم نشو.',
        'نه ممنون. یه کم آدم باید صبر داشته باشه.',
        'جدی؟! تو مشکلی داری؟ ما همدیگه رو نمی‌شناسیم اصلاً!',
      ];
      talkSay(lines[Math.floor(Math.random() * lines.length)], 'angry');
      toast('😬 خورد تو ذوقت! (' + fa(burn) + ' علاقه) — اول آشنا شو.');
      updateHUD();
      setTimeout(() => { talkRebuildFor(npc, tt => buildTalk(tt, npc)); }, 1900);
      return;
    }
    if (aff < 45 && Math.random() < .25) {
      talkSay('امروز نمی‌تونم... کار دارم! شاید یه وقت دیگه. 🙃', 'idle');
      setTimeout(() => { talkRebuildFor(npc, tt => buildTalk(tt, npc)); }, 1700);
      return;
    }
    talkSay('آره چرا که نه! بریم. ☕', 'love');
    setTimeout(() => { if (talkIsWith(npc)) startDate(npc); }, 1500);
  };
  if (early) confirmEarly(t || { refresh: () => talkRebuild(tt => buildTalk(tt, npc)) }, npc, ask);
  else ask();
}

function startDate(npc) {
  useToday(npc.id, 'date');
  closeTalk();
  playCutscene('☕ ' + npc.name.split(' (')[0] + ' قبول کرد! با هم راه افتادید سمت کافه تورم...', 3000, () => {});
  if (window.WORLD?.cafeDate) window.WORLD.cafeDate(npc, () => openDate(npc));
  else if (window.WORLD?.dateCutscene) window.WORLD.dateCutscene(npc, () => openDate(npc));
  else setTimeout(() => openDate(npc), 3200);
}

// ---------- کات‌سین ----------
let cutsceneActive = false;
function playCutscene(caption, ms, done) {
  cutsceneActive = true;
  closePanel();
  const c = $id('cutscene');
  $id('cutCaption').textContent = caption;
  c.classList.add('show');
  setTimeout(() => {
    c.classList.remove('show');
    cutsceneActive = false;
    done && done();
  }, ms);
}

// ---------- قرار کافه: سر میز، گارسون میاد ----------
const CAFE_MENU = [
  { name:'🥤 آیس کارامل ماکیاتو دبل', base:3500000, aff:12, react:'واای این همون چیزیه که تو استوری‌ها دیدم! تو بهترینی! 😍' },
  { name:'☕ لاته با لاته‌آرت', base:2200000, aff:8, react:'قلب کشیده روش! ببین! ... طرحش یه کم شبیه سیب‌زمینیه ولی قلبه دیگه! 😊' },
  { name:'🫖 چای و کیک', base:1400000, aff:5, react:'چای هم خوبه... کلاسیکه! (لبخند نصفه)' },
  { name:'☕ دو تا قهوه ترک ساده', base:900000, aff:2, react:'هوم... قهوه ترک. باشه. فال که می‌گیریم توش، مجانیه!' },
  { name:'💧 دو تا آب معدنی', base:300000, aff:-6, react:'آب؟! جدی؟! ... چرا پول نمیدی؟ اصلاً خودم دونگمو میدم! 😤' },
];
function openDate(npc) {
  if (isUpset(npc.id)) { toast('😤 قهره! اول آشتی کن.'); return; }
  talkOpen(npc, t => {
    t.say('نشستیم سر میز... گارسون اومد بالای سرمون: «در خدمتم! چی میل دارید؟»', 'idle');
    CAFE_MENU.forEach(item => {
      const price = Math.round(item.base * G.eco.housingCoef);
      t.option(item.name, faMoney(price) + (item.aff >= 8 ? ' | 🤩' : item.aff > 0 ? ' | 🙂' : ' | 😬 ریسکی!'), () => {
        if (G.money < price) { toast('💸 پولت نمی‌رسه!'); return; }
        addMoney(-price);
        t.me('دو تا ' + item.name.replace(/^\S+\s/, '') + ' لطفاً.');
        finishDate(npc, item.aff, item.react);
      });
    });
    t.option('💸 «بیا دونگی حساب کنیم!»', npc.independent ? 'اون مشکلی نداره!' : '⚠️ به کلاسش برمی‌خوره!', () => {
      t.me('بیا دونگی حساب کنیم.');
      if (npc.independent) finishDate(npc, 6, 'دقیقاً! حساب جدا، دوستی پابرجا! خوشم اومد منطقی هستی! 😎');
      else {
        addAffection(npc.id, -8);
        if (Math.random() < .4) { G.upset = G.upset || {}; G.upset[npc.id] = G.dayIndex + 1; }
        t.say('دونگی؟! ... باشه. (کیفشو برداشت و رفت حساب کرد. قیافه‌ش دیدنیه!) 😤', 'angry');
        toast('😬 خوشش نیومد! (-۸ علاقه)');
        advanceTime(1); updateHUD();
        setTimeout(() => { closeTalk(); window.WORLD?.endDate?.(); }, 2200);
      }
    });
  });
}
function finishDate(npc, affGain, react) {
  addAffection(npc.id, affGainFor(npc, affGain));
  G.happy += Math.max(0, affGain);
  G.dates[npc.id] = datesWith(npc.id) + 1;
  advanceTime(2);
  talkSay(react, affGain > 0 ? 'love' : 'angry');
  if (G.married && G.married !== npc.id) {
    const wife = NPCS.find(n => n.id === G.married);
    setTimeout(() => {
      sfx.ring();
      const caught = wifeCatchCheck(npc.id);
      if (!caught) {
        talkSay('📱 گوشیت داره زنگ می‌خوره... ' + wife.name.split(' (')[0] + 'ئه! چرا جواب نمیدی؟! 🤨', 'angry');
        addAffection(npc.id, -10); addAffection(wife.id, -15); G.happy -= 5;
        showBanner('📱 ' + wife.name.split(' (')[0] + ' هفت بار زنگ زد!', 5000);
      } else setTimeout(() => { closeTalk(); window.WORLD?.endDate?.(); }, 2400);
      updateHUD();
    }, 2500);
  }
  const j = jealousyCheck(npc.id);
  if (j) { showBanner(j, 6000); addLog(j); }
  updateHUD();
  toast(affGain > 0 ? '💕 قرار ثبت شد! (' + fa(datesWith(npc.id)) + ' از ' + fa(DATES_NEEDED) + ') — فردا دوباره!' : '😬 قرار خوبی نبود...');
  if (affGain > 0 && Math.random() < .6) setTimeout(() => { if (talkIsWith(npc)) openDateTalk(npc); }, 1600);
  else setTimeout(() => { talkRebuildFor(npc, tt => buildTalk(tt, npc)); }, 1900);
}
function openDateTalk(npc) {
  const dq = randomDateQuestion();
  talkOpen(npc, t => {
    t.say(dq.q, 'talk');
    [...dq.options].sort(() => Math.random() - .5).forEach(opt => {
      t.option(opt.label, '', () => {
        t.me(opt.label);
        const score = toneScore(npc, opt.tone);
        addAffection(npc.id, affGainFor(npc, score));
        t.say(toneReact(npc, score), score >= 3 ? 'love' : score < 0 ? 'angry' : 'idle');
        updateHUD();
        setTimeout(() => { talkRebuildFor(npc, tt => buildTalk(tt, npc)); }, 2100);
      });
    });
  });
}

// ---------- بچه: بازی، بزرگ شدن، ادامهٔ بازی با اون ----------
const CHILD_PLAY = [
  'با هم لِگو ساختید؛ یه برج زد که سه بار ریخت و هر بار بلندتر ساختش!',
  'قایم‌باشک بازی کردید. رفت پشت پرده و پاهاش بیرون بود، به روش نیاوردی!',
  'نقاشی کشید: یه خونه با یه خورشید گنده و سه تا آدمک. گفت این ماییم.',
  'قصهٔ شب گفتی براش؛ وسطش خوابش برد ولی تو تا آخرش گفتی.',
  'با توپ تو حیاط بازی کردید. گلدون همسایه شکست، جفتتون فرار کردید!',
  'ازت پرسید چرا آسمون آبیه. جواب دادی، قانع نشد، ولی خندید.',
];
function playWithChild() {
  if (!G.childName) return;
  if (usedToday('child', 'play')) { toast('👶 امروز کلی باهاش بازی کردی! فردا دوباره.'); return; }
  useToday('child', 'play');
  G.happy = Math.min(100, G.happy + 12);
  G.energy = Math.max(0, G.energy - 6);
  G.childBond = (G.childBond || 0) + 5;
  const line = CHILD_PLAY[Math.floor(Math.random() * CHILD_PLAY.length)];
  showBanner('👶 ' + G.childName + ': ' + line, 5200);
  addLog('👶 با ' + G.childName + ' بازی کردی. (+۱۲ شادی)');
  advanceTime(1);
  updateHUD();
}

// بعد از ۳۰ روز بچه بزرگ میشه و می‌ره مدرسه
function checkChildGrowth() {
  if (!G.childName || G.childGrown || G.childBornDay == null) return;
  if (G.dayIndex - G.childBornDay < 40) return;      // «بیست سالگی» به وقت بازی
  G.childGrown = true;
  setTimeout(openGenerationHandover, 1200);
}

// ---------- چرخهٔ نسل: پدر و مادر میرن شیراز، تو میشی بچه ----------
const GEN_M = ['جمشید','فرهاد','بهروز','کامران','سیاوش','هوشنگ','پرویز','بهنام','اردلان','منوچهر','فریدون','رامین','سهراب','کیوان','آرمان'];
const GEN_F = ['فرشته','مهتاب','پروانه','گلناز','سیمین','آفاق','مینا','فریبا','ترانه','شکوفه','مهناز','گیتا','لادن','نسرین','پگاه'];
const GEN_K = ['نیما','آیدا','بردیا','درسا','ماهان','ستایش'];
function makeGenNames(gen) {
  const used = new Set(), map = {};
  NPCS.forEach((n, i) => {
    const pool = n.kid ? GEN_K : n.gender === 'f' ? GEN_F : GEN_M;
    let idx = (i * 7 + gen * 13) % pool.length, guard = 0;
    while (used.has(pool[idx]) && guard++ < pool.length) idx = (idx + 1) % pool.length;
    used.add(pool[idx]);
    map[n.id] = pool[idx];
  });
  return map;
}
function applyGenNames() {
  if (!window.__ORIG_NPC_NAMES) {
    window.__ORIG_NPC_NAMES = {};
    NPCS.forEach(n => window.__ORIG_NPC_NAMES[n.id] = n.name);
  }
  NPCS.forEach(n => { n.name = (G.npcNames && G.npcNames[n.id]) || window.__ORIG_NPC_NAMES[n.id]; });
}
function openGenerationHandover() {
  const kid = G.childName;
  openPanel('🎓 ' + kid + ' بیست ساله شد!', p => {
    noteP(p, kid + ' بزرگ شد؛ آکادمی نوین‌ذهن رو تموم کرد و برای خودش کسی شده! ' +
      'پدر و مادر تصمیم گرفتن برن شیراز پیش فامیل: «این خونه و زندگی مال توئه. بعداً بهت سر می‌زنیم!» 🧳');
    actionRow(p, '🧑 ادامه با ' + kid, 'نسل جدید! یه مقدار پول برات گذاشتن؛ محله همونه ولی آدم‌های تازه می‌شناسی', () => {
      startNextGeneration();
    });
    actionRow(p, '⏳ حالا نه، چند روز دیگه', 'بعداً دوباره می‌پرسیم', () => {
      G.childGrown = false;
      G.childBornDay += 3;
      closePanel();
    });
  });
}
function startNextGeneration() {
  const kid = G.childName;
  const gen = (G.generation || 1) + 1;
  const names = makeGenNames(gen);
  const mode = G.mode;
  const wname = (NPCS.find(n => n.id === G.married)?.name || 'مامان').split(' (')[0];
  closePanel();
  // ۱) کات‌سین خداحافظی مامان و بابا
  if (typeof sayFa === 'function') sayFa('ما می‌ریم شیراز پیش فامیل. این خونه و محله مال توئه. بعداً بهت سر می‌زنیم!', .98, .8, 'm');
  playCutscene('🧳 بابا و ' + wname + ' چمدون به دست: «ما می‌ریم شیراز پیش فامیل... این خونه و محله مال توئه پسرم. مواظب خودت باش، بعداً بهت سر می‌زنیم!» 👋', 5200, () => {
    // ۲) تیتراژ
    showCredits(gen, kid, () => {
      // ۳) شروع از صفر — دقیقاً همون‌جا و همون‌جوری که بابا شروع کرد
      const keptBadges = G.badges || {};
      G = defaultGameState();
      G.mode = mode;
      G.generation = gen;
      G.npcNames = names;
      G.badges = keptBadges;      // نشان‌ها میراث خانوادگیه!
      applyGenNames();
      addLog('🧬 نسل ' + fa(gen) + ' شروع شد: ' + kid + ' — از همون نقطه‌ای که بابا شروع کرده بود!');
      launchGame(mode, true);
      showBanner('🧬 حالا تو ' + kid + ' هستی؛ ۲۰ ساله، با همون شروعی که بابات داشت. محله همونه، آدم‌ها تازه‌ن!', 9000);
      sfx.party();
    });
  });
}

// ---------- تیتراژ پایان نسل ----------
function showCredits(gen, kid, done) {
  const el = document.createElement('div');
  el.id = 'creditsWrap';
  el.style.cssText = 'position:fixed;inset:0;z-index:2000;background:#000;overflow:hidden;cursor:pointer';
  const inner = document.createElement('div');
  inner.style.cssText = 'position:absolute;left:0;right:0;top:100%;text-align:center;color:#f5e6c8;font-size:17px;line-height:2.6;animation:creditRoll 16s linear forwards';
  const castNames = NPCS.filter(n => !n.deco).slice(0, 12).map(n => n.name.split(' (')[0]).join(' · ');
  inner.innerHTML =
    '<div style="font-size:34px;color:#ffd166;margin-bottom:8px">🏙️ تهران ۱۴۰۵ — محله‌باز</div>' +
    '<div style="font-size:20px;color:#e8a83c">پایان نسل ' + fa(gen - 1) + '</div>' +
    '<br><div>🎬 کیان تقدیم می‌کند</div>' +
    '<div>🤖 آکادمی رباتیک نوین‌ذهن — NOVINZEHN.COM</div>' +
    '<br><div style="color:#9a86c8">با حضور اهالی محله:</div>' +
    '<div style="font-size:14px;max-width:600px;margin:0 auto">' + castNames + '</div>' +
    '<br><div>💍 با تشکر ویژه از خانواده‌ای که ساختی</div>' +
    '<div>🧳 پدر و مادر — عازم شیراز</div>' +
    '<br><br><div style="font-size:26px;color:#ffd166">نسل بعد: ' + kid + '</div>' +
    '<div style="font-size:14px;color:#888">همه‌چیز از ابتدا...</div>' +
    '<br><div style="font-size:12px;color:#666">(برای رد شدن کلیک کن)</div>';
  if (!$id('creditStyle')) {
    const st = document.createElement('style');
    st.id = 'creditStyle';
    st.textContent = '@keyframes creditRoll { from { transform: translateY(0); } to { transform: translateY(-160vh); } }';
    document.head.appendChild(st);
  }
  el.appendChild(inner);
  document.body.appendChild(el);
  let finished = false;
  const finish = () => { if (finished) return; finished = true; el.remove(); done(); };
  el.addEventListener('click', finish);
  setTimeout(finish, 16500);
}
function openChildHandover() {
  openPanel('🎒 ' + G.childName + ' رفت مدرسه!', p => {
    noteP(p, 'سی روز گذشت. ' + G.childName + ' کوله‌شو انداخت رو دوشش و رفت مدرسه. ' +
      'می‌خوای بقیهٔ بازی رو با ' + G.childName + ' ادامه بدی؟ (تو نقش بچه، با دوستای مدرسه‌ای‌ش)');
    actionRow(p, '🧒 آره، با ' + G.childName + ' ادامه بده', 'شخصیت بازی عوض میشه — پول و خونه سر جاشه', () => {
      G.child = true;
      G.happy = Math.min(100, G.happy + 20);
      showBanner('🧒 حالا ' + G.childName + ' هستی! دوستات تو پارک منتظرن.', 6000);
      addLog('🧒 بازی با ' + G.childName + ' ادامه پیدا کرد.');
      window.WORLD?.onChildMode?.();
      closePanel(); updateHUD();
    });
    actionRow(p, '👨 نه، خودم ادامه می‌دم', 'بچه تو خونه بزرگ میشه', () => { closePanel(); });
  });
}

// ---------- لیدربورد روابط ----------
function openLeaderboard() {
  // فقط کسایی که واقعاً باهاشون در ارتباط بودی!
  const known = NPCS.filter(n => G.met?.[n.id] || getAffection(n.id) > 0);
  const sorted = [...known].sort((a, b) => getAffection(b.id) - getAffection(a.id));
  const friends = known.filter(n => getAffection(n.id) >= 30).length;
  const best = sorted[0];
  openPanel('🏆 روابط و دوستی‌ها', p => {
    if (!known.length) {
      noteP(p, 'هنوز با کسی آشنا نشدی! برو تو شهر بچرخ، با آدما حرف بزن... محله پر از آدمای باحاله!');
      return;
    }
    noteP(p, '👥 آشناها: ' + fa(known.length) + ' نفر | دوست‌های صمیمی (علاقه ۳۰+): ' + fa(friends) + ' نفر' +
      (getAffection(best.id) > 0 ? ' | 🥇 بهترین رابطه: ' + best.name.split(' (')[0] : '') +
      (G.married ? ' | 💍 همسر: ' + NPCS.find(n=>n.id===G.married).name.split(' (')[0] : '') +
      (G.childName ? ' | 👶 ' + G.childName : ''));
    sorted.forEach((n, i) => {
      const aff = getAffection(n.id);
      const row = document.createElement('div');
      row.className = 'lbRow';
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : fa(i + 1);
      const status = G.married === n.id ? '💍' : isUpset(n.id) ? '😤 قهر' : n.marriageable ? '💗' : '🤝';
      row.innerHTML = '<span class="lbRank"></span><span class="lbName"></span><span class="lbStat"></span><div class="lbBarWrap"><i></i></div><span class="lbPct"></span>';
      row.querySelector('.lbRank').textContent = medal;
      row.querySelector('.lbName').textContent = n.name;
      row.querySelector('.lbStat').textContent = status;
      row.querySelector('.lbBarWrap i').style.width = aff + '%';
      row.querySelector('.lbPct').textContent = fa(aff) + '٪';
      p.appendChild(row);
    });
  });
}

// ---------- اخبار ----------
function openNews() {
  $id('newsBadge').style.display = 'none';
  openPanel('📰 اخبار اقتصادی و شهری', p => {
    if (!newsList.length) noteP(p, 'فعلاً خبری نیست... که خودش بهترین خبره!');
    newsList.forEach(n => {
      const d = document.createElement('p');
      d.className = 'newsItem'; d.textContent = n;
      p.appendChild(d);
    });
  });
}

// ---------- خواب اجباری نصفه‌شب ----------
function checkForcedSleep() {
  if (!gameStarted || G.traveling) return;
  const outOfEnergy = G.energy <= 0;
  if (G.hour !== 3 && !outOfEnergy) return;
  closePanel();
  if (typeof closeTalk === 'function' && typeof dialogueOpen !== 'undefined' && dialogueOpen) closeTalk();
  G.energy = 60; G.health -= 3;
  G.hour = 7; G.minute = 0;
  runDailyTick();
  // بردنت خونه و خوابیدی
  const home = buildingById('home');
  if (home) { G.px = home.x; G.pz = home.z + home.d / 2 + 3; window.WORLD?.teleport?.(G.px, G.pz); }
  showBanner(outOfEnergy
    ? '😴 دیگه انرژی نداشتی! خوابت می‌اومد... بردیمت خونه و تا صبح خوابیدی. (انرژی: ۶۰)'
    : '😴 ساعت ۳ نصفه‌شبه! چشمات باز نموند... بردیمت خونه خوابیدی. (خواب بی‌کیفیت: انرژی ۶۰)', 6000);
  addLog('😴 شب شد و خوابت برد؛ صبح تو خونه بیدار شدی.');
  updateHUD();
}

// ---------- نقشهٔ شهر (مشترک بین مینی‌مپ و نقشهٔ بزرگ) ----------
function paintCityMap(ctx, size, withNames) {
  const RANGE = 800;                       // دنیا: -۴۰۰ تا +۴۰۰
  const S = size / RANGE;
  const mx = x => (Math.max(-400, Math.min(400, x)) + 400) * S;
  const my = z => (Math.max(-400, Math.min(400, z)) + 400) * S;

  // زمین سبز محله
  const g = ctx.createLinearGradient(0, 0, 0, size);
  g.addColorStop(0, '#5f7d4a'); g.addColorStop(1, '#4d6a3e');
  ctx.fillStyle = g; ctx.fillRect(0, 0, size, size);
  // بافت نقطه‌ای چمن
  ctx.fillStyle = 'rgba(255,255,255,.05)';
  for (let i = 0; i < size; i += 14) for (let j = 0; j < size; j += 14)
    if ((i + j) % 42 === 0) ctx.fillRect(i, j, 1.5, 1.5);

  // خیابون‌ها: آسفالت با حاشیه و خط‌کشی وسط
  for (const r of ROADS) {
    const from = Math.max(-390, r.from), to = Math.min(390, r.to);
    const len = (to - from) * S;
    if (r.dir === 'h') {
      ctx.fillStyle = '#c9c4b5';
      ctx.fillRect(mx(from), my(r.c - r.hw) - 1.5, len, r.hw * 2 * S + 3);
      ctx.fillStyle = r.main ? '#4e565f' : '#5c646d';
      ctx.fillRect(mx(from), my(r.c - r.hw), len, r.hw * 2 * S);
      if (r.main) {
        ctx.strokeStyle = '#e9c860'; ctx.lineWidth = Math.max(1, S * 1.2); ctx.setLineDash([6, 5]);
        ctx.beginPath(); ctx.moveTo(mx(from), my(r.c)); ctx.lineTo(mx(to), my(r.c)); ctx.stroke();
        ctx.setLineDash([]);
      }
    } else {
      ctx.fillStyle = '#c9c4b5';
      ctx.fillRect(mx(r.c - r.hw) - 1.5, my(from), r.hw * 2 * S + 3, len);
      ctx.fillStyle = r.main ? '#4e565f' : '#5c646d';
      ctx.fillRect(mx(r.c - r.hw), my(from), r.hw * 2 * S, len);
      if (r.main) {
        ctx.strokeStyle = '#e9c860'; ctx.lineWidth = Math.max(1, S * 1.2); ctx.setLineDash([6, 5]);
        ctx.beginPath(); ctx.moveTo(mx(r.c), my(from)); ctx.lineTo(mx(r.c), my(to)); ctx.stroke();
        ctx.setLineDash([]);
      }
    }
  }
  // اسم خیابون‌های اصلی (فقط نقشهٔ بزرگ)
  if (withNames) {
    ctx.fillStyle = 'rgba(255,255,255,.85)';
    ctx.font = 'bold ' + Math.round(size / 58) + 'px Vazirmatn, Tahoma';
    for (const r of ROADS) {
      if (!r.name) continue;
      ctx.save();
      if (r.dir === 'h') { ctx.textAlign = 'left'; ctx.fillText(r.name, mx(Math.max(-380, r.from)) + 6, my(r.c) - r.hw * S - 3); }
      else { ctx.translate(mx(r.c), my(Math.max(-380, r.from)) + 8); ctx.rotate(Math.PI / 2); ctx.textAlign = 'left'; ctx.fillText(r.name, 4, -3); ctx.restore(); continue; }
      ctx.restore();
    }
  }

  // ساختمون‌ها: بلوک با سایه و آیکون؛ اسم‌ها یکی بالا یکی پایین که تو هم نرن
  let nameIdx = 0;
  for (const b of BUILDINGS) {
    const bx = mx(b.x - b.w / 2), bz = my(b.z - b.d / 2), bw = b.w * S, bd = b.d * S;
    ctx.fillStyle = 'rgba(0,0,0,.25)';
    ctx.beginPath(); ctx.roundRect(bx + 2, bz + 2.5, bw, bd, 3); ctx.fill();
    ctx.fillStyle = b.kind === 'open' ? '#2d6a4f' : '#' + b.color.toString(16).padStart(6, '0');
    ctx.globalAlpha = b.deco ? .55 : 1;
    ctx.beginPath(); ctx.roundRect(bx, bz, bw, bd, 3); ctx.fill();
    ctx.globalAlpha = 1;
    if (!b.deco && b.icon) {
      ctx.font = Math.max(9, Math.min(bw, bd) * .55) + 'px Vazirmatn, Tahoma';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(b.icon, bx + bw / 2, bz + bd / 2);
      if (withNames && b.name) {
        const above = (nameIdx++ % 2) === 1;
        const ny = above ? bz - size / 90 : bz + bd + size / 80;
        ctx.font = 'bold ' + Math.round(size / 60) + 'px Vazirmatn, Tahoma';
        ctx.textBaseline = above ? 'bottom' : 'top';
        ctx.fillStyle = '#fff';
        ctx.strokeStyle = 'rgba(0,0,0,.75)'; ctx.lineWidth = 4; ctx.lineJoin = 'round';
        ctx.strokeText(b.name, bx + bw / 2, ny);
        ctx.fillText(b.name, bx + bw / 2, ny);
        ctx.textBaseline = 'middle';
      }
    }
  }

  // بازیکن
  const px = mx(G.px), py = my(G.pz);
  ctx.beginPath(); ctx.arc(px, py, size * .045 * .8, 0, 7);
  ctx.fillStyle = 'rgba(255,34,68,.2)'; ctx.fill();
  ctx.beginPath(); ctx.arc(px, py, Math.max(3.4, size * .012), 0, 7);
  ctx.fillStyle = '#ff2244'; ctx.fill();
  ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
  if (withNames) {
    ctx.font = 'bold ' + Math.round(size / 46) + 'px Vazirmatn, Tahoma';
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
    ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.lineWidth = 3;
    ctx.strokeText('📍 تو اینجایی', px, py - size / 45);
    ctx.fillText('📍 تو اینجایی', px, py - size / 45);
  }
}

function drawMinimap() {
  const c = $id('minimap');
  if (!c || !gameStarted) return;
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  ctx.save();
  ctx.beginPath(); ctx.roundRect(0, 0, c.width, c.height, 9); ctx.clip();
  paintCityMap(ctx, c.width, false);
  // شمال + راهنمای باز کردن نقشهٔ کامل
  ctx.fillStyle = 'rgba(0,0,0,.45)';
  ctx.fillRect(0, 0, c.width, 14);
  ctx.fillStyle = '#ffd166';
  ctx.font = 'bold 9px Vazirmatn, Tahoma'; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.fillText('🧭 شمال — کلیک: نقشهٔ کامل (M)', c.width / 2, 10.5);
  ctx.restore();
}
setInterval(drawMinimap, 1500);   // ⚡ کمتر = سبک‌تر

// ---------- نقشهٔ بزرگ فول‌اسکرین شهر با اسم همهٔ مکان‌ها ----------
let cityMapEl = null;
function closeCityMap() { if (cityMapEl) { cityMapEl.remove(); cityMapEl = null; } }
function openCityMap() {
  if (cityMapEl) { closeCityMap(); return; }        // M دوباره = بستن
  closePanel();
  cityMapEl = document.createElement('div');
  cityMapEl.style.cssText = 'position:fixed;inset:0;z-index:60;background:radial-gradient(circle at 50% 35%,rgba(38,70,88,.8),rgba(5,8,18,.97) 68%);backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px';
  const size = Math.min(innerWidth, innerHeight) - 36;
  const c = document.createElement('canvas');
  // رزولوشن دوبرابر که نوشته‌ها تیز باشن
  c.width = c.height = size * 2;
  c.style.cssText = `width:${size}px;height:${size}px;border-radius:22px;border:2px solid rgba(255,209,102,.65);box-shadow:0 28px 90px rgba(0,0,0,.78),inset 0 0 0 6px rgba(255,255,255,.025)`;
  const ctx = c.getContext('2d');
  ctx.scale(2, 2);
  paintCityMap(ctx, size, true);
  const bar = document.createElement('div');
  bar.style.cssText = 'display:flex;flex-wrap:wrap;justify-content:center;gap:14px;align-items:center;color:#ffd166;font-size:13px;background:rgba(18,22,35,.82);border:1px solid rgba(255,255,255,.1);padding:8px 12px;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.35)';
  bar.innerHTML = '<b>TEHRAN 1405 • نقشهٔ زنده</b><span>📍 موقعیت تو</span><span>🏪 خدمات</span><span>🌳 فضای سبز</span><span>🛣️ خیابان اصلی</span>';
  const x = document.createElement('button');
  x.textContent = '✕ بستن (M یا Esc)';
  x.style.cssText = 'background:#e63946;color:#fff;border:none;border-radius:10px;padding:8px 22px;font-size:14px;cursor:pointer;font-family:inherit';
  x.onclick = closeCityMap;
  bar.appendChild(x);
  cityMapEl.append(c, bar);
  cityMapEl.addEventListener('click', e => { if (e.target === cityMapEl) closeCityMap(); });
  document.body.appendChild(cityMapEl);
}
$id('minimap')?.addEventListener('click', () => { if (gameStarted) openCityMap(); });

// ---------- فعالیت‌های باشگاه: تردمیل، وزنه، پرش ----------
function doGymActivity(act) {
  if (G.energy < 15) { toast('😴 انرژی نداری! اول یه چیزی بخور یا بخواب.'); return; }
  if (act === 'run') {
    G.energy -= 12; G.health += 8; G.happy += 5;
    toast('🏃 ده دقیقه دویدی! نفست بالا نمیاد ولی حالت عالیه! (+۸ سلامتی +۵ شادی)');
  } else if (act === 'lift') {
    G.energy -= 15; G.health += 10; G.happy += 4;
    toast('🏋️ وزنه زدی! فردا دستات درد می‌کنه ولی می‌ارزه! (+۱۰ سلامتی +۴ شادی)');
  } else {
    G.energy -= 8; G.happy += 8; G.health += 4;
    toast('🤸 پرش و نرمش! مربی گفت «آفرین! فقط قر نده!» (+۸ شادی +۴ سلامتی)');
  }
  missionTick('gym');
  advanceTime(1);
  updateHUD();
}

// ---------- جشن عروسی ----------
function throwParty() {
  sfx.party();
  const p = $id('party');
  p.style.display = 'block';
  const colors = ['#ffd166','#ef476f','#06d6a0','#118ab2','#ff9770'];
  for (let i = 0; i < 90; i++) {
    const c = document.createElement('div');
    c.className = 'confetti';
    c.style.right = Math.random() * 100 + 'vw';
    c.style.background = colors[i % colors.length];
    c.style.animationDuration = (2 + Math.random() * 2) + 's';
    c.style.animationDelay = Math.random() * 1.5 + 's';
    p.appendChild(c);
  }
  setTimeout(() => { p.style.display = 'none'; p.querySelectorAll('.confetti').forEach(e => e.remove()); }, 5000);
}

// ---------- گوشی تلفن: زنگ زدن به دوستا و دخترا ----------
function openPhone() {
  if (!G.phone) { toast('📱 گوشی نداری! برو موبایل‌فروشی.'); return; }
  if (G.phoneBroken) { toast('📱💔 گوشیت شکسته‌ست! اول تعمیرش کن.'); return; }
  const contacts = NPCS.filter(n => G.met?.[n.id] || getAffection(n.id) > 0);
  openPanel('📱 گوشی', p => {
    if (G.internetDown) noteP(p, '📵 اینترنت قطعه ولی تماس صوتی کار می‌کنه... فعلاً!');
    // اپ‌های گوشی
    const apps = document.createElement('div');
    apps.style.cssText = 'display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px';
    [['📋','مأموریت', () => { closePanel(); openMissions(); }],
     ['📰','اخبار',   () => { closePanel(); openNews(); }],
     ['🗺️','نقشه',   () => { closePanel(); openCityMap(); }],
     ['🏆','روابط',  () => { closePanel(); openLeaderboard(); }],
     ['🏅','نشان‌ها', () => { closePanel(); openBadges(); }],
     ['📩','پیام‌ها', () => { closePanel(); openSMS(); }],
     ['🎒','کوله',   () => { closePanel(); openBag(); }],
     ['📔','خاطرات', () => { closePanel(); openJournal(); }],
     ['👔','کمد',    () => { closePanel(); openWardrobe(); }],
     ['📷','آلبوم',  () => { closePanel(); openAlbum(); }],
     ['🐾','حیوون',  () => { closePanel(); openPetShop(); }],
     ['💸','هزینه‌ها',() => { closePanel(); openExpenses(); }],
     ['⚙️','تنظیمات',() => { closePanel(); openSettings(); }]].forEach(([ic, lb, fn]) => {
      const b = document.createElement('button');
      b.innerHTML = `<div style="font-size:22px">${ic}</div><div style="font-size:10px;margin-top:2px">${lb}</div>`;
      b.style.cssText = 'background:rgba(255,255,255,.07);border:1px solid rgba(255,209,102,.25);border-radius:12px;padding:8px 4px;color:#fff;cursor:pointer;font-family:inherit';
      b.onclick = fn;
      apps.appendChild(b);
    });
    p.appendChild(apps);
    noteP(p, '💰 موجودی: ' + faMoney(G.money) + ' | ⭐ شرافت: ' + fa(G.honor ?? 50) + ' | 💵 دلار: ' + fa(G.eco.dollar));
    actionRow(p, '🚕 تماس با تاکسی تلفنی', '۲۰٪ گرون‌تر از تاکسی خیابونی، ولی دم در میاد!', () => {
      closePanel();
      openTaxi(true);
    });
    if (!contacts.length) { noteP(p, 'شماره‌ی کس دیگه‌ای رو نداری! برو تو شهر با آدما آشنا شو.'); return; }
    contacts.forEach(n => {
      const isGirl = n.marriageable;
      const h = document.createElement('h4');
      h.textContent = (isGirl ? '💗 ' : '🤝 ') + n.name + (G.knownJobs?.[n.id] ? ' — ' + n.job : '');
      p.appendChild(h);
      if (isUpset(n.id)) {
        noteP(p, '😤 رد تماس! قهره... با گل و شیرینی حضوری برو.');
        return;
      }
      actionRow(p, '📞 گپ تلفنی', '+۲ علاقه', () => {
        addAffection(n.id, 2);
        const line = n.chats[Math.floor(Math.random() * n.chats.length)];
        npcSayPhone(p, n.name + ': «' + line + '»');
        updateHUD();
      });
      if (isGirl && G.married !== n.id) {
        actionRow(p, '☕ دعوت به دیت', 'زنگ بزن ببین میاد! (علاقه ۱۰+)', () => {
          if (getAffection(n.id) < 10) {
            npcSayPhone(p, n.name + ': «ممنون ولی... ما هنوز خیلی همو نمی‌شناسیم! یه کم دیگه آشنا شیم.» 😅');
            return;
          }
          closePanel();
          askDate(n);
        });
      }
      if (!isGirl && n.gender === 'm') {
        actionRow(p, '🎳 «پایه‌ای بریم بیرون؟»', faMoney(1000000) + ' | +۱۰ شادی رفاقتی', () => {
          if (G.money < 1000000) { toast('💸 رفیق بی‌پول! دفعه بعد.'); return; }
          addMoney(-1000000); G.happy += 10; addAffection(n.id, 5);
          advanceTime(2);
          npcSayPhone(p, MALE_HANGOUT[n.id] || (n.name + ': «بزن بریم داداش!» — کلی خوش گذشت!'));
          updateHUD();
        });
      }
    });
  });
}
function npcSayPhone(p, text) {
  const d = document.createElement('p');
  d.className = 'npcSaid';
  d.textContent = text;
  p.prepend(d);
  while (p.querySelectorAll('.npcSaid').length > 2) [...p.querySelectorAll('.npcSaid')].pop().remove();
}

// ---------- تاکسی: جابه‌جایی سریع با پول ----------
function openTaxi(called) {
  openPanel(called ? '📞🚕 تاکسی تلفنی (۲۰٪ گرون‌تر!)' : '🚕 تاکسی خیابونی', p => {
    noteP(p, called
      ? 'زنگ زدی آژانس... پنج دقیقه بعد رسید! راننده: «ترافیک بود شرمنده. کجا بریم؟»'
      : 'دست بلند کردی، تاکسی زد رو ترمز! راننده: «بپر بالا! کجا بریم؟ فقط از اتوبان نمیرم، دوربین داره!»');
    BUILDINGS.filter(b => !b.deco && b.id !== 'home').forEach(b => {
      const dist = Math.hypot(G.px - b.x, G.pz - b.z);
      if (dist < 15) return; // نزدیکه، پیاده برو!
      const fare = Math.round(dist * 25000 * (G.trafficJam ? 1.5 : 1) * (called ? 1.2 : 1));
      actionRow(p, b.icon + ' ' + b.name, faMoney(fare) + (G.trafficJam ? ' (ترافیکه، گرون‌تره!)' : ''), () => {
        if (G.money < fare) { toast('💸 راننده: «کارت‌خوان ندارم، پولم نداری؟ پیاده شو!»'); return; }
        addMoney(-fare);
        const tx = b.x + b.w/2 + 5, tz = b.z + b.d/2 + 3;
        G.px = tx; G.pz = tz;
        window.WORLD?.teleport?.(tx, tz);
        advanceTime(1);
        toast('🚕 رسیدی! راننده: «کرایه حلال‌ترین پوله!»');
        updateHUD(); closePanel();
      });
    });
    noteP(p, 'مقصدهای خیلی نزدیک تو لیست نیستن — دو قدم راهه، پیاده برو! 😄');
    // راننده کم‌حرفه؛ ولی اگه سر حرف باز شد، دیگه بسته نمیشه!
    const TAXI_TALK = [
      '🚕 راننده: «قدیما این خیابون دو طرفه بود... الان فقط یه طرفش آسفالته!»',
      '🚕 راننده: «دلار رو دیدی؟ من مسافرکشی می‌کنم که یادم بره!»',
      '🚕 راننده: «پسرم میگه بابا اسنپ شو! میگم من خودم اسنپ بودم قبل اینکه اسنپ باشه!»',
      '🚕 راننده: «این ضبط فقط شش‌وهشت می‌خونه. مسافر قبلی شش ساعت گریه کرد باهاش!»',
      '🚕 راننده: «ترافیک نیست، مردم همه اومدن ببینن ترافیک هست یا نه!»',
      '🚕 راننده: «بنزین رو ول کن، من با حرص خودم کار می‌کنم، سوختم مجانیه!»',
      '🚕 راننده: «یه مسافر داشتم آدرس نمی‌دونست، دو ساعت چرخیدیم، آخرش گفت همون‌جا که سوار شدم پیاده‌م کن!»',
      '🚕 راننده: «کولر؟ داره! فقط باد گرم میده. زمستون قدرشو می‌دونی!»',
    ];
    G.taxiChatCount = 0;
    actionRow(p, '💬 گپ با راننده', G.taxiSilent ? 'قهره!' : 'حواست باشه، پرحرفه!', () => {
      if (G.taxiSilent) { toast('🚕 راننده: «...» (قهره! خودت گفتی ساکت باشه)'); return; }
      G.taxiChatCount = (G.taxiChatCount || 0) + 1;
      G.happy += 2;
      toast(TAXI_TALK[Math.floor(Math.random() * TAXI_TALK.length)]);
      if (G.taxiChatCount === 3) setTimeout(() => toast('🚕 راننده دیگه بند نمیاد! با ترفندهای پایین ساکتش کن! 😅'), 2600);
      updateHUD();
    });
    // ترفندهای ساکت کردن راننده!
    if (G.taxiSilent) {
      actionRow(p, '🔊 «ببخشید، حالا تعریف کن»', 'آشتی با راننده', () => {
        G.taxiSilent = false;
        toast('🚕 راننده: «آخ گفتی! داشتم خفه می‌شدم! خب کجا بودم... آهان، سال ۷۴...»');
        openTaxi(called);
      });
    } else {
      const TRICKS = [
        ['🎧 «هندزفری تو گوشمه، نمی‌شنوم!»', '🚕 راننده: «باشه بابا... (تو آینه نگاه می‌کنه ببینه واقعاً هندزفری داری!)»'],
        ['😴 خودتو بزن به خواب', '🚕 راننده: «خوابید؟... خب پس برای خودم تعریف می‌کنم... (يواش‌تر ادامه میده!)»'],
        ['📱 «الو؟ آره آره دارم میام...»', '🚕 راننده: «تلفنشه، زشته حرف بزنم... (ضبط شش‌وهشت رو زیاد می‌کنه!)»'],
        ['🤕 «ببخشید سرم درد می‌کنه»', '🚕 راننده: «آخ آخ ببخشید! ساکت میشم... فقط یه نکته بگم برای سردرد: عرق نعنا!»'],
      ];
      TRICKS.forEach(([label, reply]) => {
        actionRow(p, label, 'ترفند سکوت', () => {
          G.taxiSilent = true;
          toast(reply);
          openTaxi(called);
        });
      });
    }
  });
}

// ---------- حباب گفتگوی NPC ها با هم ----------
function uiChatter(nameA, lineA, nameB, lineB) {
  if (typeof sayAs === 'function') {
    const spk = NPCS.find(n => (n.name || '').split(' (')[0] === nameA);
    spk ? sayAs(spk, lineA) : sayFa(lineA, 1.1, 1);
  }
  const c = $id('chatter');
  const mk = (name, line) => {
    const b = document.createElement('div');
    b.className = 'bubble';
    b.innerHTML = '<b></b>: <span></span>';
    b.querySelector('b').textContent = name;
    b.querySelector('span').textContent = line;
    c.appendChild(b);
    while (c.children.length > 2) c.firstChild.remove();
    setTimeout(() => b.remove(), 7000);
  };
  mk(nameA, lineA);
  setTimeout(() => mk(nameB, lineB), 2200);
}

// ---------- منوها و سیو ----------
function renderSlots(mode) {
  const wrap = $id('slots');
  wrap.innerHTML = '';
  for (let i = 1; i <= 3; i++) {
    const info = slotInfo(i);
    const row = document.createElement('div');
    row.className = 'slot';
    const txt = document.createElement('div');
    txt.innerHTML = '<b>اسلات ' + fa(i) + '</b><small>' +
      (info ? (info.date + ' — ' + faMoney(info.money) + (info.mode === '2d' ? ' — دوبعدی' : ' — سه‌بعدی')) : 'خالی') + '</small>';
    row.appendChild(txt);
    if (mode === 'save') {
      const b = document.createElement('button');
      b.textContent = info ? 'بازنویسی' : 'ذخیره';
      b.onclick = () => { saveToSlot(i); toast('💾 ذخیره شد در اسلات ' + fa(i)); renderSlots('save'); };
      row.appendChild(b);
    } else {
      const b = document.createElement('button');
      b.textContent = 'لود';
      b.disabled = !info;
      b.onclick = () => {
        if (loadFromSlot(i)) { closePanel(); launchGame(G.mode, true); }
      };
      row.appendChild(b);
      if (info) {
        const del = document.createElement('button');
        del.textContent = '🗑️'; del.className = 'del';
        del.onclick = () => { deleteSlot(i); renderSlots(mode); };
        row.appendChild(del);
      }
    }
    wrap.appendChild(row);
  }
}
function openSaveMenu(mode) {
  openPanel(mode === 'save' ? '💾 ذخیره بازی' : '📂 بارگذاری بازی', p => {
    const s = document.createElement('div'); s.id = 'slots'; p.appendChild(s);
    renderSlots(mode);
  });
}
