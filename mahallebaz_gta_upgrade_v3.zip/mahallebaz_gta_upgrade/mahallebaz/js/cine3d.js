// ===== cine3d.js — لایهٔ گرافیک سینمایی GTA-grade برای محله‌باز =====
// آسمان شیدری (خورشید/ماه/ستاره/ابر/رعد)، ریگ نور سینمایی، PMREM محیط بازتابی،
// متریال‌های PBR رویه‌ای (آسفالت/پیاده‌رو/نما)، باران کج با آسفالت خیس، وینیت/گرین فیلم.
// سه r160 — سازگار با world3d.js فعلی؛ هیچ سیستم بازیکنی حذف نمی‌شود.
'use strict';

(function () {
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const damp = (a, b, l, dt) => lerp(a, b, 1 - Math.exp(-l * dt));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const srgb = hex => {
    const c = new THREE.Color(hex);
    if (THREE.ColorManagement && THREE.ColorManagement.enabled !== false && c.convertSRGBToLinear) c.convertSRGBToLinear();
    return c;
  };

  // ============================================================
  // 1) تکسچرهای PBR رویه‌ای (albedo + roughness + normal)
  // ============================================================
  function noiseCanvas(size, drawFn) {
    const c = document.createElement('canvas');
    c.width = c.height = size;
    const ctx = c.getContext('2d');
    drawFn(ctx, size);
    return c;
  }
  function valueNoise(ctx, size, cells, amp, base = [128, 128, 128]) {
    const grid = [];
    for (let y = 0; y <= cells; y++) {
      grid[y] = [];
      for (let x = 0; x <= cells; x++) grid[y][x] = Math.random();
    }
    const img = ctx.getImageData(0, 0, size, size);
    const d = img.data;
    for (let y = 0; y < size; y++) {
      const gy = (y / size) * cells, y0 = Math.floor(gy), fy = gy - y0;
      const sy = fy * fy * (3 - 2 * fy);
      for (let x = 0; x < size; x++) {
        const gx = (x / size) * cells, x0 = Math.floor(gx), fx = gx - x0;
        const sx = fx * fx * (3 - 2 * fx);
        const v00 = grid[y0][x0], v10 = grid[y0][x0 + 1];
        const v01 = grid[y0 + 1][x0], v11 = grid[y0 + 1][x0 + 1];
        const n = lerp(lerp(v00, v10, sx), lerp(v01, v11, sx), sy);
        const i = (y * size + x) * 4;
        d[i]     = clamp(base[0] + (n - .5) * 2 * amp, 0, 255);
        d[i + 1] = clamp(base[1] + (n - .5) * 2 * amp, 0, 255);
        d[i + 2] = clamp(base[2] + (n - .5) * 2 * amp, 0, 255);
      }
    }
    ctx.putImageData(img, 0, 0);
  }
  function texFromCanvas(c, repX, repY, isData) {
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    if (repX) t.repeat.set(repX, repY || repX);
    t.anisotropy = 4;
    if (isData) { t.colorSpace = THREE.NoColorSpace; }
    else if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }
  // نرمال‌مپ از ارتفاع کانواس (سابیل عبری — سریع)
  function normalFromCanvas(srcCanvas, strength = 2) {
    const size = srcCanvas.width;
    const sctx = srcCanvas.getContext('2d');
    const src = sctx.getImageData(0, 0, size, size).data;
    const out = document.createElement('canvas');
    out.width = out.height = size;
    const octx = out.getContext('2d');
    const img = octx.createImageData(size, size);
    const d = img.data;
    const h = (x, y) => src[(((y + size) % size) * size + ((x + size) % size)) * 4] / 255;
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const dx = (h(x - 1, y) - h(x + 1, y)) * strength;
      const dy = (h(x, y - 1) - h(x, y + 1)) * strength;
      const len = Math.sqrt(dx * dx + dy * dy + 1);
      const i = (y * size + x) * 4;
      d[i] = ((dx / len) * .5 + .5) * 255;
      d[i + 1] = ((dy / len) * .5 + .5) * 255;
      d[i + 2] = (1 / len) * .5 * 255 + 127;
      d[i + 3] = 255;
    }
    octx.putImageData(img, 0, 0);
    return out;
  }

  // --- آسفالت: دانه‌سنگ + وصلهٔ قیر + خط ترک ظریف ---
  function asphaltCanvas() {
    return noiseCanvas(256, (ctx, s) => {
      ctx.fillStyle = '#3d3f42'; ctx.fillRect(0, 0, s, s);
      const img = ctx.getImageData(0, 0, s, s), d = img.data;
      for (let i = 0; i < d.length; i += 4) {
        const n = (Math.random() - .5) * 34;
        d[i] = clamp(d[i] + n, 0, 255); d[i+1] = clamp(d[i+1] + n, 0, 255); d[i+2] = clamp(d[i+2] + n * 1.05, 0, 255);
      }
      ctx.putImageData(img, 0, 0);
      // وصله‌های قیر تیره‌تر
      for (let p = 0; p < 9; p++) {
        const x = Math.random() * s, y = Math.random() * s, r = rnd(14, 46);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, 'rgba(18,19,22,.42)');
        g.addColorStop(1, 'rgba(18,19,22,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      }
      // ترک‌های مویی
      ctx.strokeStyle = 'rgba(15,15,17,.5)'; ctx.lineWidth = 1;
      for (let t = 0; t < 5; t++) {
        ctx.beginPath();
        let x = Math.random() * s, y = Math.random() * s;
        ctx.moveTo(x, y);
        for (let k = 0; k < 7; k++) { x += rnd(-26, 26); y += rnd(-26, 26); ctx.lineTo(x, y); }
        ctx.stroke();
      }
    });
  }
  function asphaltRough() {
    return noiseCanvas(256, (ctx, s) => {
      ctx.fillStyle = '#c9c9c9'; ctx.fillRect(0, 0, s, s);
      valueNoise(ctx, s, 9, 46, [201, 201, 201]);
      const img = ctx.getImageData(0, 0, s, s), d = img.data;
      for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - .5) * 18; d[i]=clamp(d[i]+n,0,255); d[i+1]=clamp(d[i+1]+n,0,255); d[i+2]=clamp(d[i+2]+n,0,255); }
      ctx.putImageData(img, 0, 0);
    });
  }
  // --- پیاده‌رو: سنگ‌فرش بتنی با بندهای گِرد ---
  function sidewalkCanvas() {
    return noiseCanvas(256, (ctx, s) => {
      ctx.fillStyle = '#a8a29a'; ctx.fillRect(0, 0, s, s);
      valueNoise(ctx, s, 12, 22, [168, 162, 154]);
      const cell = s / 4;
      ctx.strokeStyle = 'rgba(60,58,54,.85)'; ctx.lineWidth = 3;
      for (let i = 0; i <= 4; i++) {
        ctx.beginPath(); ctx.moveTo(i * cell, 0); ctx.lineTo(i * cell, s); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i * cell); ctx.lineTo(s, i * cell); ctx.stroke();
      }
      // لبهٔ روشن هر تخته
      ctx.strokeStyle = 'rgba(235,230,222,.35)'; ctx.lineWidth = 1;
      for (let i = 0; i <= 4; i++) {
        ctx.beginPath(); ctx.moveTo(i * cell + 2, 0); ctx.lineTo(i * cell + 2, s); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, i * cell + 2); ctx.lineTo(s, i * cell + 2); ctx.stroke();
      }
      const img = ctx.getImageData(0, 0, s, s), d = img.data;
      for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - .5) * 10; d[i]=clamp(d[i]+n,0,255); d[i+1]=clamp(d[i+1]+n,0,255); d[i+2]=clamp(d[i+2]+n,0,255); }
      ctx.putImageData(img, 0, 0);
    });
  }
  // --- نما: آجر/پنل با درز و کثیفی پای دیوار ---
  function facadeCanvas(tint) {
    return noiseCanvas(256, (ctx, s) => {
      ctx.fillStyle = tint || '#c9c9c9'; ctx.fillRect(0, 0, s, s);
      valueNoise(ctx, s, 10, 16, [201, 201, 201]);
      // ردیف‌های پنل/آجر
      const rows = 8, rh = s / rows;
      for (let r = 0; r < rows; r++) {
        const y = r * rh;
        ctx.fillStyle = 'rgba(0,0,0,.16)'; ctx.fillRect(0, y + rh - 2.5, s, 2.5);
        ctx.fillStyle = 'rgba(255,255,255,.09)'; ctx.fillRect(0, y, s, 1.5);
        const off = (r % 2) * rh;
        for (let x = off; x < s; x += rh * 2) {
          ctx.fillStyle = 'rgba(0,0,0,.12)';
          ctx.fillRect(x, y, 2, rh);
        }
      }
      // کثیفی/لکه
      for (let p = 0; p < 6; p++) {
        const x = Math.random() * s, y = Math.random() * s, r = rnd(18, 60);
        const g = ctx.createRadialGradient(x, y, 0, x, y, r);
        g.addColorStop(0, 'rgba(30,28,24,.14)'); g.addColorStop(1, 'rgba(30,28,24,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
      }
      const img = ctx.getImageData(0, 0, s, s), d = img.data;
      for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - .5) * 9; d[i]=clamp(d[i]+n,0,255); d[i+1]=clamp(d[i+1]+n,0,255); d[i+2]=clamp(d[i+2]+n,0,255); }
      ctx.putImageData(img, 0, 0);
    });
  }

  // کش پارچه‌های آماده — یک بار ساخته می‌شوند
  const PBR = (() => {
    const asphaltA = asphaltCanvas();
    const sidewalkA = sidewalkCanvas();
    return {
      asphalt: {
        map: texFromCanvas(asphaltA, 30, 30),
        rough: texFromCanvas(asphaltRough(), 30, 30, true),
        normal: texFromCanvas(normalFromCanvas(asphaltA, 1.6), 30, 30, true),
      },
      sidewalk: (() => {
        const a = sidewalkA;
        return {
          map: texFromCanvas(a, 60, 12),
          normal: texFromCanvas(normalFromCanvas(a, 1.4), 60, 12, true),
        };
      })(),
      facadeCache: new Map(),
      facadeFor(tint) {
        const key = tint || 'def';
        if (!this.facadeCache.has(key)) {
          const a = facadeCanvas(tint);
          this.facadeCache.set(key, {
            map: texFromCanvas(a, 3, 3),
            normal: texFromCanvas(normalFromCanvas(a, .9), 3, 3, true),
          });
        }
        return this.facadeCache.get(key);
      },
    };
  })();

  // ============================================================
  // 2) آسمان شیدری: خورشید + ماه + ستاره + ابر + رعد
  // ============================================================
  const SKY_VERT = `
    varying vec3 vDir;
    void main() {
      vDir = normalize(position);
      vec4 mv = modelViewMatrix * vec4(position, 1.0);
      gl_Position = projectionMatrix * mv;
      gl_Position.z = gl_Position.w; // هم پشت همه‌چیز
    }`;
  const SKY_FRAG = `
    uniform vec3 uSunDir;
    uniform vec3 uMoonDir;
    uniform vec3 uDayCol;
    uniform vec3 uDuskCol;
    uniform vec3 uNightCol;
    uniform float uDaylight;
    uniform float uDuskGlow;
    uniform float uOvercast;    // ۰ آفتابی .. ۱ ابری
    uniform float uNight;       // ۰ روز .. ۱ شب
    uniform float uFlash;       // رعد و برق
    uniform float uTime;
    varying vec3 vDir;

    float hash(vec3 p){ p = fract(p*0.3183099+.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
    float noise3(vec3 x){
      vec3 i = floor(x); vec3 f = fract(x);
      f = f*f*(3.0-2.0*f);
      return mix(mix(mix(hash(i+vec3(0,0,0)), hash(i+vec3(1,0,0)),f.x),
                     mix(hash(i+vec3(0,1,0)), hash(i+vec3(1,1,0)),f.x),f.y),
                 mix(mix(hash(i+vec3(0,0,1)), hash(i+vec3(1,0,1)),f.x),
                     mix(hash(i+vec3(0,1,1)), hash(i+vec3(1,1,1)),f.x),f.y),f.z);
    }
    float fbm(vec3 p){
      float v = 0.0; float a = 0.5;
      for(int i=0;i<4;i++){ v += a*noise3(p); p *= 2.13; a *= 0.5; }
      return v;
    }

    void main() {
      vec3 dir = normalize(vDir);
      float h = clamp(dir.y, -0.05, 1.0);

      // گرادیان عمودی آسمان
      vec3 dayHor = uDayCol; vec3 dayTop = uDayCol * 0.62 + vec3(0.05,0.10,0.24);
      vec3 col = mix(dayHor, dayTop, pow(max(h,0.0), 0.55));
      // غروب: نوار نارنجی گرم نزدیک افق سمت خورشید
      float sunH = dot(normalize(dir), normalize(uSunDir));
      float duskBand = pow(max(sunH, 0.0), 2.2) * pow(1.0 - h, 2.0);
      col = mix(col, uDuskCol * 1.15, clamp(duskBand * (1.2 + uDuskGlow), 0.0, 1.0));
      col = mix(col, uDuskCol, uDuskGlow * 0.38);
      // شب
      vec3 nightSky = uNightCol * (0.85 + 0.35 * (1.0 - h));
      col = mix(col, nightSky, uNight);

      // خورشید
      float sd = max(dot(dir, normalize(uSunDir)), 0.0);
      vec3 sunCol = mix(vec3(1.0,0.45,0.18), vec3(1.0,0.92,0.78), uDaylight);
      float disc = smoothstep(0.9993, 0.9998, sd);
      float halo = pow(sd, 90.0) * 0.5 + pow(sd, 350.0) * 0.6;
      float sunVis = 1.0 - uNight * 0.92 - uOvercast * 0.85;
      col += sunCol * (disc * 1.6 + halo) * max(sunVis, 0.0);

      // ماه
      float md = max(dot(dir, normalize(uMoonDir)), 0.0);
      float moonDisc = smoothstep(0.99965, 0.99985, md);
      float crater = 0.85 + 0.3 * noise3(dir * 220.0);
      col += vec3(0.92, 0.95, 1.0) * moonDisc * crater * uNight * 1.35;
      col += vec3(0.55, 0.62, 0.78) * pow(md, 240.0) * uNight * 0.35;

      // ستاره‌ها (فقط شب)
      float starN = hash(floor(dir * 420.0));
      float star = step(0.9985, starN) * (0.5 + 0.5 * sin(uTime * 2.2 + starN * 40.0));
      col += vec3(0.9, 0.93, 1.0) * star * uNight * (1.0 - uOvercast * 0.9) * step(0.02, dir.y);

      // ابر — دو لایه FBM که آروم می‌چرخند
      vec3 cp = dir / max(dir.y, 0.06) * 0.55;
      float cl = fbm(cp * 0.5 + vec3(uTime * 0.006, 0.0, uTime * 0.002));
      float cl2 = fbm(cp * 0.9 + vec3(-uTime * 0.011, 0.0, 0.0));
      float cover = clamp((cl - (0.62 - uOvercast * 0.34)) * 3.2, 0.0, 1.0);
      cover = max(cover, clamp((cl2 - (0.74 - uOvercast * 0.3)) * 2.6, 0.0, 1.0) * 0.7);
      cover *= smoothstep(0.0, 0.16, dir.y);
      vec3 cloudDay = mix(vec3(0.98,0.99,1.0), vec3(0.55,0.58,0.64), uOvercast * 0.8);
      vec3 cloudDusk = vec3(1.0,0.62,0.38) * (0.5 + uDuskGlow);
      vec3 cloudNight = vec3(0.10,0.12,0.17);
      vec3 cloudCol = mix(cloudNight, cloudDay, max(uDaylight, 0.0));
      cloudCol = mix(cloudCol, cloudDusk, uDuskGlow * 0.75);
      cloudCol = mix(cloudCol, vec3(1.1,1.1,1.2), uFlash);
      col = mix(col, cloudCol, cover * (1.0 - uNight * 0.25));

      // رعد و برق
      col += vec3(0.85,0.88,1.0) * uFlash * 0.75;

      // مه افق
      col = mix(col, uDayCol * (1.0 - uNight * 0.9), (1.0 - smoothstep(-0.02, 0.30, dir.y)) * 0.85);

      gl_FragColor = vec4(col, 1.0);
    }`;

  function makeSky(scene) {
    const uniforms = {
      uSunDir:   { value: new THREE.Vector3(0, 1, 0) },
      uMoonDir:  { value: new THREE.Vector3(0, -1, 0) },
      uDayCol:   { value: srgb(0x87ceeb) },
      uDuskCol:  { value: srgb(0xff8e4f) },
      uNightCol: { value: srgb(0x0a0f24) },
      uDaylight: { value: 1 },
      uDuskGlow: { value: 0 },
      uOvercast: { value: 0 },
      uNight:    { value: 0 },
      uFlash:    { value: 0 },
      uTime:     { value: 0 },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms, vertexShader: SKY_VERT, fragmentShader: SKY_FRAG,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(900, 40, 24), mat);
    mesh.frustumCulled = false;
    mesh.renderOrder = -100;
    scene.add(mesh);
    return { mesh, uniforms };
  }

  // ============================================================
  // 3) ریگ نور سینمایی — خورشید، ماه، آسمان (همی)، برنس پرده‌ای
  // ============================================================
  const LIGHTS = {
    sun: null, moon: null, hemi: null, bounce: null,
    sunTarget: null,
  };
  function buildLightRig(scene) {
    const sun = new THREE.DirectionalLight(0xfff2d0, 2.2);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.bias = -.0006;
    sun.shadow.normalBias = .025;
    const cam = sun.shadow.camera;
    cam.left = -46; cam.right = 46; cam.top = 46; cam.bottom = -46;
    cam.near = 5; cam.far = 240;
    sun.shadow.camera.updateProjectionMatrix();
    const sunTarget = new THREE.Object3D();
    scene.add(sunTarget); sun.target = sunTarget;

    const moon = new THREE.DirectionalLight(0x9db4e8, 0);
    moon.castShadow = true;
    moon.shadow.mapSize.set(1024, 1024);
    moon.shadow.bias = -.0006;
    moon.shadow.normalBias = .03;
    Object.assign(moon.shadow.camera, { left:-40, right:40, top:40, bottom:-40, near:5, far:240 });
    moon.shadow.camera.updateProjectionMatrix();
    scene.add(moon); moon.target = sunTarget;

    const hemi = new THREE.HemisphereLight(0xbdd7ff, 0x8a7a5e, .55);
    scene.add(hemi);

    const bounce = new THREE.DirectionalLight(0xffd9a8, 0);
    bounce.position.set(-30, 22, -40);
    scene.add(bounce);

    LIGHTS.sun = sun; LIGHTS.moon = moon; LIGHTS.hemi = hemi; LIGHTS.bounce = bounce;
    LIGHTS.sunTarget = sunTarget;
    scene.add(sun);
    return LIGHTS;
  }

  // ============================================================
  // 4) محیط PMREM از آسمان → بازتاب طبیعی روی همهٔ متریال‌ها
  // ============================================================
  function buildEnvMap(renderer, scene, skyMesh, THREE_ref) {
    try {
      const pmrem = new THREE.PMREMGenerator(renderer);
      pmrem.compileEquirectangularShader();
      const rt = pmrem.fromScene(scene, 0.04);
      const tex = rt.texture;
      pmrem.dispose();
      return tex;
    } catch (e) { console.warn('PMREM failed', e); return null; }
  }

  // ============================================================
  // 5) باران کج + آسفالت خیس
  // ============================================================
  function makeRain(scene) {
    const COUNT = 1300;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(COUNT * 3);
    const spd = new Float32Array(COUNT);
    for (let i = 0; i < COUNT; i++) {
      pos[i*3] = rnd(-60, 60);
      pos[i*3+1] = rnd(0, 42);
      pos[i*3+2] = rnd(-60, 60);
      spd[i] = rnd(26, 40);
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xaac6ee, size: .09, transparent: true, opacity: .5,
      sizeAttenuation: true, depthWrite: false,
    });
    const points = new THREE.Points(geo, mat);
    points.frustumCulled = false;
    points.visible = false;
    scene.add(points);
    let wet = 0;
    const api = {
      points, wet,
      setWet(v) { wet = clamp(v, 0, 1); api.wet = wet; },
      update(dt, anchor) {
        points.position.set(anchor.x, 0, anchor.z);
        const a = geo.attributes.position;
        for (let i = 0; i < COUNT; i++) {
          let y = a.getY(i) - spd[i] * dt;
          if (y < 0) y = 42;
          a.setY(i, y);
          let x = a.getX(i) + 7 * dt;               // باد مورب
          if (x > 60) x = -60;
          a.setX(i, x);
        }
        a.needsUpdate = true;
        mat.opacity = .32 + wet * .3;
      },
      setStrength(v) { mat.opacity = .1 + v * .45; },
    };
    return api;
  }

  // ============================================================
  // 6) لایهٔ فیلم: وینیت + گرین + سایه‌زنی رنگی (DOM، بدون هزینهٔ GPU)
  // ============================================================
  function installFilmOverlay() {
    if (document.getElementById('cineFilm')) return;
    const el = document.createElement('div');
    el.id = 'cineFilm';
    el.style.cssText = 'position:fixed;inset:0;z-index:6;pointer-events:none;'
      + 'background:radial-gradient(ellipse at 50% 42%, transparent 58%, rgba(8,6,12,.42) 100%);'
      + 'mix-blend-mode:multiply;';
    const grain = document.createElement('div');
    grain.id = 'cineGrain';
    grain.style.cssText = 'position:absolute;inset:-60px;opacity:.05;pointer-events:none;'
      + 'background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'140\' height=\'140\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'.85\' numOctaves=\'2\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E");'
      + 'animation: cineGrainShift .42s steps(3) infinite;';
    const style = document.createElement('style');
    style.textContent = '@keyframes cineGrainShift{0%{transform:translate(0,0)}34%{transform:translate(-24px,14px)}67%{transform:translate(18px,-20px)}100%{transform:translate(0,0)}}';
    document.head.appendChild(style);
    el.appendChild(grain);
    (document.getElementById('game') || document.body).appendChild(el);
  }

  // پارچهٔ متریال PBR برای world3d (آسفالت/پیاده‌رو/نما)
  window.CINE_PBR = {
    asphalt() {
      return { map: PBR.asphalt.map, normal: PBR.asphalt.normal, rough: PBR.asphalt.rough };
    },
    sidewalk() {
      return { map: PBR.sidewalk.map, normal: PBR.sidewalk.normal };
    },
    facade() {
      return { normal: PBR.facadeFor(null).normal };
    },
  };

  // ============================================================
  // 7) اتصال به world3d — API اصلی
  // ============================================================
  window.CINE3D = function install(scene, renderer, camera, opts) {
    const state = {
      sky: makeSky(scene),
      lights: buildLightRig(scene),
      rain: makeRain(scene),
      envRT: null,
      envDirty: true,
      envTimer: 0,
      flash: 0,
      flashTimer: rnd(4, 9),
      storm: false,
      weather: 'sunny',
      overcast: 0,
      mode: 'high',
    };
    installFilmOverlay();

    // نورهای قدیمی را که world3d می‌سازد کمی عقب می‌کشیم تا دوتایی نزنند
    // (world3d خودش این کار را با W.cineDowngrade انجام می‌دهد)

    const S = state.sky.uniforms;

    // ---- جداول رنگ ----
    const DAY_BY_WEATHER = {
      sunny: 0x7fb8e8, cloudy: 0x9aa5b1, rainy: 0x5c6b7a,
      polluted: 0xb0a080, snowy: 0xcfd8e3, stormy: 0x5a5a66,
    };

    function update(dt, now, game) {
      const G = window.G || {};
      const player = game && game.player ? game.player : null;
      const t = ((G.hour ?? 12) + (G.minute ?? 0) / 60) / 24;
      const elev = Math.sin((t - .25) * TAU);
      const daylight = clamp((elev + .15) * 2.2, 0, 1);
      const duskGlow = Math.max(0, 1 - Math.abs(elev) * 5) * (t > .5 ? 1 : .7);
      const night = clamp(1 - daylight * 1.6, 0, 1);
      const weather = G.weather || 'sunny';
      const isStorm = weather === 'stormy';
      const overcastWanted = (weather === 'rainy' || isStorm || weather === 'snowy' || weather === 'cloudy') ? (weather === 'cloudy' ? .55 : .85) : (weather === 'polluted' ? .45 : 0);
      state.overcast = damp(state.overcast, overcastWanted, 1.2, dt);

      // --- رعد و برق ---
      if (isStorm && daylight < .9) {
        state.flashTimer -= dt;
        if (state.flashTimer <= 0) { state.flash = 1; state.flashTimer = rnd(3.5, 11); }
      }
      state.flash = Math.max(0, state.flash - dt * 4.2);
      S.uFlash.value = state.flash * (0.5 + 0.5 * Math.sin(now * .06));

      // --- جهت‌ها ---
      const az = t * TAU;
      const sunDir = new THREE.Vector3(Math.cos(az), Math.sin((t - .25) * TAU), .38).normalize();
      // خورشید از شرق به غرب
      sunDir.set(Math.cos((t - .25) * TAU), Math.sin((t - .25) * TAU), .35).normalize();
      if (sunDir.y < -0.12) sunDir.y = -0.12;
      const moonDir = sunDir.clone().negate();
      moonDir.y = Math.abs(moonDir.y) + .18;
      S.uSunDir.value.copy(sunDir);
      S.uMoonDir.value.copy(moonDir);
      S.uDaylight.value = daylight;
      S.uDuskGlow.value = duskGlow;
      S.uNight.value = night;
      S.uOvercast.value = state.overcast;
      S.uTime.value = now * .001;
      S.uDayCol.value.copy(srgb(DAY_BY_WEATHER[weather] ?? 0x87ceeb));

      // --- نورها ---
      const L = state.lights;
      const wI = { sunny:2.3, cloudy:1.5, rainy:1.1, polluted:1.2, snowy:1.6, stormy:.85 }[weather] || 2;
      const sunI = daylight * wI * (1 - state.overcast * .55);
      L.sun.intensity = sunI;
      L.sun.color.copy(srgb(duskGlow > .3 ? 0xff9a55 : daylight > .75 ? 0xfff3dd : 0xffd9a0));
      L.sun.position.copy(sunDir).multiplyScalar(90);
      L.sun.position.y = Math.max(L.sun.position.y, 12);
      L.moon.intensity = night * .5 * (1 - state.overcast * .7);
      L.moon.color.setHex(0x9db4e8);
      L.moon.position.copy(moonDir).multiplyScalar(80);
      L.moon.position.y = Math.max(L.moon.position.y, 20);
      L.hemi.intensity = .18 + daylight * .55 * (1 - state.overcast * .3) + state.flash * .6;
      L.hemi.color.copy(S.uDayCol.value).lerp(srgb(0xffffff), .2);
      L.hemi.groundColor.setHex(night > .5 ? 0x14161f : 0x8a7a5e);
      L.bounce.intensity = .25 + duskGlow * .3 + night * .06;
      L.bounce.color.copy(srgb(duskGlow > .35 ? 0xffb27a : 0xbcd0e8));
      // هدف نور دنبال بازیکن (سایهٔ شارپ نزدیک، بدون لبهٔ بریده)
      if (player) {
        L.sunTarget.position.set(player.position.x, 0, player.position.z);
      }

      // --- مه گرم/سرد سینمایی ---
      const fogCol = new THREE.Color().copy(S.uDayCol.value).lerp(srgb(0xffd9b0), duskGlow * .55).lerp(srgb(0x0a0e1c), night * .92);
      scene.fog.color.copy(fogCol);
      if (scene.background && scene.background.isColor) scene.background.copy(fogCol);

      // --- باران ---
      const rainWanted = weather === 'rainy' || isStorm;
      state.rain.points.visible = rainWanted && state.mode !== 'low' && !(game && game.inside);
      if (rainWanted) state.rain.update(dt, player ? player.position : { x: 0, z: 0 });
      state.rain.setWet(rainWanted ? clamp((wet_progress(G)) + (isStorm ? .35 : 0), 0, 1) : Math.max(0, state.rain.wet - dt * .03));

      // --- محیط PMREM هر ۲ ثانیه (فقط وقتی نور عوض شده) ---
      state.envTimer -= dt;
      if (state.envTimer <= 0) {
        state.envTimer = 2.5;
        refreshEnv(renderer, scene, state);
      }

      // --- افق مه‌آلود برای کول‌ینگ دور ---
      return { daylight, duskGlow, night, sunI, elev };
    }

    function wet_progress(G) { return (G.weather === 'rainy' || G.weather === 'stormy') ? .6 : 0; }

    function refreshEnv(renderer, scene, state) {
      try {
        if (state.envRT) state.envRT.dispose();
        const pmrem = new THREE.PMREMGenerator(renderer);
        const skyOnly = new THREE.Scene();
        const cloneMesh = state.sky.mesh.clone();
        cloneMesh.material = state.sky.mesh.material;
        skyOnly.add(cloneMesh);
        const rt = pmrem.fromScene(skyOnly, 0.03);
        state.envRT = rt;
        if (scene.environment !== undefined) scene.environment = rt.texture;
        pmrem.dispose();
      } catch (e) { /* ساکت — پشتیبانی نشد */ }
    }

    // آسفالت خیس: roughness را با باران کم می‌کنیم
    function applyWetness(roadMat, sidewalkMat) {
      const w = state.rain.wet;
      if (roadMat && roadMat.roughness !== undefined) roadMat.roughness = lerp(.92, .28, w);
      if (roadMat && roadMat.metalness !== undefined) roadMat.metalness = lerp(.02, .16, w);
      if (sidewalkMat && sidewalkMat.roughness !== undefined) sidewalkMat.roughness = lerp(.95, .55, w);
    }

    function setMode(m) {
      state.mode = m;
      const L = state.lights;
      if (m === 'low') {
        L.sun.castShadow = false; L.moon.castShadow = false;
        L.sun.shadow.mapSize.set(1024, 1024); L.moon.shadow.mapSize.set(512, 512);
        state.rain.points.visible = false;
      } else if (m === 'mid') {
        L.sun.castShadow = true; L.moon.castShadow = false;
        L.sun.shadow.mapSize.set(1024, 1024);
      } else {
        L.sun.castShadow = true; L.moon.castShadow = false;
        L.sun.shadow.mapSize.set(2048, 2048);
      }
      L.sun.shadow.map?.dispose?.();
      L.sun.shadow.map = null;
    }

    return {
      update, setMode, applyWetness, refreshEnv,
      get rain() { return state.rain; },
      get state() { return state; },
      uniforms: S,
    };
  };
})();
