// ===== world3d.js — دنیای سه‌بعدی: شهر، بازیکن، ماشین، آب‌وهوا =====
'use strict';

function createWorld3D() {
  const THREE = window.THREE;
  const W = { mode: '3d' };

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87ceeb);
  scene.fog = new THREE.Fog(0x87ceeb, 80, 260);

  const camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, .1, 500);
  const renderer = new THREE.WebGLRenderer({ antialias:true });
  renderer.setSize(innerWidth, innerHeight);
  // ⚡ کیفیت پیش‌فرض بر اساس توان دستگاه
  const _lowEnd = (navigator.hardwareConcurrency || 4) <= 4 || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
  if (!G.settings) G.settings = {};
  if (!G.settings.quality) G.settings.quality = _lowEnd ? 'mid' : 'high';
  renderer.setPixelRatio(Math.min(devicePixelRatio, _lowEnd ? 1 : 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap; // سایه نرم
  if (renderer.toneMappingExposure !== undefined) renderer.toneMappingExposure = 1.12;
  if (renderer.outputColorSpace !== undefined) renderer.outputColorSpace = THREE.SRGBColorSpace;
  else if (renderer.outputEncoding !== undefined) renderer.outputEncoding = THREE.sRGBEncoding;
  if (renderer.toneMapping !== undefined) { renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05; }
  $id('game').appendChild(renderer.domElement);
  const canvas = renderer.domElement;

  // ===== ریگ نور سینمایی (cine3d): خورشید/ماه/همی/برنس — جایگزین نورهای قدیمی =====
  const cine = window.CINE3D ? window.CINE3D(scene, renderer, camera) : null;
  const sun = cine ? cine.state.lights.sun : (() => {
    const s0 = new THREE.DirectionalLight(0xfff2d0, 2.2);
    s0.position.set(40, 70, 30); s0.castShadow = true;
    Object.assign(s0.shadow.camera, { left:-100, right:100, top:100, bottom:-100 });
    scene.add(s0); return s0;
  })();
  const amb = cine ? cine.state.lights.hemi : (() => {
    const a0 = new THREE.AmbientLight(0xbbccff, .55); scene.add(a0); return a0;
  })();
  const fill = cine ? cine.state.lights.bounce : (() => {
    const f0 = new THREE.DirectionalLight(0xaebfe0, .35);
    f0.position.set(-30, 25, -40); scene.add(f0); return f0;
  })();
  if (cine) { cine.setMode(G.settings.quality === 'mid' ? 'mid' : G.settings.quality === 'low' ? 'low' : 'high'); }

  // زمین و شبکهٔ خیابون‌های به‌هم‌پیوسته (بلوارهای اصلی + کمربندی دور شهر)
  const groundCanvas = document.createElement('canvas');
  groundCanvas.width = groundCanvas.height = 256;
  (() => {
    const ctx = groundCanvas.getContext('2d');
    ctx.fillStyle = '#8a9a5b'; ctx.fillRect(0, 0, 256, 256);
    const img = ctx.getImageData(0, 0, 256, 256);
    for (let i = 0; i < img.data.length; i += 4) {
      const n = (Math.random() - .5) * 22;
      img.data[i] += n; img.data[i+1] += n * .9; img.data[i+2] += n * .6;
    }
    ctx.putImageData(img, 0, 0);
  })();
  const groundTex = new THREE.CanvasTexture(groundCanvas);
  groundTex.wrapS = groundTex.wrapT = THREE.RepeatWrapping;
  groundTex.repeat.set(120, 120);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(940, 940), new THREE.MeshStandardMaterial({ color: 0x8a9a5b, map: groundTex, roughness: 1 }));
  ground.rotation.x = -Math.PI/2; ground.receiveShadow = true;
  scene.add(ground);
  // ===== آسفالت PBR: آلبیدو + نورمال + رافنس (از cine3d) =====
  const CINE_PBR = window.CINE_PBR || null;
  const asphaltP = CINE_PBR ? CINE_PBR.asphalt() : null;
  const roadMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: asphaltP ? asphaltP.map : null,
    normalMap: asphaltP ? asphaltP.normal : null,
    normalScale: new THREE.Vector2(.75, .75),
    roughnessMap: asphaltP ? asphaltP.rough : null,
    roughness: .92, metalness: .02,
  });
  W.cineRoadMat = roadMat;
  const MAIN_LANES = [-160, 0, 160];                 // مختصات بلوارها — ترافیک فقط روی همینا
  MAIN_LANES.forEach(c => {
    const v = new THREE.Mesh(new THREE.PlaneGeometry(14, 940), roadMat);
    v.rotation.x = -Math.PI/2; v.position.set(c, .01, 0); scene.add(v);
    const h = new THREE.Mesh(new THREE.PlaneGeometry(940, 14), roadMat);
    h.rotation.x = -Math.PI/2; h.position.set(0, .01, c); scene.add(h);
  });
  // دو خیابون فرعی قدیمی
  [[14, 240, -80, -60], [240, 14, 80, 60]].forEach(([w, d, x, z]) => {
    const r = new THREE.Mesh(new THREE.PlaneGeometry(w, d), roadMat);
    r.rotation.x = -Math.PI/2; r.position.set(x, .01, z);
    r.receiveShadow = true;
    scene.add(r);
  });
  // ===== پیاده‌رو سنگ‌فرش PBR دو طرف بلوارها =====
  const sidewalkP = CINE_PBR ? CINE_PBR.sidewalk() : null;
  if (sidewalkP) {
    const swMat = new THREE.MeshStandardMaterial({
      color: 0xffffff, map: sidewalkP.map, normalMap: sidewalkP.normal,
      normalScale: new THREE.Vector2(.8, .8),
      roughness: .95, metalness: 0,
    });
    W.cineSidewalkMat = swMat;
    const swGeoV = new THREE.PlaneGeometry(4.6, 940);
    const swGeoH = new THREE.PlaneGeometry(940, 4.6);
    MAIN_LANES.forEach(c => {
      for (const off of [9.3, -9.3]) {
        const v = new THREE.Mesh(swGeoV, swMat);
        v.rotation.x = -Math.PI/2; v.position.set(c + off, .015, 0); v.receiveShadow = true;
        scene.add(v);
        const h = new THREE.Mesh(swGeoH, swMat);
        h.rotation.x = -Math.PI/2; h.position.set(0, .015, c + off); h.receiveShadow = true;
        scene.add(h);
      }
    });
  }
  // خط‌کشی‌ها: یک InstancedMesh برای همهٔ خط‌ها (۲ دراُکال به‌جای صدها)
  {
    const dashGeo = new THREE.PlaneGeometry(.5, 4);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xdddddd, transparent: true, opacity: .85 });
    const dashes = [];
    MAIN_LANES.forEach(c => {
      for (let i = -450; i < 455; i += 12) {
        dashes.push([c, i, 0]);          // عمودی
        dashes.push([i, c, 1]);          // افقی
      }
    });
    const inst = new THREE.InstancedMesh(dashGeo, lineMat, dashes.length);
    const dummy = new THREE.Object3D();
    dashes.forEach(([x, z, horiz], i) => {
      dummy.position.set(x, .02, z);
      dummy.rotation.set(-Math.PI/2, 0, horiz ? 0 : Math.PI/2);
      dummy.updateMatrix();
      inst.setMatrixAt(i, dummy.matrix);
    });
    inst.instanceMatrix.needsUpdate = true;
    scene.add(inst);
  }

  // ===== متریال‌های خودرو: بدنه clearcoat سینمایی + شیشه آینه‌ای =====
  const CAR_GLASS_MAT = new THREE.MeshStandardMaterial({
    color: 0x0e1c26, roughness: .05, metalness: .95, envMapIntensity: 2.2,
  });
  const CAR_TIRE_MAT = new THREE.MeshStandardMaterial({ color: 0x0c0c0e, roughness: .95, metalness: 0 });
  const CAR_RIM_MAT = new THREE.MeshStandardMaterial({ color: 0xc9cfd8, roughness: .25, metalness: .95, envMapIntensity: 1.4 });
  const HEAD_GEO = new THREE.BoxGeometry(.42, .2, .06);
  const TAIL_GEO = new THREE.BoxGeometry(.35, .18, .06);
  const HEAD_MAT = new THREE.MeshStandardMaterial({ color: 0xfff6d8, emissive: 0xffe9a8, emissiveIntensity: 1.2 });
  const TAIL_MAT = new THREE.MeshStandardMaterial({ color: 0x8a1420, emissive: 0xff2a30, emissiveIntensity: .55 });
  const HEAD_MAT_OFF = new THREE.MeshStandardMaterial({ color: 0xe8e4d2, emissiveIntensity: 0 });
  const TAIL_MAT_ON = new THREE.MeshStandardMaterial({ color: 0xb51f2e, emissive: 0xff2230, emissiveIntensity: 2.2 });
  const CAR_SHADOW_TEX = (() => {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const ctx = c.getContext('2d');
    const g = ctx.createRadialGradient(32, 32, 4, 32, 32, 31);
    g.addColorStop(0, 'rgba(0,0,0,.5)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  const CAR_SHADOW_MAT = new THREE.MeshBasicMaterial({ map: CAR_SHADOW_TEX, transparent: true, depthWrite: false, opacity: .85 });
  const CAR_SHADOW_GEO = new THREE.PlaneGeometry(4.4, 5.6);
  const CARS3 = window.CARS3D ? window.CARS3D(THREE) : null;   // ماشین‌های جدید (cars3d.js)
  const showCars = [];                                          // ماشین‌های چرخان نمایشگاه
  const PAINTS = [null, 0xe63946, 0xf97316, 0xfacc15, 0x22c55e, 0x06b6d4, 0x3b82f6, 0x8b5cf6, 0xec4899, 0xf5f5f5, 0x111214, 0x9ca3af];  // پالت رنگ (کلید C)

  // ---------- ساختمون‌ساز با kind های مختلف ----------
  const colliders = [];
  const _camBlockers = [];      // بدنهٔ ساختمان‌ها برای برخورد دوربین (تعریف زودهنگام)
  let _lastFrameDt = .016;      // برای cine.update قبل از حلقه
  let _prevCarPos = null;
  let _carYawRate = 0, _carSpdPrev = 0, _carAccS = 0, _nitroOn = false, _lastSmoke = 0, _lastHorn = 0;
  // 📊 سنجش عملکرد (بالا تعریف میشه که حلقه همیشه پیداش کنه)
  var _fps = 0, _fpsT = 0, _fpsN = 0;
  function fpsTick(dt) { _fpsT += dt; _fpsN++; if (_fpsT >= .5) { _fps = _fpsN / _fpsT; _fpsT = 0; _fpsN = 0; } }
  W.perfInfo = () => 'FPS≈' + Math.round(_fps) + ' | اشیا: ' + scene.children.length +
    ' | draw: ' + renderer.info.render.calls + ' | مثلث: ' + Math.round(renderer.info.render.triangles / 1000) + 'k';
  var farCull = 0;          // کالینگ فاصله‌ای (var: قبل از تعریف هم خونده میشه)
  var cullables = [];
  // ⚡ کش متریال: رنگ‌های تکراری یک متریال مشترک بگیرن (به‌جای هزاران متریال)
  const MAT_CACHE = new Map();
  function mat(c, roughness = .85, metalness = .05) {
    const key = c + '|' + roughness + '|' + metalness;
    let m = MAT_CACHE.get(key);
    if (!m) { m = new THREE.MeshStandardMaterial({ color: c, roughness, metalness }); MAT_CACHE.set(key, m); }
    return m;
  }
  // ⚡ بافت نمای ساختمان: الگوی پنل با نویز ظریف که روی رنگ هر ساختمان اعمال می‌شود
  // (تکسچر خاکستری نزدیک‌به‌سفید × رنگ متریال = نما دیگه صاف و پلاستیکی به‌نظر نمی‌رسه)
  function makeFacadeCanvas() {
    const c = document.createElement('canvas');
    c.width = c.height = 256;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#cfcfcf'; ctx.fillRect(0, 0, 256, 256);
    const img = ctx.getImageData(0, 0, 256, 256);
    for (let i = 0; i < img.data.length; i += 4) {
      const n = (Math.random() - .5) * 16;
      img.data[i] += n; img.data[i+1] += n; img.data[i+2] += n;
    }
    ctx.putImageData(img, 0, 0);
    ctx.strokeStyle = 'rgba(0,0,0,.11)'; ctx.lineWidth = 2;
    for (let x = 0; x <= 256; x += 32) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 256); ctx.stroke(); }
    for (let y = 0; y <= 256; y += 32) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(256, y); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(255,255,255,.07)';
    for (let x = 1; x <= 256; x += 32) { ctx.beginPath(); ctx.moveTo(x + 1, 0); ctx.lineTo(x + 1, 256); ctx.stroke(); }
    return c;
  }
  const FACADE_CANVAS = makeFacadeCanvas();
  const WALL_MAT_CACHE = new Map();
  function wallMat(c, w, d, h, roughness = .88, metalness = .04) {
    const key = c + '|' + Math.round(w) + '|' + Math.round(h);
    let m = WALL_MAT_CACHE.get(key);
    if (!m) {
      const tex = new THREE.CanvasTexture(FACADE_CANVAS);
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(Math.max(1, w / 4), Math.max(1, h / 4));
      const params = { color: c, map: tex, roughness, metalness };
      if (facadeP) {
        const nt = facadeP.normal.clone(); nt.needsUpdate = true;
        nt.wrapS = nt.wrapT = THREE.RepeatWrapping;
        nt.repeat.set(Math.max(1, w / 4), Math.max(1, h / 4));
        params.normalMap = nt;
        params.normalScale = new THREE.Vector2(.6, .6);
      }
      m = new THREE.MeshStandardMaterial(params);
      WALL_MAT_CACHE.set(key, m);
    }
    return m;
  }
  // ===== نمای PBR: نرمال‌مپ آجر/پنل + شیشهٔ بازتابی =====
  const facadeP = CINE_PBR ? CINE_PBR.facade() : null;
  const WIN_MAT = new THREE.MeshLambertMaterial({ color: 0x224466, emissive: 0x112233 });
  const GLASS_MAT = new THREE.MeshStandardMaterial({
    color: 0x3d5a72, roughness: .08, metalness: .9, envMapIntensity: 1.6,
  });
  // ===== ساختمان‌های رندری: رندر سه‌رخ روی صفحات ضربدری + پد تخت =====
  const _facadeTex = {}, _facadeCbs = {};
  function facadeTex(url, cb) {
    if (!_facadeCbs[url]) {
      _facadeCbs[url] = [];
      _facadeTex[url] = new THREE.TextureLoader().load(url, t => {
        if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = 4;
        t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
        _measureFacadeAvg(url, t.image);
        for (const cb2 of _facadeCbs[url]) cb2(t);
      });
    }
    _facadeCbs[url].push(cb);
    return _facadeTex[url];
  }
  // میانگین رنگ رندر → پد زیر ساختمان هم‌رنگ خودش می‌شود
  const _facadeAvg = {}, _tintMats = {};
  function _measureFacadeAvg(url, img) {
    try {
      const c = document.createElement('canvas');
      c.width = c.height = 48;
      const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(img, 0, 0, 48, 48);
      const d = x.getImageData(0, 0, 48, 48).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) continue;
        r += d[i]; g += d[i + 1]; b += d[i + 2]; n++;
      }
      if (!n) return;
      const hex = (((r / n) << 16) | ((g / n) << 8) | (b / n)) & 0xffffff;
      _facadeAvg[url] = hex;
      for (const m of (_tintMats[url] || [])) m._setTint(hex);
    } catch (e) { /* ignore */ }
  }
  const _tintCache = {};
  function tintMat(hex) {
    if (_tintCache[hex]) return _tintCache[hex];
    const m = new THREE.MeshStandardMaterial({ color: hex, roughness: .9, metalness: 0 });
    m._setTint = h => m.color.setHex(h);
    _tintCache[hex] = m;
    return m;
  }
  function _shadeHex(hex, k) {
    const r = Math.min(255, ((hex >> 16 & 255) * k) | 0),
          g = Math.min(255, ((hex >> 8 & 255) * k) | 0),
          b = Math.min(255, ((hex & 255) * k) | 0);
    return ((r << 16) | (g << 8) | b) >>> 0;
  }
  const _renderNightMats = [];
  function buildRenderVisual(b, g, body) {
    body.visible = false;            // بدنهٔ توپر پنهان؛ فقط برای برخورد/دوربین می‌ماند
    body.castShadow = false;
    const hex0 = _facadeAvg[b.img] || b.color;
    // پد تخت مثل میدان‌جلوی ساختمان — نه جعبهٔ بلند
    const padMat = tintMat(_shadeHex(hex0, .55));
    (_tintMats[b.img] || (_tintMats[b.img] = [])).push(padMat);
    const padR = Math.max(b.w, b.d) * .62;
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(padR, padR * 1.04, .16, 20), padMat);
    pad.position.y = .08;
    pad.receiveShadow = true;
    g.add(pad);
    // رندر روی سه صفحهٔ ضربدری → حجم کامل از هر زاویه
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: .8, metalness: 0,
      alphaTest: .3, side: THREE.DoubleSide,
      emissive: 0xffc46b, emissiveIntensity: 0,
    });
    _renderNightMats.push(mat);
    const geo = new THREE.PlaneGeometry(1, 1);
    const planes = [];
    for (const rot of [0, Math.PI / 3, Math.PI * 2 / 3]) {
      const p = new THREE.Mesh(geo, mat);
      p.rotation.y = rot;
      g.add(p);
      planes.push(p);
    }
    const fit = img => {
      const imgAR = img.width / img.height;
      const maxW = Math.min(Math.max(b.w, b.d) * 1.45, Math.min(b.w, b.d) * 1.6 + 6);
      const ph = Math.min(b.h * 1.3, maxW / imgAR);
      const pw = ph * imgAR;
      for (const p of planes) {
        p.scale.set(pw, ph, 1);      // کشیدگی در فضای خودِ صفحه، نه بعد از چرخش
        p.position.y = ph / 2 + .1;  // روی زمین می‌ایستد
      }
    };
    facadeTex(b.img, t => {
      mat.map = t; mat.emissiveMap = t; mat.needsUpdate = true;
      if (t.image && t.image.width) fit(t.image);
    });
  }
  function _applyPhotoFacadeNight(daylight) {
    const glow = Math.max(0, 1 - daylight * 2.2) * .55;   // پنجره‌ها شب روشن
    for (const m of _renderNightMats) m.emissiveIntensity = glow;
  }
  const WIN_GEO = new THREE.BoxGeometry(1.2, 1.4, .1);          // ⚡ هندسهٔ مشترک همهٔ پنجره‌ها
  const WIN_FRAME_GEO = new THREE.BoxGeometry(1.42, 1.62, .07);
  const WIN_FRAME_MAT = new THREE.MeshStandardMaterial({ color: 0xe9dfd0, roughness: .9 });
  const god = window.GOD_CONFIG || {};
  const makeDetailedPerson = (color, look, id) => window.createGameCharacter
    ? window.createGameCharacter(THREE, mat, color, look, id)
    : makePerson(color, look);
  function buildBuilding(b) {
    const g = new THREE.Group();
    if (b.kind === 'open') { // پارک
      const lawn = new THREE.Mesh(new THREE.PlaneGeometry(b.w, b.d), mat(0x3a7d44));
      lawn.rotation.x = -Math.PI/2; lawn.position.y = .02;
      g.add(lawn);
      const fenceMat = mat(0x555555);
      for (let fx = -b.w/2; fx <= b.w/2; fx += 3) {
        const f = new THREE.Mesh(new THREE.BoxGeometry(.15, 1, .15), fenceMat);
        f.position.set(fx, .5, -b.d/2); g.add(f);
        const f2 = f.clone(); f2.position.z = b.d/2; g.add(f2);
      }
      const bench = new THREE.Mesh(new THREE.BoxGeometry(2.4, .5, .8), mat(0x8b5a2b));
      bench.position.set(2, .4, 2); g.add(bench);
      const fountain = new THREE.Mesh(new THREE.CylinderGeometry(2, 2.4, .8, 12), mat(0x88bbdd));
      fountain.position.set(-4, .4, -3); g.add(fountain);
    } else {
      const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), wallMat(b.color, b.w, b.d, b.h));
      body.position.y = b.h/2; body.castShadow = body.receiveShadow = true;
      g.add(body);
      if (b.kind !== 'open') _camBlockers.push(body);
      if (b.img) {
        if (window.ARCH3D) { body.visible = false; body.castShadow = false; window.ARCH3D.build(b, g); }   // 🏙️ معماری سه‌بعدی واقعی
        else buildRenderVisual(b, g, body);   // رندر سه‌رخ (حالت پشتیبان)
      }
      // پنجره‌ها
      const winMat = WIN_MAT;
      const _photoMode = !!b.img;   // نمای عکس‌دار: پنجره/در/سایبان procedural خاموش
      if (!_photoMode) {
      // ⚡ پنجره‌ها با InstancedMesh: کل پنجره‌های یک ساختمون فقط ۲ draw call
      const winPos = [];
      for (let fy = 2; fy < b.h - 1; fy += 3)
        for (let fx = -b.w/2 + 1.5; fx < b.w/2 - 1; fx += 2.6) {
          if (winPos.length >= 20) break;
          winPos.push([fx, fy]);
        }
      if (winPos.length) {
        const dummy = new THREE.Object3D();
        const glass = new THREE.InstancedMesh(WIN_GEO, winMat, winPos.length);
        const frames = new THREE.InstancedMesh(WIN_FRAME_GEO, WIN_FRAME_MAT, winPos.length);
        winPos.forEach(([fx, fy], i) => {
          dummy.position.set(fx, fy, b.d/2 + .05); dummy.updateMatrix();
          glass.setMatrixAt(i, dummy.matrix);
          dummy.position.set(fx, fy, b.d/2 + .02); dummy.updateMatrix();
          frames.setMatrixAt(i, dummy.matrix);
        });
        glass.instanceMatrix.needsUpdate = frames.instanceMatrix.needsUpdate = true;
        g.add(frames, glass);
      }
      // در
      const door = new THREE.Mesh(new THREE.BoxGeometry(2, 2.6, .15), mat(0x5c3a21));
      door.position.set(0, 1.3, b.d/2 + .06);
      g.add(door);
      // قاب، سایبان و جزئیات نما؛ ساختمان‌ها از حالت مکعب ساده خارج می‌شوند.
      const doorFrame = new THREE.Mesh(new THREE.BoxGeometry(2.35, 2.92, .11), mat(0xe6d6bd));
      doorFrame.position.set(0, 1.46, b.d/2 + .015); g.add(doorFrame);
      door.position.z += .13;
      const awning = new THREE.Mesh(new THREE.BoxGeometry(Math.min(5.2, b.w * .58), .18, 1.25), mat(b.kind === 'commercial' ? 0xe63946 : 0x264653));
      awning.position.set(0, 3.05, b.d/2 + .55); awning.rotation.x = -.08; g.add(awning);
      if (b.h > 7) {
        for (let fy = 4.1; fy < b.h - 1; fy += 3.2) {
          const balcony = new THREE.Mesh(new THREE.BoxGeometry(Math.min(5.5, b.w * .62), .16, .85), mat(0xd8d0c4));
          balcony.position.set(0, fy, b.d/2 + .42); g.add(balcony);
          const rail = new THREE.Mesh(new THREE.BoxGeometry(Math.min(5.3, b.w * .6), .48, .06), mat(0x363d45, .42, .62));
          rail.position.set(0, fy + .28, b.d/2 + .82); g.add(rail);
        }
      }
      const step1 = new THREE.Mesh(new THREE.BoxGeometry(3.1, .18, 1.05), mat(0xb9ad9c));
      step1.position.set(0, .09, b.d/2 + .65); g.add(step1);
      const porchLamp = new THREE.Mesh(new THREE.SphereGeometry(.13, 8, 8),
        new THREE.MeshStandardMaterial({color:0xfff0b5,emissive:0xffc857,emissiveIntensity:1.5}));
      porchLamp.position.set(1.35, 2.45, b.d/2 + .22); g.add(porchLamp);
      const cornice = new THREE.Mesh(new THREE.BoxGeometry(b.w + .45, .28, b.d + .45), mat(0xe0d3c1));
      cornice.position.y = b.h + .05; g.add(cornice);
      if (b.h > 8) {
        const ac = new THREE.Group();
        const acBody = new THREE.Mesh(new THREE.BoxGeometry(1.15,.62,.42), mat(0xd7dce0,.55,.2));
        const fan = new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,.04,12), mat(0x59636d,.45,.5));
        fan.rotation.x=Math.PI/2; fan.position.z=.23; ac.add(acBody,fan);
        ac.position.set(b.w*.32, b.h*.62, b.d/2+.18); g.add(ac);
      }
      } // پایان !_photoMode
      // سقف بر اساس نوع (نمای عکس‌دار سقف عکس خودش را دارد)
      if (!_photoMode)
      if (b.kind === 'gable') {
        const roof = new THREE.Mesh(new THREE.ConeGeometry(Math.max(b.w, b.d)/1.5, 3, 4), mat(0x8d3b2f));
        roof.rotation.y = Math.PI/4; roof.position.y = b.h + 1.5; roof.castShadow = true;
        g.add(roof);
      } else if (b.kind === 'dome') {
        const dome = new THREE.Mesh(new THREE.SphereGeometry(Math.min(b.w, b.d)/2.4, 14, 10, 0, Math.PI*2, 0, Math.PI/2), mat(0xd4af37));
        dome.position.y = b.h; dome.castShadow = true;
        g.add(dome);
        // ستون‌ها
        for (const sx of [-b.w/2 + 1, b.w/2 - 1]) {
          const col = new THREE.Mesh(new THREE.CylinderGeometry(.4, .4, b.h * .8, 8), mat(0xf5f0e6));
          col.position.set(sx, b.h * .4, b.d/2 + .5);
          g.add(col);
        }
      } else if (b.kind === 'tower') {
        const top = new THREE.Mesh(new THREE.BoxGeometry(b.w * .6, 2, b.d * .6), mat(b.color));
        top.position.y = b.h + 1;
        const antenna = new THREE.Mesh(new THREE.CylinderGeometry(.1, .1, 4), mat(0xcc2222));
        antenna.position.y = b.h + 4;
        g.add(top, antenna);
      } else if (b.kind === 'awning') {
        const awn = new THREE.Mesh(new THREE.BoxGeometry(b.w * .9, .3, 2.2), mat(0xe63946));
        awn.position.set(0, 3, b.d/2 + 1.1);
        const awn2 = new THREE.Mesh(new THREE.BoxGeometry(b.w * .9, .3, 2.2), mat(0xffffff));
        awn2.position.set(0, 3.31, b.d/2 + 1.1);
        awn2.scale.set(.97, 1, .97);
        g.add(awn, awn2);
      } else if (b.kind === 'modern') {
        const glass = new THREE.Mesh(new THREE.BoxGeometry(b.w * .95, b.h * .7, .2), GLASS_MAT);
        glass.position.set(0, b.h * .45, b.d/2 + .11);
        const band = new THREE.Mesh(new THREE.BoxGeometry(b.w + .4, .8, b.d + .4), mat(0x222222));
        band.position.y = b.h;
        g.add(glass, band);
      } else { // flat
        const edge = new THREE.Mesh(new THREE.BoxGeometry(b.w + .5, .5, b.d + .5), mat(0x333333));
        edge.position.y = b.h + .25;
        g.add(edge);
      }
      colliders.push({ x: b.x, z: b.z, hx: b.w/2 + .8, hz: b.d/2 + .8 });
      godBldCollider[b.id] = colliders[colliders.length - 1];
    }
    godBldGroups[b.id] = g;
    // گل‌فروشی: گلدون‌ها و گل‌های رنگی جلوی مغازه!
    if (b.id === 'flower') {
      const flowerColors = [0xff2d78, 0xffd166, 0xffffff, 0xc084fc, 0xff6b35, 0xff8fab];
      for (let i = 0; i < 6; i++) {
        const fx = -b.w/2 + 1 + i * (b.w - 2) / 5;
        const pot = new THREE.Mesh(new THREE.CylinderGeometry(.28, .2, .5, 8), mat(0xb5651d, .9, 0));
        pot.position.set(fx, .25, b.d/2 + 1);
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(.03, .04, .5, 6), mat(0x2d6a4f));
        stem.position.set(fx, .75, b.d/2 + 1);
        const bloom = new THREE.Mesh(new THREE.SphereGeometry(.16, 8, 8), mat(flowerColors[i], .6, 0));
        bloom.position.set(fx, 1.05, b.d/2 + 1);
        const leaves = new THREE.Mesh(new THREE.SphereGeometry(.12, 6, 6), mat(0x40916c));
        leaves.position.set(fx + .08, .8, b.d/2 + 1.05);
        g.add(pot, stem, bloom, leaves);
      }
      // باکس گل بزرگ کنار در
      const box = new THREE.Mesh(new THREE.BoxGeometry(2, .5, .8), mat(0x8b5a2b, .9, 0));
      box.position.set(-b.w/2 + 1.4, .25, b.d/2 + 2);
      g.add(box);
      for (let i = 0; i < 5; i++) {
        const bl = new THREE.Mesh(new THREE.SphereGeometry(.14, 8, 8), mat(flowerColors[(i + 2) % 6], .6, 0));
        bl.position.set(-b.w/2 + .7 + i * .38, .65, b.d/2 + 2);
        g.add(bl);
      }
    }
    // نمایشگاه اتومبیل: ماشین‌های ویترینی روی سکو!
    if (b.id === 'dealership') {
      const showColors = [0xe63946, 0xffffff, 0x1d3557];
      for (let i = 0; i < 3; i++) {
        const fx = -b.w/2 + 3 + i * (b.w - 6) / 2;
        const podium = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.8, .3, 16), mat(0xdddddd, .3, .4));
        podium.position.set(fx, .15, b.d/2 + 3.2);
        g.add(podium);
        const show = makeCarMesh(showColors[i], ['bmw', 'camry', 'haima'][i], { player: true });
        show.position.set(fx, .3, b.d/2 + 3.2);
        show.rotation.y = -Math.PI/5 + i * Math.PI/5;
        show.scale.setScalar(.85);
        if (show.userData.setLamps) show.userData.setLamps(true);
        g.add(show);
        showCars.push({ car: show, spd: (i % 2 ? -1 : 1) * (.25 + i * .06) });
        const ring = new THREE.Mesh(new THREE.TorusGeometry(2.55, .05, 6, 40), new THREE.MeshBasicMaterial({ color: [0xff4d6d, 0x38bdf8, 0x34d399][i] }));
        ring.rotation.x = Math.PI / 2; ring.position.set(fx, .34, b.d/2 + 3.2);
        g.add(ring);
      }
      // پرچم‌های نمایشگاه
      for (const fx of [-b.w/2 + 1, b.w/2 - 1]) {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(.06, .06, 4.5), mat(0x999999, .4, .7));
        pole.position.set(fx, 2.25, b.d/2 + 5.5);
        const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.1, .6), new THREE.MeshBasicMaterial({ color: 0x00b4d8, side: THREE.DoubleSide }));
        flag.position.set(fx + .55, 4.2, b.d/2 + 5.5);
        g.add(pole, flag);
      }
    }
    // تابلوی نئونی آکادمی رباتیک نوین‌ذهن
    if (b.id === 'robotics') {
      const lc = document.createElement('canvas');
      lc.width = 256; lc.height = 256;
      const ctx = lc.getContext('2d');
      ctx.fillStyle = '#14101f'; ctx.fillRect(0, 0, 256, 256);
      ctx.save();
      ctx.shadowBlur = 30;
      // نیمه بنفش مغز — خطوط ارگانیک
      ctx.shadowColor = '#6a4c9c';
      ctx.fillStyle = '#6a4c9c';
      ctx.beginPath();
      ctx.moveTo(128, 38);
      ctx.bezierCurveTo(70, 30, 38, 70, 44, 118);
      ctx.bezierCurveTo(36, 160, 66, 208, 122, 214);
      ctx.bezierCurveTo(126, 190, 122, 160, 128, 128);
      ctx.bezierCurveTo(122, 96, 126, 66, 128, 38);
      ctx.fill();
      // چین‌های مغز بنفش
      ctx.strokeStyle = '#8d6cc0'; ctx.lineWidth = 5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(88, 90, 22, .4, 2.5); ctx.stroke();
      ctx.beginPath(); ctx.arc(84, 155, 20, 3.5, 5.6); ctx.stroke();
      // نیمه طلایی
      ctx.shadowColor = '#e8a83c';
      ctx.fillStyle = '#e8a83c';
      ctx.beginPath();
      ctx.moveTo(128, 38);
      ctx.bezierCurveTo(186, 30, 218, 70, 212, 118);
      ctx.bezierCurveTo(220, 160, 190, 208, 134, 214);
      ctx.bezierCurveTo(130, 190, 134, 160, 128, 128);
      ctx.bezierCurveTo(134, 96, 130, 66, 128, 38);
      ctx.fill();
      ctx.strokeStyle = '#f2c46d'; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.arc(168, 90, 22, .7, 2.8); ctx.stroke();
      ctx.beginPath(); ctx.arc(172, 155, 20, 3.8, 5.9); ctx.stroke();
      ctx.restore();
      // «ن» به‌صورت negative space وسط مغز
      ctx.fillStyle = '#14101f';
      ctx.font = 'bold 86px Vazirmatn, Tahoma';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('ن', 128, 122);
      // اسم آکادمی
      ctx.shadowBlur = 12; ctx.shadowColor = '#e8a83c';
      ctx.fillStyle = '#f5e6c8';
      ctx.font = 'bold 26px Vazirmatn, Tahoma';
      ctx.fillText('نوین‌ذهن', 128, 238);
      const logoTex = new THREE.CanvasTexture(lc);
      const neonFrame = new THREE.Mesh(new THREE.BoxGeometry(5.6, 5.6, .3),
        new THREE.MeshStandardMaterial({ color: 0x0a0812, emissive: 0x6a4c9c, emissiveIntensity: .35, roughness: .4 }));
      neonFrame.position.set(0, b.h + 3.2, b.d/2 - 1);
      const logo = new THREE.Mesh(new THREE.PlaneGeometry(5.1, 5.1),
        new THREE.MeshBasicMaterial({ map: logoTex }));
      logo.position.set(0, b.h + 3.2, b.d/2 - .82);
      const pole1 = new THREE.Mesh(new THREE.CylinderGeometry(.15, .15, 3.4), mat(0x222222, .4, .8));
      pole1.position.set(-2, b.h + 1, b.d/2 - 1);
      const pole2 = pole1.clone(); pole2.position.x = 2;
      g.add(neonFrame, logo, pole1, pole2);
    }
    // تابلوی اسم
    if (!b.deco && b.name) {
      const label = makeLabel3D(b.icon + ' ' + b.name);
      label.position.y = (b.kind === 'open' ? 4 : b.h + (b.kind === 'gable' ? 4 : 3));
      label.scale.set(9, 2.2, 1);
      g.add(label);
    }
    g.position.set(b.x, 0, b.z);
    cullables.push(g);
    // ادیت‌های ذخیره‌شدهٔ گادمود
    const ge = godEdits.buildings?.[b.id];
    if (ge) {
      g.position.set(ge.x, 0, ge.z);
      g.rotation.y = ge.rotY || 0;
      const c = godBldCollider[b.id];
      if (c) {
        c.x = ge.x; c.z = ge.z;
        if (Math.round(Math.abs(ge.rotY || 0) / (Math.PI / 2)) % 2 === 1) { const t = c.hx; c.hx = c.hz; c.hz = t; }
      }
    }
    scene.add(g);
  }
  const godBldGroups = {}, godBldCollider = {};
  const GOD_KEY = 'tehran1405-god';
  let godEdits;
  try { godEdits = JSON.parse(safeStore.getItem(GOD_KEY) || '{}'); } catch { godEdits = {}; }
  godEdits.buildings = godEdits.buildings || {};
  godEdits.npcs = godEdits.npcs || {};
  godEdits.roads = godEdits.roads || [];
  godEdits.interiors = godEdits.interiors || {};

  const LABEL_CACHE = new Map();
  function makeLabel3D(text) {
    // ⚡ کش: هر متن یک بار تکسچر می‌سازه و بقیه ازش استفاده می‌کنن
    const cached = LABEL_CACHE.get(text);
    if (cached) return new THREE.Sprite(cached);
    const c = document.createElement('canvas');
    c.width = 256; c.height = 64;
    const ctx = c.getContext('2d');
    ctx.fillStyle = 'rgba(10,10,25,.75)';
    ctx.roundRect(4, 5, 248, 54, 11); ctx.fill();
    ctx.strokeStyle = '#ffd166'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = '#ffd166';
    ctx.font = 'bold 26px Vazirmatn, Tahoma';
    ctx.textAlign = 'center';
    ctx.fillText(text, 128, 41);
    const tex = new THREE.CanvasTexture(c);
    tex.minFilter = THREE.LinearFilter;            // بدون mipmap = سریع‌تر
    tex.generateMipmaps = false;
    const matSpr = new THREE.SpriteMaterial({ map: tex, depthTest: false });
    LABEL_CACHE.set(text, matSpr);
    return new THREE.Sprite(matSpr);
  }

  BUILDINGS.forEach(buildBuilding);

  // ---------- استند بزرگ عکس، آزاد وسط شهر (نه چسبیده به هیچ ساختمونی) ----------
  (() => {
    const standGroup = new THREE.Group();
    const PHOTO_W = 8, PHOTO_H = 10; // پرتره، نه مربع
    const FRAME_T = .35;
    const loader = new THREE.TextureLoader();
    const photoMat = new THREE.MeshBasicMaterial({ color: 0xffffff }); // تا لود عکس، سفید
    loader.load('assets/billboard-user.png', tex => {
      if (tex.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) tex.colorSpace = THREE.SRGBColorSpace;
      photoMat.map = tex;
      photoMat.color.set(0xffffff);
      photoMat.needsUpdate = true;
    });
    const photoGeo = new THREE.PlaneGeometry(PHOTO_W, PHOTO_H);
    const photoFront = new THREE.Mesh(photoGeo, photoMat);
    photoFront.position.set(0, PHOTO_H/2 + 1.4, FRAME_T/2 + .02);
    const photoBack = new THREE.Mesh(photoGeo, photoMat);
    photoBack.position.set(0, PHOTO_H/2 + 1.4, -FRAME_T/2 - .02);
    photoBack.rotation.y = Math.PI;
    standGroup.add(photoFront, photoBack);

    // قاب دور عکس
    const frameMat = mat(0x2a2a2e, .5, .3);
    const frameSideGeo = new THREE.BoxGeometry(.35, PHOTO_H + .6, FRAME_T);
    const frameTopGeo = new THREE.BoxGeometry(PHOTO_W + .7, .35, FRAME_T);
    const fL = new THREE.Mesh(frameSideGeo, frameMat); fL.position.set(-PHOTO_W/2 - .17, PHOTO_H/2 + 1.4, 0);
    const fR = fL.clone(); fR.position.x = PHOTO_W/2 + .17;
    const fT = new THREE.Mesh(frameTopGeo, frameMat); fT.position.set(0, PHOTO_H + 1.4 + .17, 0);
    const fB = fT.clone(); fB.position.y = 1.4 - .17;
    fL.castShadow = fR.castShadow = fT.castShadow = fB.castShadow = true;
    standGroup.add(fL, fR, fT, fB);

    // دو پایه‌ی نگه‌دارنده، آزاد وسط میدون (نه چسبیده به دیوار)
    const legMat = mat(0x3a3a40, .45, .4);
    [-1, 1].forEach(side => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(.4, 1.6, .4), legMat);
      leg.position.set(side * (PHOTO_W/2 - .4), .8, .5);
      leg.rotation.x = -.12 * side * 0 - .1;
      leg.castShadow = true;
      standGroup.add(leg);
      const legBack = leg.clone(); legBack.position.z = -.5;
      standGroup.add(legBack);
    });
    // پایه‌ی سنگی زیرش
    const base = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.7, .4, 20), mat(0x8a8a8f, .8, .05));
    base.position.y = .2; base.receiveShadow = true;
    standGroup.add(base);

    standGroup.position.set(18, 0, -18); // فضای باز و آزاد وسط شهر، دور از خیابون و ساختمون‌ها
    standGroup.rotation.y = Math.PI / 4; // رو به چهارراه مرکزی
    scene.add(standGroup);
    colliders.push({ x: 18, z: -18, hx: 3, hz: 3 });
  })();

  // خانه‌های تزئینی قابل تنظیم در God Mode.
  const extraHomeCount = Math.max(0, Math.min(24, god.extraHomes ?? 8));
  for (let i = 0; i < extraHomeCount; i++) {
    const side = i % 2 ? 1 : -1;
    const row = Math.floor(i / 2);
    buildBuilding({ id:'god-home-'+i, name:'خانهٔ محله', icon:'🏠', kind:'residential', deco:true,
      x: side * (76 + (row % 3) * 18), z: -105 + Math.floor(row / 3) * 28,
      w:12, d:10, h:6 + (i % 3) * 2, color:[0xc98262,0xd6b47d,0x7393a7,0xa98570][i%4] });
  }

  // تیر چراغ‌برق (شب روشن میشن) و نیمکت‌های خیابون
  const lampBulbs = [];
  const lampLights = [];          // نورهای واقعی چراغ خیابان (استخرشده)
  const LAMP_LIGHT_COUNT = 5;     // فقط نزدیک‌ترین‌ها نور واقعی می‌گیرند
  for (let li = 0; li < LAMP_LIGHT_COUNT; li++) {
    const pl = new THREE.PointLight(0xffd98a, 0, 26, 2);
    pl.visible = false;
    scene.add(pl);
    lampLights.push(pl);
  }
  const lampPositions = [];
  function addLamp(x, z) {
    colliders.push({ x, z, hx: .4, hz: .4 });     // تو تیر چراغ‌برق نریم
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(.14, .18, 5.5, 8), mat(0x2a2a34, .5, .7));
    pole.position.set(x, 2.75, z); pole.castShadow = true;
    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.4, .12, .12), mat(0x2a2a34, .5, .7));
    arm.position.set(x + .6, 5.4, z);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(.28, 10, 8),
      new THREE.MeshStandardMaterial({ color: 0xfff2c0, emissive: 0xffe8a3, emissiveIntensity: 0, roughness: .3 }));
    bulb.position.set(x + 1.2, 5.3, z);
    scene.add(pole, arm, bulb);
    lampBulbs.push(bulb);
    lampPositions.push(bulb.position);
  }
  for (let i = -200; i <= 200; i += 33) { addLamp(-8.5, i); addLamp(i, 8.5); }
  // توزیع نور واقعی بین نزدیک‌ترین تیرها به بازیکن (هر فریم نه — سبک)
  function updateLampLights() {
    const night = G.hour >= 19 || G.hour < 6;
    if (!night) { lampLights.forEach(l => { l.intensity = 0; l.visible = false; }); return; }
    const px = player.position.x, pz = player.position.z;
    const best = [];
    for (const p of lampPositions) {
      const d = (p.x - px) * (p.x - px) + (p.z - pz) * (p.z - pz);
      if (best.length < LAMP_LIGHT_COUNT) { best.push({ p, d }); best.sort((a, b) => a.d - b.d); }
      else if (d < best[best.length - 1].d) { best[best.length - 1] = { p, d }; best.sort((a, b) => a.d - b.d); }
    }
    for (let i = 0; i < LAMP_LIGHT_COUNT; i++) {
      const l = lampLights[i];
      if (i < best.length) {
        const p = best[i].p;
        l.position.set(p.x, p.y - .2, p.z);
        l.intensity = 22 + Math.sin(i * 2.4) * 2;
        l.visible = true;
      } else { l.intensity = 0; l.visible = false; }
    }
  }
  function addBench(x, z, rot = 0) {
    const b = new THREE.Group();
    const seat = new THREE.Mesh(new THREE.BoxGeometry(2.4, .18, .7), mat(0x8b5a2b, .9, 0));
    seat.position.y = .55;
    const back = new THREE.Mesh(new THREE.BoxGeometry(2.4, .6, .12), mat(0x8b5a2b, .9, 0));
    back.position.set(0, .95, -.3);
    [[-1, 0], [1, 0]].forEach(([lx]) => {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(.15, .55, .6), mat(0x333333, .5, .6));
      leg.position.set(lx, .28, 0);
      b.add(leg);
    });
    b.add(seat, back);
    b.position.set(x, 0, z); b.rotation.y = rot;
    scene.add(b);
    colliders.push({ x, z, hx: 1.3, hz: 1.3 });   // نیمکت هم جامده!
  }
  addBench(-9.5, 20, Math.PI/2); addBench(-9.5, -20, Math.PI/2); addBench(20, 9.5, Math.PI);

  TREE_SPOTS.forEach(([x0, z0]) => {
    const c0 = typeof clampOffStreetCenter === 'function' ? clampOffStreetCenter(x0, z0, 2.5) : { x: x0, z: z0 };
    const x = c0.x, z = c0.z;
    colliders.push({ x, z, hx: .7, hz: .7 });          // از تو درخت رد نشیم!
    const t = new THREE.Group();
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.3, .45, 2.6), mat(0x5c3a21));
    trunk.position.y = 1.3; trunk.castShadow = true;
    const crown = new THREE.Mesh(new THREE.SphereGeometry(1.8, 8, 8), mat(0x2d6a4f));
    crown.position.y = 3.6; crown.castShadow = true;
    t.add(trunk, crown);
    t.position.set(x, 0, z);
    scene.add(t);
  });

  // ---------- تابلوی صرافی داینامیک ----------
  const sc = document.createElement('canvas');
  sc.width = 512; sc.height = 256;
  const sctx = sc.getContext('2d');
  const sarafiTex = new THREE.CanvasTexture(sc);
  function drawSarafi() {
    sctx.fillStyle = '#0b3d0b'; sctx.fillRect(0, 0, 512, 256);
    sctx.strokeStyle = '#ffd166'; sctx.lineWidth = 8; sctx.strokeRect(6, 6, 500, 244);
    sctx.fillStyle = '#ffd166'; sctx.font = 'bold 40px Vazirmatn, Tahoma'; sctx.textAlign = 'center';
    sctx.fillText('صرافی تهران ۱۴۰۵', 256, 56);
    sctx.fillStyle = '#fff'; sctx.font = 'bold 48px Vazirmatn, Tahoma';
    sctx.fillText('دلار: ' + fa(G.eco.dollar), 256, 130);
    sctx.fillStyle = '#aaffaa'; sctx.font = '30px Vazirmatn, Tahoma';
    sctx.fillText('بنزین: ' + fa(G.eco.benzin) + ' | تورم: ' + fa(G.eco.inflation) + '٪', 256, 200);
    sarafiTex.needsUpdate = true;
  }
  drawSarafi();
  const sarafiBack = new THREE.Mesh(new THREE.BoxGeometry(10.4, 5.4, .4), mat(0x111111));
  sarafiBack.position.set(8, 9, 12);
  const sarafiSign = new THREE.Mesh(new THREE.PlaneGeometry(10, 5), new THREE.MeshBasicMaterial({ map: sarafiTex }));
  sarafiSign.position.set(8, 9, 12.25);
  const sarafiPole = new THREE.Mesh(new THREE.CylinderGeometry(.3, .3, 7), mat(0x333333));
  sarafiPole.position.set(8, 3.5, 12);
  scene.add(sarafiBack, sarafiSign, sarafiPole);

  // ---------- آدمک ----------
  function makePerson(shirtColor, opts = {}) {
    const { pants = 0x333355, skin = 0xf0c8a0, hair = 0x2b1d0e,
            style = 'hair', accColor = 0x264653, moustache = false } = opts;
    const g = new THREE.Group();
    const legL = new THREE.Group();
    const lm = new THREE.Mesh(new THREE.CapsuleGeometry(.155, .5, 8, 14), mat(pants));
    lm.position.y = -.37;
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(.34, .16, .5, 2, 2, 2), mat(0x1a1a1a));
    shoe.position.set(0, -.72, .06);
    legL.add(lm, shoe); legL.position.set(-.22, .8, 0);
    const legR = legL.clone(); legR.position.x = .22;
    const body = new THREE.Mesh(new THREE.CylinderGeometry(.38, .46, 1.05, 20), mat(shirtColor));
    body.position.y = 1.4; body.castShadow = true;
    const armL = new THREE.Group();
    const am = new THREE.Mesh(new THREE.CapsuleGeometry(.1, .58, 8, 12), mat(shirtColor));
    am.position.y = -.35;
    const hand = new THREE.Mesh(new THREE.SphereGeometry(.11, 14, 12), mat(skin));
    hand.position.y = -.78;
    armL.add(am, hand); armL.position.set(-.52, 1.85, 0);
    const armR = armL.clone(); armR.position.x = .52;
    const head = new THREE.Group();
    head.add(new THREE.Mesh(new THREE.SphereGeometry(.36, 24, 18), mat(skin)));
    [-.13, .13].forEach(x => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(.075, 12, 10), mat(0xffffff));
      eye.position.set(x, .05, .3);
      const pupil = new THREE.Mesh(new THREE.SphereGeometry(.035, 10, 8), mat(0x1a1a1a));
      pupil.position.set(x, .05, .365);
      head.add(eye, pupil);
    });
    const nose = new THREE.Mesh(new THREE.SphereGeometry(.06, 10, 8), mat(0xdba97e));
    nose.position.set(0, -.05, .34); head.add(nose);
    const mouth = new THREE.Mesh(new THREE.TorusGeometry(.09, .02, 8, 16, Math.PI), mat(0x8b3a3a));
    mouth.position.set(0, -.14, .3); mouth.rotation.x = Math.PI; head.add(mouth);
    if (moustache) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(.24, .06, .06), mat(0x222222));
      m.position.set(0, -.11, .33); head.add(m);
    }
    if (style === 'hair') {
      // موی بالای سر — عقب‌تر و بالاتر که رو چشم نیاد!
      const h = new THREE.Mesh(new THREE.SphereGeometry(.36, 12, 10, 0, Math.PI*2, 0, Math.PI/2.4), mat(hair));
      h.position.set(0, .12, -.06);
      // پشت سر
      const back = new THREE.Mesh(new THREE.SphereGeometry(.34, 12, 10, 0, Math.PI*2, 0, Math.PI/1.8), mat(hair));
      back.position.set(0, .05, -.14);
      head.add(h, back);
    } else if (style === 'cap') {
      const top = new THREE.Mesh(new THREE.SphereGeometry(.36, 12, 8, 0, Math.PI*2, 0, Math.PI/2.6), mat(accColor));
      top.position.set(0, .13, -.02);
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(.34, .34, .05, 18, 1, false, 0, Math.PI), mat(accColor));
      brim.rotation.y = -Math.PI / 2;      // نیم‌دایره رو بچرخون سمت جلو (نه پهلو!)
      brim.position.set(0, .26, .06);      // بالای پیشونی، بالاتر از چشم‌ها
      brim.scale.set(1, 1, .78);
      head.add(top, brim);
    } else if (style === 'helmet') {
      const h = new THREE.Mesh(new THREE.SphereGeometry(.39, 12, 10, 0, Math.PI*2, 0, Math.PI/2.1), mat(accColor));
      h.position.set(0, .09, -.03);
      head.add(h);
    } else if (style === 'scarf') {
      // روسری: فقط بالای سر و پشت — صورت کاملاً باز!
      const s = new THREE.Mesh(new THREE.SphereGeometry(.40, 12, 10, 0, Math.PI*2, 0, Math.PI/2.3), mat(accColor));
      s.position.set(0, .11, -.04);
      const back = new THREE.Mesh(new THREE.SphereGeometry(.38, 12, 10, 0, Math.PI*2, 0, Math.PI/1.7), mat(accColor));
      back.position.set(0, .02, -.16);
      const under = new THREE.Mesh(new THREE.CylinderGeometry(.34, .44, .35, 10), mat(accColor));
      under.position.set(0, -.5, -.06);
      head.add(s, back, under);
    } else if (style === 'bald') {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(.3, .07, 6, 12), mat(0x999999));
      ring.rotation.x = Math.PI/2; ring.position.y = .05; head.add(ring);
    }
    head.position.y = 2.35;
    g.add(legL, legR, body, armL, armR, head);
    g.userData.limbs = { legL, legR, armL, armR };
    return g;
  }

  // بازیکن نمونهٔ ماژولار خودش را دارد؛ NPCها فعلاً با makePerson قدیمی می‌مانند.
  // 👕 تیپ بازیکن از کمد لباس (rp-life.js)
  function playerLookFromOutfit() {
    const base = JSON.parse(JSON.stringify(god.playerLook || {}));
    if (typeof ensureOutfit !== 'function') return base;
    ensureOutfit();
    const o = G.outfit, Wd = WEARABLES;
    const hat = Wd.hat.opts[o.hat] || Wd.hat.opts.none;
    base.outfit = Object.assign({}, base.outfit, {
      jacket: (Wd.shirt.opts[o.shirt] || {}).color ?? 0xb32632,
      shirt:  (Wd.shirt.opts[o.shirt] || {}).color ?? 0x17223b,
      pants:  (Wd.pants.opts[o.pants] || {}).color ?? 0x273247,
      shoes:  (Wd.shoes.opts[o.shoes] || {}).color ?? 0xf4f1ea,
    });
    base.accessory = Object.assign({}, base.accessory, {
      hat: hat.style === 'hair' ? 'none' : (hat.style === 'helmet' ? 'helmet' : 'cap'),
      hatColor: hat.color ?? 0x17223b,
    });
    return base;
  }
  function buildPlayerMesh() {
    return window.createPlayerCharacter
      ? window.createPlayerCharacter(THREE, mat, playerLookFromOutfit())
      : makePerson(0xe63946, { style:'cap', accColor:0x1d3557 });
  }
  let player = buildPlayerMesh();
  {
    // بازیکن هیچ‌وقت وسط خیابون اسپاون نشه
    const sp = typeof clampOffStreetCenter === 'function' ? clampOffStreetCenter(G.px, G.pz) : { x: G.px, z: G.pz };
    if (sp.moved) { G.px = sp.x; G.pz = sp.z; }
    player.position.set(G.px, 0, G.pz);
  }
  scene.add(player);
  worldReady = true;

  // ماشین بازیکن
  let playerCarMesh = null;
  let driving = false;
  function makeCarMesh(color, key, opts) {
    if (CARS3) { try { return CARS3.makeCar(color, key, opts); } catch (err) { console.warn('cars3d failed, legacy car', err); } }
    return makeCarMeshLegacy(color);
  }
  function makeCarMeshLegacy(color) {
    const g = new THREE.Group();
    const paint = new THREE.MeshPhysicalMaterial({
      color, roughness: .22, metalness: .78,
      clearcoat: 1, clearcoatRoughness: .1, envMapIntensity: 1.5,
    });
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.15, .72, 4.35), paint);
    body.position.y = .75; body.castShadow = true;
    const hood = new THREE.Mesh(new THREE.BoxGeometry(2.02, .18, 1.25), paint);
    hood.position.set(0, 1.13, 1.38);
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.82, .7, 2.05), paint);
    cabin.position.set(0, 1.42, -.18);
    const windshield = new THREE.Mesh(new THREE.PlaneGeometry(1.55, .58), CAR_GLASS_MAT);
    windshield.position.set(0, 1.48, .866); windshield.rotation.x = -.16;
    const rearGlass = windshield.clone(); rearGlass.position.z = -1.225; rearGlass.rotation.x = .16;
    const bumperF = new THREE.Mesh(new THREE.BoxGeometry(2.2, .18, .16), mat(0x25282c, .36, .7));
    bumperF.position.set(0, .62, 2.22);
    const bumperR = bumperF.clone(); bumperR.position.z = -2.22;
    g.add(body, hood, cabin, windshield, rearGlass, bumperF, bumperR);
    const wheels = [];
    [[-1.05,-1.45],[1.05,-1.45],[-1.05,1.45],[1.05,1.45]].forEach(w => {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(.42, .42, .32, 14), CAR_TIRE_MAT);
      wheel.rotation.z = Math.PI/2;
      wheel.castShadow = true;
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.34,12), CAR_RIM_MAT);
      hub.rotation.z = Math.PI/2;
      const wrap = new THREE.Group();
      wrap.add(wheel, hub);
      wrap.position.set(w[0], .42, w[1]);
      g.add(wrap); wheels.push(wrap);
    });
    const headL = new THREE.Mesh(HEAD_GEO, HEAD_MAT); headL.position.set(-.72,.86,2.21);
    const headR = headL.clone(); headR.position.x = .72;
    const tailL = new THREE.Mesh(TAIL_GEO, TAIL_MAT); tailL.position.set(-.72,.86,-2.21);
    const tailR = tailL.clone(); tailR.position.x = .72;
    g.add(headL, headR, tailL, tailR);
    // سایهٔ تماس همیشه‌زیر ماشین (حتی وقتی shadowmap خاموش است)
    const blob = new THREE.Mesh(CAR_SHADOW_GEO, CAR_SHADOW_MAT);
    blob.rotation.x = -Math.PI/2; blob.position.y = .021; blob.renderOrder = 2;
    g.add(blob);
    g.userData.wheels = wheels;
    g.userData.paint = paint;
    g.userData.head = [headL, headR];
    g.userData.tail = [tailL, tailR];
    return g;
  }
  function refreshCar() {
    if (playerCarMesh) { scene.remove(playerCarMesh); playerCarMesh = null; }
    const car = activeCarData();
    if (car) {
      const paintCol = carPaintColor(car);
      playerCarMesh = makeCarMesh(paintCol, car.id, { player: true });
      playerCarMesh.position.set(player.position.x + 4, 0, player.position.z);
      // چراغ جلوی واقعی برای ماشین بازیکن (شب)
      if (CARS3) {
        const sp = new THREE.SpotLight(0xfff1c8, 0, 60, .55, .75, 1.2);
        sp.position.set(0, .9, 2.0); sp.target.position.set(0, 0, 16);
        playerCarMesh.add(sp, sp.target);
        playerCarMesh.userData.spot = sp;
      }
      _plLamp = null;
      scene.add(playerCarMesh);
    }
  }
  let _plLamp = null;
  refreshCar();

  // ---------- ترافیک شهری ----------
  const HONKS = [
    '🚗 راننده: «هوووی! درست راه برو داداش!»',
    '🚕 راننده: «مگه پیاده‌رو نیست؟! بیا وسط خیابون دیگه!»',
    '🚙 راننده: «بپا جوون! جون خودت شیرینه!»',
    '🚗 راننده: «برو کنار عمو، عجله دارم!»',
    '🛻 راننده: «چراغ قرمز مال منه، خیابون مال تو؟!»',
  ];
  let lastHonk = 0, knockUntil = 0, lastArgue = 0;
  const traffic = [];
  const trafficColors = [0xd62828, 0x005f73, 0xe9c46a, 0xffffff, 0x555555, 0x40916c];
  function spawnTraffic() {
    const vertical = Math.random() < .5;
    const dir = Math.random() < .5 ? 1 : -1;
    const isTaxi = Math.random() < .35;
    const tKeys = ['pride', 'tiba', 'p206', 'samand', 'camry', 'haima', 'dena', 'quick', 'bmw'];
    const tKey = isTaxi ? 'samand' : tKeys[Math.floor(Math.random() * tKeys.length)];
    const car = makeCarMesh(isTaxi ? 0xf4c430 : trafficColors[Math.floor(Math.random() * trafficColors.length)], tKey,
      isTaxi ? { style: 'taxi', taxi: true, neon: false } : { neon: false });
    if (car.userData.plF) { car.userData.plF.visible = false; car.userData.plB.visible = false; }
    if (isTaxi) {
      const lbl = makeLabel3D('🚕 تاکسی');
      lbl.position.y = 2.6; lbl.scale.set(4, 1, 1);
      car.add(lbl);
    }
    // فقط روی یکی از بلوارهای واقعی راه می‌افتن — از ته جاده (پشت مه)، نه از ناکجا
    const roadC = MAIN_LANES[Math.floor(Math.random() * MAIN_LANES.length)];
    const lane = roadC + 3.2 * dir;
    if (vertical) { car.position.set(lane, 0, -460 * dir); car.rotation.y = dir > 0 ? 0 : Math.PI; }
    else { car.position.set(-460 * dir, 0, lane); car.rotation.y = dir > 0 ? Math.PI/2 : -Math.PI/2; }
    scene.add(car);
    // چراغ جلو/عقب: شب و باران روشن
    if (car.userData.setLamps) car.userData.setLamps(G.hour >= 19 || G.hour < 6);
    const speed = 8 + Math.random() * 6;
    // پلاک: مثل «۱۲ ط ۳۴۵» — فیزیکی هم پشت و جلوی ماشین می‌چسبه
    const plate = fa(10 + Math.floor(Math.random() * 89)) + ' ' +
      ['ط','ب','ن','س','د','م'][Math.floor(Math.random() * 6)] + ' ' +
      fa(100 + Math.floor(Math.random() * 899));
    const pc = document.createElement('canvas');
    pc.width = 128; pc.height = 32;
    const px2 = pc.getContext('2d');
    px2.fillStyle = '#fff'; px2.fillRect(0, 0, 128, 32);
    px2.fillStyle = '#1d3557'; px2.fillRect(0, 0, 18, 32);
    px2.strokeStyle = '#111'; px2.lineWidth = 3; px2.strokeRect(0, 0, 128, 32);
    px2.fillStyle = '#111'; px2.font = 'bold 17px Vazirmatn, Tahoma'; px2.textAlign = 'center'; px2.textBaseline = 'middle';
    px2.fillText(plate, 73, 17);
    const plateTex = new THREE.CanvasTexture(pc);
    const plateMat = new THREE.MeshBasicMaterial({ map: plateTex });
    const plateBack = new THREE.Mesh(new THREE.PlaneGeometry(1.15, .3), plateMat);
    plateBack.position.set(0, car.userData.plateYBack ?? .55, (car.userData.zR ?? -2.22) - .012); plateBack.rotation.y = Math.PI;
    const plateFront = new THREE.Mesh(new THREE.PlaneGeometry(1.15, .3), plateMat);
    plateFront.position.set(0, car.userData.plateY ?? .55, (car.userData.zF ?? 2.22) + .012);
    car.add(plateBack, plateFront);
    traffic.push({ car, vertical, dir, speed, taxi: isTaxi, plate, fast: !isTaxi && speed > 11.5 });
  }
  function nearTaxi() {
    return traffic.some(t => t.taxi && t.car.position.distanceTo(player.position) < 7);
  }
  setInterval(() => { if (gameStarted && !gamePaused && traffic.length < (god.trafficCount ?? 6)) spawnTraffic(); }, 3500);

  // ================= 🏎️ افکت‌ها و حس رانندگی =================
  function carPaintColor(car) {
    const i = (G.carPaintIdx && G.carPaintIdx[car.id]) || 0;
    return PAINTS[i] != null ? PAINTS[i] : car.color;
  }
  function cyclePaint() {
    const car = activeCarData();
    if (!car || !playerCarMesh) return;
    if (!driving && playerCarMesh.position.distanceTo(player.position) > 9) return;
    G.carPaintIdx = G.carPaintIdx || {};
    G.carPaintIdx[car.id] = ((G.carPaintIdx[car.id] || 0) + 1) % PAINTS.length;
    const api = playerCarMesh.userData.api;
    if (api) api.setColor(carPaintColor(car));
    try { sfx.click(); } catch {}
    toast('🎨 رنگ ماشین عوض شد! (C = رنگ بعدی)');
  }
  function honkHorn() {
    const now = performance.now();
    if (now - _lastHorn < 450) return;
    _lastHorn = now;
    try { beep(392, .32, 'square', .05); beep(494, .32, 'square', .04); } catch {}
  }
  const _smokeTex = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const x = c.getContext('2d');
    const g = x.createRadialGradient(32, 32, 2, 32, 32, 31);
    g.addColorStop(0, 'rgba(255,255,255,.9)'); g.addColorStop(.5, 'rgba(255,255,255,.35)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();
  const _smoke = [];
  function puff(x, y, z, vx, vz, col, size, life) {
    let p = _smoke.find(o => o.life <= 0);
    if (!p) {
      if (_smoke.length >= 70) return;
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: _smokeTex, transparent: true, depthWrite: false }));
      scene.add(sp); p = { s: sp, life: 0, max: 1, size: 1, vx: 0, vz: 0 }; _smoke.push(p);
    }
    p.life = p.max = life; p.size = size; p.vx = vx; p.vz = vz;
    p.s.position.set(x, y, z); p.s.material.color.setHex(col); p.s.material.opacity = .5;
    p.s.scale.setScalar(size); p.s.visible = true;
  }
  let _eng = null;
  function engineUpdate(on, spd, nitro) {
    try {
      if (!on || !sfxOn()) { if (_eng && audioCtx) _eng.g.gain.setTargetAtTime(0, audioCtx.currentTime, .08); return; }
      if (!_eng) {
        audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        const o1 = audioCtx.createOscillator(), o2 = audioCtx.createOscillator();
        const f = audioCtx.createBiquadFilter(), g = audioCtx.createGain();
        o1.type = 'sawtooth'; o2.type = 'square'; f.type = 'lowpass'; f.frequency.value = 400; g.gain.value = 0;
        o1.connect(f); o2.connect(f); f.connect(g); g.connect(audioCtx.destination);
        o1.start(); o2.start();
        _eng = { o1, o2, f, g };
      }
      const t = audioCtx.currentTime;
      const base = 46 + spd * 6.2 + (nitro ? 22 : 0);
      _eng.o1.frequency.setTargetAtTime(base, t, .06);
      _eng.o2.frequency.setTargetAtTime(base * .5, t, .06);
      _eng.f.frequency.setTargetAtTime(260 + spd * 38 + (nitro ? 400 : 0), t, .08);
      _eng.g.gain.setTargetAtTime(.02 + Math.min(.03, spd * .0014) + (nitro ? .012 : 0), t, .08);
    } catch {}
  }
  // هر فریم در حین رانندگی: چرخ، فرمان، رول/پیچ، ترمز، دود دریفت، شعلهٔ نیترو، صدا
  function driveFx(dt, now, carSpd, mx, mz) {
    const api = playerCarMesh && playerCarMesh.userData.api;
    if (!api) return;
    const acc = (carSpd - _carSpdPrev) / Math.max(dt, .001); _carSpdPrev = carSpd;
    _carAccS += (Math.max(-7, Math.min(7, acc)) - _carAccS) * Math.min(1, dt * 6);
    const yr = _carYawRate;
    const steerIn = Math.max(-1, Math.min(1, yr / 3.5));
    const lat = Math.max(-1.3, Math.min(1.3, yr * carSpd / 14));
    api.update(dt, carSpd, steerIn, _carAccS, lat, _nitroOn);
    const braking = (!(mx || mz) && carSpd > .8) || _carAccS < -4;
    api.setBrake(braking);
    const pp = playerCarMesh.position, ry = playerCarMesh.rotation.y;
    const sn = Math.sin(ry), cs = Math.cos(ry);
    const drift = Math.abs(yr) > 2.6 && carSpd > 7;
    if ((drift || (braking && carSpd > 9)) && now - _lastSmoke > 45) {
      _lastSmoke = now;
      for (const sd of [-1, 1]) {
        const lx = sd * (api.W / 2 - .2), lz = api.zR + .9;
        puff(pp.x + lx * cs + lz * sn, .25, pp.z - lx * sn + lz * cs, (Math.random() - .5) * .8, (Math.random() - .5) * .8, 0xd8d8dc, 1.5, .9);
      }
    }
    if (_nitroOn && now - _lastSmoke > 30) {
      _lastSmoke = now;
      for (const sd of [-1, 1]) {
        const lx = sd * (api.W / 2 - .55), lz = api.zR - .9;
        puff(pp.x + lx * cs + lz * sn, .4, pp.z - lx * sn + lz * cs, -sn * 3, -cs * 3, 0x66ccff, .9, .45);
      }
    }
    if (_nitroOn && carSpd > 12) { /* لرزش دوربین نیترو */
      camera.position.y += (Math.random() - .5) * .05; camera.position.x += (Math.random() - .5) * .05;
    }
    engineUpdate(!gamePaused, carSpd, _nitroOn);
  }
  function updateCarFx(dt, now) {
    for (const sc of showCars) sc.car.rotation.y += sc.spd * dt;
    for (const p of _smoke) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.s.visible = false; continue; }
      const k = 1 - p.life / p.max;
      p.s.position.x += p.vx * dt; p.s.position.z += p.vz * dt; p.s.position.y += dt * .7;
      p.s.scale.setScalar(p.size * (1 + k * 2.4));
      p.s.material.opacity = .5 * (1 - k);
    }
    if (!driving) { _nitroOn = false; if (_eng) engineUpdate(false, 0, false); }
    if (playerCarMesh && playerCarMesh.userData.api) {
      const lampsOn = G.hour >= 19 || G.hour < 6 || G.weather === 'rainy' || G.weather === 'stormy';
      if (_plLamp !== lampsOn) {
        _plLamp = lampsOn;
        playerCarMesh.userData.api.setLamps(lampsOn);
        if (playerCarMesh.userData.spot) playerCarMesh.userData.spot.intensity = lampsOn ? 40 : 0;
      }
      if (!driving) {                       // پارک: ترمز/نیترو/تیلت آروم برمی‌گرده
        playerCarMesh.userData.api.update(dt, 0, 0, 0, 0, false);
        playerCarMesh.userData.api.setBrake(false);
      }
    }
  }
  function updateTraffic(dt, now) {
    updateCarFx(dt, now);
    const lampsShouldBeOn = G.hour >= 19 || G.hour < 6 || G.weather === 'rainy' || G.weather === 'stormy';
    for (let i = traffic.length - 1; i >= 0; i--) {
      const t = traffic[i];
      const distToPlayer = t.car.position.distanceTo(player.position);
      if (t.car.userData.setLamps && t._lampOn !== lampsShouldBeOn) { t._lampOn = lampsShouldBeOn; t.car.userData.setLamps(lampsShouldBeOn); }
      // راننده‌های عادی برای عابر ترمز می‌زنن؛ فقط تندروها خطرناکن
      let spd = t.speed * (G.trafficJam ? .4 : 1);
      // فاصلهٔ ایمن با ماشین جلویی؛ خودروها دیگر داخل هم نمی‌روند.
      const blockedByCar = traffic.some(o => {
        if (o === t || o.vertical !== t.vertical || o.dir !== t.dir) return false;
        if (t.vertical) {
          const gap = (o.car.position.z - t.car.position.z) * t.dir;
          return Math.abs(o.car.position.x - t.car.position.x) < 1.2 && gap > 0 && gap < 7;
        }
        const gap = (o.car.position.x - t.car.position.x) * t.dir;
        return Math.abs(o.car.position.z - t.car.position.z) < 1.2 && gap > 0 && gap < 7;
      });
      if (blockedByCar) spd = 0;
      if (!driving && !t.fast && distToPlayer < 4.5) spd = 0;
      // برای NPCها همه ترمز می‌زنن (حتی تندروها) — به مردم نمی‌زنن
      if (spd > 0) for (const nm of npcMeshes) {
        if (nm.mesh.visible && t.car.position.distanceTo(nm.mesh.position) < 4) { spd = 0; break; }
      }
      if (t.vertical) t.car.position.z += spd * dt * t.dir;
      else t.car.position.x += spd * dt * t.dir;
      { const ap = t.car.userData.api;
        if (ap && distToPlayer < 140) {
          ap.update(dt, spd, 0, 0, 0);
          ap.setBrake(spd < t.speed * (G.trafficJam ? .4 : 1) * .5);
        } }
      // بوق و تیکه برای عابر وسط خیابون
      if (!driving && distToPlayer < 6 && now - lastHonk > 5000) {
        lastHonk = now;
        sfx.honk();
        sayFa(['هوووی! بپا!', 'هی آقا! کجا؟!', 'برو کنار عمو!', 'هييي! جون خودت شیرینه!'][Math.floor(Math.random() * 4)], 1.2, .8, 'm');
        toast(HONKS[Math.floor(Math.random() * HONKS.length)]);
      }
      // تصادف! فقط ماشین‌های تندرو می‌زنن — دنبالش بدو تا پلاکشو ببینی!
      if (!driving && t.fast && distToPlayer < 2 && now > (knockUntil || 0)) {
        knockUntil = now + 2000;
        G.health -= 5; G.happy -= 3;
        t.hitRun = now + 6000;                      // فرصت تعقیب برای دید بهتر
        // همون لحظهٔ زدن، پلاک یه نظرِ کوتاه دیده میشه
        G.lastHitPlate = { plate: t.plate, day: G.dayIndex };
        showPlateFlash(t.plate, 1400);
        sayFa('آاااخ! هوووی! کجا میری؟!', 1.15, .82, 'm');
        toast('🚑 زد و در رفت! پلاکشو یه لحظه دیدی — دنبالش بدو (Shift) که بهتر ببینیش! (-۵ سلامتی)');
        addLog('🚑 تصادف! پلاک رو نصفه‌نیمه دیدی؛ برو کلانتری گزارش بده.');
        updateHUD();
      }
      // تعقیب: نزدیکش موندی؟ پلاک رو کامل و طولانی می‌بینی
      if (t.hitRun) {
        if (now > knockUntil && distToPlayer < 10) {
          t.hitRun = null;
          showPlateFlash(t.plate, 4500);
          toast('👀 دنبالش دویدی و پلاکشو کامل دیدی! حفظش کن — پلیس ازت می‌پرسه کدوم بود!');
        } else if (now > t.hitRun) {
          t.hitRun = null;
        }
      }
      // ماشین جلوی NPC ترمز کرده؟ گاهی سرِ هم داد می‌زنن (بدون زدن!)
      if (spd === 0 && now > lastArgue + 20000) {
        for (const nm of npcMeshes) {
          if (nm.mesh.visible && t.car.position.distanceTo(nm.mesh.position) < 3.5) {
            lastArgue = now;
            if (player.position.distanceTo(nm.mesh.position) < 25) {
              const [a1, a2] = randomArgue();
              uiChatter(nm.npc.name.split(' (')[0], a1, '🚗 راننده', a2);
            }
            break;
          }
        }
      }
      if (Math.abs(t.car.position.x) > 470 || Math.abs(t.car.position.z) > 470) {
        scene.remove(t.car);
        traffic.splice(i, 1);
      }
    }
  }
  // برخورد با ماشین‌ها: از وسطشون رد نمیشیم
  function hitsCar(pos) {
    if (playerCarMesh && !driving && pos.distanceTo(playerCarMesh.position) < 2.6) return true;
    for (const t of traffic)
      if (pos.distanceTo(t.car.position) < 2.6) return true;
    return false;
  }
  // آدم‌ها هم جامدن: از تو NPC ها رد نمیشیم
  function hitsNpc(pos, r = .95) {
    if (INT.isInside()) return false;
    for (const nm of npcMeshes)
      if (nm.mesh.visible && pos.distanceTo(nm.mesh.position) < r) return true;
    return false;
  }

  // NPC ها
  const npcMeshes = [];
  NPCS.forEach((n, npcIndex) => {
    const m = makeDetailedPerson(n.color, n.look, n.id);
    const hang = buildingById(n.hangout);
    let hx = hang.x + (hang.w/2 + 4), hz = hang.z + hang.d/2 + 3;
    if (typeof clampOffStreetCenter === 'function') { const c = clampOffStreetCenter(hx, hz, 2.2); hx = c.x; hz = c.z; }
    m.position.set(hx, 0, hz);
    if (npcIndex >= Math.ceil(NPCS.length * ((god.npcPercent ?? 100) / 100))) m.visible = false;
    if (n.kid) m.scale.set(.68, .68, .68);
    const lbl = makeLabel3D(n.name);
    lbl.position.y = n.kid ? 4.6 : 3.3; lbl.scale.set(5.5, 1.4, 1);
    m.add(lbl);
    scene.add(m);
    npcMeshes.push({ npc: n, mesh: m, home: m.position.clone(), target: m.position.clone(), t: Math.random() * 4 });
  });

  // ---------- فضای داخلی ساختمون‌ها ----------
  const INT = createInteriors({ THREE, scene, mat, makePerson: makeDetailedPerson, makeLabel3D, player, camera });
  function refreshStreetNpcs() {
    for (let i = 0; i < npcMeshes.length; i++) {
      const nm = npcMeshes[i];
      const out = npcHereToday(nm.npc) && !npcInShopToday(nm.npc);
      nm.mesh.visible = out && i < Math.ceil(npcMeshes.length * ((god.npcPercent ?? 100) / 100));
    }
  }
  refreshStreetNpcs();

  // ---------- گپ NPC ها با هم ----------
  let social = null, nextSocial = performance.now() + 12000;
  function updateSocial(now) {
    if (!social && now > nextSocial && npcMeshes.length > 1) {
      const a = npcMeshes[Math.floor(Math.random() * npcMeshes.length)];
      let b;
      do { b = npcMeshes[Math.floor(Math.random() * npcMeshes.length)]; } while (b === a);
      social = { a, b, phase: 'walk', until: now + 25000 };
      b.target.copy(a.mesh.position);
      b.t = 30; // نره سمت هدف تصادفی
    }
    if (!social) return;
    const { a, b } = social;
    if (social.phase === 'walk') {
      b.target.copy(a.mesh.position);
      if (b.mesh.position.distanceTo(a.mesh.position) < 3.5) {
        social.phase = 'talk';
        social.until = performance.now() + 9000;
        // اگه بازیکن نزدیکه، مکالمه رو می‌شنوه!
        if (player.position.distanceTo(a.mesh.position) < 25) {
          const [l1, l2] = randomAmbient();
          uiChatter(a.npc.name.split(' (')[0], l1, b.npc.name.split(' (')[0], l2);
        }
      }
    }
    if (now > social.until) {
      b.t = 0; a.t = 0;
      social = null;
      nextSocial = now + 15000 + Math.random() * 15000;
    }
  }

  // ---------- آب‌وهوا (particles) ----------
  const precipGeo = new THREE.BufferGeometry();
  const precipCount = 450;   // ⚡ ذرات کمتر
  const precipPos = new Float32Array(precipCount * 3);
  for (let i = 0; i < precipCount; i++) {
    precipPos[i*3] = (Math.random() - .5) * 160;
    precipPos[i*3+1] = Math.random() * 50;
    precipPos[i*3+2] = (Math.random() - .5) * 160;
  }
  precipGeo.setAttribute('position', new THREE.BufferAttribute(precipPos, 3));
  const rainMat = (cine && cine.rain) ? cine.rain.points.material : new THREE.PointsMaterial({ color: 0x99bbee, size: .25, transparent: true, opacity: .7 });
  const snowMat = new THREE.PointsMaterial({ color: 0xffffff, size: .45, transparent: true, opacity: .9 });
  const dustMat = new THREE.PointsMaterial({ color: 0xc2a878, size: .5, transparent: true, opacity: .5 });
  const precip = new THREE.Points(precipGeo, rainMat);
  precip.visible = false;
  scene.add(precip);

  let precipWanted = false;
  var worldReady = false;      // تا لود کامل player/INT، cine.update با null صدا زده میشه
  function applyWeather() {
    scene.fog.near = G.weather === 'polluted' ? 25 : 70;
    scene.fog.far = G.weather === 'polluted' ? 100 : 300;
    precipWanted = ['rainy', 'snowy', 'stormy'].includes(G.weather);
    // باران واقعی از cine3d؛ precip قدیمی فقط برای برف/گردوخاک
    const rainNow = G.weather === 'rainy' || G.weather === 'stormy';
    precip.material = G.weather === 'snowy' ? snowMat : G.weather === 'stormy' ? dustMat : rainMat;
    precip.visible = precipWanted && !rainNow;
    if (cine && W.cineRoadMat) cine.applyWetness(W.cineRoadMat, W.cineSidewalkMat);
  }
  // چرخه‌ی نور شبانه‌روزی — سینمایی (cine3d): آسمان شیدری + خورشید/ماه + مه گرم
  const skyByWeather = { sunny:0x87ceeb, cloudy:0x9aa5b1, rainy:0x5c6b7a, polluted:0xb0a080, snowy:0xcfd8e3, stormy:0x6a5c48 };
  const _skyNightC = new THREE.Color(0x0b1026);
  const _skyDuskC = new THREE.Color(0xf4a261);
  function updateDayLight() {
    const t = (G.hour + G.minute / 60) / 24;
    const elev = Math.sin((t - .25) * Math.PI * 2);
    const daylight = Math.max(0, Math.min(1, (elev + .15) * 2.2));
    const duskGlow = Math.max(0, 1 - Math.abs(elev) * 5) * (t > .5 ? 1 : .7);
    if (cine) {
      cine.update(_lastFrameDt, performance.now(), worldReady ? { player, inside: INT.isInside() } : null);
      if (worldReady) updateLampLights();
    } else {
      const base = new THREE.Color(skyByWeather[G.weather] || 0x87ceeb);
      const sky = _skyNightC.clone().lerp(base, daylight).lerp(_skyDuskC, duskGlow * .45);
      scene.background = sky;
      scene.fog.color = sky;
      const wI = { sunny:2.2, cloudy:1.4, rainy:1, polluted:1.1, snowy:1.5, stormy:.8 }[G.weather] || 2;
      sun.intensity = .12 + daylight * wI;
      sun.color.setHex(duskGlow > .3 ? 0xffb26b : 0xfff2d0);
      sun.position.set(Math.cos(t * Math.PI * 2) * 60, 15 + daylight * 55, 30);
      amb.intensity = .22 + daylight * .6;
    }
    // چراغ‌های خیابون شب روشن!
    const lampOn = daylight < .35 ? 2.4 : 0;
    for (const b of lampBulbs) b.material.emissiveIntensity = lampOn;
    _applyPhotoFacadeNight(daylight);   // پنجره‌های عکس‌دار شب می‌درخشند
    if (window.ARCH3D) window.ARCH3D.setNight(daylight);   // پنجره‌های ساختمان‌ها شب روشن
  }
  applyWeather();
  updateDayLight();

  // ---------- ورودی ----------
  const keys = {};
  let camYaw = 0, camPitch = .35;
  const ARROWS = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
  const keydown = e => {
    keys[e.code] = true;
    if (ARROWS.includes(e.code) || e.code === 'Space') e.preventDefault();   // صفحه اسکرول نشه
    if (W.godIsOn?.()) {
      if (e.code === 'KeyR') W.godRotate();
      if (e.code === 'Equal' || e.code === 'NumpadAdd') W.godRoadLen(8);
      if (e.code === 'Minus' || e.code === 'NumpadSubtract') W.godRoadLen(-8);
      return;
    }
    if (e.code === 'KeyE') tryInteract();
    if (e.code === 'KeyF') toggleDrive();
    if ((e.code === 'KeyH' || e.code === 'KeyC') && !(e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) && !panelOpen && gameStarted) {
      if (e.code === 'KeyH' && driving) honkHorn();
      if (e.code === 'KeyC') cyclePaint();
    }
  };
  const keyup = e => keys[e.code] = false;
  addEventListener('keydown', keydown);
  addEventListener('keyup', keyup);
  // دوربین بدون pointer lock: موس آزاده؛ فقط با کلیکِ نگه‌داشته (یا کشیدن انگشت) می‌چرخه
  const safeLock = () => {};
  let camDrag = null;
  canvas.addEventListener('pointerdown', e => {
    if (camDrag === null) {
      camDrag = { id: e.pointerId, x: e.clientX, y: e.clientY };
      try { canvas.setPointerCapture(e.pointerId); } catch {}
    }
  });
  canvas.addEventListener('pointermove', e => {
    if (camDrag && e.pointerId === camDrag.id && !panelOpen) {
      const base = (G.settings?.sensitivity ?? 45) / 45;
      const sens = (e.pointerType === 'touch' ? .006 : .0045) * base;
      camYaw -= (e.clientX - camDrag.x) * sens;
      camPitch = Math.max(.08, Math.min(1.2, camPitch + (e.clientY - camDrag.y) * sens));
      camDrag.x = e.clientX; camDrag.y = e.clientY;
      G._tutCam = true;
    }
  });
  const endCamDrag = e => { if (camDrag && e.pointerId === camDrag.id) camDrag = null; };
  canvas.addEventListener('pointerup', endCamDrag);
  canvas.addEventListener('pointercancel', endCamDrag);

  function toggleDrive() {
    if (panelOpen || !gameStarted) return;
    const car = activeCarData();
    if (!car) { toast('🚗 ماشین نداری! برو نمایشگاه.'); return; }
    if (!driving) {
      if (playerCarMesh.position.distanceTo(player.position) > 6) { toast('🚗 ماشینت دوره! (کنار جاش پارکه)'); return; }
      if (G.fuel <= 0) { toast('⛽ بنزین نداری! ماشین رو هل بدی؟'); return; }
      if (G.damage >= 90) { toast('🔧 ماشین داغونه! اول تعمیرگاه.'); return; }
      driving = true; player.visible = false;
      toast('🚗 سوار شدی! F پیاده · Shift نیترو 🔥 · H بوق · C رنگ');
    } else {
      driving = false;
      player.visible = true;
      player.position.set(playerCarMesh.position.x + 3, 0, playerCarMesh.position.z);
      toast('🚶 پیاده شدی');
    }
  }

  function collide(pos, hx = 0, hz = 0) {
    const list = INT.isInside() ? INT.colliders() : colliders;
    for (const c of list)
      if (Math.abs(pos.x - c.x) < c.hx + hx && Math.abs(pos.z - c.z) < c.hz + hz) return true;
    return false;
  }

  // ---------- تعامل ----------
  function nearestTarget() {
    if (INT.isInside()) {
      const t = INT.nearestInside(player.position);
      if (!t) return null;
      return { ...t, inside: true };
    }
    if (walletMesh && walletMesh.position.distanceTo(player.position) < 3) return { type:'wallet', label:'👛 برداشتن کیف پول' };
    for (const nm of npcMeshes)
      if (nm.mesh.visible && nm.mesh.position.distanceTo(player.position) < 4.5) return { type:'npc', npc: nm.npc, mesh:nm.mesh };
    if (nearTaxi()) return { type:'taxi' };
    for (const b of BUILDINGS) {
      if (b.deco) continue;
      const dx = Math.abs(player.position.x - b.x), dz = Math.abs(player.position.z - b.z);
      const rx = b.w/2 + 4, rz = b.d/2 + 4;
      if (dx < rx && dz < rz) return { type:'building', b };
    }
    return null;
  }
  function tryInteract() {
    if (W.godIsOn?.()) return;
    if (panelOpen || !gameStarted || driving || dialogueOpen) return;
    const t = nearestTarget();
    if (!t) return;
    if (W.challengeCatch && W.challengeCatch()) return;
    // 💍 گشتن نقاط طلایی
    if (CH && CH.type === 'ring') {
      const sp = CH.spots.find(s2 => !s2.checked && s2.mesh.position.distanceTo(player.position) < 5);
      if (sp) {
        sp.checked = true; CH.found++;
        const idx = CH.spots.indexOf(sp);
        scene.remove(sp.mesh);
        if (idx === CH.ringIn) {
          return chEnd(true, '💍✨ پیداش کردی! زیر یه سنگ کنار ' + sp.b.name + ' برق می‌زد. ملوک‌خانم حلقه رو بوسید و گریه کرد: «چهل سال خاطره تو این حلقه‌ست... تو دیگه پسر خودمی!»', () => questReward('ring'));
        }
        toast('🔍 اینجا نبود... (' + fa(CH.found) + ' از ۵ جا گشتی)');
        return;
      }
    }
    if (t.type === 'npc') {
      // طرف برگرده سمت ما
      if (t.mesh) t.mesh.rotation.y = Math.atan2(player.position.x - t.mesh.position.x, player.position.z - t.mesh.position.z);
      openNPC(t.npc, { inside: !!t.inside });
    }
    else if (t.type === 'wallet') { scene.remove(walletMesh); walletMesh = null; openWalletChoice(); }
    else if (t.type === 'taxi') openTaxi(false);
    else if (t.type === 'exit') W.exitInterior();
    else if (t.type === 'shop') openCounterTalk(t.b);      // سفارش با حباب حرف، نه پنل متنی
    else if (t.type === 'buy') openBuySpot(t);             // بخش‌های مغازه (کلاه، کفش، ...)
    else if (t.type === 'site') openNovinzehnSite();       // کامپیوتر سایت آکادمی
    else if (t.type === 'gymact') doGymActivity(t.act);    // تردمیل / وزنه / پرش
    else if (t.type === 'report') openShopPanel('policeStation');   // میز گزارش کلانتری
    else if (t.type === 'npc-robot') toast(['🤖 «بیپ-بوپ! روز خوبی داشته باشی انسان!»','🤖 «سلام! امروز ۰ خطا داشتم. رکورد زدم!»','🤖 «خوش اومدی! چای نداریم ولی برق فراوونه!»','🤖 «ویز! دوستان کوچک من دارن آیندهٔ ایران رو می‌سازن!»'][Math.floor(Math.random()*4)]);
    else if (t.type === 'child') playWithChild();
    else W.enterInterior(t.b.id);
  }

  // ---------- حلقه ----------
  const clock = new THREE.Clock();
  // ابزار دوربین سینمایی
  const _camTarget = new THREE.Vector3();
  const _lookTarget = new THREE.Vector3();
  const _smoothLook = new THREE.Vector3();
  const _ray = new THREE.Raycaster();
  let walkT = 0, running = true, cinematic = null, jumpV = 0, stepT = 0, frameNo = 0;
  let nextChirp = performance.now() + 6000;
  // کیف پول گمشده: هر از گاهی یه جایی نزدیک بازیکن می‌افته
  let walletMesh = null, walletNext = performance.now() + 45000;
  function spawnWallet() {
    const a = Math.random() * Math.PI * 2, d = 9 + Math.random() * 6;
    let wx = player.position.x + Math.cos(a) * d, wz = player.position.z + Math.sin(a) * d;
    if (typeof clampOffStreetCenter === 'function') { const c = clampOffStreetCenter(wx, wz, 2); wx = c.x; wz = c.z; }
    if (collide({ x: wx, z: wz })) return;      // تو دیوار نیفته
    walletMesh = new THREE.Group();
    const w1 = new THREE.Mesh(new THREE.BoxGeometry(.55, .12, .38), mat(0x6b3f23, .8, 0));
    w1.position.y = .07;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(.8, .06, 8, 20),
      new THREE.MeshBasicMaterial({ color: 0xffd166, transparent: true, opacity: .7 }));
    ring.rotation.x = Math.PI / 2; ring.position.y = .1;
    walletMesh.add(w1, ring);
    walletMesh.position.set(wx, 0, wz);
    scene.add(walletMesh);
  }
  function updateWallet(now) {
    if (INT.isInside() || driving) return;
    if (!walletMesh && now > walletNext) { spawnWallet(); walletNext = now + 240000 + Math.random() * 180000; }
    if (walletMesh) walletMesh.children[1].rotation.z = now * .002;
  }
  let talking = null;     // { nm }  — گفتگوی رودررو
  let approach = null;    // { nm, done, t } — انیمیشن کوچیک نزدیک شدن

  function frame() {
    if (!running) return;
    requestAnimationFrame(frame);
    const dt = Math.min(clock.getDelta(), .05);
    _lastFrameDt = dt;
    fpsTick(dt);
    const now = performance.now();

    // دوربین سینمایی کات‌سین
    if (cinematic) {
      const a = now * .0005;
      camera.position.lerp(new THREE.Vector3(
        cinematic.cx + Math.sin(a) * 8, 3.2, cinematic.cz + Math.cos(a) * 8), .06);
      camera.lookAt(cinematic.cx, 1.8, cinematic.cz);
      updateDayLight();
      renderer.render(scene, camera);
      return;
    }

    // ---- انیمیشن نزدیک شدن به طرف (قبل از باز شدن حباب گفتگو) ----
    if (approach) {
      const a = approach;
      a.t += dt;
      const to = a.nm.mesh.position;
      const dir = new THREE.Vector3().subVectors(player.position, to); dir.y = 0;
      if (dir.length() < .01) dir.set(0, 0, 1);
      dir.normalize();
      const spot = to.clone().addScaledVector(dir, 2.5); spot.y = 0;
      player.position.lerp(spot, Math.min(1, dt * 6));
      const face = new THREE.Vector3().subVectors(to, player.position);
      player.rotation.y = Math.atan2(face.x, face.z);
      a.nm.mesh.rotation.y = Math.atan2(-face.x, -face.z);
      walkT += dt * 12;
      const L = player.userData.limbs;
      L.legL.rotation.x = Math.sin(walkT) * .5;
      L.legR.rotation.x = -Math.sin(walkT) * .5;
      // دوربین دو نفره
      talkCamera(a.nm, dt, .18);
      clampCamInside();
      if (a.t > .75 || player.position.distanceTo(spot) < .25) {
        const L2 = player.userData.limbs;
        L2.legL.rotation.x = L2.legR.rotation.x = 0;
        talking = { nm: a.nm };
        const done = a.done; approach = null;
        done && done();
      }
      updateDayLight();
      renderer.render(scene, camera);
      return;
    }

    // ---- ایستاده وسط گفتگو: فقط دوربین و انیمیشن حرف زدن ----
    if (talking) {
      talkCamera(talking.nm, dt, .1);
      clampCamInside();
      const t = now * .006;
      talking.nm.mesh.userData.limbs.armR.rotation.x = Math.sin(t) * .25 - .15;
      player.rotation.y = Math.atan2(
        talking.nm.mesh.position.x - player.position.x,
        talking.nm.mesh.position.z - player.position.z);
      // طرف هم برگرده رو به ما، پشتش به ما نباشه
      talking.nm.mesh.rotation.y = Math.atan2(
        player.position.x - talking.nm.mesh.position.x,
        player.position.z - talking.nm.mesh.position.z);
      // سر هم مستقل از بدن، موقعیت تازهٔ بازیکن را دنبال می‌کند.
      const talkHead = talking.nm.mesh.userData.characterParts?.head;
      if (talkHead) {
        // چشم تو چشم: سر دقیقاً رو به بازیکن + یه تکون خیلی کوچیک که زنده باشه
        let local = Math.atan2(player.position.x - talking.nm.mesh.position.x,
                               player.position.z - talking.nm.mesh.position.z) - talking.nm.mesh.rotation.y;
        local = Math.atan2(Math.sin(local), Math.cos(local));
        talkHead.rotation.y += (Math.max(-.5, Math.min(.5, local)) + Math.sin(now * .002) * .02 - talkHead.rotation.y) * .15;
        talkHead.rotation.x = Math.sin(now * .0013) * .03;
      }
      updateDayLight();
      renderer.render(scene, camera);
      return;
    }

    if (gameStarted && !gamePaused && !panelOpen && !G.traveling) {
      // گادمود: زمان و حرکت بازیکن قفل؛ فقط ادیتور
      if (W.godIsOn?.()) {
        W.godFrame(dt);
        INT.update(dt);
        updateDayLight();
        $id('interactHint').style.display = 'none';
        renderer.render(scene, camera);
        return;
      }
      // ساعت بازی: هر ثانیه واقعی = ۲ دقیقه بازی
      G.minute += dt * 120 / 60;
      if (G.minute >= 60) { G.minute -= 60; G.hour++; if (G.hour >= 24) { G.hour = 0; runDailyTick(); } checkForcedSleep(); if (G.hour % 2 === 0) updateHUD(); }

      let mx = 0, mz = 0;
      const seated = INT.seated();
      if (!seated) {
      if (keys['KeyW'] || keys['ArrowUp'])    mz -= 1;
      if (keys['KeyS'] || keys['ArrowDown'])  mz += 1;
      if (keys['KeyA'] || keys['ArrowLeft'])  mx -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) mx += 1;
      if (window.touchInput) { mx += touchInput.mx; mz += touchInput.mz; }
      }

      if (driving && playerCarMesh) {
        const car = activeCarData();
        let speed = car.speed * (G.trafficJam ? .5 : 1) * (1 - G.damage / 200);
        _nitroOn = !!((keys['ShiftLeft'] || keys['ShiftRight'] || window.touchInput?.run) && (mx || mz) && G.fuel > 0 && !G.trafficJam);
        if (_nitroOn) speed *= 1.55;
        _carYawRate = 0;
        if (G.fuel <= 0) { driving = false; player.visible = true; player.position.copy(playerCarMesh.position); toast('⛽ بنزین تموم شد!'); }
        if (mx || mz) {
          const len = Math.hypot(mx, mz); mx/=len; mz/=len;
          // حرکت نسبت به دوربین (سبک GTA): W = جلو در جهت دید، A/D = چپ/راست دید
          const sin = Math.sin(camYaw), cos = Math.cos(camYaw);
          const dx = (mz * sin + mx * cos) * speed * dt;
          const dz = (mz * cos - mx * sin) * speed * dt;
          const next = playerCarMesh.position.clone(); next.x += dx; next.z += dz;
          if (!collide(next, 1.2, 1.2) && !hitsNpc(next, 2.2)) {
            playerCarMesh.position.copy(next);
            { // فرمان نرم: بدنه با سرعت محدود به سمت جهت حرکت می‌چرخه (حس دریفت)
              const tgt = Math.atan2(dx, dz);
              let dA = tgt - playerCarMesh.rotation.y; dA = Math.atan2(Math.sin(dA), Math.cos(dA));
              const maxT = 7 * dt, turn = Math.max(-maxT, Math.min(maxT, dA));
              playerCarMesh.rotation.y += turn;
              _carYawRate = dt > 0 ? turn / dt : 0;
            }
            G.fuel = Math.max(0, G.fuel - dt * .12 * (_nitroOn ? 3 : 1));
            if (Math.random() < activeCarData().fragility * dt * .1) G.damage = Math.min(100, G.damage + 1);
          } else if (Math.random() < .3) {
            G.damage = Math.min(100, G.damage + 2);
          }
          playerCarMesh.position.x = Math.max(-455, Math.min(455, playerCarMesh.position.x));
          playerCarMesh.position.z = Math.max(-455, Math.min(455, playerCarMesh.position.z));
        }
        // دوربین رانندگی: دمپ نمایی (مستقل از فریم‌ریت) + FOV پویا با سرعت
        const camK = 1 - Math.exp(-8 * dt);
        _camTarget.set(
          playerCarMesh.position.x + Math.sin(camYaw) * Math.cos(camPitch) * 13,
          3 + Math.sin(camPitch) * 13,
          playerCarMesh.position.z + Math.cos(camYaw) * Math.cos(camPitch) * 13);
        camera.position.lerp(_camTarget, camK);
        const lookK = 1 - Math.exp(-14 * dt);
        _lookTarget.set(playerCarMesh.position.x, 2, playerCarMesh.position.z);
        _smoothLook.lerp(_lookTarget, lookK);
        camera.lookAt(_smoothLook);
        // FOV: سرعت واقعی تخمینی از جابه‌جایی
        const carSpd = _prevCarPos ? playerCarMesh.position.distanceTo(_prevCarPos) / Math.max(dt, .001) : 0;
        _prevCarPos = _prevCarPos || playerCarMesh.position.clone();
        _prevCarPos.copy(playerCarMesh.position);
        const wantedFov = 62 + Math.min(14, carSpd * .55) + (_nitroOn ? 8 : 0);
        if (Math.abs(camera.fov - wantedFov) > .1) {
          camera.fov += (wantedFov - camera.fov) * Math.min(1, dt * 4);
          camera.updateProjectionMatrix();
        }
        // لرزش جزئی موتور در سرعت بالا
        if (carSpd > 9) {
          const sh = Math.min(.045, (carSpd - 9) * .004);
          camera.position.y += (Math.random() - .5) * sh;
          camera.position.x += (Math.random() - .5) * sh;
        }
        driveFx(dt, now, carSpd, mx, mz);
      } else {
        // افتادن بعد از تصادف
        player.rotation.z = now < knockUntil ? Math.PI / 2 : 0;
        // پرش با Space
        const groundY = INT.isInside() ? INTERIOR_Y : 0;
        if (keys['Space'] && !INT.seated() && !dialogueOpen) {
          if (CH && CH.type === 'paintball') { if (!CH._spaceHeld) { CH._spaceHeld = true; chShoot(); } }
          else if (player.position.y <= groundY + .02) jumpV = 7.5;
        }
        if (!keys['Space'] && CH) CH._spaceHeld = false;
        if (jumpV || player.position.y > groundY) {
          player.position.y += jumpV * dt;
          jumpV -= 22 * dt;
          if (player.position.y <= groundY) { player.position.y = groundY; jumpV = 0; }
        }
        const speed = now < knockUntil ? 0 : (keys['ShiftLeft'] || window.touchInput?.run) ? 12 : 6.5;
        if (mx || mz) {
          const len = Math.hypot(mx, mz); mx/=len; mz/=len;
          // حرکت نسبت به دوربین (سبک GTA): W = جلو در جهت دید، A/D = چپ/راست دید
          const sin = Math.sin(camYaw), cos = Math.cos(camYaw);
          const dx = (mz * sin + mx * cos) * speed * dt;
          const dz = (mz * cos - mx * sin) * speed * dt;
          const next = player.position.clone(); next.x += dx;
          if (!collide(next) && !hitsCar(next) && !hitsNpc(next)) player.position.x = next.x;
          next.copy(player.position); next.z += dz;
          if (!collide(next) && !hitsCar(next) && !hitsNpc(next)) player.position.z = next.z;
          if (INT.isInside()) {
            // محکم‌کاری: از دیوارهای اتاق بیرون نزنیم
            const R = INT.room();
            if (R) {
              player.position.x = Math.max(-R.W / 2 + .8, Math.min(R.W / 2 - .8, player.position.x));
              player.position.z = Math.max(-R.D / 2 + .8, Math.min(R.D / 2 - .8, player.position.z));
            }
          }
          player.position.x = Math.max(-455, Math.min(455, player.position.x));
          player.position.z = Math.max(-455, Math.min(455, player.position.z));
          player.rotation.y = Math.atan2(dx, dz);
          walkT += dt * 10;
          const L = player.userData.limbs;
          L.legL.rotation.x = Math.sin(walkT) * .7;
          L.legR.rotation.x = -Math.sin(walkT) * .7;
          L.armL.rotation.x = -Math.sin(walkT) * .5;
          L.armR.rotation.x = Math.sin(walkT) * .5;
          G.px = player.position.x; G.pz = player.position.z;
          G._tutMoved = true;
          // صدای قدم
          stepT += dt;
          if (stepT > (speed > 8 ? .27 : .38)) { stepT = 0; sfx.step(); }
        } else {
          // وایسادی؟ پاها صاف — دیگه پا رو هوا نمی‌مونه
          walkT = 0;
          const L = player.userData.limbs;
          L.legL.rotation.x = L.legR.rotation.x = 0;
          L.armL.rotation.x = L.armR.rotation.x = 0;
        }
        const seat = INT.seated() && INT.seatCenter();
        if (seat) {
          // دوربین سر میز قرار — مثل د سیمز از پهلو
          camera.position.lerp(new THREE.Vector3(seat.x + 5.4, INTERIOR_Y + 3.2, seat.z + .3), .16);
          clampCamInside();
          camera.lookAt(seat.x, INTERIOR_Y + 1.5, seat.z);
          updateTraffic(dt, now); INT.update(dt); updateDayLight();
          renderer.render(scene, camera);
          return;
        }
        const camDist = INT.isInside() ? 7.5 : 9;
        const camK = 1 - Math.exp(-9 * dt);
        _camTarget.set(
          player.position.x + Math.sin(camYaw) * Math.cos(camPitch) * camDist,
          player.position.y + 2 + Math.sin(camPitch) * camDist,
          player.position.z + Math.cos(camYaw) * Math.cos(camPitch) * camDist);
        // برخورد دوربین با ساختمان‌ها: اگر هدف پشت دیوار است نزدیک‌تر شو
        if (!INT.isInside() && _camBlockers.length) {
          const from = new THREE.Vector3(player.position.x, player.position.y + 1.6, player.position.z);
          const dirC = new THREE.Vector3().subVectors(_camTarget, from);
          const lenC = dirC.length();
          dirC.normalize();
          _ray.set(from, dirC);
          _ray.far = lenC;
          const hitsC = _ray.intersectObjects(_camBlockers, false);
          if (hitsC.length) {
            const d = Math.max(2.2, hitsC[0].distance - .5);
            _camTarget.copy(from).addScaledVector(dirC, d);
          }
        }
        camera.position.lerp(_camTarget, camK);
        clampCamInside();
        const lookK = 1 - Math.exp(-16 * dt);
        _lookTarget.set(player.position.x, player.position.y + 1.6, player.position.z);
        _smoothLook.lerp(_lookTarget, lookK);
        camera.lookAt(_smoothLook);
      }

      INT.update(dt);
      updateTraffic(dt, now);
      updateSocial(now);
      updateWallet(now);
      updateChallenge(dt, now);
      updatePet(dt, now);
      if ((frameNo = (frameNo + 1) % 15) === 0) updateCulling();
      // چهچههٔ گنجشک‌ها تو روز
      if (!INT.isInside() && G.hour >= 6 && G.hour <= 19 && now > nextChirp) {
        sfx.chirp();
        nextChirp = now + 5000 + Math.random() * 9000;
      }

      // NPC پرسه
      for (const nm of npcMeshes) {
        if (nm.frozen) continue;                // گادمود فریزش کرده
        // داره میره تو مغازه‌ش: مستقیم سمت در، رسید غیب میشه (رفته داخل)
        if (nm.goingShop) {
          const dir = nm.target.clone().sub(nm.mesh.position); dir.y = 0;
          if (dir.length() > .8) {
            dir.normalize();
            nm.mesh.position.addScaledVector(dir, dt * 2.6);
            nm.mesh.rotation.y = Math.atan2(dir.x, dir.z);
            const L = nm.mesh.userData.limbs, t = now * .011;
            L.legL.rotation.x = Math.sin(t) * .6;
            L.legR.rotation.x = -Math.sin(t) * .6;
          } else {
            nm.goingShop = false;
            nm.mesh.visible = false;              // رفت داخل مغازه
            const L = nm.mesh.userData.limbs;
            L.legL.rotation.x = L.legR.rotation.x = 0;
          }
          continue;
        }
        nm.t -= dt;
        if (nm.t <= 0) {
          nm.t = 3 + Math.random() * 5;
          nm.target = nm.home.clone().add(new THREE.Vector3((Math.random()-.5)*8, 0, (Math.random()-.5)*8));
          if (typeof clampOffStreetCenter === 'function') {
            const c = clampOffStreetCenter(nm.target.x, nm.target.z, 2.2);
            nm.target.x = c.x; nm.target.z = c.z;   // مقصد پیاده‌رو باشه نه وسط آسفالت
          }
        }
        const dir = nm.target.clone().sub(nm.mesh.position); dir.y = 0;
        if (dir.length() > .4) {
          dir.normalize();
          const nxt = nm.mesh.position.clone().addScaledVector(dir, dt * 1.2);
          if (nxt.distanceTo(player.position) > 1.1) {   // از تو بازیکن رد نشن
            nm.mesh.position.copy(nxt);
            nm.mesh.rotation.y = Math.atan2(dir.x, dir.z);
            const L = nm.mesh.userData.limbs, t = now * .008;
            L.legL.rotation.x = Math.sin(t) * .5;
            L.legR.rotation.x = -Math.sin(t) * .5;
          }
        } else {
          const L = nm.mesh.userData.limbs;               // وایساده؟ پاها صاف
          L.legL.rotation.x = L.legR.rotation.x = 0;
        }
        // نگاه طبیعی: آدم‌های نزدیک با سر دنبال بازیکن می‌کنند؛ در گفتگو تمام بدن برمی‌گردد.
        const head = nm.mesh.userData.characterParts?.head;
        if (head) {
          const dxLook = player.position.x - nm.mesh.position.x;
          const dzLook = player.position.z - nm.mesh.position.z;
          const distance = Math.hypot(dxLook, dzLook);
          if (distance < 8) {
            const worldAngle = Math.atan2(dxLook, dzLook);
            let localAngle = worldAngle - nm.mesh.rotation.y;
            localAngle = Math.atan2(Math.sin(localAngle), Math.cos(localAngle));
            head.rotation.y += (Math.max(-.65, Math.min(.65, localAngle)) - head.rotation.y) * .12;
          } else head.rotation.y *= .86;
        }
      }

      updateDayLight();

      // بارش / گردوغبار
      precip.visible = precipWanted && !INT.isInside();
      if (precip.visible) {
        const pos = precipGeo.attributes.position;
        const dust = G.weather === 'stormy';
        const fall = G.weather === 'snowy' ? 6 : dust ? 3 : 30;
        for (let i = 0; i < precipCount; i++) {
          let y = pos.getY(i) - fall * dt;
          if (dust) { // گردوخاک افقی هم حرکت می‌کنه
            let x = pos.getX(i) + 18 * dt;
            if (x > 80) x = -80;
            pos.setX(i, x);
          }
          if (y < 0) y = dust ? 8 + Math.random() * 10 : 50;
          pos.setY(i, y);
        }
        pos.needsUpdate = true;
        precip.position.x = player.position.x;
        precip.position.z = player.position.z;
      }

      // راهنمای تعامل
      const t = nearestTarget();
      const hint = $id('interactHint');
      if (t && !panelOpen && !driving && !dialogueOpen) {
        hint.style.display = 'block';
        hint.textContent = 'E ⌨️ ' + (t.label ? t.label
          : t.type === 'npc' ? 'گفتگو با ' + t.npc.name
          : t.type === 'taxi' ? '🚕 سوار تاکسی شو!'
          : 'ورود به ' + t.b.name);
      } else hint.style.display = 'none';
    }

    renderer.render(scene, camera);
  }
  frame();

  const onResize = () => {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  };
  addEventListener('resize', onResize);

  // ---------- API مشترک ----------
  W.onNewDay = () => { drawSarafi(); applyWeather(); refreshStreetNpcs(); };
  W.onCarChanged = () => refreshCar();
  W.onMarried = () => {};
  W.requestLock = safeLock;
  W.teleport = (x, z) => { player.position.set(x, 0, z); driving = false; player.visible = true; if (W.snapCamera) W.snapCamera(); };
  W.nearTaxi = nearTaxi;
  // دوربین سینمایی به یک نقطه + جابه‌جایی بازیکن
  function goCinematic(px, pz, ms, done) {
    driving = false; player.visible = true;
    player.position.set(px - 1.2, 0, pz);
    G.px = player.position.x; G.pz = player.position.z;
    player.rotation.y = Math.PI / 2;
    cinematic = { cx: px, cz: pz };
    setTimeout(() => { cinematic = null; done(); }, ms);
  }
  // کات‌سین قرار: دوتایی می‌رید جلوی کافه
  W.dateCutscene = (npc, done) => {
    const cafe = buildingById('cafe');
    const px = cafe.x, pz = cafe.z + cafe.d/2 + 4;
    const nm = npcMeshes.find(m => m.npc.id === npc.id);
    if (nm) {
      nm.mesh.position.set(px + 1.2, 0, pz);
      nm.target.copy(nm.mesh.position);
      nm.t = 30;
      nm.mesh.rotation.y = -Math.PI / 2; // رو به هم!
    }
    goCinematic(px, pz, 4300, () => { if (nm) nm.t = 0; done(); });
  };
  // کات‌سین کار: پشت میز محل کار
  W.workCutscene = (job, done) => {
    const b = buildingById(job.place || (job.remote ? 'home' : 'restaurant')) || buildingById('home');
    goCinematic(b.x, b.z + b.d/2 + 3, 3500, done);
  };
  // ---------- دوربین دو نفرهٔ گفتگو (سبک د سیمز) ----------
  function talkCamera(nm, dt, k) {
    const a = player.position, b = nm.mesh.position;
    const mid = new THREE.Vector3((a.x + b.x) / 2, a.y + 1.9, (a.z + b.z) / 2);
    // عمود بر خط دو نفر، کمی بالاتر
    const dir = new THREE.Vector3().subVectors(b, a); dir.y = 0; dir.normalize();
    const side = new THREE.Vector3(-dir.z, 0, dir.x);
    const want = mid.clone().addScaledVector(side, 4.6); want.y = player.position.y + 3.1;
    camera.position.lerp(want, Math.min(1, k * 60 * dt));
    camera.lookAt(mid.x, player.position.y + 1.85, mid.z);
  }

  function npcEntry(id) { return npcMeshes.find(nm => nm.npc.id === id); }

  // دوربین از دیوارهای اتاق بیرون نزنه
  function clampCamInside() {
    if (!INT.isInside()) return;
    const R = INT.room();
    if (!R) return;
    const p = camera.position;
    p.x = Math.max(-R.W / 2 + .9, Math.min(R.W / 2 - .9, p.x));
    p.z = Math.max(-R.D / 2 + .9, Math.min(R.D / 2 - .9, p.z));
    const base = INT.seated() ? INTERIOR_Y : player.position.y;
    p.y = Math.max(base + 1.6, Math.min(base + R.H - .35, p.y));
  }

  // ---------- API گفتگو ----------
  // مختصات صفحه‌ای بالای سر یک نفر (برای حباب حرف)
  W.screenOf = who => {
    let obj = null;
    if (who === 'player') obj = player;
    else { const nm = npcEntry(who); obj = nm && nm.mesh; }
    if (!obj) return null;
    const v = new THREE.Vector3(obj.position.x, 3.5, obj.position.z).project(camera);
    if (v.z > 1) return null;
    return { x: (v.x * .5 + .5) * innerWidth, y: (-v.y * .5 + .5) * innerHeight, behind: v.z > 1 };
  };
  // انیمیشن کوچیک «رفتن سمت طرف» بعد گفتگو
  W.approach = (npcId, done) => {
    const nm = npcEntry(npcId);
    if (!nm) { done && done(); return; }
    nm.t = 9999;                      // وسط حرف نپره جای دیگه
    driving = false; player.visible = true;
    approach = { nm, done, t: 0 };
  };
  W.endTalk = () => {
    if (talking) { talking.nm.t = 0; talking.nm.mesh.userData.limbs.armR.rotation.x = 0; }
    talking = null; approach = null;
  };
  W.isTalking = () => !!(talking || approach);
  // هدیه: یه جعبهٔ کادو بده دستش و بپره بالا (سبک د سیمز)
  W.giftAnim = (npcId, kind) => {
    const nm = npcEntry(npcId);
    if (!nm) return;
    const box = new THREE.Group();
    const b1 = new THREE.Mesh(new THREE.BoxGeometry(.42, .42, .42), mat(kind === 'flower' ? 0xff5d8f : kind === 'sweet' ? 0xf7d08a : 0x6a4c93));
    const ribbon = new THREE.Mesh(new THREE.BoxGeometry(.46, .46, .09), mat(0xffd166));
    const ribbon2 = new THREE.Mesh(new THREE.BoxGeometry(.09, .46, .46), mat(0xffd166));
    box.add(b1, ribbon, ribbon2);
    box.position.set(0, 1.55, .55);
    nm.mesh.add(box);
    const t0 = performance.now();
    (function hop() {
      const e = (performance.now() - t0) / 1600;
      if (e >= 1) { nm.mesh.remove(box); nm.mesh.position.y = 0; return; }
      box.rotation.y += .12;
      box.position.y = 1.55 + Math.sin(e * Math.PI * 3) * .22;
      nm.mesh.position.y = Math.abs(Math.sin(e * Math.PI * 3)) * .28;   // از خوشحالی می‌پره!
      requestAnimationFrame(hop);
    })();
  };
  // آفتابی/غیب کردن یک NPC از خیابون (روزهایی که پشت دخل مغازه‌ست)
  // NPC عجله‌ای واقعاً پیاده بره تا در مغازه‌ش و بره داخل
  W.npcGoShop = id => {
    const nm = npcEntry(id);
    const b = buildingById(nm?.npc.hangout);
    if (!nm || !b || !nm.mesh.visible) return;
    nm.goingShop = true;
    nm.t = 9999;
    nm.target = new THREE.Vector3(b.x, 0, b.z + b.d / 2 + 1.2);
  };
  W.setNpcOutside = (id, on) => {
    const nm = npcEntry(id);
    if (nm) nm.mesh.visible = on;
  };
  W.npcOutside = id => { const nm = npcEntry(id); return !!(nm && nm.mesh.visible); };

  // ---------- API فضای داخلی ----------
  let outsideReturn = null;
  // دوربین رو بدون پرواز ۱۰۰ واحدی بچسبون پشت بازیکن
  function snapCamera() {
    const d = INT.isInside() ? 7.5 : 9;
    if (INT.isInside()) camPitch = Math.max(camPitch, .72);
    camera.position.set(
      player.position.x + Math.sin(camYaw) * Math.cos(camPitch) * d,
      player.position.y + 2 + Math.sin(camPitch) * d,
      player.position.z + Math.cos(camYaw) * Math.cos(camPitch) * d);
    clampCamInside();
    camera.lookAt(player.position.x, player.position.y + 1.6, player.position.z);
  }
  W.snapCamera = snapCamera;
  W.enterInterior = id => {
    const b = buildingById(id);
    if (!b) return;
    if (b.kind === 'open') { openBuilding(id); return; }
    outsideReturn = { x: b.x, z: b.z + b.d / 2 + 3.5 };
    driving = false;
    if (INT.enter(id)) {
      snapCamera();
      sfx.door();
      toast('🚪 اومدی تو ' + b.name + ' — نزدیک در، E بزن که برگردی بیرون');
      $id('interactHint').style.display = 'none';
    }
  };
  W.exitInterior = () => {
    if (!INT.isInside()) return;
    INT.endDate();
    INT.exit();
    const r = outsideReturn || { x: G.px, z: G.pz };
    player.position.set(r.x, 0, r.z);
    player.visible = true;
    G.px = r.x; G.pz = r.z;
    outsideReturn = null;
    snapCamera();
  };
  W.insideOf = () => INT.id();
  W.cafeDate = (npc, done) => {
    const cafe = buildingById('cafe');
    outsideReturn = { x: cafe.x, z: cafe.z + cafe.d / 2 + 3.5 };
    INT.cafeDate(npc, done);
    snapCamera();
  };
  W.endDate = () => { INT.endDate(); W.exitInterior(); };
  W.onChildMode = () => {
    player.scale.set(.72, .72, .72);
    refreshStreetNpcs();
    toast('🧒 حالا بچه‌ای! دوستات تو پارک محله‌ن.');
  };
  if (G.child) player.scale.set(.72, .72, .72);
  W.onChild = () => { if (INT.isInside() && INT.id() === 'home') { const id = INT.id(); INT.exit(); INT.enter(id); } };

  // ================= گادمود: ادیتور دنیای بازی =================
  // انتخاب با کلیک | WASD/جهت‌ها = جابه‌جایی | R = چرخش ۹۰° | ذخیره = ماندگار
  let godOn = false, godSel = null;   // godSel = {type:'npc'|'building'|'furn'|'road', obj, id?, idx?}
  const godRoadMeshes = [];
  const godRay = new THREE.Raycaster();
  const godMarker = new THREE.Mesh(new THREE.TorusGeometry(1.6, .12, 8, 24),
    new THREE.MeshBasicMaterial({ color: 0xffd166, depthTest: false }));
  godMarker.rotation.x = Math.PI / 2;
  godMarker.visible = false; godMarker.renderOrder = 99;
  scene.add(godMarker);

  function godBuildRoad(rd, idx) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(rd.horizontal ? rd.len : 12, rd.horizontal ? 12 : rd.len),
      new THREE.MeshLambertMaterial({ color: 0x4a4a4a }));
    m.rotation.x = -Math.PI / 2;
    m.position.set(rd.x, .015, rd.z);
    m.userData.godRoadIdx = idx;
    scene.add(m);
    godRoadMeshes[idx] = m;
    return m;
  }
  godEdits.roads.forEach((rd, i) => godBuildRoad(rd, i));

  // ادیت‌های مبلمان فضای داخلی رو بعد از ساخت اتاق اعمال کن
  function godApplyInterior(id) {
    const ed = godEdits.interiors[id];
    const grp = INT.group();
    if (!ed || !grp) return;
    Object.entries(ed).forEach(([k, v]) => {
      const m = grp.children[+k];
      if (m) { m.position.x = v.x; m.position.z = v.z; if (v.rotY != null) m.rotation.y = v.rotY; }
    });
  }
  const _enterInterior = W.enterInterior;
  W.enterInterior = id => { _enterInterior(id); godApplyInterior(id); };

  function godPanel() {
    let el = $id('godPanel');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'godPanel';
    el.style.cssText = 'position:fixed;top:130px;left:50%;transform:translateX(-50%);z-index:75;display:flex;gap:8px;align-items:center;background:rgba(10,6,26,.92);border:1px solid #b08cff;border-radius:12px;padding:8px 12px;color:#e8dbff;font-size:12px;flex-wrap:wrap;justify-content:center;max-width:94vw';
    el.innerHTML = '<b style="color:#b08cff">🛠 گادمود</b>' +
      '<span id="godHint">کلیک=انتخاب | WASD/جهت‌ها=جابه‌جایی | R=چرخش ۹۰° | -/+=طول خیابون</span>';
    const btn = (label, fn, color) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.style.cssText = 'background:' + (color || '#3a2f56') + ';color:#fff;border:none;border-radius:8px;padding:6px 12px;cursor:pointer;font-family:inherit;font-size:12px';
      b.onclick = fn;
      el.appendChild(b);
      return b;
    };
    btn('➕ خیابون', () => {
      const rd = { x: Math.round(player.position.x), z: Math.round(player.position.z), len: 60, horizontal: Math.abs(Math.sin(camYaw)) > .7 };
      godEdits.roads.push(rd);
      const m = godBuildRoad(rd, godEdits.roads.length - 1);
      godSel = { type: 'road', obj: m, idx: godEdits.roads.length - 1 };
      toast('🛣️ خیابون جدید! با WASD جابه‌جا کن، R بچرخون، +/- طولش کن.');
    });
    btn('🗑 حذف انتخاب', () => {
      if (!godSel) { toast('اول یه چیزی انتخاب کن!'); return; }
      if (godSel.type === 'road') {
        scene.remove(godSel.obj);
        godEdits.roads[godSel.idx] = null;
        toast('🗑 خیابون حذف شد.');
      } else if (godSel.type === 'npc') {
        delete godEdits.npcs[godSel.id]; godSel.obj.frozen = false;
        toast('🔓 ادیت این آدم پاک شد و آزاد شد.');
      } else if (godSel.type === 'building') {
        delete godEdits.buildings[godSel.id];
        toast('↩️ ادیت ساختمون پاک شد (بعد از شروع دوباره سر جاش برمی‌گرده).');
      } else if (godSel.type === 'furn') {
        const ed = godEdits.interiors[INT.id()]; if (ed) delete ed[godSel.idx];
        toast('↩️ ادیت این وسیله پاک شد (با ورود دوباره سر جاش برمی‌گرده).');
      }
      godSel = null;
    }, '#7a3040');
    btn('💾 ذخیرهٔ چیدمان', () => {
      godEdits.roads = godEdits.roads.filter(Boolean);
      // بازسازی خیابون‌ها با ایندکس‌های تازه
      godRoadMeshes.forEach(m => m && scene.remove(m));
      godRoadMeshes.length = 0;
      godSel = null;
      godEdits.roads.forEach((rd, i) => godBuildRoad(rd, i));
      safeStore.setItem(GOD_KEY, JSON.stringify(godEdits));
      toast('💾 چیدمان گادمود ذخیره شد — همیشه اعمال میشه!');
    }, '#1f6f4a');
    btn('❌ خروج', () => W.godToggle(), '#8a2530');
    document.body.appendChild(el);
    return el;
  }

  W.godToggle = () => {
    godOn = !godOn;
    godPanel().style.display = godOn ? 'flex' : 'none';
    godMarker.visible = false; godSel = null;
    toast(godOn ? '🛠 گادمود روشن! کلیک کن روی آدم/ساختمون/وسیله/خیابون.' : '🛠 گادمود خاموش.');
  };

  function godPick(cx, cy) {
    godRay.setFromCamera({ x: (cx / innerWidth) * 2 - 1, y: -(cy / innerHeight) * 2 + 1 }, camera);
    const hits = godRay.intersectObjects(scene.children, true);
    for (const h of hits) {
      let o = h.object;
      while (o) {
        if (o.userData.godRoadIdx != null && godEdits.roads[o.userData.godRoadIdx])
          return { type: 'road', obj: o, idx: o.userData.godRoadIdx };
        const nm = npcMeshes.find(n => n.mesh === o);
        if (nm) return { type: 'npc', obj: nm, id: nm.npc.id };
        const bid = Object.keys(godBldGroups).find(k => godBldGroups[k] === o);
        if (bid) return { type: 'building', obj: godBldGroups[bid], id: bid };
        const grp = INT.group();
        if (grp && o.parent === grp) return { type: 'furn', obj: o, idx: grp.children.indexOf(o) };
        o = o.parent;
      }
    }
    return null;
  }

  function godTarget() {
    if (!godSel) return null;
    return godSel.type === 'npc' ? godSel.obj.mesh : godSel.obj;
  }

  function godRecord() {
    const t = godTarget(); if (!t) return;
    if (godSel.type === 'building')
      godEdits.buildings[godSel.id] = { x: t.position.x, z: t.position.z, rotY: t.rotation.y };
    else if (godSel.type === 'npc') {
      godEdits.npcs[godSel.id] = { rotY: t.rotation.y, x: t.position.x, z: t.position.z, freeze: true };
      godSel.obj.frozen = true;
      godSel.obj.home.copy(t.position);
    } else if (godSel.type === 'road') {
      const rd = godEdits.roads[godSel.idx];
      rd.x = t.position.x; rd.z = t.position.z;
    } else if (godSel.type === 'furn') {
      const id = INT.id(); if (!id) return;
      godEdits.interiors[id] = godEdits.interiors[id] || {};
      godEdits.interiors[id][godSel.idx] = { x: t.position.x, z: t.position.z, rotY: t.rotation.y };
    }
  }

  function godRotate() {
    const t = godTarget(); if (!t) return;
    if (godSel.type === 'road') {
      const rd = godEdits.roads[godSel.idx];
      rd.horizontal = !rd.horizontal;
      t.geometry.dispose();
      t.geometry = new THREE.PlaneGeometry(rd.horizontal ? rd.len : 12, rd.horizontal ? 12 : rd.len);
    } else {
      t.rotation.y += Math.PI / 2;
      if (godSel.type === 'building') {
        const c = godBldCollider[godSel.id];
        if (c) { const tmp = c.hx; c.hx = c.hz; c.hz = tmp; }
      }
    }
    godRecord();
  }

  function godRoadLen(d) {
    if (!godSel || godSel.type !== 'road') return;
    const rd = godEdits.roads[godSel.idx];
    rd.len = Math.max(16, rd.len + d);
    const t = godSel.obj;
    t.geometry.dispose();
    t.geometry = new THREE.PlaneGeometry(rd.horizontal ? rd.len : 12, rd.horizontal ? 12 : rd.len);
    godRecord();
  }

  function godFrame(dt) {
    const t = godTarget();
    if (t) {
      let dx = 0, dz = 0;
      if (keys['KeyW'] || keys['ArrowUp'])    dz -= 1;
      if (keys['KeyS'] || keys['ArrowDown'])  dz += 1;
      if (keys['KeyA'] || keys['ArrowLeft'])  dx -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) dx += 1;
      if (dx || dz) {
        t.position.x += dx * 6 * dt;
        t.position.z += dz * 6 * dt;
        if (godSel.type === 'building') {
          const c = godBldCollider[godSel.id];
          if (c) { c.x = t.position.x; c.z = t.position.z; }
        }
        godRecord();
      }
      godMarker.visible = true;
      godMarker.position.set(t.position.x, (INT.isInside() ? INTERIOR_Y : 0) + .25, t.position.z);
    } else godMarker.visible = false;
    // دوربین همون حالت عادی دور بازیکن
    const camDist = INT.isInside() ? 7.5 : 12;
    camera.position.lerp(new THREE.Vector3(
      player.position.x + Math.sin(camYaw) * Math.cos(camPitch) * camDist,
      player.position.y + 2 + Math.sin(camPitch) * camDist,
      player.position.z + Math.cos(camYaw) * Math.cos(camPitch) * camDist), .15);
    clampCamInside();
    camera.lookAt(player.position.x, player.position.y + 1.6, player.position.z);
  }
  W.godFrame = godFrame;
  W.godIsOn = () => godOn;
  W.godRotate = godRotate;
  W.godRoadLen = godRoadLen;
  const _cafeDate = W.cafeDate;
  W.cafeDate = (npc, done) => { _cafeDate(npc, done); godApplyInterior('cafe'); };

  // انتخاب با کلیک (وقتی درگ نکرده باشیم)
  let godDown = null;
  canvas.addEventListener('pointerdown', e => { if (godOn) godDown = { x: e.clientX, y: e.clientY }; });
  canvas.addEventListener('pointerup', e => {
    if (!godOn || !godDown) return;
    if (Math.hypot(e.clientX - godDown.x, e.clientY - godDown.y) < 6) {
      const s = godPick(e.clientX, e.clientY);
      if (s) {
        godSel = s;
        toast('✅ انتخاب شد: ' + (s.type === 'npc' ? s.obj.npc.name : s.type === 'building' ? (buildingById(s.id)?.name || s.id) : s.type === 'road' ? 'خیابون' : 'وسیلهٔ داخل مغازه'));
      }
    }
    godDown = null;
  });

  // اعمال ادیت‌های ذخیره‌شدهٔ آدم‌ها
  for (const nm of npcMeshes) {
    const e = godEdits.npcs[nm.npc.id];
    if (e) {
      if (e.x != null) { nm.mesh.position.set(e.x, 0, e.z); nm.home.copy(nm.mesh.position); }
      nm.mesh.rotation.y = e.rotY || 0;
      nm.frozen = !!e.freeze;
    }
  }

  // ================= 🎪 چالش‌های محله (سبک Sneaky Sasquatch) =================
  var CH = null;   // {type, until, meshes[], data...} — var که قبل از تعریف هم قابل‌خوندن باشه
  function chTimerEl() {
    let el = $id('chTimer');
    if (!el) {
      el = document.createElement('div');
      el.id = 'chTimer';
      el.style.cssText = 'position:fixed;top:150px;right:50%;transform:translateX(50%);z-index:60;background:rgba(180,40,40,.92);color:#fff;padding:8px 22px;border-radius:12px;font-size:14px;font-weight:bold;display:none;text-align:center;box-shadow:0 6px 20px rgba(0,0,0,.4)';
      document.body.appendChild(el);
    }
    return el;
  }
  function chRunner(color, x, z, opts) {
    const m = makePerson(color, opts || { style: 'cap', accColor: 0x222222 });
    if (typeof clampOffStreetCenter === 'function') { const c = clampOffStreetCenter(x, z, 2); x = c.x; z = c.z; }
    m.position.set(x, 0, z);
    scene.add(m);
    CH.meshes.push(m);
    return m;
  }
  function chRing(x, z, color) {
    const r = new THREE.Mesh(new THREE.TorusGeometry(4, .35, 8, 24),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: .85 }));
    r.rotation.x = Math.PI / 2; r.position.set(x, .4, z);
    scene.add(r); CH.meshes.push(r);
    return r;
  }
  function chEnd(ok, caption, rewardFn) {
    const t = CH; CH = null; G.challenge = null;
    chTimerEl().style.display = 'none';
    (t?.meshes || []).forEach(m => scene.remove(m));
    playCutscene(caption, 4600, () => {
      if (ok && rewardFn) rewardFn();
      updateHUD();
      // اختتامیه با دیالوگ خود شخصیت + نشان
      setTimeout(() => window.challengeEndDialog?.(t.type, ok), 400);
    });
  }
  W.challengeStart = type => {
    if (CH || !gameStarted || G.traveling) return;
    G.challenge = { type };
    CH = { type, meshes: [], t0: performance.now() };
    const px = player.position.x, pz = player.position.z;
    if (type === 'race') {
      // 🏃 مسابقهٔ دو دور کمربندی — ۴ ایست بازرسی
      CH.cps = [[160, 160], [160, -160], [-160, -160], [-160, 160]];
      CH.cpi = 0;
      CH.until = performance.now() + 210000;
      CH.ring = chRing(160, 160, 0xffd166);
      sfx.alert(); if (typeof sayFa === 'function') sayAs(NPCS.find(n => n.id === 'akbar'), 'مسابقه شروع شد! بدو پهلوون!');
      showBanner('🏃 اکبرآقا: «مسابقهٔ دو محله! چهار گوشهٔ کمربندی رو به ترتیب رد کن — با Shift بدو! جایزه ۵ میلیون!»', 7000);
    } else if (type === 'purse') {
      // 👜 کیف‌قاپ! بدو بگیرش
      const th = chRunner(0x333333, px + 9, pz + 3);
      const bag = new THREE.Mesh(new THREE.BoxGeometry(.5, .4, .25), mat(0xd63384));
      bag.position.set(.5, 1.5, .3); th.add(bag);
      CH.thief = th;
      CH.wp = new THREE.Vector3(px + 60, 0, pz + 40);
      CH.until = performance.now() + 50000;
      sfx.alert(); if (typeof sayFa === 'function') sayAs(NPCS.find(n => n.id === 'fezzeh'), 'آهاای! کیفم! دزد! بگیرش!');
      showBanner('👜 ملوک‌خانم: «کیفم!! دزد!! بگیرش جوون!» — بدو بهش برس! (Shift = دویدن)', 6000);
    } else if (type === 'lostkid') {
      G.challenge.asked = 0;
      sfx.alert(); if (typeof sayFa === 'function') sayFa('هومن گم شده! کمک کنید!', 1, 1.45, 'f');
      showBanner('🧒 مامانِ هومن گریه‌کنان: «هومن از مدرسه برنگشته! تو رو خدا پیداش کن!» — از اهالی محله بپرس (E روی آدم‌ها)', 8000);
      chTimerEl().style.display = 'block';
      chTimerEl().textContent = '🧒 هومن گم شده — از اهالی بپرس!';
    } else if (type === 'paintball') {
      // 🎨 پینت‌بال پلیس! Space = شلیک
      CH.thieves = [];
      for (let i = 0; i < 3; i++) {
        const th = chRunner([0x333333, 0x4a3a2a, 0x2a2a3a][i], px + 14 + i * 6, pz - 10 + i * 8);
        th.userData.hits = 0;
        th.userData.wp = new THREE.Vector3(px + (Math.random() - .5) * 90, 0, pz + (Math.random() - .5) * 90);
        CH.thieves.push(th);
      }
      CH.until = performance.now() + 100000;
      sfx.alert(); if (typeof sayFa === 'function') sayAs(NPCS.find(n => n.id === 'police'), 'سه تا دزد فرار کردن! با تفنگ رنگی بزنشون!');
      showBanner('🚨 افسر رحیمی: «سه تا دزد از طلافروشی زدن! این تفنگ پینت‌بال — رنگی‌شون کن تا گمشون نکنیم! (Space = شلیک، هر کدوم ۲ تیر)»', 8500);
    } else if (type === 'cat') {
      const spot = TREE_SPOTS[7] || [28, 24];
      CH.catPos = new THREE.Vector3(spot[0], 4.1, spot[1]);
      const cat = new THREE.Group();
      const body = new THREE.Mesh(new THREE.SphereGeometry(.35, 10, 8), mat(0xd9a066));
      const head = new THREE.Mesh(new THREE.SphereGeometry(.22, 8, 8), mat(0xd9a066));
      head.position.set(.3, .25, 0);
      const e1 = new THREE.Mesh(new THREE.ConeGeometry(.08, .18, 4), mat(0xb9824a)); e1.position.set(.25, .48, .1);
      const e2 = e1.clone(); e2.position.z = -.1;
      cat.add(body, head, e1, e2);
      cat.position.copy(CH.catPos);
      scene.add(cat); CH.meshes.push(cat); CH.cat = cat;
      CH.ring = chRing(spot[0], spot[1], 0xff8fab);
      sfx.alert();
      showBanner('🐱 ننه‌قمر: «پشمک رفته بالای درخت (حلقهٔ صورتی رو نقشه‌ست)! بپر بگیرش مادر!» — برو زیر درخت، بپر (Space) و E بزن', 8000);
      chTimerEl().style.display = 'block';
      chTimerEl().textContent = '🐱 پشمک روی درخته — نزدیک حلقهٔ صورتی';
    } else if (type === 'fire') {
      // 🔥 آتش نانوایی: ۳ بار سطل آب از کارواش به نانوایی
      const bak = buildingById('bakery');
      CH.trips = 0; CH.carrying = false;
      CH.src = buildingById('repair') || buildingById('market');
      CH.dst = bak;
      CH.ring = chRing(CH.src.x, CH.src.z + CH.src.d/2 + 4, 0x3fa9f5);
      // شعله روی نانوایی
      const fl = new THREE.Mesh(new THREE.ConeGeometry(2.4, 5, 8), new THREE.MeshBasicMaterial({ color: 0xff6b1a, transparent: true, opacity: .8 }));
      fl.position.set(bak.x, bak.h + 2, bak.z);
      scene.add(fl); CH.meshes.push(fl); CH.flame = fl;
      CH.until = performance.now() + 150000;
      sfx.alert();
      showBanner('🔥 نانوایی آتیش گرفته! حلقهٔ آبی = سطل آب، بعد برو نانوایی! (۳ بار)', 8000);
    } else if (type === 'ring') {
      // 💍 ۵ نقطهٔ درخشان رو بگرد
      CH.spots = [];
      const cands = BUILDINGS.filter(b => !b.deco).sort(() => Math.random() - .5).slice(0, 5);
      cands.forEach(b => {
        const g = new THREE.Mesh(new THREE.SphereGeometry(.7, 10, 10), new THREE.MeshBasicMaterial({ color: 0xffe066 }));
        g.position.set(b.x + b.w/2 + 3, 1.2, b.z + b.d/2 + 3);
        scene.add(g); CH.meshes.push(g);
        CH.spots.push({ mesh: g, b, checked: false });
      });
      CH.ringIn = Math.floor(Math.random() * 5);
      CH.found = 0;
      CH.until = performance.now() + 220000;
      showBanner('💍 پنج نقطهٔ طلایی تو محله! برو نزدیکشون و E بزن — حلقه تو یکیشونه!', 8500);
    } else if (type === 'carrace') {
      // 🏎️ مسابقهٔ ماشین دور کمربندی
      CH.cps = [[160, 160], [160, -160], [-160, -160], [-160, 160]];
      CH.cpi = 0;
      CH.until = performance.now() + 170000;
      CH.ring = chRing(160, 160, 0xff4d4d);
      CH.needCar = true;
      showBanner('🏎️ مسابقهٔ ماشین! سوار شو (F) و چهار گوشهٔ کمربندی رو رد کن — شرط ۱۰ میلیون!', 8000);
    } else if (type === 'dog') {
      // 🐕 سگ فراری: آروم نزدیک شو (دویدن = فرار)
      const dog = new THREE.Group();
      const bd = new THREE.Mesh(new THREE.CapsuleGeometry(.32, .8, 4, 8), mat(0xa9754f)); bd.rotation.z = Math.PI/2; bd.position.y = .55;
      const hd = new THREE.Mesh(new THREE.SphereGeometry(.28, 9, 8), mat(0xa9754f)); hd.position.set(.6, .8, 0);
      const tl = new THREE.Mesh(new THREE.CylinderGeometry(.06, .03, .5), mat(0x8a5f3f)); tl.position.set(-.65, .8, 0); tl.rotation.z = -.7;
      dog.add(bd, hd, tl);
      dog.position.set(px + 12, 0, pz + 6);
      scene.add(dog); CH.meshes.push(dog);
      CH.dog = dog; CH.dogCalm = 0;
      CH.until = performance.now() + 120000;
      showBanner('🐕 «پهلوون» ترسیده! آروم برو نزدیکش (ندو!) و نزدیکش ۳ ثانیه بمون تا آروم شه.', 8500);
    } else if (type === 'moving') {
      // 📦 ۵ جعبه از آپارتمان به کامیون
      const ap = buildingById('apartment1');
      CH.box = null; CH.done = 0;
      CH.from = { x: ap.x, z: ap.z + ap.d/2 + 4 };
      CH.to = { x: ap.x + 18, z: ap.z + ap.d/2 + 4 };
      const truck = makeCarMesh(0x557a95); truck.scale.set(1.4, 1.6, 1.8);
      truck.position.set(CH.to.x, 0, CH.to.z);
      scene.add(truck); CH.meshes.push(truck);
      CH.ring = chRing(CH.from.x, CH.from.z, 0xc9a227);
      CH.until = performance.now() + 190000;
      showBanner('📦 پنج جعبه! حلقهٔ طلایی = بردار، بعد ببر سمت کامیون. (۵ بار)', 8000);
    } else if (type === 'festival') {
      // 🎭 خرید از ۴ مغازه و رسوندن به مسجد
      const shops = ['bakery', 'pastry', 'juice', 'market'].map(buildingById).filter(Boolean);
      CH.stops = shops; CH.si = 0; CH.final = buildingById('mosque');
      CH.until = performance.now() + 230000;
      CH.ring = chRing(shops[0].x, shops[0].z + shops[0].d/2 + 4, 0xba68c8);
      showBanner('🎭 جشن محله! از ۴ مغازه خرید کن (حلقهٔ بنفش) و آخرش ببر مسجد!', 8500);
    } else if (type === 'medicine') {
      // 💊 دارو از بیمارستان به خونهٔ بیمار
      const hos = buildingById('hospital'), home = buildingById('apartment1');
      CH.picked = false; CH.hos = hos; CH.home = home;
      CH.ring = chRing(hos.x, hos.z + hos.d/2 + 4, 0xff5252);
      CH.until = performance.now() + 110000;
      sfx.alert();
      showBanner('💊 اورژانسی! اول بیمارستان (حلقهٔ قرمز) دارو بگیر، بعد سریع ببر آپارتمان گلستان!', 8000);
    } else if (type === 'thief') {
      // 🕵️ کشیک شبانه جلوی سوپرمارکت
      const mk = buildingById('market');
      CH.market = mk; CH.thiefOut = false; CH.caught = false;
      CH.ring = chRing(mk.x, mk.z + mk.d/2 + 5, 0x6a4c93);
      CH.until = performance.now() + 150000;
      showBanner('🕵️ کشیک! برو تو حلقهٔ بنفش جلوی سوپرمارکت و صبر کن... دزد که اومد، دنبالش کن!', 8500);
    } else if (type === 'power') {
      // ⚡ ژنراتور تعمیرگاه: ۳ بار ابزار ببر
      const rp = buildingById('repair');
      CH.trips = 0; CH.carrying = false;
      CH.src = buildingById('dealership');
      CH.dst = rp;
      CH.ring = chRing(CH.src.x, CH.src.z + CH.src.d/2 + 4, 0xffd166);
      CH.until = performance.now() + 170000;
      // چراغ‌های شهر خاموش
      lampBulbs.forEach(b => b.material.emissiveIntensity = 0);
      lampLights.forEach(l => l.intensity = 0);
      showBanner('⚡ برق رفته! سه بار ابزار از نمایشگاه (حلقهٔ زرد) ببر تعمیرگاه تا ژنراتور راه بیفته!', 8500);
    } else if (type === 'robotics') {
      // 🤖 برو آکادمی و تشویق کن
      const rb = buildingById('robotics');
      CH.target = rb;
      CH.ring = chRing(rb.x, rb.z + rb.d/2 + 4, 0xb08cff);
      CH.until = performance.now() + 200000;
      showBanner('🤖 مسابقهٔ رباتیک ' + (G.childName || 'بچه‌ت') + ' شروع شده! برو آکادمی نوین‌ذهن (حلقهٔ بنفش)!', 8000);
    } else if (type === 'delivery') {
      const opts2 = BUILDINGS.filter(b => !b.deco && b.kind !== 'open' && Math.hypot(b.x - px, b.z - pz) > 40);
      CH.stops = [];
      for (let i = 0; i < 3 && opts2.length; i++)
        CH.stops.push(opts2.splice(Math.floor(Math.random() * opts2.length), 1)[0]);
      CH.si = 0;
      CH.until = performance.now() + 200000;
      CH.ring = chRing(CH.stops[0].x, CH.stops[0].z + CH.stops[0].d / 2 + 4, 0x80ed99);
      sfx.alert(); if (typeof sayFa === 'function') sayAs(NPCS.find(n => n.id === 'asghar'), 'موتورم خرابه! این سفارشا رو تو برسون داداش!');
      showBanner('🍕 اصغر: «موتورم ریخت به هم! این ۳ تا سفارش رو تو برسون: ' + CH.stops.map(b => b.name).join('، ') + ' — حلقهٔ سبز = مقصد بعدی!»', 9000);
    }
  };
  function chShoot() {
    if (!CH || CH.type !== 'paintball') return false;
    // شلیک از مرکز دوربین
    const dir = new THREE.Vector3(); camera.getWorldDirection(dir);
    let best = null, bestAng = .22;
    for (const th of CH.thieves) {
      if (th.userData.hits >= 2) continue;
      const to = th.position.clone().sub(camera.position);
      const d = to.length();
      if (d > 60) continue;
      const ang = to.normalize().angleTo(dir);
      if (ang < bestAng) { bestAng = ang; best = th; }
    }
    sfx.click();
    if (best) {
      best.userData.hits++;
      const splat = new THREE.Mesh(new THREE.SphereGeometry(.35, 8, 8),
        new THREE.MeshBasicMaterial({ color: [0xff2d78, 0x00e5a0, 0xffd166][Math.floor(Math.random() * 3)] }));
      splat.position.set((Math.random() - .5) * .6, 1.3 + Math.random() * .6, (Math.random() - .5) * .4);
      best.add(splat);
      if (best.userData.hits >= 2) {
        toast('🎨 رنگی شد! وایساد! (' + fa(CH.thieves.filter(t => t.userData.hits >= 2).length) + ' از ۳)');
        if (typeof sayFa === 'function') sayFa('آاای! تسلیمم! تسلیمم!', 1.2, .95, 'm');
      }
      if (CH.thieves.every(t => t.userData.hits >= 2)) {
        chEnd(true, '🚔 ون پلیس رسید؛ سه تا دزدِ رنگارنگ رو سوار کردن! افسر رحیمی دستشو گذاشت رو شونه‌ت: «دستت طلا! بدون تو گمشون می‌کردیم. محله بهت افتخار می‌کنه!» 👮🤝', () => {
          addMoney(8000000); G.happy += 12; addHonor(10);
          addNews('🚔 دزدهای طلافروشی با کمک یکی از اهالی دستگیر شدند!');
          addLog('🎨 مأموریت پینت‌بال کامل شد: +۸ میلیون، +۱۰ شرافت');
        });
      }
      return true;
    }
    toast('🎨 خطا رفت! دقیق‌تر نشونه بگیر (وسط صفحه)');
    return true;
  }
  function updateChallenge(dt, now) {
    if (!CH) return;
    const el = chTimerEl();
    const left = CH.until ? Math.max(0, Math.ceil((CH.until - now) / 1000)) : null;
    if (CH.type === 'race') {
      el.style.display = 'block';
      el.textContent = '🏃 ایست بازرسی ' + fa(CH.cpi + 1) + ' از ۴ — ⏱ ' + fa(left);
      const [cx, cz] = CH.cps[CH.cpi];
      CH.ring.position.set(cx, .4, cz);
      CH.ring.rotation.z = now * .002;
      if (Math.hypot(player.position.x - cx, player.position.z - cz) < 9) {
        CH.cpi++;
        sfx.money();
        if (CH.cpi >= 4) {
          chEnd(true, '🏆 خط پایان! اکبرآقا سوت‌زنان: «ایول پهلوون! رکورد محله رو زدی! این ۵ میلیون حلالت!» بقیه نفس‌نفس‌زنان رسیدن...', () => {
            addMoney(5000000); G.happy += 12; G.health += 5;
            addLog('🏃 مسابقهٔ دو محله رو بردی! +۵ میلیون');
          });
          return;
        }
        toast('✅ ایست ' + fa(CH.cpi) + ' رد شد! بعدی: حلقهٔ طلایی');
      }
      if (left === 0) chEnd(false, '⏱ دیر رسیدی! اکبرآقا: «عیب نداره، دفعه بعد! برو رو تردمیل تمرین کن!» 😄', null);
    } else if (CH.type === 'purse') {
      el.style.display = 'block';
      el.textContent = '👜 بدو بگیرش! ⏱ ' + fa(left);
      const th = CH.thief;
      const d = th.position.clone().sub(CH.wp);
      if (d.length() < 4) CH.wp.set(player.position.x + (Math.random() - .5) * 120, 0, player.position.z + (Math.random() - .5) * 120);
      const dir = CH.wp.clone().sub(th.position).normalize();
      th.position.addScaledVector(dir, dt * 7.4);
      th.rotation.y = Math.atan2(dir.x, dir.z);
      const L = th.userData.limbs, tt = now * .012;
      L.legL.rotation.x = Math.sin(tt) * .7; L.legR.rotation.x = -Math.sin(tt) * .7;
      if (th.position.distanceTo(player.position) < 2.2) {
        chEnd(true, '👜 گرفتیش! کیف رو پس گرفتی و دزده پا گذاشت به فرار. ملوک‌خانم اشک‌شوق‌ریزان: «الهی خیر ببینی مادر! کل محله باید بدونن چه جوونی هستی!» 🥲', () => {
          addMoney(2000000); addHonor(8); G.happy += 10;
          addNews('👜 کیف‌قاپ محله ناکام ماند — یکی از اهالی کیف ملوک‌خانم را پس گرفت!');
          addLog('👜 کیف ملوک‌خانم رو نجات دادی: +۸ شرافت');
        });
      } else if (left === 0) {
        chEnd(false, '💨 در رفت! ملوک‌خانم: «عیب نداره مادر، تو تلاشتو کردی...» (تا یه هفته سوژهٔ خبراشه!)', null);
      }
    } else if (CH.type === 'lostkid') {
      if (G.challenge?.asked >= 2) el.textContent = '🧒 هومن تو گیم‌نت ستاره‌ست! برو داخل!';
      if (G.challenge?.found) {
        chEnd(true, '🧒 هومن رو پیدا کردی — پای بازی، غرقِ گیم! بردیش خونه؛ مامانش بغلش کرد و کلی گریه کرد: «تو فرشته‌ای جوون!» هومن: «فقط دو راند دیگه مونده بود!» 😅', () => {
          addMoney(1500000); addHonor(10); G.happy += 12;
          addNews('🧒 هومنِ گم‌شده در گیم‌نت پیدا شد! ماجرا ختم به خیر شد.');
          addLog('🧒 هومن رو پیدا کردی: +۱۰ شرافت');
        });
      }
    } else if (CH.type === 'paintball') {
      el.style.display = 'block';
      el.textContent = '🎨 رنگی‌شده‌ها: ' + fa(CH.thieves.filter(t => t.userData.hits >= 2).length) + ' از ۳ — ⏱ ' + fa(left) + ' — Space = شلیک';
      for (const th of CH.thieves) {
        if (th.userData.hits >= 2) continue;
        const d = th.position.clone().sub(th.userData.wp);
        if (d.length() < 4) th.userData.wp.set(player.position.x + (Math.random() - .5) * 100, 0, player.position.z + (Math.random() - .5) * 100);
        const dir = th.userData.wp.clone().sub(th.position).normalize();
        th.position.addScaledVector(dir, dt * 5.5);
        th.rotation.y = Math.atan2(dir.x, dir.z);
        const L = th.userData.limbs, tt = now * .011 + th.position.x;
        L.legL.rotation.x = Math.sin(tt) * .6; L.legR.rotation.x = -Math.sin(tt) * .6;
      }
      if (left === 0) chEnd(false, '💨 فرار کردن! افسر رحیمی: «عیب نداره، پلاکاشون رو داریم. ممنون که کمک کردی.» (نصف جایزه رو داد)', () => { addMoney(3000000); });
    } else if (CH.type === 'cat') {
      CH.cat.position.y = 4.1 + Math.sin(now * .004) * .15;
    } else if (CH.type === 'fire') {
      el.style.display = 'block';
      el.textContent = '🔥 سطل آب ' + fa(CH.trips) + ' از ۳ — ' + (CH.carrying ? 'ببرش نانوایی!' : 'برو حلقهٔ آبی') + ' ⏱ ' + fa(left);
      CH.flame.scale.setScalar(1 - CH.trips * .3);
      const tgt = CH.carrying ? CH.dst : CH.src;
      CH.ring.position.set(tgt.x, .4, tgt.z + tgt.d/2 + 4);
      CH.ring.material.color.setHex(CH.carrying ? 0xff6b1a : 0x3fa9f5);
      if (Math.hypot(player.position.x - tgt.x, player.position.z - (tgt.z + tgt.d/2 + 4)) < 8) {
        if (CH.carrying) { CH.trips++; CH.carrying = false; sfx.money(); toast('💦 یه سطل ریختی! (' + fa(CH.trips) + ' از ۳)'); }
        else { CH.carrying = true; toast('🪣 سطل آب برداشتی! بدو نانوایی!'); }
        if (CH.trips >= 3) return chEnd(true, '🔥💦 آتیش خاموش شد! ننه‌قمر با چشم گریون بغلت کرد: «اگه تو نبودی نونوایی می‌سوخت مادر!» مردم محله دست زدن.', () => questReward('fire'));
      }
      if (left === 0) chEnd(false, '🔥 آتش‌نشانی رسید و خاموش کرد؛ نصف تنور سوخت. ننه‌قمر: «مهم اینه تو اومدی کمک...»', null);
    } else if (CH.type === 'ring') {
      el.style.display = 'block';
      el.textContent = '💍 ' + fa(CH.found) + ' جا رو گشتی از ۵ — ⏱ ' + fa(left);
      CH.spots.forEach(sp => { if (!sp.checked) sp.mesh.position.y = 1.2 + Math.sin(now * .004) * .25; });
      if (left === 0) chEnd(false, '💍 پیدا نشد... ملوک‌خانم غصه‌دار رفت خونه.', null);
    } else if (CH.type === 'carrace') {
      el.style.display = 'block';
      el.textContent = '🏎️ ایست ' + fa(CH.cpi + 1) + ' از ۴ — ' + (driving ? 'برو!' : '⚠️ سوار ماشین شو (F)') + ' ⏱ ' + fa(left);
      const [cx, cz] = CH.cps[CH.cpi];
      CH.ring.position.set(cx, .4, cz);
      const pp = driving && playerCarMesh ? playerCarMesh.position : player.position;
      if (driving && Math.hypot(pp.x - cx, pp.z - cz) < 10) {
        CH.cpi++; sfx.money();
        if (CH.cpi >= 4) return chEnd(true, '🏎️🏁 اول شدی! رضا مکانیک از ماشین پیاده شد و دست داد: «رانندگیت حرف نداره داداش! این ده میلیون حلالت!»', () => questReward('carrace'));
        toast('✅ ایست ' + fa(CH.cpi) + ' رد شد!');
      }
      if (left === 0) chEnd(false, '🏎️ باختی! رضا خندید: «نصف شرط رو بده بسه، رفیقیم!»', () => addMoney(-3000000));
    } else if (CH.type === 'dog') {
      el.style.display = 'block';
      const d = CH.dog.position.distanceTo(player.position);
      const running = keys['ShiftLeft'] || window.touchInput?.run;
      el.textContent = '🐕 فاصله: ' + fa(Math.round(d)) + 'م — ' + (running ? '⚠️ ندو! می‌ترسه' : 'آروم برو') + ' — آرامش: ' + fa(Math.round(CH.dogCalm * 33)) + '٪';
      if (d < 4 && !running) { CH.dogCalm += dt; CH.dog.rotation.y = Math.atan2(player.position.x - CH.dog.position.x, player.position.z - CH.dog.position.z); }
      else if (d < 7 && running) {
        CH.dogCalm = 0;
        const away = CH.dog.position.clone().sub(player.position).normalize();
        CH.dog.position.addScaledVector(away, dt * 9);
        CH.dog.rotation.y = Math.atan2(away.x, away.z);
      }
      if (CH.dogCalm >= 3) return chEnd(true, '🐕 پهلوون آروم شد و اومد سمتت! دمشو تکون داد و باهات تا قصابی اومد. اصغرآقا: «سگ آدم‌شناسه، تو رو قبول داره!»', () => questReward('dog'));
      if (left === 0) chEnd(false, '🐕 در رفت... اصغرآقا نگرانه. اگه دیدیش خبرش کن.', null);
    } else if (CH.type === 'moving') {
      el.style.display = 'block';
      el.textContent = '📦 جعبه ' + fa(CH.done) + ' از ۵ — ' + (CH.carrying ? 'ببر کامیون!' : 'برو جعبه بردار') + ' ⏱ ' + fa(left);
      const tgt = CH.carrying ? CH.to : CH.from;
      CH.ring.position.set(tgt.x, .4, tgt.z);
      CH.ring.material.color.setHex(CH.carrying ? 0x557a95 : 0xc9a227);
      if (Math.hypot(player.position.x - tgt.x, player.position.z - tgt.z) < 7) {
        if (CH.carrying) { CH.done++; CH.carrying = false; sfx.money(); toast('📦 گذاشتی تو کامیون! (' + fa(CH.done) + ' از ۵)'); }
        else { CH.carrying = true; toast('📦 جعبه رو برداشتی! (سنگینه، آروم برو)'); }
        if (CH.done >= 5) return chEnd(true, '📦 همه رو بردی! عمو غلام کمرشو گرفت و خندید: «جوون که باشی این کارا آسونه! خدا قوت پسرم!»', () => questReward('moving'));
      }
      if (left === 0) chEnd(false, '📦 وقت تموم شد. عمو غلام: «بقیه‌شو خودمون یه جوری می‌بریم، خسته نباشی.»', null);
    } else if (CH.type === 'festival') {
      el.style.display = 'block';
      const isFinal = CH.si >= CH.stops.length;
      const tgt = isFinal ? CH.final : CH.stops[CH.si];
      el.textContent = isFinal ? '🎭 همه رو خریدی! ببر مسجد — ⏱ ' + fa(left)
                               : '🎭 خرید ' + fa(CH.si + 1) + ' از ۴: ' + tgt.name + ' — ⏱ ' + fa(left);
      CH.ring.position.set(tgt.x, .4, tgt.z + tgt.d/2 + 4);
      if (Math.hypot(player.position.x - tgt.x, player.position.z - (tgt.z + tgt.d/2 + 4)) < 8) {
        if (isFinal) return chEnd(true, '🎭 جشن محله ترکوند! چراغونی، آش ننه‌قمر، شیرینی یاسی و صدای موزیک تا نصفه‌شب. افسر رحیمی: «مردم نمی‌دونن، ولی من می‌دونم پشت این جشن کی بود.»', () => questReward('festival'));
        CH.si++; sfx.money(); toast('✅ خرید انجام شد! بعدی: ' + (CH.si < CH.stops.length ? CH.stops[CH.si].name : 'مسجد محله'));
      }
      if (left === 0) chEnd(false, '🎭 دیر شد و جشن یه کم لنگ زد... ولی زحمتت دیده شد.', null);
    } else if (CH.type === 'medicine') {
      el.style.display = 'block';
      const tgt = CH.picked ? CH.home : CH.hos;
      el.textContent = (CH.picked ? '💊 دارو دستته! بدو آپارتمان گلستان' : '💊 اول برو بیمارستان') + ' — ⏱ ' + fa(left);
      CH.ring.position.set(tgt.x, .4, tgt.z + tgt.d/2 + 4);
      if (Math.hypot(player.position.x - tgt.x, player.position.z - (tgt.z + tgt.d/2 + 4)) < 8) {
        if (!CH.picked) { CH.picked = true; sfx.money(); toast('💊 دارو رو گرفتی! سریع برسون!'); }
        else return chEnd(true, '💊 به‌موقع رسید! مریم پرستار نفس راحتی کشید: «حالش خوب شد. یه جون نجات دادی — می‌فهمی یعنی چی؟»', () => questReward('medicine'));
      }
      if (left === 0) chEnd(false, '💊 دیر رسیدی... خوشبختانه اورژانس رسید. دفعهٔ بعد سریع‌تر.', null);
    } else if (CH.type === 'thief') {
      el.style.display = 'block';
      const mk = CH.market, wx = mk.x, wz = mk.z + mk.d/2 + 5;
      if (!CH.thiefOut) {
        const near = Math.hypot(player.position.x - wx, player.position.z - wz) < 8;
        el.textContent = near ? '🕵️ کشیک... صبر کن ' + fa(Math.max(0, 8 - Math.floor((CH.watch || 0)))) + ' ثانیه' : '🕵️ برو تو حلقهٔ بنفش و کشیک بده';
        if (near) {
          CH.watch = (CH.watch || 0) + dt;
          if (CH.watch > 8) {
            CH.thiefOut = true;
            const th = chRunner(0x1f2430, mk.x, mk.z + mk.d/2 + 2);
            CH.thief = th; CH.wp = new THREE.Vector3(mk.x + 70, 0, mk.z + 50);
            sfx.alert();
            if (typeof sayFa === 'function') sayFa('آهای! وایسا ببینم!', 1.2, .8, 'm');
            toast('👤 اومد! داره فرار می‌کنه — دنبالش بدو!');
          }
        } else CH.watch = 0;
      } else {
        el.textContent = '🕵️ دنبالش بدو! ⏱ ' + fa(left);
        const th = CH.thief;
        if (th.position.distanceTo(CH.wp) < 4) CH.wp.set(player.position.x + (Math.random()-.5)*110, 0, player.position.z + (Math.random()-.5)*110);
        const dir = CH.wp.clone().sub(th.position).normalize();
        th.position.addScaledVector(dir, dt * 7.2);
        th.rotation.y = Math.atan2(dir.x, dir.z);
        const L = th.userData.limbs, tt = now * .012;
        L.legL.rotation.x = Math.sin(tt) * .7; L.legR.rotation.x = -Math.sin(tt) * .7;
        if (th.position.distanceTo(player.position) < 2.3)
          return chEnd(true, '🕵️ گرفتیش! یه پسر نوجوونِ گشنه بود... مش‌قاسم به‌جای شکایت، بهش کار داد تو دکون: «تو نه‌تنها دزد رو گرفتی، یه آدم رو نجات دادی.»', () => questReward('thief'));
      }
      if (left === 0) chEnd(false, '🕵️ امشب نیومد (یا در رفت). مش‌قاسم: «باشه، یه شب دیگه کشیک می‌دیم.»', null);
    } else if (CH.type === 'power') {
      el.style.display = 'block';
      el.textContent = '⚡ ابزار ' + fa(CH.trips) + ' از ۳ — ' + (CH.carrying ? 'ببر تعمیرگاه!' : 'برو حلقهٔ زرد') + ' ⏱ ' + fa(left);
      const tgt = CH.carrying ? CH.dst : CH.src;
      CH.ring.position.set(tgt.x, .4, tgt.z + tgt.d/2 + 4);
      if (Math.hypot(player.position.x - tgt.x, player.position.z - (tgt.z + tgt.d/2 + 4)) < 8) {
        if (CH.carrying) { CH.trips++; CH.carrying = false; sfx.money(); toast('🔧 یه دست ابزار رسید! (' + fa(CH.trips) + ' از ۳)'); }
        else { CH.carrying = true; toast('🧰 ابزار برداشتی!'); }
        if (CH.trips >= 3) {
          lampBulbs.forEach(b => b.material.emissiveIntensity = 2.4);
          lampLights.forEach(l => { if (G.hour >= 19 || G.hour < 6) l.intensity = 22; });
          return chEnd(true, '⚡💡 ژنراتور روشن شد و برقِ کل محله برگشت! صدای دست‌زدن و سوت مردم از پنجره‌ها بلند شد. رضا: «اون صدا مالِ توئه داداش!»', () => questReward('power'));
        }
      }
      if (left === 0) chEnd(false, '⚡ نشد امشب... با شمع می‌سازیم، فردا دوباره.', null);
    } else if (CH.type === 'robotics') {
      el.style.display = 'block';
      el.textContent = '🤖 برو آکادمی نوین‌ذهن — ⏱ ' + fa(left);
      const t2 = CH.target;
      CH.ring.rotation.z = now * .002;
      if (Math.hypot(player.position.x - t2.x, player.position.z - (t2.z + t2.d/2 + 4)) < 9)
        return chEnd(true, '🤖🏆 رسیدی! ' + (G.childName || 'بچه‌ت') + ' از رو سکو تو رو دید و کل صورتش روشن شد. رباتش دوم شد، ولی وقتی مدال رو گرفت اول از همه به تو نگاه کرد. این لحظه‌ها برنمی‌گرده.', () => questReward('robotics'));
      if (left === 0) chEnd(false, '🤖 نرسیدی... تو جمعیت دنبالت گشت. دفعهٔ بعد حتماً برو.', null);
    } else if (CH.type === 'delivery') {
      el.style.display = 'block';
      const st = CH.stops[CH.si];
      el.textContent = '🍕 سفارش ' + fa(CH.si + 1) + ' از ۳: ' + st.name + ' — ⏱ ' + fa(left);
      CH.ring.position.set(st.x, .4, st.z + st.d / 2 + 4);
      CH.ring.rotation.z = now * .002;
      if (Math.hypot(player.position.x - st.x, player.position.z - (st.z + st.d / 2 + 4)) < 8) {
        CH.si++; sfx.money();
        if (CH.si >= 3) {
          chEnd(true, '🍕 هر سه سفارش گرم رسید! اصغر از ته دل خندید: «داداش تو از من پیک‌تری! این انعام‌ها هم مال خودت!» 🤝', () => {
            addMoney(4000000); G.happy += 10; addHonor(3);
            addLog('🍕 سفارش‌های اصغر رو رسوندی: +۴ میلیون');
          });
          return;
        }
        toast('✅ تحویل شد! بعدی: ' + CH.stops[CH.si].name);
      }
      if (left === 0) chEnd(false, '⏱ سفارش‌ها سرد شد... اصغر: «فدای سرت! منم روز اول همین بودم.»', null);
    }
  }
  W.challengeActive = () => !!CH;
  W.challengeAbort = () => {
    if (!CH) return;
    (CH.meshes || []).forEach(m => scene.remove(m));
    CH = null; G.challenge = null;
    chTimerEl().style.display = 'none';
  };
  W.challengeShoot = chShoot;
  W.challengeCatch = () => {
    if (CH && CH.type === 'cat' && CH.cat && player.position.distanceTo(new THREE.Vector3(CH.catPos.x, player.position.y, CH.catPos.z)) < 4) {
      chEnd(true, '🐱 پریدی و پشمک رو گرفتی! میومیوکنان تو بغلت لم داد. ننه‌قمر یه قابلمه آش داغ داد دستت: «نوش جونت مادر!»', () => {
        G.health += 20; G.happy += 10; addHonor(3);
        addLog('🐱 پشمک نجات پیدا کرد! آش ننه‌قمر: +۲۰ سلامتی');
      });
      return true;
    }
    return false;
  };
  // پیدا شدن هومن موقع ورود به گیم‌نت
  const _enterInterior2 = W.enterInterior;
  W.enterInterior = id => {
    _enterInterior2(id);
    if (id === 'gamenet' && G.challenge?.type === 'lostkid' && (G.challenge.asked || 0) >= 2) G.challenge.found = true;
  };

  // عوض کردن لباس → کاراکتر از نو ساخته میشه
  W.refreshOutfit = () => {
    const pos = player.position.clone(), rot = player.rotation.y, vis = player.visible, sc = player.scale.clone();
    scene.remove(player);
    player = buildPlayerMesh();
    player.position.copy(pos); player.rotation.y = rot; player.visible = vis; player.scale.copy(sc);
    scene.add(player);
  };
  W.refreshHome = () => {
    if (INT.isInside() && INT.id() === 'home') { const id = INT.id(); INT.exit(); INT.enter(id); snapCamera(); }
  };

  // 🎨 کیفیت گرافیک
  W.applyQuality = q => {
    const px = q === 'low' ? .75 : q === 'mid' ? 1 : Math.min(devicePixelRatio, 1.5);
    renderer.setPixelRatio(px);
    renderer.shadowMap.enabled = q !== 'low';
    sun.castShadow = q !== 'low';
    scene.fog.near = q === 'low' ? 45 : 70;
    scene.fog.far = q === 'low' ? 150 : q === 'mid' ? 240 : 300;
    camera.far = q === 'low' ? 220 : q === 'mid' ? 400 : 700;
    camera.updateProjectionMatrix();
    if (q === 'low') precip.visible = false;
    // ساختمون‌های دور در کیفیت پایین مخفی بشن
    farCull = q === 'low' ? 150 : q === 'mid' ? 240 : 0;
    if (cine) cine.setMode(q);
  };
  // ⚡ کالینگ فاصله‌ای: چیزهای دور رندر نشن
  function updateCulling() {
    if (!farCull) { cullables.forEach(o => o.visible = true); return; }
    const px = player.position.x, pz = player.position.z;
    for (const o of cullables) {
      const d = Math.hypot(o.position.x - px, o.position.z - pz);
      o.visible = d < farCull;
    }
  }
  // 🐾 حیوون خونگی دنبالت میاد (سگ)
  var petMesh = null;   // var: چون updatePet زودتر از تعریف صدا زده میشه
  W.spawnPet = () => {
    if (petMesh) { scene.remove(petMesh); petMesh = null; }
    if (!G.pet || G.pet.type === 'bird') return;
    const g = new THREE.Group();
    const col = G.pet.type === 'dog' ? 0xa9754f : 0x777777;
    const bd = new THREE.Mesh(new THREE.CapsuleGeometry(.26, .6, 4, 8), mat(col)); bd.rotation.z = Math.PI/2; bd.position.y = .45;
    const hd = new THREE.Mesh(new THREE.SphereGeometry(.24, 9, 8), mat(col)); hd.position.set(.48, .65, 0);
    const tl = new THREE.Mesh(new THREE.CylinderGeometry(.05, .02, .42), mat(col)); tl.position.set(-.52, .65, 0); tl.rotation.z = -.7;
    g.add(bd, hd, tl);
    g.position.copy(player.position);
    scene.add(g); petMesh = g;
    const lbl = makeLabel3D((G.pet.type === 'dog' ? '🐕 ' : '🐱 ') + G.pet.name);
    lbl.position.y = 1.6; lbl.scale.set(4, 1, 1);
    g.add(lbl);
  };
  if (G.pet) setTimeout(() => W.spawnPet(), 500);
  function updatePet(dt, now) {
    if (!petMesh || INT.isInside()) { if (petMesh) petMesh.visible = !INT.isInside(); return; }
    petMesh.visible = true;
    const d = petMesh.position.distanceTo(player.position);
    if (d > 2.5) {
      const dir = player.position.clone().sub(petMesh.position).normalize();
      petMesh.position.addScaledVector(dir, dt * Math.min(7, d * 1.6));
      petMesh.rotation.y = Math.atan2(dir.x, dir.z);
      petMesh.position.y = Math.abs(Math.sin(now * .012)) * .12;
    } else petMesh.position.y = 0;
  }

  W.destroy = () => {
    running = false;
    removeEventListener('keydown', keydown);
    removeEventListener('keyup', keyup);
    removeEventListener('resize', onResize);
    renderer.dispose();
    canvas.remove();
    const film = document.getElementById('cineFilm');
    if (film) film.remove();
  };
  return W;
}
