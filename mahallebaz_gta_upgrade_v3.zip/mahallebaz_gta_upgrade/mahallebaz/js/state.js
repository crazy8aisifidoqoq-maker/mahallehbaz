// ===== state.js — وضعیت بازی، تقویم شمسی، سیو/لود =====
'use strict';

const FA_MONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
const FA_DAYS_IN_MONTH = [31,31,31,31,31,31,30,30,30,30,30,29];
const fa = n => Math.round(n).toLocaleString('fa-IR');
const faDigits = n => String(Math.round(n)).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const faMoney = n => fa(n) + ' تومن';

function defaultGameState() {
  return {
    mode: '3d',
    dayIndex: 0,          // روز از ۱ فروردین ۱۴۰۵
    hour: 8, minute: 0,
    money: 40000000,
    health: 90, energy: 90, happy: 70,
    job: null, workedToday: false, missedWork: 0,
    education: false, studying: 0, robotics: 0,
    phone: null, phoneBroken: false,
    clothesLevel: 0,
    homeOwned: false, rentPaidDay: 0,
    cars: [], activeCar: null, fuel: 0, damage: 0,
    bank: { deposit: 0, loan: 0 },
    married: null, childName: null, childProgress: 0,
    affection: {},
    upset: {},
    dates: {},
    met: {}, knownJobs: {},
    flowers: 0, sweets: 0,
    passport: false,
    honor: 50,             // شرافت (۰ تا ۱۰۰)
    traveling: null,
    weather: 'sunny',
    trafficJam: false, internetDown: false, powerOut: false, roadClosed: false,
    eco: {
      dollar: 98500,
      benzin: 15000,
      inflation: 42,       // درصد سالانه
      housingCoef: 1.0,
      carCoef: 1.0,
    },
    px: -120, pz: -111,    // موقعیت بازیکن (دم خونه)
    stats: { daysPlayed: 0, totalEarned: 0 },
  };
}

let G = defaultGameState();
window.G = G;   // دسترسی دیباگ/تست

// ---- تقویم شمسی (شمارش از ۱ فروردین ۱۴۰۵) ----
function shamsiDate(dayIndex) {
  let year = 1405, d = dayIndex;
  for (;;) {
    const yearLen = 365; // ساده: ۱۴۰۵ غیرکبیسه
    if (d < yearLen) break;
    d -= yearLen; year++;
  }
  let m = 0;
  while (d >= FA_DAYS_IN_MONTH[m]) { d -= FA_DAYS_IN_MONTH[m]; m++; }
  return { year, month: m, day: d + 1 };
}
function shamsiStr(dayIndex) {
  const s = shamsiDate(dayIndex);
  return faDigits(s.day) + ' ' + FA_MONTHS[s.month] + ' ' + faDigits(s.year);
}
const WEEKDAYS = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];
function weekdayStr(dayIndex) { return WEEKDAYS[dayIndex % 7]; }
function isFriday(dayIndex) { return dayIndex % 7 === 6; }

// ---- سیو/لود ۳ اسلات ----
const SLOT_PREFIX = 'tehran1405-slot-';
const safeStore = (() => {
  try { localStorage.getItem('x'); return localStorage; }
  catch { const m = {}; return { getItem: k => m[k] ?? null, setItem: (k,v) => m[k]=v, removeItem: k => delete m[k] }; }
})();

function saveToSlot(slot) {
  const data = { ...G, savedAt: shamsiStr(G.dayIndex), traveling: null };
  safeStore.setItem(SLOT_PREFIX + slot, JSON.stringify(data));
}
function slotInfo(slot) {
  try {
    const d = JSON.parse(safeStore.getItem(SLOT_PREFIX + slot));
    if (!d) return null;
    return { date: d.savedAt, money: d.money, mode: d.mode, job: d.job, dayIndex: d.dayIndex || 0 };
  } catch { return null; }
}
function loadFromSlot(slot) {
  try {
    const d = JSON.parse(safeStore.getItem(SLOT_PREFIX + slot));
    if (!d) return false;
    G = Object.assign(defaultGameState(), d);
    G.traveling = null;
    return true;
  } catch { return false; }
}
function deleteSlot(slot) { safeStore.removeItem(SLOT_PREFIX + slot); }

// تازه‌ترین اسلات پرشده (برای دکمهٔ «ادامهٔ آخرین بازی»)
function latestSlot() {
  let best = null, bestDay = -1;
  for (let i = 1; i <= 3; i++) {
    const info = slotInfo(i);
    if (info && info.dayIndex >= bestDay) { bestDay = info.dayIndex; best = i; }
  }
  return best;
}

// ---- ابزار stats ----
function clampStats() {
  G.health = Math.max(0, Math.min(100, G.health));
  G.energy = Math.max(0, Math.min(100, G.energy));
  G.happy  = Math.max(0, Math.min(100, G.happy));
  G.money  = Math.max(0, Math.round(G.money));
}
function addMoney(n) { G.money += n; if (n > 0) G.stats.totalEarned += n; clampStats(); }
