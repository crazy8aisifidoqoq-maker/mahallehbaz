// ===== rp-life.js — خانه و مبلمان، پوشیدنی‌ها، رفاقت مردانه =====
'use strict';

/* ---------------------------------------------------------------
   🏠 خانه: خرید مبلمان + ارتقا + مهمونی
--------------------------------------------------------------- */
const FURNITURE = {
  sofa:    { icon:'🛋️', name:'مبل راحتی',      price: 12000000, comfort: 8,  desc:'شب‌ها خواب بهتر، صبح‌ها انرژی بیشتر' },
  tv:      { icon:'📺', name:'تلویزیون بزرگ',  price: 18000000, happy: 10, desc:'شب‌نشینی و فوتبال' },
  carpet:  { icon:'🟥', name:'فرش دستباف',     price: 25000000, comfort: 6, happy: 6, desc:'گرمای خونهٔ ایرانی' },
  plant:   { icon:'🪴', name:'گلدون بزرگ',     price: 3000000,  happy: 4,  desc:'خونه جون می‌گیره' },
  fridge:  { icon:'🧊', name:'یخچال جدید',     price: 22000000, comfort: 5, desc:'خوراکی‌ها خراب نمیشن' },
  bed:     { icon:'🛏️', name:'تخت‌خواب دونفره', price: 16000000, comfort: 12, desc:'خواب عمیق‌تر' },
  desk:    { icon:'🪑', name:'میز کار',         price: 8000000,  desc:'برای دورکاری و درس' },
  lamp:    { icon:'💡', name:'چراغ مطالعه',     price: 2000000,  happy: 3,  desc:'نور گرم شبانه' },
};
function hasFurniture(k) { return !!(G.home && G.home.items && G.home.items[k]); }
function homeComfort() {
  let c = 0;
  Object.keys((G.home && G.home.items) || {}).forEach(k => { c += FURNITURE[k]?.comfort || 0; });
  return c + (G.home?.level || 0) * 10;
}
function openHome() {
  G.home = G.home || { items: {}, level: 0 };
  openPanel('🏠 خونهٔ من', p => {
    noteP(p, 'راحتی خونه: ' + fa(homeComfort()) + ' | سطح خونه: ' + fa(G.home.level + 1) +
      ' — خونهٔ راحت‌تر یعنی خواب بهتر و انرژی بیشتر.');
    // خواب
    actionRow(p, '🛏️ خوابیدن تا صبح', 'انرژی +' + fa(60 + homeComfort()) + ' | سلامتی +' + fa(5 + Math.floor(homeComfort()/4)), () => {
      const gain = 60 + homeComfort();
      G.energy = Math.min(100, G.energy + gain);
      G.health = Math.min(100, G.health + 5 + Math.floor(homeComfort()/4));
      const toMorning = (24 - G.hour + 7) % 24 || 24;
      for (let i = 0; i < toMorning; i++) { G.hour = (G.hour + 1) % 24; if (G.hour === 0) runDailyTick(); }
      journal('😴 خوابیدم و صبح سرحال بیدار شدم.');
      toast('🌅 صبح بخیر! سرحال شدی.');
      updateHUD(); closePanel();
    });
    // ارتقای خونه
    const upPrice = Math.round((80000000 * (G.home.level + 1)) * G.eco.housingCoef);
    if (G.home.level < 3) {
      actionRow(p, '⬆️ ارتقای خونه به سطح ' + fa(G.home.level + 2), faMoney(upPrice) + ' | +۱۰ راحتی دائمی', () => {
        if (G.money < upPrice) { toast('💸 پولش رو نداری! پس‌انداز کن.'); return; }
        addMoney(-upPrice); G.home.level++; G.happy += 15;
        journal('🏠 خونه‌م رو یه پله بردم بالا! (سطح ' + fa(G.home.level + 1) + ')');
        showBanner('🏠 خونه‌ت ارتقا پیدا کرد! حالا جادارتر و راحت‌تره.', 5000);
        updateHUD(); openHome();
      });
    }
    // مهمونی
    const friends = NPCS.filter(n => !n.kid && getAffection(n.id) >= 35 && !isUpset(n.id));
    actionRow(p, '🎉 دعوت دوستان به شام', friends.length
      ? faMoney(6000000) + ' | ' + fa(friends.length) + ' نفر میان — علاقهٔ همه +۸' : '⛔ هنوز دوست صمیمی نداری (علاقه ۳۵+)',
      () => {
        if (!friends.length) { toast('👥 اول با اهالی رفیق شو!'); return; }
        if (G.money < 6000000) { toast('💸 خرج شام رو نداری!'); return; }
        addMoney(-6000000);
        friends.forEach(n => addAffection(n.id, 8));
        G.happy += 25; G.energy -= 10;
        for (let i = 0; i < 4; i++) { G.hour = (G.hour + 1) % 24; if (G.hour === 0) runDailyTick(); }
        sfx.party();
        showBanner('🎉 مهمونی ترکوند! ' + friends.map(n => n.name.split(' (')[0]).slice(0,4).join('، ') + ' تا نصفه‌شب موندن!', 7000);
        journal('🎉 دوستام رو دعوت کردم خونه؛ شام و خنده تا نصفه‌شب.');
        updateHUD(); closePanel();
      }, !friends.length);
    // خرید مبلمان
    const h = document.createElement('h4'); h.textContent = '🛋️ مبلمان و وسایل خونه'; p.appendChild(h);
    Object.entries(FURNITURE).forEach(([k, f]) => {
      const owned = hasFurniture(k);
      const price = Math.round(f.price * G.eco.housingCoef * (typeof honorPriceFactor === 'function' ? honorPriceFactor() : 1));
      actionRow(p, f.icon + ' ' + f.name + (owned ? ' ✅' : ''),
        owned ? 'داری — ' + f.desc : faMoney(price) + ' | ' + f.desc,
        () => {
          if (G.money < price) { toast('💸 پولت کم داری!'); return; }
          addMoney(-price);
          G.home.items = G.home.items || {};
          G.home.items[k] = true;
          if (f.happy) G.happy += f.happy;
          journal('🛋️ برای خونه ' + f.name + ' خریدم.');
          toast(f.icon + ' ' + f.name + ' اومد تو خونه!');
          window.WORLD?.refreshHome?.();
          updateHUD(); openHome();
        }, owned);
    });
  });
}

/* ---------------------------------------------------------------
   👕 پوشیدنی‌ها — روی کاراکتر دیده میشن
--------------------------------------------------------------- */
const WEARABLES = {
  shirt: {
    label: '👕 پیراهن',
    opts: {
      basic:  { name:'پیراهن ساده',    price: 0,        color: 0xe63946 },
      blue:   { name:'پیراهن آبی',     price: 2500000,  color: 0x1d3557 },
      green:  { name:'پیراهن سبز',     price: 2500000,  color: 0x2a9d8f },
      formal: { name:'کت‌وشلوار رسمی', price: 12000000, color: 0x22232b, classy: 3 },
      white:  { name:'پیراهن سفید',    price: 3500000,  color: 0xf1faee, classy: 1 },
    },
  },
  pants: {
    label: '👖 شلوار',
    opts: {
      basic: { name:'شلوار معمولی', price: 0,       color: 0x333355 },
      jean:  { name:'جین آبی',      price: 3200000, color: 0x2c4a72 },
      black: { name:'پارچه‌ای مشکی', price: 4200000, color: 0x1a1a20, classy: 2 },
      beige: { name:'کتان بژ',      price: 3800000, color: 0xc2b280 },
    },
  },
  hat: {
    label: '🧢 کلاه',
    opts: {
      none:  { name:'بدون کلاه',    price: 0,       style: 'hair' },
      cap:   { name:'کلاه نقاب‌دار', price: 1200000, style: 'cap', color: 0x1d3557 },
      fedora:{ name:'کلاه شاپو',    price: 2800000, style: 'cap', color: 0x4a3b2e, classy: 2 },
      helmet:{ name:'کلاه‌ایمنی',   price: 900000,  style: 'helmet', color: 0xffd166 },
    },
  },
  shoes: {
    label: '👟 کفش',
    opts: {
      basic:   { name:'کفش معمولی', price: 0,       color: 0x1a1a1a },
      sneaker: { name:'کتونی سفید', price: 3800000, color: 0xf1faee },
      leather: { name:'چرم مجلسی',  price: 5200000, color: 0x3b2314, classy: 2 },
      sport:   { name:'کتونی ورزشی', price: 4200000, color: 0xe63946 },
    },
  },
};
function ensureOutfit() {
  G.outfit = G.outfit || { shirt: 'basic', pants: 'basic', hat: 'cap', shoes: 'basic' };
  G.wardrobe = G.wardrobe || { shirt: { basic: 1 }, pants: { basic: 1 }, hat: { cap: 1 }, shoes: { basic: 1 } };
  return G.outfit;
}
function outfitClass() {
  ensureOutfit();
  let c = 0;
  Object.entries(G.outfit).forEach(([slot, key]) => { c += WEARABLES[slot]?.opts[key]?.classy || 0; });
  return c;   // تیپ بهتر = برخورد بهتر
}
function openWardrobe() {
  ensureOutfit();
  openPanel('👔 کمد لباس', p => {
    noteP(p, 'لباست روی خودت دیده میشه! تیپ بهتر یعنی برخورد بهتر مردم. (امتیاز تیپ: ' + fa(outfitClass()) + ')');
    Object.entries(WEARABLES).forEach(([slot, def]) => {
      const h = document.createElement('h4'); h.textContent = def.label; p.appendChild(h);
      Object.entries(def.opts).forEach(([key, o]) => {
        const owned = !!(G.wardrobe[slot] && G.wardrobe[slot][key]);
        const worn = G.outfit[slot] === key;
        const price = Math.round(o.price * (typeof honorPriceFactor === 'function' ? honorPriceFactor() : 1));
        actionRow(p, (worn ? '✅ ' : '') + o.name + (o.classy ? ' ⭐'.repeat(o.classy) : ''),
          worn ? 'الان تنته' : owned ? 'داری — بپوش' : faMoney(price),
          () => {
            if (!owned) {
              if (G.money < price) { toast('💸 پولش رو نداری!'); return; }
              addMoney(-price);
              G.wardrobe[slot] = G.wardrobe[slot] || {};
              G.wardrobe[slot][key] = 1;
              journal('👕 ' + o.name + ' خریدم.');
            }
            G.outfit[slot] = key;
            G.happy += 3;
            window.WORLD?.refreshOutfit?.();
            toast('👔 ' + o.name + ' پوشیدی!');
            updateHUD(); openWardrobe();
          }, worn);
      });
    });
  });
}

/* ---------------------------------------------------------------
   🤝 رفاقت مردانه — رفیق صمیمی، قرض، دعوا و آشتی
--------------------------------------------------------------- */
const BRO_ACTS = [
  { id:'tea',   icon:'🍵', name:'چایی و گپ',        cost: 300000,  aff: 4, happy: 4, txt:'یه چایی زدید و کلی حرف زدید.' },
  { id:'foot',  icon:'⚽', name:'فوتبال تو زمین خاکی', cost: 0,     aff: 6, happy: 8, energy: -12, txt:'یه بازی جانانه! عرق ریختید و خندیدید.' },
  { id:'kabab', icon:'🍢', name:'کباب مهمونش کن',   cost: 4500000, aff: 10, happy: 10, txt:'کباب زدید؛ گفت این محبتت یادم می‌مونه!' },
  { id:'help',  icon:'🛠️', name:'کمک تو کارش',      cost: 0,      aff: 8, energy: -15, txt:'یه دستی به کارش رسوندی؛ خیلی ممنون شد.' },
];
function broLevel(id) {
  const a = getAffection(id);
  return a >= 80 ? 'رفیق گرمابه و گلستان' : a >= 55 ? 'رفیق صمیمی' : a >= 30 ? 'دوست' : a >= 10 ? 'آشنا' : 'همسایه';
}
function buildBroMenu(t, npc) {
  t.group('🤝 رفاقت — ' + broLevel(npc.id));
  BRO_ACTS.forEach(a => {
    const done = usedToday(npc.id, 'bro_' + a.id);
    t.option(a.icon + ' ' + a.name, done ? '✅ امروز انجام شد' : (a.cost ? faMoney(a.cost) + ' | ' : '') + '+' + fa(a.aff) + ' رفاقت', () => {
      if (a.cost && G.money < a.cost) { talkSay('شرمنده داداش، پول ندارم فعلاً...', 'sad'); return; }
      useToday(npc.id, 'bro_' + a.id);
      if (a.cost) addMoney(-a.cost);
      addAffection(npc.id, a.aff);
      if (a.happy) G.happy += a.happy;
      if (a.energy) G.energy += a.energy;
      rememberNPC(npc.id, 'با هم ' + a.name + ' داشتیم');
      journal('🤝 با ' + npc.name.split(' (')[0] + ': ' + a.name);
      t.say(a.txt, 'happy');
      updateHUD(); setTimeout(t.refresh, 1600);
    }, done);
  });
  // قرض دادن و گرفتن — اعتماد
  G.debts = G.debts || {};
  const debt = G.debts[npc.id] || 0;
  if (debt > 0) {
    t.option('💵 «بدهیت رو یادت هست؟»', 'ازت ' + faMoney(debt) + ' طلب داری', () => {
      if (Math.random() < .6 + getAffection(npc.id) / 250) {
        addMoney(debt); delete G.debts[npc.id];
        addAffection(npc.id, 5);
        t.say('آره داداش! بیا اینم پولت. مرد و قولش! ممنون که کمکم کردی.', 'happy');
        journal('💵 ' + npc.name.split(' (')[0] + ' بدهیش رو پس داد.');
      } else t.say('آخ... این ماه سخت گذشت. هفتهٔ دیگه حتماً می‌دم، به مولا!', 'sad');
      updateHUD(); setTimeout(t.refresh, 1800);
    });
  } else if (getAffection(npc.id) >= 40) {
    t.option('💵 «پول لازم داری؟»', 'قرض ۵ میلیون — اعتماد و رفاقت زیاد میشه', () => {
      if (G.money < 5000000) { talkSay('کاش داشتم بهت بدم...', 'sad'); return; }
      addMoney(-5000000);
      G.debts[npc.id] = 5000000;
      addAffection(npc.id, 12);
      rememberNPC(npc.id, 'تو روز سختی بهم قرض دادی');
      journal('💵 به ' + npc.name.split(' (')[0] + ' ۵ میلیون قرض دادم.');
      t.say('داداش... همین که پرسیدی یعنی رفیقمی. جبران می‌کنم!', 'happy');
      updateHUD(); setTimeout(t.refresh, 1800);
    });
  }
  // دعوا و آشتی
  if (isUpset(npc.id)) {
    t.option('🤗 «داداش بیا آشتی کنیم»', bagCount('sweet') ? 'با جعبه شیرینی' : 'بدون شیرینی سخته!', () => {
      if (bagCount('sweet')) {
        bagTake('sweet');
        delete G.upset[npc.id];
        addAffection(npc.id, 10);
        t.say('ای بابا! شیرینی هم که آوردی... باشه، گذشت. بیا بغلم!', 'happy');
        journal('🤗 با ' + npc.name.split(' (')[0] + ' آشتی کردم.');
      } else t.say('فعلاً دلخورم... یه جعبه شیرینی بیار شاید نرم شدم!', 'angry');
      updateHUD(); setTimeout(t.refresh, 1800);
    });
  } else if (getAffection(npc.id) >= 20) {
    t.option('😠 «سرِ حرفت وایسا!» (دعوا)', 'ریسک داره! رفاقت خراب میشه', () => {
      addAffection(npc.id, -18);
      G.upset = G.upset || {}; G.upset[npc.id] = G.dayIndex + 2;
      G.happy -= 6;
      rememberNPC(npc.id, 'یه بار بد باهام حرف زدی');
      journal('😠 با ' + npc.name.split(' (')[0] + ' دعوام شد.');
      t.say('چی گفتی؟! باشه... فعلاً حرف نزنیم بهتره.', 'angry');
      updateHUD(); setTimeout(closeTalk, 2200);
    });
  }
}
