// ===== god-mode.js — کنترل زندهٔ دنیای بازی برای سازنده =====
'use strict';
(function () {
  const KEY = 'tehran1405_god_config_v1';
  const defaults = { npcPercent:100, trafficCount:6, extraHomes:8, quality:'high', playerLook:{} };
  try { window.GOD_CONFIG = Object.assign({}, defaults, JSON.parse(localStorage.getItem(KEY) || '{}')); }
  catch { window.GOD_CONFIG = Object.assign({}, defaults); }

  const row = (label, control) => {
    const r = document.createElement('label'); r.className = 'godRow';
    const t = document.createElement('span'); t.textContent = label;
    r.append(t, control); return r;
  };
  const range = (key, min, max, step, suffix) => {
    const wrap = document.createElement('div'); wrap.className = 'godRange';
    const value = document.createElement('b');
    const input = document.createElement('input'); input.type='range'; input.min=min; input.max=max; input.step=step;
    input.value=window.GOD_CONFIG[key];
    const sync=()=>value.textContent=input.value+(suffix||''); sync(); input.oninput=sync;
    input.dataset.key=key; wrap.append(input,value); return wrap;
  };
  function openGodMode() {
    document.getElementById('godModeWrap')?.remove();
    const wrap=document.createElement('div'); wrap.id='godModeWrap';
    wrap.innerHTML='<div class="godCard"><header><div><small>TEHRAN 1405</small><h2>⚡ GOD MODE</h2></div><button class="godClose">✕</button></header><p class="godLead">دنیا را همان لحظه‌ای که می‌سازی تنظیم کن.</p><div class="godControls"></div><div class="godActions"></div></div>';
    const controls=wrap.querySelector('.godControls');
    controls.append(row('جمعیت NPCها',range('npcPercent',10,100,10,'٪')),
      row('ترافیک هم‌زمان',range('trafficCount',0,14,1,'')),
      row('خانه‌های تزئینی',range('extraHomes',0,24,2,'')));
    const hat=document.createElement('select'); hat.dataset.look='hat';
    [['cap','کلاه کپ'],['none','بدون کلاه'],['helmet','کلاه ایمنی']].forEach(([v,n])=>hat.add(new Option(n,v)));
    hat.value=window.GOD_CONFIG.playerLook?.accessory?.hat || 'cap'; controls.append(row('پوشش سر بازیکن',hat));
    const jacket=document.createElement('input'); jacket.type='color'; jacket.dataset.look='jacket';
    jacket.value='#'+((window.GOD_CONFIG.playerLook?.outfit?.jacket ?? 0xb32632).toString(16).padStart(6,'0'));
    controls.append(row('رنگ کاپشن بازیکن',jacket));
    const actions=wrap.querySelector('.godActions');
    const boost=document.createElement('button'); boost.textContent='💰 منابع نامحدود';
    boost.onclick=()=>{ G.money=999999999999; G.energy=G.health=G.happy=100; G.food=G.fuel=999; updateHUD(); toast('⚡ منابع کامل شد!'); };
    const apply=document.createElement('button'); apply.className='godApply'; apply.textContent='اعمال و بازسازی دنیا';
    apply.onclick=()=>{
      wrap.querySelectorAll('[data-key]').forEach(i=>window.GOD_CONFIG[i.dataset.key]=Number(i.value));
      window.GOD_CONFIG.playerLook={ accessory:{hat}, outfit:{jacket:parseInt(jacket.value.slice(1),16)} };
      window.GOD_CONFIG.playerLook.accessory.hat=hat.value;
      localStorage.setItem(KEY,JSON.stringify(window.GOD_CONFIG));
      wrap.remove();
      if(gameStarted) launchGame(G.mode,true);
    };
    const reset=document.createElement('button'); reset.textContent='↺ تنظیمات اولیه';
    reset.onclick=()=>{localStorage.removeItem(KEY); window.GOD_CONFIG=Object.assign({},defaults); wrap.remove(); if(gameStarted) launchGame(G.mode,true);};
    actions.append(boost,reset,apply);
    wrap.querySelector('.godClose').onclick=()=>wrap.remove();
    wrap.onclick=e=>{if(e.target===wrap)wrap.remove();}; document.body.appendChild(wrap);
  }
  window.openGodMode=openGodMode;
  addEventListener('DOMContentLoaded',()=>document.getElementById('godBtn')?.addEventListener('click',openGodMode));
})();
