// ===== rp-onboard.js — راهنمای شروع، تنظیمات، بالانس اقتصاد =====
'use strict';

/* ---------------------------------------------------------------
   ⚙️ تنظیمات
--------------------------------------------------------------- */
function ensureSettings() {
  G.settings = Object.assign({
    sfx: true,          // افکت صوتی
    voice: true,        // صدای فارسی شخصیت‌ها
    music: true,        // موسیقی پس‌زمینه
    sensitivity: 45,    // حساسیت چرخش دوربین (۱۰ تا ۱۰۰)
    quality: 'high',    // کیفیت گرافیک
    hardMode: false,    // اقتصاد سخت‌گیرانه
    tips: true,         // راهنمای گوشه صفحه
  }, G.settings || {});
  return G.settings;
}
function openSettings() {
  ensureSettings();
  openPanel('⚙️ تنظیمات', p => {
    const toggle = (key, label, desc) => {
      actionRow(p, (G.settings[key] ? '✅ ' : '⬜ ') + label, desc, () => {
        G.settings[key] = !G.settings[key];
        if (key === 'music') { G.settings.music ? startMusic() : stopMusic(); }
        toast(label + ': ' + (G.settings[key] ? 'روشن' : 'خاموش'));
        openSettings();
      });
    };
    toggle('sfx', '🔊 افکت‌های صوتی', 'بوق، زنگ، جشن، قدم');
    toggle('voice', '🗣️ صدای شخصیت‌ها', 'خوندن دیالوگ‌ها با صدا');
    toggle('music', '🎵 موسیقی پس‌زمینه', 'ملودی آرام محله (شب و روز فرق داره)');
    actionRow(p, '🎤 تست صدای شخصیت‌ها', 'یه مرد، یه خانم و یه بچه حرف می‌زنن', () => {
      if (typeof pickFaVoice === 'function') pickFaVoice();
      sayFa('سلام! من یکی از مردهای محله‌م.', 1, .78, 'm');
      setTimeout(() => sayFa('سلام! من یکی از خانم‌های محله‌م.', 1.05, 1.4, 'f'), 2600);
      setTimeout(() => sayFa('سلام! من بچهٔ محله‌م!', 1.2, 1.85, 'k'), 5200);
      const vs = speechSynthesis.getVoices() || [];
      const faCount = vs.filter(v => v.lang?.startsWith('fa')).length;
      toast(faCount ? '🗣️ ' + fa(faCount) + ' صدای فارسی روی این دستگاه نصبه.'
                    : '⚠️ صدای فارسی نصب نیست — با صدای پیش‌فرض خونده میشه. (مرورگر Edge معمولاً فارسی داره)');
    });
    toggle('tips', '💡 راهنمای گوشهٔ صفحه', 'یادآوری کلیدها و کارهای روز');
    toggle('hardMode', '🔥 حالت سخت', 'خرج‌ها بیشتر، درآمد کمتر — برای بازیکن حرفه‌ای');

    const h = document.createElement('h4'); h.textContent = '🖱️ حساسیت چرخش دوربین'; p.appendChild(h);
    [['🐢 کم', 20], ['🚶 متوسط', 45], ['🏃 زیاد', 75], ['⚡ خیلی زیاد', 100]].forEach(([lb, v]) => {
      actionRow(p, (G.settings.sensitivity === v ? '✅ ' : '') + lb, 'حساسیت: ' + fa(v), () => {
        G.settings.sensitivity = v; toast('🖱️ حساسیت: ' + lb); openSettings();
      }, G.settings.sensitivity === v);
    });

    const h2 = document.createElement('h4'); h2.textContent = '🎨 کیفیت گرافیک'; p.appendChild(h2);
    [['🌟 بالا', 'high'], ['⚖️ متوسط', 'mid'], ['🔋 کم (موبایل ضعیف)', 'low']].forEach(([lb, v]) => {
      actionRow(p, (G.settings.quality === v ? '✅ ' : '') + lb, '', () => {
        G.settings.quality = v;
        window.WORLD?.applyQuality?.(v);
        toast('🎨 کیفیت: ' + lb); openSettings();
      }, G.settings.quality === v);
    });

    const h3 = document.createElement('h4'); h3.textContent = '📖 راهنما'; p.appendChild(h3);
    actionRow(p, '❓ دیدن دوبارهٔ راهنمای بازی', 'کلیدها و کارهای اصلی', () => { closePanel(); openHelpBook(); });
    actionRow(p, '🔁 اجرای دوبارهٔ آموزش اولیه', 'قدم‌به‌قدم از اول', () => { G.tutorial = null; closePanel(); startTutorial(); });
    const h4 = document.createElement('h4'); h4.textContent = '⚠️ خطرناک'; p.appendChild(h4);
    actionRow(p, '🗑️ پاک کردن همهٔ سیوها', 'برگشت به روز اول — برگشت‌ناپذیر!', () => {
      if (!G._confirmWipe) { G._confirmWipe = true; toast('⚠️ مطمئنی؟ یه بار دیگه بزن تا پاک شه!'); return; }
      for (let i = 1; i <= 3; i++) deleteSlot(i);
      toast('🗑️ همهٔ سیوها پاک شد.');
      G._confirmWipe = false;
      closePanel();
    });
  });
}

/* ---------------------------------------------------------------
   📖 راهنمای کامل
--------------------------------------------------------------- */
function openHelpBook() {
  openPanel('📖 راهنمای بازی', p => {
    const sec = (t, lines) => {
      const h = document.createElement('h4'); h.textContent = t; p.appendChild(h);
      lines.forEach(l => noteP(p, l));
    };
    sec(onTouch() ? '📱 کنترل لمسی' : '⌨️ کلیدها', onTouch() ? [
      '• جوی‌استیک گوشهٔ صفحه = راه رفتن | دکمهٔ 🏃 = دویدن',
      '• دکمهٔ E = تعامل/ورود/گفتگو | دکمهٔ F = سوار/پیاده شدن ماشین',
      '• کشیدن انگشت روی صفحه = چرخوندن دوربین',
      '• نوار بالای صفحه: نقشه، اخبار، مأموریت، کوله و منو',
    ] : [
      '• WASD یا جهت‌ها = راه رفتن (Shift = دویدن)',
      '• Space = پریدن | E = تعامل/ورود/گفتگو | F = سوار/پیاده شدن ماشین',
      '• کلیک نگه‌داشته + کشیدن = چرخوندن دوربین',
      '• M = نقشه | N = اخبار | Esc = منو | ` یا دوبار Tab = کنسول مخفی',
    ]);
    sec('🎯 هدف بازی', [
      '• کار کن، پول دربیار، خونه بساز، رفیق و عشق پیدا کن',
      '• هر ۳ روز یه مأموریت محله میاد — انجامش بده و نشان بگیر',
      '• ازدواج کن، بچه‌دار شو؛ بچه بزرگ میشه و بازی با نسل بعدی ادامه پیدا می‌کنه',
    ]);
    sec('💡 نکته‌های مهم', [
      '• هر روز با هر نفر: یک گپ + یک خاطره + سه گپ دونفره (با دخترها)',
      '• جواب بی‌ادب = دلخوری و اخراج از مغازه!',
      '• شرافت بالا = تخفیف تو همهٔ مغازه‌ها؛ شرافت پایین = گرون‌تر',
      '• انرژی که تموم شه، هرجا باشی خوابت می‌بره و می‌بَرنت خونه',
    ]);
    sec('🎒 چیزهایی که یادت نره', [
      '• 📋 مأموریت روزانه = پول راحت',
      '• 🎒 کوله = هدیه‌ها رو نگه دار برای وقتی که لازمه',
      '• 📔 خاطرات = تاریخچهٔ زندگیت خودکار نوشته میشه',
      '• 📱 گوشی = همه‌چیز یه‌جا (پیام، نقشه، نشان، کمد لباس)',
    ]);
  });
}

/* ---------------------------------------------------------------
   🎓 آموزش اولیه — قدم‌به‌قدم
--------------------------------------------------------------- */
/* روی گوشی، کلاس touch را main.js روی body می‌گذارد؛ راهنما باید همان چیزی را
   بگوید که بازیکن جلوی چشمش دارد — جوی‌استیک و دکمه‌ها، نه WASD و موس. */
const onTouch = () => document.body.classList.contains('touch');
const tip = (keyboard, touch) => () => (onTouch() ? touch : keyboard);

const TUTORIAL_STEPS = [
  { id:'move',   text: tip('🎮 با WASD راه برو (Shift = دویدن)',
                           '🎮 با جوی‌استیک گوشهٔ صفحه راه برو (دکمهٔ 🏃 = دویدن)'),
                 check: () => G._tutMoved },
  { id:'camera', text: tip('🖱️ کلیک کن و نگه‌دار، موس رو بکش تا دوربین بچرخه',
                           '🖐️ انگشتت رو روی صفحه بکش تا دوربین بچرخه'),
                 check: () => G._tutCam },
  { id:'enter',  text: tip('🚪 برو نزدیک یه ساختمون و E بزن تا بری داخل',
                           '🚪 برو نزدیک یه ساختمون و دکمهٔ E رو بزن تا بری داخل'),
                 check: () => window.WORLD?.insideOf?.() },
  { id:'talk',   text: tip('💬 با یه نفر حرف بزن (E روی آدم‌ها)',
                           '💬 برو کنار یه نفر و دکمهٔ E رو بزن تا حرف بزنی'),
                 check: () => Object.keys(G.met || {}).length > 0 },
  { id:'mission',text: tip('📋 دکمهٔ «مأموریت» رو بزن و کارهای امروز رو ببین',
                           '📋 دکمهٔ «مأموریت» رو بزن و کارهای امروز رو ببین'),
                 check: () => G._tutMission },
  { id:'job',    text: tip('🧰 یه شغل پیدا کن (تو مغازه‌ها گزینهٔ استخدام هست)',
                           '🧰 یه شغل پیدا کن (تو مغازه‌ها گزینهٔ استخدام هست)'),
                 check: () => !!G.job },
];
function tutorialBox() {
  let el = $id('tutBox');
  if (!el) {
    el = document.createElement('div');
    el.id = 'tutBox';
    el.style.cssText = 'position:fixed;bottom:190px;right:50%;transform:translateX(50%);z-index:58;' +
      'background:linear-gradient(135deg,rgba(106,76,147,.95),rgba(30,25,60,.95));color:#fff;' +
      'padding:11px 22px;border-radius:14px;font-size:14px;border:1px solid rgba(255,209,102,.5);' +
      'box-shadow:0 8px 30px rgba(0,0,0,.5);display:none;max-width:88vw;text-align:center';
    document.body.appendChild(el);
  }
  return el;
}
function startTutorial() {
  G.tutorial = { step: 0, done: false };
  showBanner('🎓 خوش اومدی به تهران ۱۴۰۵! چند قدم ساده یادت می‌دم، بعدش خودت میدون‌داری.', 6500);
  tickTutorial();
}
function tickTutorial() {
  if (!G.tutorial || G.tutorial.done || !gameStarted) { tutorialBox().style.display = 'none'; return; }
  const st = TUTORIAL_STEPS[G.tutorial.step];
  if (!st) {
    G.tutorial.done = true;
    tutorialBox().style.display = 'none';
    showBanner('🎓 آموزش تموم شد! حالا محله مال توئه. هر وقت گم شدی: Esc → راهنما', 6000);
    addMoney(3000000);
    toast('🎁 هدیهٔ شروع: ۳ میلیون تومن!');
    journal('🎓 آموزش بازی رو تموم کردم.');
    updateHUD();
    return;
  }
  const el = tutorialBox();
  el.style.display = 'block';
  el.innerHTML = '🎓 قدم ' + fa(G.tutorial.step + 1) + ' از ' + fa(TUTORIAL_STEPS.length) + ': ' +
    (typeof st.text === 'function' ? st.text() : st.text);
  if (st.check()) {
    G.tutorial.step++;
    sfx.money();
    toast('✅ آفرین! قدم بعدی...');
    setTimeout(tickTutorial, 900);
  } else setTimeout(tickTutorial, 900);
}

/* ---------------------------------------------------------------
   💰 بالانس اقتصاد — خرج‌های واقعی زندگی
--------------------------------------------------------------- */
function dailyExpenses() {
  const hard = G.settings?.hardMode;
  const mul = (hard ? 1.6 : 1) * (G.eco?.housingCoef || 1);
  let total = 0;
  const lines = [];
  // خوراک روزانه
  const food = Math.round(900000 * mul);
  total += food; lines.push('🍽️ خوراک روزانه: ' + faMoney(food));
  // اجاره (اگه خونه نخریدی)
  if (!G.homeOwned) {
    const rent = Math.round(2500000 * mul);
    total += rent; lines.push('🏠 اجارهٔ روزانه: ' + faMoney(rent));
  }
  // قبض‌ها هر ۵ روز
  if (G.dayIndex % 5 === 0 && G.dayIndex > 0) {
    const bill = Math.round(3500000 * mul);
    total += bill; lines.push('🧾 قبض برق و گاز: ' + faMoney(bill));
  }
  // ماشین: بنزین و استهلاک
  if ((G.cars || []).length) {
    const car = Math.round(1200000 * mul);
    total += car; lines.push('⛽ خرج ماشین: ' + faMoney(car));
  }
  // خانواده
  if (G.married) {
    const fam = Math.round((G.childName ? 3500000 : 2000000) * mul);
    total += fam; lines.push('👨‍👩‍👧 خرج خانواده: ' + faMoney(fam));
  }
  addMoney(-total);
  if (G.money < 0) {
    G.money = 0;
    G.happy -= 12;
    addLog('💸 پولت تموم شد! گشنگی و استرس... باید کار کنی.');
    toast('💸 ورشکست شدی! برو سر کار وگرنه اوضاع بدتر میشه.');
  }
  journal('💸 خرج امروز: ' + faMoney(total));
  addLog('💸 خرج امروز: ' + faMoney(total) + ' (' + lines.length + ' مورد)');
  return { total, lines };
}
function openExpenses() {
  openPanel('💸 هزینه‌های زندگی', p => {
    noteP(p, 'هر روز این‌ها از حسابت کم میشه — کار نکنی، ته می‌کشه!');
    const hard = G.settings?.hardMode;
    const mul = (hard ? 1.6 : 1) * (G.eco?.housingCoef || 1);
    noteP(p, '🍽️ خوراک روزانه: ' + faMoney(Math.round(900000 * mul)));
    if (!G.homeOwned) noteP(p, '🏠 اجاره روزانه: ' + faMoney(Math.round(2500000 * mul)) + ' (خونه بخری حذف میشه)');
    noteP(p, '🧾 قبض برق و گاز: ' + faMoney(Math.round(3500000 * mul)) + ' — هر ۵ روز');
    if ((G.cars || []).length) noteP(p, '⛽ خرج ماشین: ' + faMoney(Math.round(1200000 * mul)));
    if (G.married) noteP(p, '👨‍👩‍👧 خرج خانواده: ' + faMoney(Math.round((G.childName ? 3500000 : 2000000) * mul)));
    const h = document.createElement('h4'); h.textContent = '💡 راه‌های درآمد'; p.appendChild(h);
    noteP(p, '• شغل ثابت (روزی ۱ تا ۴.۵ میلیون) — مینی‌گیم درست بزنی ۲۵٪ بیشتر');
    noteP(p, '• مأموریت روزانه: ۳ کار × ۱.۵ میلیون');
    noteP(p, '• مأموریت‌های محله (هر ۳ روز): ۲ تا ۱۰ میلیون');
    noteP(p, '• سپردهٔ بانکی سود روزانه داره');
  });
}
