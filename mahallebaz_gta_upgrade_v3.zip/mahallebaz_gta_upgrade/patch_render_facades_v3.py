# -*- coding: utf-8 -*-
"""Render-style buildings v3:
- world3d.js: crossed X-planes with the alpha render + tinted plinth; invisible
  body stays for colliders/camera-blocker; no procedural roofs for photo buildings
- index.html: world3d -> v60
"""
import io
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz"
W3 = BASE + r"\js\world3d.js"
IX = BASE + r"\index.html"

fail = []
def sub1(s, old, new, tag):
    if s.count(old) != 1:
        fail.append("%s (count=%d)" % (tag, s.count(old)))
        return s
    print("OK  " + tag)
    return s.replace(old, new, 1)

s = open(W3, encoding="utf-8", newline="").read()

# 1) جایگزینی کامل بلوک فاساد با سیستم رندر ضربدری
i0 = s.find("// ===== نماهای عکس")
i1 = s.find("const WIN_GEO")
assert i0 >= 0 and i1 > i0, "facade block not found"

NEW_BLOCK = """// ===== ساختمان‌های رندری: رندر سه‌رخ روی دو صفحهٔ ضربدری + سکوی تیره =====
  const _facadeTex = {}, _facadeCbs = {};
  function facadeTex(url, cb) {
    if (!_facadeCbs[url]) {
      _facadeCbs[url] = [];
      _facadeTex[url] = new THREE.TextureLoader().load(url, t => {
        if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = 4;
        t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
        _measureFacadeAvg(url, t.image);
        for (const cb2 of _facadeCbs[url]) cb2(t);
      });
    }
    _facadeCbs[url].push(cb);
    return _facadeTex[url];
  }
  // میانگین رنگ رندر → سکوی زیر ساختمان هم‌رنگ خودش می‌شود
  const _facadeAvg = {}, _tintMats = {};
  function _measureFacadeAvg(url, img) {
    try {
      const c = document.createElement('canvas');
      c.width = c.height = 48;
      const x = c.getContext('2d', { willReadFrequently: true });
      x.drawImage(img, 0, 0, 48, 48);
      const d = x.getImageData(0, 0, 48, 48).data;
      let r = 0, g = 0, b = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) {
        if (d[i + 3] < 128) continue;
        r += d[i]; g += d[i + 1]; b += d[i + 2]; n++;
      }
      if (!n) return;
      const hex = (((r / n) << 16) | ((g / n) << 8) | (b / n)) & 0xffffff;
      _facadeAvg[url] = hex;
      for (const m of (_tintMats[url] || [])) m._setTint(hex);
    } catch (e) { /* ignore */ }
  }
  const _tintCache = {};
  function tintMat(hex) {
    if (_tintCache[hex]) return _tintCache[hex];
    const m = new THREE.MeshStandardMaterial({ color: hex, roughness: .9, metalness: 0 });
    m._setTint = h => m.color.setHex(h);
    _tintCache[hex] = m;
    return m;
  }
  function _shadeHex(hex, k) {
    const r = Math.min(255, ((hex >> 16 & 255) * k) | 0),
          g = Math.min(255, ((hex >> 8 & 255) * k) | 0),
          b = Math.min(255, ((hex & 255) * k) | 0);
    return ((r << 16) | (g << 8) | b) >>> 0;
  }
  const _renderNightMats = [];
  function buildRenderVisual(b, g, body) {
    body.visible = false;            // بدنهٔ توپر پنهان؛ فقط برای برخورد/دوربین می‌ماند
    body.castShadow = false;
    const hex0 = _facadeAvg[b.img] || b.color;
    const plinthH = Math.min(2.2, b.h * .3);
    const plinthMat = tintMat(_shadeHex(hex0, .5));
    (_tintMats[b.img] || (_tintMats[b.img] = [])).push(plinthMat);
    const plinth = new THREE.Mesh(
      new THREE.BoxGeometry(Math.min(b.w, 30), plinthH, Math.min(b.d, 30)), plinthMat);
    plinth.position.y = plinthH / 2;
    plinth.castShadow = plinth.receiveShadow = true;
    g.add(plinth);
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff, roughness: .8, metalness: 0,
      alphaTest: .45, side: THREE.DoubleSide,
      emissive: 0xffc46b, emissiveIntensity: 0,
    });
    _renderNightMats.push(mat);
    const geo = new THREE.PlaneGeometry(1, 1);
    const p1 = new THREE.Mesh(geo, mat), p2 = new THREE.Mesh(geo, mat);
    p1.rotation.y = Math.PI / 4;     // ضربدری: از هر زاویه حجم دارد
    p2.rotation.y = -Math.PI / 4;
    g.add(p1, p2);
    const fit = img => {
      const imgAR = img.width / img.height;
      const maxW = Math.max(b.w, b.d) * 1.4;
      const ph = Math.min(b.h * 1.22, maxW / imgAR);
      const pw = ph * imgAR;
      for (const p of [p1, p2]) {
        p.scale.set(pw, ph, 1);      // کشیدگی در فضای خودِ صفحه، نه بعد از چرخش
        p.position.y = ph / 2 + .05; // روی زمین می‌ایستد
      }
    };
    facadeTex(b.img, t => {
      mat.map = t; mat.emissiveMap = t; mat.needsUpdate = true;
      if (t.image && t.image.width) fit(t.image);
    });
  }
  function _applyPhotoFacadeNight(daylight) {
    const glow = Math.max(0, 1 - daylight * 2.2) * .55;   // پنجره‌ها شب روشن
    for (const m of _renderNightMats) m.emissiveIntensity = glow;
  }
  """
s = s[:i0] + NEW_BLOCK + s[i1:]

# 2) بدنه: همیشه متریال ساده + فراخوانی رندر ضربدری
s = sub1(s,
    "const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), b.img ? coverBoxMats(b) : wallMat(b.color, b.w, b.d, b.h));",
    "const body = new THREE.Mesh(new THREE.BoxGeometry(b.w, b.h, b.d), wallMat(b.color, b.w, b.d, b.h));",
    "body back to wallMat")

s = sub1(s,
    "      if (b.kind !== 'open') _camBlockers.push(body);",
    "      if (b.kind !== 'open') _camBlockers.push(body);\n      if (b.img) buildRenderVisual(b, g, body);   // رندر سه‌رخ جای بدنهٔ توپر",
    "buildRenderVisual call")

# 3) حذف گنبد اضافه‌شده در v2 (رندرها سقف خودشان را دارند)
s = sub1(s,
    "\n      if (_photoMode && b.kind === 'dome') {   // گنبد بالای نمای عکس\u200cدار حفظ شود\n        const dome2 = new THREE.Mesh(new THREE.SphereGeometry(Math.min(b.w, b.d)/2.4, 14, 10, 0, Math.PI*2, 0, Math.PI/2), mat(0xd4af37));\n        dome2.position.y = b.h; dome2.castShadow = true;\n        g.add(dome2);\n      }",
    "",
    "remove v2 dome block")

open(W3, "w", encoding="utf-8", newline="").write(s)

# 4) بومپ نسخه
s = open(IX, encoding="utf-8", newline="").read()
s = sub1(s, "js/world3d.js?v=59", "js/world3d.js?v=60", "bump world3d v60")
open(IX, "w", encoding="utf-8", newline="").write(s)

print("\n" + ("ALL PATCHES OK" if not fail else "FAILURES:\n  " + "\n  ".join(fail)))
sys.exit(1 if fail else 0)
