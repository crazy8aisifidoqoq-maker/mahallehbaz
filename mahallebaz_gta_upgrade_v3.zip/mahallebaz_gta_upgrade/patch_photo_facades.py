# -*- coding: utf-8 -*-
"""Attach real photo facades to BUILDINGS:
- world-data.js: add img/photoW/photoH fields per building id (line-wise, CRLF-safe)
- world3d.js: per-URL cached texture material, front+back planes per photo building,
  hide procedural windows/door/awning/roof for those buildings, night emissive glow
- index.html: bump world-data -> v55, world3d -> v58
"""
import io
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = r"C:\Users\USER\Downloads\mahallebaz_gta_upgrade\mahallebaz"
WD = BASE + r"\js\world-data.js"
W3 = BASE + r"\js\world3d.js"
IX = BASE + r"\index.html"

fail = []
def sub1(s, old, new, tag):
    if s.count(old) != 1:
        fail.append("%s (count=%d)" % (tag, s.count(old)))
        return s
    print("OK  " + tag)
    return s.replace(old, new, 1)

# ---------------- world-data.js ----------------
s = open(WD, encoding="utf-8", newline="").read()

IMG = {
    'home':       ("assets/buildings/home_red.png",        .99, 1.05),
    'mansion':    ("assets/buildings/classic.png",         .99, 1.0),
    'deco4':      ("assets/buildings/modern.png",          .99, .92),
    'deco1':      ("assets/buildings/apartment_brick.png", None, None),
    'apartment1': ("assets/buildings/apartment_glass.png", None, None),
    'deco5':      ("assets/buildings/tower_dark.png",      None, None),
    'dealership': ("assets/buildings/office_curved.png",   .98, .85),
    'deco3':      ("assets/buildings/cylinder_tower.png",  None, None),
}
lines = s.split("\r\n") if "\r\n" in s else s.split("\n")
sep = "\r\n" if "\r\n" in s else "\n"
hit = set()
for i, ln in enumerate(lines):
    m = re.search(r"id:'([A-Za-z0-9_]+)',", ln)
    if not m or m.group(1) not in IMG:
        continue
    bid = m.group(1)
    if "img:" in ln:
        continue
    url, pw, ph = IMG[bid]
    extra = " img:'%s'," % url
    if pw is not None:
        extra += " photoW:%s, photoH:%s," % (pw, ph)
    ln2, n = re.subn(r"(color:0x[0-9a-fA-F]+,)", lambda mm: mm.group(1) + extra, ln, count=1)
    if n != 1:
        fail.append("world-data %s: color anchor not found" % bid)
        continue
    lines[i] = ln2
    hit.add(bid)
missing = set(IMG) - hit
if missing:
    fail.append("world-data ids not found: %s" % sorted(missing))
s = sep.join(lines)
open(WD, "w", encoding="utf-8", newline="").write(s)
print("world-data: %d/%d ids tagged" % (len(hit), len(IMG)))

# ---------------- world3d.js ----------------
s = open(W3, encoding="utf-8", newline="").read()

# A) facade material cache + photo plane builder (before WIN_GEO)
INSERT_A = """  // ===== نماهای عکس‌دار واقعی (assets/buildings/*.png) =====
  const _facadeMat = {};
  function facadePlaneMat(url) {
    if (_facadeMat[url]) return _facadeMat[url];
    const tex = new THREE.TextureLoader().load(url, t => {
      if (t.colorSpace !== undefined && THREE.SRGBColorSpace !== undefined) t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 4;
    });
    const m = new THREE.MeshStandardMaterial({
      map: tex, transparent: true, alphaTest: .5, roughness: .85, metalness: 0,
      emissive: 0xffc46b, emissiveMap: tex, emissiveIntensity: 0, side: THREE.DoubleSide,
    });
    _facadeMat[url] = m;
    return m;
  }
  const _photoBld = [];
  function applyPhotoFacade(b, g) {
    if (!b.img || b.kind === 'open') return;
    const pw = b.w * (b.photoW || .96), ph = b.h * (b.photoH || .96);
    const geo = new THREE.PlaneGeometry(pw, ph);
    const mats = [];
    for (const side of [1, -1]) {
      const p = new THREE.Mesh(geo, facadePlaneMat(b.img));
      p.position.set(0, ph / 2, side * (b.d / 2 + .12));
      if (side === -1) p.rotation.y = Math.PI;   // از پشت هم درست دیده شود
      g.add(p);
      mats.push(p.material);
    }
    _photoBld.push(mats);
  }
  function _applyPhotoFacadeNight(daylight) {
    const glow = Math.max(0, 1 - daylight * 2.2) * 1.15;
    for (const mats of _photoBld)
      for (const m of mats) m.emissiveIntensity = glow;
  }
  const WIN_GEO = new THREE.BoxGeometry(1.2, 1.4, .1);"""
s = sub1(s, "  const WIN_GEO = new THREE.BoxGeometry(1.2, 1.4, .1);", INSERT_A, "A insert facade utils")

# B) hide procedural window/door/awning block for photo buildings
s = sub1(s,
    "      const winMat = WIN_MAT;\n      // ⚡ پنجره‌ها با InstancedMesh: کل پنجره‌های یک ساختمون فقط ۲ draw call",
    "      const winMat = WIN_MAT;\n      const _photoMode = !!b.img;   // نمای عکس‌دار: پنجره/در/سایبان procedural خاموش\n      if (!_photoMode) {\n      // ⚡ پنجره‌ها با InstancedMesh: کل پنجره‌های یک ساختمون فقط ۲ draw call",
    "B open !_photoMode")

s = sub1(s,
    "        ac.position.set(b.w*.32, b.h*.62, b.d/2+.18); g.add(ac);\n      }\n      // سقف بر اساس نوع\n      if (b.kind === 'gable') {",
    "        ac.position.set(b.w*.32, b.h*.62, b.d/2+.18); g.add(ac);\n      }\n      } // پایان !_photoMode\n      // سقف بر اساس نوع (نمای عکس‌دار سقف عکس خودش را دارد)\n      if (!_photoMode)\n      if (b.kind === 'gable') {",
    "B close !_photoMode + guard roofs")

# C) attach photo planes after colliders
s = sub1(s,
    "      godBldCollider[b.id] = colliders[colliders.length - 1];",
    "      godBldCollider[b.id] = colliders[colliders.length - 1];\n      applyPhotoFacade(b, g);",
    "C applyPhotoFacade call")

# D) night glow hookup
s = sub1(s,
    "    for (const b of lampBulbs) b.material.emissiveIntensity = lampOn;",
    "    for (const b of lampBulbs) b.material.emissiveIntensity = lampOn;\n    _applyPhotoFacadeNight(daylight);   // پنجره‌های عکس‌دار شب می‌درخشند",
    "D night glow")

open(W3, "w", encoding="utf-8", newline="").write(s)

# ---------------- index.html version bump ----------------
s = open(IX, encoding="utf-8", newline="").read()
s = sub1(s, "js/world-data.js?v=54", "js/world-data.js?v=55", "bump world-data v55")
s = sub1(s, "js/world3d.js?v=57", "js/world3d.js?v=58", "bump world3d v58")
open(IX, "w", encoding="utf-8", newline="").write(s)

print("\n" + ("ALL PATCHES OK" if not fail else "FAILURES:\n  " + "\n  ".join(fail)))
sys.exit(1 if fail else 0)
